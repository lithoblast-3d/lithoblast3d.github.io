"""
Punto de arranque de LithoBlast3D.

Cómo ejecutarlo (en la terminal PowerShell de VS Code, con (.venv) activo):
    python ejecutar.py
"""

import os
import sys

# pyvistaqt debe saber que usamos PySide6. Esto debe ir ANTES de cualquier import de la app.
os.environ.setdefault("QT_API", "pyside6")

if getattr(sys, "frozen", False):
    # Programa empaquetado (LithoBlast3D.exe, sin consola): la salida y los errores van a un registro,
    # y un error inesperado se muestra en una ventana en lugar de cerrar el programa en silencio.
    from pathlib import Path

    _carpeta = Path.home() / ".barreno3d"
    _carpeta.mkdir(parents=True, exist_ok=True)
    _registro = open(_carpeta / "registro.txt", "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stdout or _registro
    sys.stderr = sys.stderr or _registro

    def _error_no_controlado(tipo, valor, traza):
        import traceback
        texto = "".join(traceback.format_exception(tipo, valor, traza))
        _registro.write(texto)
        try:
            from PySide6.QtWidgets import QApplication, QMessageBox
            if QApplication.instance():
                QMessageBox.critical(None, "LithoBlast3D", f"Ocurrió un error:\n\n{valor}\n\n"
                                     f"Detalle en {_carpeta / 'registro.txt'}")
        except Exception:  # noqa: BLE001
            pass

    sys.excepthook = _error_no_controlado

from app.main import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
