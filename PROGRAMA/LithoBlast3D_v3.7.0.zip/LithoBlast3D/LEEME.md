# LithoBlast3D — versión 3.7.0

Diseño y análisis de voladuras para **tajo abierto** y **minería subterránea**.

## Ejecutar
Terminal PowerShell de VS Code, en `C:\Proyectos\barreno3d`, con `(.venv)` activo:

    python ejecutar.py

Pruebas del motor de cálculo:

    python -m unittest discover -s tests -v

## Crear el instalador y publicarlo en internet
- `empaquetar\crear_ejecutable.ps1 -Instalador`: crea `LithoBlast3D.exe` (no requiere Python),
  un .zip portátil y el instalador en español (con Inno Setup 7).
- `web\`: página de descarga con el mismo estilo del programa, lista para GitHub Pages.
- `web\app\`: versión para celular (Android/iPhone) con el mismo motor de cálculo (Pyodide):
  malla automática por tipo de arranque, malla de banco sobre DXF, 3D, DXF, análisis.
  `python tools/web/construir_movil.py` actualiza su motor (`nucleo.zip`).
- Paso a paso: `web\PUBLICAR.md`.

## 3.7.0 — Opciones según la labor
- **Chimenea y tajeo**: sección siempre rectangular (sin arco ni cuneta); Forma, Flecha y Cuneta se desactivan.
- **Tajeo con SLOT**: si el tajeo no tiene cara libre se abre un slot (línea vertical de taladros vacíos y
  cargados alternados) y el resto sale en columnas hacia él. Slot central si el tajeo es ancho (≥ 2·B + 1 m),
  slot lateral si es angosto; se mantiene la opción breasting (con cara libre inferior).
- **Tajo abierto** en la lista de labores: lleva a la malla sobre la topografía (DWG/DXF con curvas de nivel).
- **Burden**: se agregan los modelos de Pearse y Langefors (nueve fórmulas comparadas).

## 3.6.2 — Nuevo nombre: LithoBlast3D
- El programa se llama ahora **LithoBlast3D** (antes Barreno 3D): ventana, instalador (LithoBlast3D.exe),
  accesos directos, app del celular y página web.
- Los proyectos `.b3d` ya guardados se abren igual; tu configuración (carpeta `.barreno3d` del usuario) se conserva.
- El instalador nuevo reemplaza al anterior (misma identificación de instalación).
- La página web detecta sola tu usuario y repositorio de GitHub: ya no hay que editar `const REPO`.

## Corrección 3.6.1
- **Chimeneas**: la malla salía con la sección de un frente (arco de baúl). Ahora la chimenea es siempre **rectangular**
  (ancho × largo del techo, sin arco ni cuneta); en el formulario se desactivan Forma, Flecha y Cuneta al elegir chimenea.

## NUEVO en 3.6 — Mallas revisadas, sonido y interfaz renovada

### Mallas revisadas (se auditó cada opción en frentes, chimeneas y tajeos; prueba automática `tests/test_mallas_correctas.py`)
- **Chimeneas**: no hay piso ni techo como en un frente; los taladros del perímetro ahora son **contorno
  (cuadradores)**, con la carga del contorno y saliendo juntos al final (antes salían «arrastres» y «corona»).
  Resultado en 1.5 × 1.5 m: 15–21 taladros cargados y FC ≈ 3–5 kg/m³, en el rango de las chimeneas 5'×5' de Retamas.
- **Corte en V**: ya no se ofrece donde no es práctico (p. ej. 1.5 m de ancho daba 0.32 m de avance); explica qué
  ancho necesita y sugiere un corte paralelo.
- **Corte de Ash**: en secciones pequeñas usa menos cuadros y carga escalonada (menos en los cuadros pegados al
  alivio), para no sobrecargar el centro.
- **Referencia Volcan**: solo se adapta a secciones de área parecida (0.7–1.45 veces); antes, en 3 × 3 m dejaba
  los 50 taladros de 3.8 × 4.0 m y el FC subía a 5 kg/m³.
- Se verificó el orden de salida (arranque → ayudas → hastiales/contorno → corona → arrastres) en todas las opciones.

### Sonido en la simulación del ciclo (🔊 / 🔇)
- Perforadora (jackleg o jumbo), motor diésel del jumbo y del scoop, golpes del atacador, clic de los conectores,
  chispazo y siseo de la mecha, estampido de cada taladro con eco, ventilador y golpe del balde. Sonidos sintetizados
  (ilustrativos). El navegador activa el sonido al primer toque de ▶ o de una fase.

### Interfaz
- Windows: barra de herramientas con iconos y nombres cortos, botones y tarjetas con nuevo acabado, versión en la
  barra de estado y en el título.
- Teléfono: cabecera y barra inferior translúcidas, pestaña activa resaltada, botones con relieve y transiciones.

## NUEVO en 3.5 — Ciclo completo: convencional y mecanizado, amarres y scoop

Todo lo anterior se mantiene.

### Simulación del ciclo (teléfono: pestaña «Simular» · Windows: Malla automática → elegir malla → «🎬 Simular ciclo 3D»)
- **Método de trabajo**: *Mecanizado* (jumbo + scoop) o *Convencional* (jackleg + scoop pequeño si entra; si no
  entra ninguno se indica que la limpieza sería con pala neumática y carros o con winche).
- **Fases**: perforación → carguío → **amarre** → encendido y voladura → ventilación → **limpieza** → resultado.
- **Amarre**: *Carmex + conectores + mecha rápida* (la mecha rápida se tiende en el orden de salida; la llama recorre
  ≈ 35 s/m y cada Carmex arde ≈ 170 s/m: el programa muestra a cuántos segundos sale cada taladro) o
  *Fanel + cordón detonante* (el retardo lo da el número del Fanel). Tiempos de fábrica: se miden en la mina.
- **Trabajador** con EPP (casco con lámpara, lentes, camisa amarilla/azul con cintas reflectivas, guantes, botas) y
  postura calculada: sostiene la jackleg, carga con el atacador, amarra y chispea.
- **Jackleg** con barreno y broca, pata neumática, manguera de aire con lubricador y manguera de agua.
- **Scoop** articulado (balde con dientes, brazos, cabina lateral, 4 llantas) con medidas de ficha: Cat R1300G
  (2.8 m³), Cat R1700 (5.7 m³) y Epiroc ST2G (1.9 m³; alto y largo aproximados, no figuran en la hoja consultada).
  Carga el material roto, sale y descarga; se indican los ciclos reales estimados (esponjamiento 1.5 supuesto).
- En Windows se abre en el navegador con three.js incluido: **funciona sin internet**.

### Inicio
- Teléfono: nueva pantalla de **Inicio** (accesos por labor: frente, chimenea, tajeo, tajo abierto, simular,
  Emulnor, referencias, cálculos) y el ciclo de minado explicado. Ficha **Emulnor** completa: 4 tipos, 88
  presentaciones (incluidas las tubulares) y accesorios.
- Windows: **Pantalla de inicio** al abrir (Ayuda → Pantalla de inicio; se puede desactivar).

### Correcciones
- **Malla sobre la topografía**: el área de voladura se dibujaba plana a la cota media («en el aire» sobre terreno
  inclinado). Ahora el borde se apoya en la superficie (cota del TIN en cada punto) en Windows, en el DXF exportado
  y en el teléfono; la vista 3D del teléfono dibuja además la superficie del terreno.
- Tajeo: aviso cuando el factor de carga supera mucho la referencia (cartuchos grandes en taladros de tajeo).

## NUEVO en 3.4 — Labores, equipos, productos y referencias de minas

Todo lo anterior se mantiene; esto se agrega encima.

### Labor y equipo (Malla automática, Ctrl+M · en el teléfono: Frente → «Labor y equipo»)
- **Labor**: frente de avance, **chimenea** (malla en el techo, taladros hacia arriba) o **tajeo** de corte y
  relleno (breasting: filas horizontales con el burden y espaciamiento que indiques).
- **Equipo de perforación** elegido por las medidas de la sección y las del catálogo: el jumbo solo si su sección
  mínima de trabajo cabe (y con 2 brazos solo si el área lo justifica); si no, **jackleg**. Chimenea → **stoper**.
  Puedes forzar un equipo; el programa avisa si no cumple. Ej.: 1.5 × 1.5 m → jackleg, nunca jumbo.
- Catálogo editable: *Simulación 3D → Equipos de perforación…* (en el teléfono: Más → Equipos de perforación).
  Las medidas vienen de las fichas de los fabricantes; donde el fabricante no publica la sección mínima se usa
  el ancho/alto del equipo + holguras (0.49 m por lado, 0.86 m arriba). No son límites universales: cámbialos.
- **Iniciación**: Carmex + mecha rápida o detonadores no eléctricos + cordón; cantidades por malla.

### Productos (ficha técnica FAMESA, Emulnor 500/1000/3000/5000)
- *Explosivos → + Desde ficha técnica*: densidad, VOD, RWS y **kg por cartucho** de cada presentación.
  Con kg/cartucho la carga de cada taladro sale de la ficha, no de la densidad nominal.

### Referencias de minas (Simulación 3D → Referencias de minas · Más → Referencias)
- **Volcan SC-CR 2022**: 13 mallas de avance por RMR, digitalizadas (taladros, explosivo y retardos).
  La malla automática ofrece «Referencia Volcan» adaptada a tu sección y compara cada opción con las 2 más parecidas.
- **Retamas**: chimeneas 5'×5' y 8'×5' por RMR; tajeos de corte y relleno (tesis).
- Son **ejemplos de minas concretas**, con su roca, explosivos y equipos: sirven para comparar, no son reglas.

### Simular (teléfono: pestaña «Simular»)
- Usa la malla elegida en Frente: labor a escala, equipo con las medidas del catálogo (jumbo con sus brazos,
  jackleg con operador y juego de barrenos, stoper sobre plataforma en la chimenea), cada taladro perforado
  **dentro de la roca** (◐ roca transparente/sólida), carguío (columna de explosivo por producto, cebo y taco),
  voladura por retardos, humos, material desplazado y nuevo frente con los culos de taladro.
- Los fragmentos, su recorrido y la pila son **ilustrativos** (no predicen la fragmentación real).
- En el detalle de cada malla: cotas, **esquema de carguío por tipo de taladro**, accesorios y comparación.
- En Windows, la perforación manual del simulador muestra ahora al operador a escala.
  (El simulador de Windows no hace chimeneas verticales; para eso usa «Simular» del teléfono.)

## NUEVO en 3.1 — DWG de curvas de nivel → malla → DWG
1. **Instala ODA File Converter** (gratis, opendesign.com → Guest files). Es el programa que
   convierte DWG ↔ DXF; LithoBlast3D lo usa en segundo plano. Si no lo encuentra solo:
   Topografía y CAD → Configurar conversor DWG → elige `ODAFileConverter.exe`.
2. **Topografía y CAD → Importar DXF / DWG** (Ctrl+Shift+I): abre el DWG del profesor y
   marca la capa de curvas de nivel en «Usar para TIN». Se crea la superficie del terreno.
3. **Topografía y CAD → Diseñar malla sobre la topografía** (Ctrl+T):
   - Área: rectángulo (centro Este/Norte, largo, ancho, azimut) o cualquier polilínea
     cerrada del DWG (por ejemplo el límite del disparo dibujado en AutoCAD).
   - Burden, espaciamiento, tresbolillo o cuadrada, margen al borde.
   - Azimut de salida: se detecta solo buscando la cara del banco junto al área
     (botón «Detectar salida por la pendiente»); la 1.ª fila queda junto a la cara.
   - Fondo: hasta una cota de piso (cada taladro con su longitud real según su collar)
     o altura de banco constante; sobreperforación, inclinación, taco, Ø y explosivo.
   - Secuencia fila por fila o en V, con ms entre taladros y entre filas.
   - Vista previa en planta con las curvas de nivel, tabla de taladros (cota, altura,
     longitud, kg, retardo) y totales. «Crear en el proyecto» la coloca (Ctrl+Z deshace).
4. **Topografía y CAD → Exportar malla a DWG / DXF** (Ctrl+Shift+E): guarda en DWG
   (versión 2000 a 2018) o DXF. Capas: COLLARES, ALIVIOS, TALADROS (eje 3D), CARGA,
   PIE, TXT_ID, TXT_RETARDO, TXT_COTA, TXT_LONGITUD, SECCION_AREA, LEYENDA y las capas
   originales de la topografía. Coordenadas reales (UTM) y cotas: se superpone exacto
   sobre el plano del profesor. Para frentes subterráneos hay una vista 2D del frente.
   Sin ODA File Converter guarda en DXF: AutoCAD lo abre y lo puedes «Guardar como» DWG.

## NUEVO en 3.0
### Malla automática: eliges el tipo de arranque (Ctrl+M)
Escribe la sección (ancho, alto, forma, flecha), la roca (clase o tu RMR/RQD), los
diámetros (perforación y alivio), el número de alivios, la longitud de barra, el
explosivo y la cuneta. Pulsa **Generar opciones** y aparecen tarjetas con cada malla
completa, cada una con el nombre de su tipo de arranque:
- Tres arranques del estándar de 6 pies adaptados a tu sección (Cruz de 5 alivios,
  Triángulo de 3, Rectángulo de 6, según lo que exista en la biblioteca).
- Corte cilíndrico de 4 secciones (Holmberg).
- Corte de 4 cuadrantes con el criterio de Ash.
- Corte quemado (alivios del mismo diámetro que los cargados).
- Corte en V (cuña), con taladros inclinados y avance limitado por el ancho.
Cada tarjeta muestra taladros, cargados, alivios, kg, factor de carga, metros
perforados, avance y avisos. **Elegir esta malla** la abre en el editor (vista frontal,
planta, lateral, 3D y tabla editable: posición, tipo, retardo, cartuchos, kg, función).
**Usar en el proyecto** la coloca en el frente (un solo paso, Ctrl+Z la deshace).
Si el proyecto no tiene explosivos, se usan valores genéricos que puedes cambiar luego.

### Menú Análisis (Centro de análisis: F9)
- **Fragmentación**: Kuz-Ram (Cunningham 1987) con factor de roca A, índice de
  uniformidad n, curva Swebrec (b de KCO) y Rosin-Rammler; % bajo la parrilla;
  comparación de escenarios; ajuste a la granulometría medida (Swebrec y Rosin-Rammler
  con R²) y cálculo de A calibrado.
- **Zona de daño (Kirsch)**: mapa de esfuerzos sobre la malla del proyecto,
  Pb = ρ·VOD²/8 con desacople (dc/dh)^2.6, radios de trituración y fracturamiento,
  % de la sección cubierta.
- **Comparador de burden**: Andersen, Ash, Konya 1972 y 1983, López Jimeno, Rustan y
  Olofsson; aplica la mediana al diseño.
- **Macizo rocoso**: RMR89, Q de Barton, GSI, Em (Bieniawski, Serafim-Pereira,
  Nicholson-Bieniawski, Hoek-Diederichs), Hoek-Brown (mb, s, a), carga de Unal,
  longitud de pernos y luz sin soporte.
- **Cimbra metálica**: arco con patas rectas por el método de rigidez, carga de Unal,
  deformada, diagramas N y M, verificación σ = N/A + M/S y comparación de perfiles W.
- **Respuesta dinámica**: Newmark-β (aceleración promedio) para 1 GDL y espectro
  Sd/Sv/Sa desde un registro CSV (t [s], a [g]) o un registro de ejemplo.
- **Costos del ciclo**: costo horario de equipos (amortización, interés y seguros,
  reparaciones, neumáticos, energía) y costo de cada tarea; totales por disparo, metro,
  m³ y tonelada; plantillas guardables en JSON y exportación CSV.
Los valores iniciales salen del proyecto abierto; todos son editables.

### Interfaz
Tema oscuro renovado: tarjetas, botón principal en turquesa, pestañas y tablas limpias,
indicadores grandes con los resultados clave y gráficos con el mismo estilo.

## Malla teórica por fórmulas
**Editar → Malla automática teórica** (Ctrl+Alt+M). Escribe pocos datos y el programa calcula todo:
- Frente subterráneo (arranque de taladros paralelos, según Yilmaz 2023,
  Scientific Reports 13:2449, que recoge Holmberg, Olofsson y Persson): ancho, alto,
  altura del arco, longitud de perforación, Ø de perforación, Ø del alivio (rimado),
  explosivo. Alivio central; cuadros del arranque alternados a 45° (B1, Bn = 0.7·W,
  Wn = 1.7·W); ayudas en columnas y filas; hastiales, corona y arrastres según la Tabla 2
  (burden B = 30·qb/dh, carga de fondo + columna).
  Explosivos: registra RWS (ANFO = 1) y AWS (Dynamex M = 1) de la ficha técnica.
- Banco de tajo abierto: largo y ancho del área, altura de banco, Ø de perforación,
  densidad de roca, explosivo y MODELO DE BURDEN:
  Konya; Ash (Tabla I de Kb); Ash modificado (densidades y VOD de referencia);
  Pearse (RQD, JSF, resistencia a la tracción dinámica, presión de detonación);
  Langefors (c, f por inclinación, S/B, errores de perforación).
  Para Ash, Pearse y Langefors: S = KS·B, T = KT·B, J = KJ·B (presentación de
  MSc. E. Noriega, semana 11 de PyV). Correcciones respecto de las diapositivas:
  Kb1 de Ash modificado es adimensional; Langefors usa c̄ = c + 0.05 (1.4–15 m).
- Frente: forma de sección "Baúl (arco)" o "Esquinas redondeadas" (radio). Ayudas en
  cuadrícula alineada con el arranque (columnas a los lados, filas arriba y abajo),
  arranque a media altura, carga del arranque según la carga necesaria de cada cuadro
  (Ec. 4 / Holmberg) y aviso con el alivio necesario para la perforación indicada.
  Al crear un frente se quitan superficie y bancos de tajo (Ctrl+Z los recupera).
- Frente: opción "Cartuchos atacados" (desmarcada = carga de fondo con el diámetro real
  del cartucho). Cobertura: ningún punto queda a más de 0.75·B de un taladro cargado.
Muestra la malla, la ficha de resultados (burden, espaciamiento, taco, número de taladros)
y los totales (kg, factor de carga, factor de potencia) antes de crearla.
Fórmulas y estado de verificación: `app/calc/diseno_automatico.py`.
Diseño preliminar: verifícalo en campo y ajústalo con los resultados reales.

## Cómo trabajar con datos reales
1. **Archivo → Nuevo**: nombre, escenario (tajo / subterráneo) y parámetros.
2. **Editar → Explosivos**: registra tus explosivos con la densidad de la ficha técnica.
3. **Editar → Diseñar malla** (Ctrl+M): genera toda la malla con vista previa
   (tajo: filas, burden, espaciamiento, tresbolillo; subterráneo: sección, alivios,
   arranque, ayudas, contorno). También puedes agregar pozos con **+ Agregar pozo** y edita la tabla (doble clic en la celda),
   o impórtalos con **Importar CSV** (ver `plantilla_pozos.csv`).
4. **Archivo → Guardar** crea un archivo `.b3d` con todo el proyecto.

## Diseño según el tipo de roca
En **Malla automática**, panel "Tipo de roca": RMR, RQD, GSI (0 = RMR − 5) y densidad.
- Clase RMR (Bieniawski 1989) · GSI ≈ RMR − 5 (Hoek et al. 1995) · Jv = (115 − RQD)/3.3.
- Consumo específico de Ashby: CE = 0.56·ρ·tan((GSI+15)/2)/∛Jv.
- Constante de roca: c = 0.8784·CE + 0.052 (BISTUA 2021).
- Frente: c entra en el arranque (Ec. 4) y el burden se corrige con √(0.45/c̄) (Langefors).
- Banco: Ash (tipo de roca), Pearse (RQD, JSF), Langefors (c); Konya y Ash modificado
  solo usan la densidad.
- Comparación con EXSA: N° taladros = 4√S/dt + k·S (dura 0.5/2; semidura 0.6/1.5;
  blanda 0.7/1). Aviso si el diseño difiere más de 35 %.
Ficha técnica: `app/calc/roca.py`.

## Simulación de la voladura
**Análisis → Simular voladura** (Ctrl+B).
1. "Asignar secuencia automática" con los tiempos NOMINALES de tus detonadores:
   - Frente: arranque cuadro por cuadro (1.er cuadro taladro a taladro) → ayudas (en cada
     retardo salen las que tienen más cerca una abertura ya creada) → hastiales → corona →
     arrastres (esquinas al final). Tiempo = número × intervalo.
   - Banco: fila por fila desde la cara libre, en línea o en V (retardo entre taladros y
     entre filas).
2. Reproducir / pausar / barra de tiempo / velocidad. Cada taladro detona en su tiempo y se
   sombrea la roca que rompe hasta la abertura más cercana (burden efectivo).
3. Tabla de carga por retardo (kg) y aviso de carga máxima por retardo.
4. Se marcan en amarillo los taladros que salen sin abertura cercana (burden efectivo
   > 1.5 × distancia a su vecino): señal para revisar la secuencia.
Los números de retardo y tiempos también se ven y se editan en la tabla de perforaciones.
Ficha técnica: `app/core/secuencia.py`.

## Mapa de vibración (colores)
**Análisis → Mapa de vibración** (Ctrl+G). Modelo Holmberg–Persson (1979) en un plano
horizontal (tajo) o paralelo al frente (subterráneo). Colores por umbrales de PPV
(por defecto Bauer y Calder, 1970): azul < 254, verde 254–635, amarillo 635–2540,
rojo > 2540 mm/s. Constantes K, α, β iniciales SIN CALIBRAR (700, 0.7, 1.5).
Ficha técnica: `app/calc/energia.py`.

## Formato CSV
Separador `;` o `,`. Decimales con coma o punto.
Columnas obligatorias: `id, este_x, norte_y, cota_z, longitud, diametro_mm`.
Opcionales: `azimut, inclinacion, explosivo, taco, funcion`.
El nombre del explosivo debe coincidir con uno registrado en Editar → Explosivos.

## Cálculos
Ver la ficha técnica en `app/calc/carga.py` (fórmulas, fuentes, supuestos y límites).
Carga lineal, carga por pozo, volumen, tonelaje, factor de carga y factor de potencia.
Verifica los resultados con mediciones de campo antes de usarlos.

## Adaptar una malla del estándar
**Biblioteca de mallas → Adaptar una malla del estándar…**
Escribe ancho y alto, tipo de roca (Buena/Regular/Mala o RMR), Ø de perforación y de
alivios, longitud de perforación y si quieres cuneta (lado, ancho, profundidad).
- Tipos de arranque medidos en los 54 planos del PDF:
  · Cruz de 5 alivios (roca buena y regular; alivios a ≈0.125 m del central),
  · Triángulo de 3 alivios (roca mala),
  · Rectángulo de 6 alivios (planos con ANFO, roca regular).
  Puedes dejar «Automático» o elegir uno.
- Se toma el plano real de la misma roca con la sección más parecida; su arranque se copia
  con sus medidas reales (sin escalar); hastiales, corona y arrastres se redistribuyen con
  el MISMO espaciamiento del plano; las ayudas se trasladan entre arranque y perímetro y
  se completan hasta tener la misma cobertura que el plano. Retardos, cartuchos y explosivo
  se heredan del taladro de origen.
- Informe: plano de referencia, conteos, espaciamientos, cobertura, explosivo por m² y una
  comprobación teórica del 1.er cuadro (1.7·D0, solo referencia).
- Se edita a mano (arrastrar, doble clic, Supr, tabla) y luego «Usar en el proyecto».
- En la Biblioteca, «Adaptar a otra sección / cuneta…» abre lo mismo con ese plano como base.
La malla teórica anterior sigue en **Malla automática teórica** (Ctrl+Alt+M), también
para bancos de tajo abierto.

## NUEVO en 2.0 — Biblioteca de mallas del estándar
**Biblioteca de mallas → Biblioteca de mallas del estándar** (Ctrl+L).
Fuente: MIN-SOS-ESO-001 v02 «Voladura en labores de avance de 6 pies» (Cía. Minera
Poderosa), 54 planos de las secciones 1.20×1.80, 2.50×2.50, 2.50×2.70, 2.70×2.70,
3.00×3.00 y 3.50×3.50 (roca buena, regular y mala; variantes de explosivo e iniciación).
- Las TABLAS de cada plano (cuenta de detonadores, explosivos, accesorios, parámetros) se
  tomaron del texto del PDF tal cual.
- El DIBUJO de cada malla es una imagen dentro del PDF: se DIGITALIZÓ (círculos de color =
  taladros cargados; blancos = alivios; rótulo «detonador,cartuchos[,ANFO kg]» por OCR,
  corregido con las tablas del mismo plano). Escala = ancho y alto de la sección.
- Verificación automática contra las tablas del plano: 53 de 54 planos coinciden en
  número de taladros, cuenta por detonador, cartuchos y perforaciones por explosivo.
  La pág. 55 (3.50×3.50, roca buena) tiene una diferencia DEL PROPIO DOCUMENTO: el dibujo
  muestra 29 taladros naranjas y 27 amarillos; la tabla dice 27 y 28.
- 141 de 2 228 rótulos quedaron marcados «revisar» (borde magenta/amarillo): su valor se
  dedujo de las tablas y de la simetría, compáralos con el plano original de fondo.
- Vistas: Frontal (editable, con el plano original de fondo), Planta, Lateral, 3D,
  Tablas del plano y Verificación. Edición: arrastrar = mover; doble clic = agregar
  (Shift = alivio); Supr = eliminar; doble clic en la tabla = editar valores.
  «Guardar edición» guarda en tu carpeta de usuario (`~/.barreno3d`), sin tocar el estándar.
- «Usar en el proyecto»: pide el Ø de perforación y de alivios (el estándar NO los indica),
  ubicación y azimut. La carga de cada taladro = cartuchos × kg/cartucho de la tabla del
  plano (+ ANFO del rótulo si lo hay). La densidad del cartucho se DERIVA de esa tabla y de
  la medida nominal (1"x8") y queda marcada como referencial.
- Todo queda marcado «Del estándar (digitalizado)». Puedes marcar un plano como
  «Verificado» con una nota.
Herramientas de digitalización usadas: `tools/digitalizacion/`.

## NUEVO en 2.0 — Topografía y CAD
**Topografía y CAD → Importar DXF / DWG** (Ctrl+Shift+I).
- DXF ASCII (R12–2018): LINE, LWPOLYLINE (elevación y arcos), POLYLINE 2D/3D, malla
  policara, 3DFACE, POINT, TEXT/MTEXT, CIRCLE, ARC, SPLINE (por sus puntos), INSERT
  (bloques con escala y rotación). Capas con su color. Unidades por $INSUNITS (o elígelas).
  Se conservan coordenadas y escala (convertidas a metros).
- DXF binario: instala `pip install ezdxf`.
- DWG: formato cerrado. Instala el programa gratuito **ODA File Converter**
  (opendesign.com → Guest files). LithoBlast3D lo usa para convertir el DWG a DXF y luego
  lo lee. Si no se detecta: Topografía y CAD → Configurar conversor DWG. Alternativa: en
  AutoCAD/Civil 3D «Guardar como DXF». Las superficies propias de Civil 3D deben
  exportarse antes como caras 3D o polilíneas.
- No se importan: HATCH, DIMENSION, sólidos ACIS (se informan en el resumen).
- TIN: Delaunay de curvas y puntos (lado máximo y densificación opcionales).
- Perfil topográfico (usa la última medición), pendientes coloreadas y clasificación
  plataforma / intermedia / talud según TUS umbrales (no es un diseño de bancos).
- Consultar coordenadas (Ctrl+K) y Medir distancia (Ctrl+Shift+D) con clics en la vista 3D.

## NUEVO en 2.0 — Simulador 3D de Perforación Minera
**Simulación 3D → Simulación completa** (Ctrl+Shift+B) o cada etapa por separado
(Simulador de jumbo, Perforación, Carguío, Voladura, Fragmentación, Comparación).
Usa la malla del proyecto (automática o de la biblioteca) en un frente subterráneo.
13 etapas del ciclo de minado: labor → malla → ingreso del equipo → perforación → retiro →
carguío (ilustrativo) → secuencia de salida → detonación → fragmentación → ventilación →
limpieza con scoop → desatado → sostenimiento (shotcrete y pernos, patrón ilustrativo).
Estilo «Presentación (vista en corte)»: piso claro, pared con concreto lanzado y placas de
pernos, sin techo ni pared del lado de la cámara, material volado resaltado en color
(elegible) y título de cada etapa. También está el estilo «Realista (galería cerrada)».
Controles: iniciar, pausar, continuar, reiniciar, solo una etapa, en cadena, cámara lenta,
velocidad 0.1–8×. Cámaras: superior, frontal, lateral, isométrica, libre, operador y
cinematográfica. Calidad baja/media/alta, cuadrícula, rótulos, polvo, sonido, medición,
selección de taladros con sus datos y comparación antes/después.
- Equipo GENÉRICO (parámetros editables con «⚙ Parámetros del equipo»): se comprueba que
  quepa en la sección, el alcance y los giros de los brazos y que la viga no choque con el
  contorno. Si no cabe (p. ej. 1.20×1.80) se simula una perforadora manual con barra de avance.
- Bloques: celdas de Voronoi del volumen a volar + física simplificada (gravedad,
  choques, rozamiento, reposo). Sonidos sintetizados (no grabaciones).
- ⚠ Lo que viene del proyecto: sección, taladros, cargas, retardos/orden. El resto
  (equipo, polvo, destello, vibración de cámara, tamaño y trayectoria de bloques) es
  ILUSTRATIVO: no es una predicción de fragmentación, proyección ni vibraciones.
- El carguío es una vista educativa en corte (vacíos → cargados); no describe
  procedimientos de manipulación de explosivos.

## Reportes
**Reportes → Reporte del proyecto (HTML)** (Ctrl+R): resumen, explosivos, pozos, contornos,
topografía y avisos. Se abre en el navegador (Imprimir → PDF).

## Estructura
    ejecutar.py           Arranque
    app/core/             Datos, edición (deshacer/rehacer), archivos, resultados, reporte
    app/calc/             Motor de cálculo (sin interfaz)
    app/biblioteca/       Biblioteca del estándar (datos digitalizados y verificación)
    app/datos/            Datos de la biblioteca e imágenes de los planos
    app/cad/              DXF, DWG (ODA), TIN, perfiles, pendientes
    app/sim3d/            Simulador 3D: ciclo, cinemática, fragmentos, física, audio, ventana
    app/viewer/           Visor 3D
    app/ui/               Ventana, paneles, diálogos, tema
    tests/                Pruebas (cálculo, biblioteca, CAD, simulador)
    tools/                Digitalización del PDF y prueba de interfaz sin pantalla
