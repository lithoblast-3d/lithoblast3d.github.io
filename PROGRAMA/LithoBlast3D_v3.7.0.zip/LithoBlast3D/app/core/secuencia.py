"""
Secuencia de salida y simulación de la voladura.

FICHA TÉCNICA
=============
Qué hace
    1. Asigna una secuencia de salida automática (número de retardo y tiempo nominal).
    2. Reproduce la voladura en el tiempo: qué taladros ya detonaron en el instante t.
    3. Revisa la secuencia con indicadores geométricos y de carga.

Orden de salida (criterio habitual en frentes y bancos; se puede cambiar)
    Frente: alivios (sin carga) → arranque, cuadro por cuadro (1.er cuadro taladro a
    taladro; los siguientes por pares opuestos) → ayudas de adentro hacia afuera →
    hastiales → corona → arrastres (esquinas al final).
    Banco: fila por fila desde la cara libre; dentro de la fila, desde un extremo (en
    línea) o desde el centro hacia los lados (en V).

Tiempos
    Frente: tiempo = número de retardo × intervalo. Banco: tiempo = fila × retardo entre
    filas + posición × retardo entre taladros. Los intervalos los escribe el usuario: deben
    ser los tiempos NOMINALES del fabricante de los detonadores que se usen.

Indicadores (no son modelos de fragmentación ni de daño)
    - Burden efectivo al salir: distancia del taladro a la abertura más cercana existente en
      ese instante (alivios, taladros que ya salieron y, en banco, la cara libre).
    - Taladro "sin cara libre cercana": su burden efectivo es mayor que 1.5 veces la
      distancia a su vecino más cercano (o la separación típica de la malla, si es mayor).
      Es una señal para revisar la secuencia.
    - Carga por retardo (kg que detonan en el mismo tiempo nominal): dato de entrada para
      cualquier control de vibraciones.
"""

import math
from dataclasses import dataclass, field

from app.core.modelo import Perforacion, Proyecto
from app.core.resultados import carga_de_pozo

ORDEN_PERIFERIA = ["Hastial", "Contorno", "Corona", "Arrastre"]
FACTOR_SIN_CARA_LIBRE = 1.5


# ----------------------------------------------------------------- coordenadas 2D
def coordenadas_2d(proyecto: Proyecto) -> tuple[dict[str, tuple[float, float]], str]:
    """Coordenadas para dibujar: frente → (s, z) en la cara; banco → (x, y) en planta."""
    pozos = proyecto.perforaciones()
    if not pozos:
        return {}, ""
    if proyecto.diseno.escenario == "subterraneo":
        a = math.radians(sum(p.azimut for p in pozos) / len(pozos))
        x0 = sum(p.x for p in pozos) / len(pozos)
        y0 = sum(p.y for p in pozos) / len(pozos)
        return ({p.id: ((p.x - x0) * math.cos(a) - (p.y - y0) * math.sin(a), p.z) for p in pozos},
                "frente")
    return {p.id: (p.x, p.y) for p in pozos}, "planta"


def contorno_2d(proyecto: Proyecto, vertices) -> list[tuple[float, float]]:
    pozos = proyecto.perforaciones()
    if not pozos:
        return []
    a = math.radians(sum(p.azimut for p in pozos) / len(pozos))
    x0 = sum(p.x for p in pozos) / len(pozos)
    y0 = sum(p.y for p in pozos) / len(pozos)
    return [((x - x0) * math.cos(a) - (y - y0) * math.sin(a), z) for x, y, z in vertices]


def _agrupar(valores: list[tuple[str, float]], tolerancia: float) -> list[list[str]]:
    """Agrupa ids cuyos valores difieren menos que 'tolerancia' (valores ordenados)."""
    grupos: list[list[str]] = []
    ultimo = None
    for ident, v in sorted(valores, key=lambda t: t[1]):
        if ultimo is None or v - ultimo > tolerancia:
            grupos.append([])
        grupos[-1].append(ident)
        ultimo = v
    return grupos


def _vecino_mas_cercano(xy: dict[str, tuple[float, float]]) -> dict[str, float]:
    salida = {}
    for i, p in xy.items():
        salida[i] = min((math.dist(p, q) for j, q in xy.items() if j != i), default=0.0)
    return salida


# ----------------------------------------------------------------- frente
def secuencia_frente(proyecto: Proyecto, intervalo_ms: float) -> dict[str, tuple[int, float | None]]:
    xy, _ = coordenadas_2d(proyecto)
    pozos = proyecto.perforaciones()
    alivios = [p for p in pozos if p.explosivo_id is None or p.funcion == "Alivio"]
    cargados = [p for p in pozos if p not in alivios]
    if alivios:
        cx = sum(xy[p.id][0] for p in alivios) / len(alivios)
        cz = sum(xy[p.id][1] for p in alivios) / len(alivios)
    else:
        cx = sum(xy[p.id][0] for p in cargados) / max(len(cargados), 1)
        cz = sum(xy[p.id][1] for p in cargados) / max(len(cargados), 1)

    def dist(p):
        return math.hypot(xy[p.id][0] - cx, xy[p.id][1] - cz)

    def angulo(p):
        return math.atan2(xy[p.id][1] - cz, xy[p.id][0] - cx)

    vecino = _vecino_mas_cercano({p.id: xy[p.id] for p in cargados}) if len(cargados) > 1 else {}
    paso = sorted(vecino.values())[len(vecino) // 2] if vecino else 0.5  # separación típica
    resultado: dict[str, tuple[int, float | None]] = {p.id: (0, None) for p in alivios}
    numero = 0

    # Arranque: cuadros por distancia al alivio
    arranque = [p for p in cargados if p.funcion == "Arranque"]
    cuadros = [[proyecto.objeto(i) for i in g]
               for g in _agrupar([(p.id, dist(p)) for p in arranque], 0.02)]
    for k, cuadro in enumerate(cuadros):
        cuadro.sort(key=angulo)
        if k == 0:
            # 1.er cuadro: cada taladro en su propio retardo, alternando lados opuestos
            orden = [cuadro[0], cuadro[2], cuadro[1], cuadro[3]] if len(cuadro) == 4 else cuadro
            for p in orden:
                numero += 1
                resultado[p.id] = (numero, None)
        else:
            mitad = len(cuadro) // 2
            pares = [[cuadro[i], cuadro[i + mitad]] for i in range(mitad)] if len(cuadro) % 2 == 0 \
                else [[p] for p in cuadro]
            for par in pares:
                numero += 1
                for p in par:
                    resultado[p.id] = (numero, None)

    # Ayudas: anillos de adentro hacia afuera (bandas de una separación típica)
    ayudas = [p for p in cargados if p.funcion not in ["Arranque", *ORDEN_PERIFERIA]]
    # Cada retardo: las ayudas que tienen más cerca una abertura ya creada (alivios y
    # taladros que ya salieron). Así cada grupo rompe hacia lo que ya se abrió.
    abiertos = [xy[p.id] for p in alivios] + [xy[p.id] for p in arranque]
    pendientes = list(ayudas)
    while pendientes:
        burden_ef = {p.id: min(math.dist(xy[p.id], a) for a in abiertos) for p in pendientes}
        minimo = min(burden_ef.values())
        grupo = [p for p in pendientes if burden_ef[p.id] <= minimo + 0.25 * paso]
        numero += 1
        for p in grupo:
            resultado[p.id] = (numero, None)
            abiertos.append(xy[p.id])
        pendientes = [p for p in pendientes if p not in grupo]

    # Periferia
    for funcion in ["Hastial", "Contorno", "Corona"]:
        grupo = [p for p in cargados if p.funcion == funcion]
        if grupo:
            numero += 1
            for p in grupo:
                resultado[p.id] = (numero, None)
    arrastres = [p for p in cargados if p.funcion == "Arrastre"]
    if arrastres:
        extremos = {min(arrastres, key=lambda p: xy[p.id][0]).id,
                    max(arrastres, key=lambda p: xy[p.id][0]).id}
        numero += 1
        for p in arrastres:
            if p.id not in extremos:
                resultado[p.id] = (numero, None)
        numero += 1
        for i in extremos:
            resultado[i] = (numero, None)

    return {i: (n, (n * intervalo_ms if n > 0 else None)) for i, (n, _t) in resultado.items()}


# ----------------------------------------------------------------- banco
def secuencia_banco(proyecto: Proyecto, entre_taladros_ms: float, entre_filas_ms: float,
                    en_v: bool = False, invertir_cara: bool = False) -> dict[str, tuple[int, float | None]]:
    pozos = [p for p in proyecto.perforaciones() if p.explosivo_id is not None]
    if not pozos:
        return {}
    xy = {p.id: (p.x, p.y) for p in pozos}
    u, v = _ejes_malla(list(xy.values()))
    cx = sum(x for x, _ in xy.values()) / len(xy)
    cy = sum(y for _, y in xy.values()) / len(xy)

    def a_lo_largo(i):
        return (xy[i][0] - cx) * u[0] + (xy[i][1] - cy) * u[1]

    def hacia_atras(i):
        valor = (xy[i][0] - cx) * v[0] + (xy[i][1] - cy) * v[1]
        return -valor if invertir_cara else valor

    vecino = _vecino_mas_cercano(xy)
    paso = sorted(vecino.values())[len(vecino) // 2] if len(vecino) > 1 else 1.0
    filas = _agrupar([(i, hacia_atras(i)) for i in xy], paso * 0.4)
    tiempos = {}
    for f, fila in enumerate(filas):
        if en_v:
            for i in fila:
                tiempos[i] = f * entre_filas_ms + round(abs(a_lo_largo(i)) / paso) * entre_taladros_ms
        else:
            for k, i in enumerate(sorted(fila, key=a_lo_largo)):
                tiempos[i] = f * entre_filas_ms + k * entre_taladros_ms
    distintos = sorted(set(round(t, 3) for t in tiempos.values()))
    numero = {t: k + 1 for k, t in enumerate(distintos)}
    salida = {i: (numero[round(t, 3)], t) for i, t in tiempos.items()}
    for p in proyecto.perforaciones():
        salida.setdefault(p.id, (0, None))
    return salida


def _ejes_malla(puntos) -> tuple[tuple[float, float], tuple[float, float]]:
    """Dirección de las filas (eje principal de los puntos) y su perpendicular."""
    n = len(puntos)
    cx = sum(x for x, _ in puntos) / n
    cy = sum(y for _, y in puntos) / n
    sxx = sum((x - cx) ** 2 for x, _ in puntos)
    syy = sum((y - cy) ** 2 for _, y in puntos)
    sxy = sum((x - cx) * (y - cy) for x, y in puntos)
    ang = 0.5 * math.atan2(2 * sxy, sxx - syy)
    u = (math.cos(ang), math.sin(ang))
    return u, (-u[1], u[0])


# ----------------------------------------------------------------- análisis y simulación
@dataclass
class EstadoPozo:
    id: str
    x: float
    y: float
    tiempo: float | None
    retardo: int
    carga_kg: float
    alivio: bool
    burden_efectivo: float | None = None
    sin_cara_libre: bool = False


@dataclass
class Simulacion:
    vista: str  # "frente" | "planta"
    pozos: list[EstadoPozo] = field(default_factory=list)
    contornos: list[list[tuple[float, float]]] = field(default_factory=list)
    retardos: list[tuple[int, float, int, float]] = field(default_factory=list)  # n°, t, taladros, kg
    duracion: float = 0.0
    sin_tiempo: int = 0
    avisos: list[str] = field(default_factory=list)

    def estado(self, t: float) -> list[tuple[EstadoPozo, str]]:
        """Estado de cada taladro en el instante t: 'alivio', 'pendiente', 'detonando', 'detonado'."""
        salida = []
        for p in self.pozos:
            if p.alivio:
                salida.append((p, "alivio"))
            elif p.tiempo is None or t < p.tiempo:
                salida.append((p, "pendiente"))
            elif t < p.tiempo + max(self.duracion * 0.03, 10.0):
                salida.append((p, "detonando"))
            else:
                salida.append((p, "detonado"))
        return salida


def preparar_simulacion(proyecto: Proyecto) -> Simulacion:
    from app.core.modelo import Contorno

    xy, vista = coordenadas_2d(proyecto)
    sim = Simulacion(vista=vista)
    if not xy:
        sim.avisos.append("El proyecto no tiene taladros.")
        return sim
    for p in proyecto.perforaciones():
        cp = carga_de_pozo(proyecto, p)
        alivio = not cp.cargado
        sim.pozos.append(EstadoPozo(p.id, *xy[p.id], p.tiempo_ms if not alivio else None,
                                    p.retardo, cp.carga if cp.cargado else 0.0, alivio))
    if vista == "frente":
        sim.contornos = [contorno_2d(proyecto, o.vertices) for o in proyecto.objetos.values()
                         if isinstance(o, Contorno)]

    cargados = [p for p in sim.pozos if not p.alivio]
    sim.sin_tiempo = sum(1 for p in cargados if p.tiempo is None)
    if sim.sin_tiempo:
        sim.avisos.append(f"{sim.sin_tiempo} taladro(s) cargado(s) sin tiempo de salida: "
                          "asigna la secuencia.")
    con_tiempo = [p for p in cargados if p.tiempo is not None]
    if not con_tiempo:
        return sim
    sim.duracion = max(p.tiempo for p in con_tiempo)

    # Carga por retardo
    por_tiempo: dict[float, list[EstadoPozo]] = {}
    for p in con_tiempo:
        por_tiempo.setdefault(round(p.tiempo, 3), []).append(p)
    for t in sorted(por_tiempo):
        grupo = por_tiempo[t]
        sim.retardos.append((grupo[0].retardo, t, len(grupo), sum(p.carga_kg for p in grupo)))

    # Burden efectivo al salir
    vecino = _vecino_mas_cercano({p.id: (p.x, p.y) for p in sim.pozos})
    aberturas_iniciales = [(p.x, p.y) for p in sim.pozos if p.alivio]
    ids_arranque = {q.id for q in proyecto.perforaciones() if q.funcion == "Arranque"}
    # Separación típica de la malla (mediana de la distancia al vecino más cercano)
    distancias_vecino = sorted(vecino[p.id] for p in con_tiempo)
    separacion_tipica = distancias_vecino[len(distancias_vecino) // 2] if distancias_vecino else 0.0
    cara_libre = None
    if vista == "planta":
        u, v = _ejes_malla([(p.x, p.y) for p in con_tiempo])
        primeros = [p for p in con_tiempo if p.tiempo == min(q.tiempo for q in con_tiempo)]
        # Cara libre: paralela a las filas, a un burden por delante de la fila que sale primero
        proy = [(p.x * v[0] + p.y * v[1]) for p in con_tiempo]
        frente_v = sum(p.x * v[0] + p.y * v[1] for p in primeros) / len(primeros)
        hacia = -1 if frente_v <= sum(proy) / len(proy) else 1
        cara_libre = (v, frente_v + hacia * min(vecino[p.id] for p in primeros))
    for p in con_tiempo:
        abiertos = aberturas_iniciales + [(q.x, q.y) for q in con_tiempo if q.tiempo < p.tiempo - 1e-9]
        distancias = [math.dist((p.x, p.y), a) for a in abiertos]
        if cara_libre is not None:
            v, nivel = cara_libre
            distancias.append(abs(p.x * v[0] + p.y * v[1] - nivel))
        p.burden_efectivo = min(distancias) if distancias else None
        if p.id in ids_arranque:
            continue  # su burden lo fija el método del arranque (Ec. 3–6): sale hacia el cuadro previo
        referencia = max(vecino[p.id], separacion_tipica)
        if p.burden_efectivo is None or p.burden_efectivo > FACTOR_SIN_CARA_LIBRE * referencia:
            p.sin_cara_libre = True
    n_malos = sum(1 for p in con_tiempo if p.sin_cara_libre)
    if n_malos:
        sim.avisos.append(f"{n_malos} taladro(s) salen sin una abertura cercana (burden efectivo "
                          f"> {FACTOR_SIN_CARA_LIBRE:g} × separación de la malla): revisa la secuencia.")
    kg_max = max(r[3] for r in sim.retardos)
    t_max = next(r for r in sim.retardos if r[3] == kg_max)
    sim.avisos.append(f"Carga máxima por retardo: {kg_max:.1f} kg (t = {t_max[1]:.0f} ms, "
                      f"{t_max[2]} taladros).")
    return sim
