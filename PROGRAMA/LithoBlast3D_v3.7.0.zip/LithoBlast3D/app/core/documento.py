"""
Documento abierto: proyecto + selección + historial (deshacer/rehacer) + avisos de cambio.

Toda modificación del proyecto debe pasar por los métodos de esta clase.
Así funcionan el deshacer/rehacer y se actualizan todos los paneles.
"""

import copy
from collections.abc import Callable
from dataclasses import dataclass, replace
from pathlib import Path

from app.core.modelo import ConfigMapa, DisenoVoladura, Explosivo, Perforacion, Proyecto
from app.core.seleccion import GestorSeleccion

CAMPOS_EDITABLES_POZO = {
    "x", "y", "z", "azimut", "inclinacion", "longitud", "diametro_mm",
    "explosivo_id", "taco", "funcion", "retardo", "tiempo_ms",
}


class ErrorEdicion(ValueError):
    """La modificación pedida no es válida; el proyecto no cambia."""


@dataclass
class _Paso:
    descripcion: str
    deshacer: Callable[[], None]
    rehacer: Callable[[], None]


class Documento:
    def __init__(self, proyecto: Proyecto, ruta: str | Path | None = None):
        self.proyecto = proyecto
        self.ruta = Path(ruta) if ruta else None
        self.modificado = False
        self.seleccion = GestorSeleccion()
        self._oyentes: list[Callable[[], None]] = []
        self._deshacer: list[_Paso] = []
        self._rehacer: list[_Paso] = []

    # ------------------------------------------------------------ avisos
    def suscribir_cambios(self, funcion: Callable[[], None]) -> None:
        self._oyentes.append(funcion)

    def _avisar(self) -> None:
        self.modificado = True
        if self.seleccion.actual and self.proyecto.objeto(self.seleccion.actual) is None:
            self.seleccion.seleccionar(None, origen="documento")
        for funcion in list(self._oyentes):
            funcion()

    def marcar_guardado(self, ruta: str | Path) -> None:
        self.ruta = Path(ruta)
        self.modificado = False
        for funcion in list(self._oyentes):
            funcion()

    # ------------------------------------------------------------ historial
    def _registrar(self, descripcion: str, deshacer, rehacer) -> None:
        rehacer()
        self._deshacer.append(_Paso(descripcion, deshacer, rehacer))
        self._rehacer.clear()
        self._avisar()

    def puede_deshacer(self) -> str | None:
        return self._deshacer[-1].descripcion if self._deshacer else None

    def puede_rehacer(self) -> str | None:
        return self._rehacer[-1].descripcion if self._rehacer else None

    def deshacer(self) -> str | None:
        if not self._deshacer:
            return None
        paso = self._deshacer.pop()
        paso.deshacer()
        self._rehacer.append(paso)
        self._avisar()
        return paso.descripcion

    def rehacer(self) -> str | None:
        if not self._rehacer:
            return None
        paso = self._rehacer.pop()
        paso.rehacer()
        self._deshacer.append(paso)
        self._avisar()
        return paso.descripcion

    # ------------------------------------------------------------ pozos
    @staticmethod
    def validar_pozo(pozo: Perforacion) -> None:
        if pozo.longitud <= 0:
            raise ErrorEdicion("La longitud debe ser mayor que 0 m")
        if pozo.diametro_mm <= 0:
            raise ErrorEdicion("El diámetro debe ser mayor que 0 mm")
        if pozo.taco < 0 or pozo.taco > pozo.longitud:
            raise ErrorEdicion("El taco debe estar entre 0 m y la longitud del taladro")
        if not -90 <= pozo.inclinacion <= 90:
            raise ErrorEdicion("La inclinación debe estar entre −90° y 90°")

    def actualizar_pozo(self, pozo_id: str, **cambios) -> None:
        pozo = self.proyecto.objeto(pozo_id)
        if not isinstance(pozo, Perforacion):
            raise ErrorEdicion(f"No existe el taladro {pozo_id}")
        desconocidos = set(cambios) - CAMPOS_EDITABLES_POZO
        if desconocidos:
            raise ErrorEdicion(f"Campos no editables: {', '.join(sorted(desconocidos))}")
        if "explosivo_id" in cambios and cambios["explosivo_id"] is not None \
                and self.proyecto.explosivo(cambios["explosivo_id"]) is None:
            raise ErrorEdicion("Explosivo no registrado")
        antes = {k: getattr(pozo, k) for k in cambios}
        if antes == cambios:
            return
        self.validar_pozo(replace(pozo, **cambios))
        demo_antes = pozo.es_demo

        def aplicar(valores, demo):
            def hacer():
                for k, v in valores.items():
                    setattr(pozo, k, v)
                pozo.es_demo = demo
            return hacer

        self._registrar(f"Editar {pozo_id}", aplicar(antes, demo_antes), aplicar(cambios, False))

    def agregar_pozos(self, pozos: list[Perforacion], descripcion: str = "") -> None:
        for pozo in pozos:
            self.validar_pozo(pozo)
            if pozo.id in self.proyecto.objetos:
                raise ErrorEdicion(f"Ya existe un objeto con id {pozo.id}")
        ids = [p.id for p in pozos]

        def hacer():
            for p in pozos:
                self.proyecto.agregar_objeto(p)

        def deshacer():
            for i in ids:
                self.proyecto.eliminar_objeto(i)

        self._registrar(descripcion or f"Agregar {len(pozos)} taladro(s)", deshacer, hacer)

    def asignar_secuencia(self, valores: dict[str, tuple[int, float | None]],
                          descripcion: str = "Asignar secuencia de salida") -> None:
        """Cambia retardo y tiempo de varios pozos en UN paso deshacible."""
        pozos = {i: self.proyecto.objeto(i) for i in valores}
        pozos = {i: p for i, p in pozos.items() if isinstance(p, Perforacion)}
        antes = {i: (p.retardo, p.tiempo_ms) for i, p in pozos.items()}

        def poner(tabla):
            def hacer():
                for i, (n, t) in tabla.items():
                    if i in pozos:
                        pozos[i].retardo, pozos[i].tiempo_ms = n, t
            return hacer

        self._registrar(descripcion, poner(antes), poner({i: valores[i] for i in pozos}))

    def aplicar_lote(self, nuevos: list, eliminar_ids: list[str] | None = None,
                     nuevo_diseno: DisenoVoladura | None = None, descripcion: str = "") -> None:
        """Elimina, agrega objetos y (opcional) cambia el diseño en UN solo paso deshacible."""
        eliminar_ids = [i for i in (eliminar_ids or []) if i in self.proyecto.objetos]
        quedan = set(self.proyecto.objetos) - set(eliminar_ids)
        for obj in nuevos:
            if isinstance(obj, Perforacion):
                self.validar_pozo(obj)
            if obj.id in quedan:
                raise ErrorEdicion(f"Ya existe un objeto con id {obj.id}")
            quedan.add(obj.id)
        eliminados = [self.proyecto.objetos[i] for i in eliminar_ids]
        diseno_antes = copy.deepcopy(self.proyecto.diseno)

        def hacer():
            for o in eliminados:
                self.proyecto.eliminar_objeto(o.id)
            for o in nuevos:
                self.proyecto.agregar_objeto(o)
            if nuevo_diseno is not None:
                self.proyecto.diseno = copy.deepcopy(nuevo_diseno)

        def deshacer():
            for o in nuevos:
                self.proyecto.eliminar_objeto(o.id)
            for o in eliminados:
                self.proyecto.objetos[o.id] = o
            self.proyecto.diseno = copy.deepcopy(diseno_antes)

        self._registrar(descripcion or "Aplicar cambios", deshacer, hacer)

    def nuevo_pozo(self, referencia_id: str | None = None) -> Perforacion:
        """Crea (sin agregar) un pozo nuevo copiando el de referencia o valores básicos."""
        d = self.proyecto.diseno
        nuevo_id = self.proyecto.nuevo_id_pozo()
        ref = self.proyecto.objeto(referencia_id)
        if not isinstance(ref, Perforacion):
            pozos = self.proyecto.perforaciones()
            ref = pozos[-1] if pozos else None
        if ref is not None:
            desplazamiento = d.espaciamiento if d.escenario == "tajo" else 0.5
            return replace(ref, id=nuevo_id, nombre=nuevo_id, x=ref.x + desplazamiento, es_demo=False)
        if d.escenario == "tajo":
            return Perforacion(id=nuevo_id, nombre=nuevo_id, capa_id="perforaciones",
                               x=0.0, y=0.0, z=0.0, inclinacion=90.0,
                               longitud=d.altura_banco, diametro_mm=165.0, funcion="Producción")
        return Perforacion(id=nuevo_id, nombre=nuevo_id, capa_id="perforaciones",
                           x=0.0, y=0.0, z=1.5, inclinacion=0.0,
                           longitud=d.avance, diametro_mm=45.0, funcion="Ayuda")

    def importar_capas_y_objetos(self, capas: list, objetos: list, descripcion: str = "") -> None:
        """Agrega capas nuevas y objetos en un solo paso deshacible (importación CAD)."""
        existentes = {c.id for c in self.proyecto.capas}
        nuevas = [c for c in capas if c.id not in existentes]
        ids = set(self.proyecto.objetos)
        for o in objetos:
            if o.id in ids:
                raise ErrorEdicion(f"Ya existe un objeto con id {o.id}")
            ids.add(o.id)

        def hacer():
            self.proyecto.capas.extend(copy.copy(c) for c in nuevas)
            for o in objetos:
                self.proyecto.agregar_objeto(o)

        def deshacer():
            for o in objetos:
                self.proyecto.eliminar_objeto(o.id)
            ids_n = {c.id for c in nuevas}
            self.proyecto.capas = [c for c in self.proyecto.capas if c.id not in ids_n]

        self._registrar(descripcion or "Importar CAD", deshacer, hacer)

    def cambiar_atributos(self, objeto_id: str, descripcion: str = "", **cambios) -> None:
        """Cambia atributos de cualquier objeto (p. ej. coloreado de un TIN), deshacible."""
        obj = self.proyecto.objeto(objeto_id)
        if obj is None:
            raise ErrorEdicion(f"No existe {objeto_id}")
        for k in cambios:
            if not hasattr(obj, k):
                raise ErrorEdicion(f"Atributo desconocido: {k}")
        antes = {k: getattr(obj, k) for k in cambios}

        def poner(valores):
            def hacer():
                for k, v in valores.items():
                    setattr(self.proyecto.objetos[objeto_id], k, v)
            return hacer

        self._registrar(descripcion or "Cambiar propiedades", poner(antes), poner(cambios))

    def eliminar_objetos(self, ids: list[str]) -> None:
        objetos = [self.proyecto.objeto(i) for i in ids if self.proyecto.objeto(i) is not None]
        if not objetos:
            return

        def hacer():
            for o in objetos:
                self.proyecto.eliminar_objeto(o.id)

        def deshacer():
            for o in objetos:
                self.proyecto.objetos[o.id] = o

        self._registrar(f"Eliminar {', '.join(o.id for o in objetos)}", deshacer, hacer)

    # ------------------------------------------------------------ diseño y explosivos
    def actualizar_diseno(self, nuevo: DisenoVoladura) -> None:
        anterior = copy.deepcopy(self.proyecto.diseno)
        if anterior == nuevo:
            return

        def poner(valor):
            def hacer():
                self.proyecto.diseno = copy.deepcopy(valor)
            return hacer

        self._registrar("Cambiar parámetros de voladura", poner(anterior), poner(nuevo))

    def actualizar_mapa(self, nuevo: ConfigMapa) -> None:
        anterior = copy.deepcopy(self.proyecto.mapa)
        if anterior == nuevo:
            return

        def poner(valor):
            def hacer():
                self.proyecto.mapa = copy.deepcopy(valor)
            return hacer

        texto = "Mostrar mapa de vibración" if nuevo.activo and not anterior.activo else (
            "Ocultar mapa de vibración" if anterior.activo and not nuevo.activo
            else "Cambiar mapa de vibración")
        self._registrar(texto, poner(anterior), poner(nuevo))

    def reemplazar_explosivos(self, nuevos: list[Explosivo]) -> None:
        for e in nuevos:
            if not e.nombre.strip():
                raise ErrorEdicion("Todos los explosivos necesitan un nombre")
            if e.densidad_gcc <= 0:
                raise ErrorEdicion(f"La densidad de «{e.nombre}» debe ser mayor que 0")
        nombres = [e.nombre.strip().lower() for e in nuevos]
        if len(nombres) != len(set(nombres)):
            raise ErrorEdicion("Hay explosivos con el mismo nombre")

        anteriores = copy.deepcopy(self.proyecto.explosivos)
        ids_nuevos = {e.id for e in nuevos}
        afectados = {p.id: p.explosivo_id for p in self.proyecto.perforaciones()
                     if p.explosivo_id and p.explosivo_id not in ids_nuevos}

        def hacer():
            self.proyecto.explosivos = copy.deepcopy(nuevos)
            for pid in afectados:
                self.proyecto.objetos[pid].explosivo_id = None

        def deshacer():
            self.proyecto.explosivos = copy.deepcopy(anteriores)
            for pid, eid in afectados.items():
                if pid in self.proyecto.objetos:
                    self.proyecto.objetos[pid].explosivo_id = eid

        self._registrar("Editar explosivos", deshacer, hacer)
