"""
Prepara y ejecuta el mapa de vibración sobre el proyecto.

- Tajo (pozos casi verticales): plano HORIZONTAL que corta los pozos.
- Subterráneo (pozos casi horizontales): plano PARALELO AL FRENTE dentro de la roca.
La profundidad del plano se mide desde el collar, a lo largo del pozo.
"""

from dataclasses import dataclass

import numpy as np

from app.calc.energia import ColumnaCarga, ppv_holmberg_persson, zonas
from app.core.modelo import ConfigMapa, Contorno, Perforacion, Proyecto
from app.core.resultados import carga_de_pozo


@dataclass
class ResultadoMapa:
    origen: np.ndarray  # punto del plano (m)
    eje_u: np.ndarray  # vector unitario horizontal del plano
    eje_v: np.ndarray  # vector unitario vertical (o Norte) del plano
    bordes_u: np.ndarray  # nu+1 valores (m)
    bordes_v: np.ndarray  # nv+1 valores (m)
    ppv: np.ndarray  # nv × nu (mm/s), en el centro de cada celda
    zona: np.ndarray  # nv × nu, 0..3
    plano: str  # descripción del plano
    area_celda: float  # m²
    ppv_max: float

    def areas_por_zona(self) -> list[float]:
        return [float((self.zona == z).sum()) * self.area_celda for z in range(4)]

    def esquinas(self) -> np.ndarray:
        """Coordenadas X, Y, Z de las esquinas de las celdas: (nv+1) × (nu+1) × 3."""
        uu, vv = np.meshgrid(self.bordes_u, self.bordes_v)
        return self.origen + uu[..., None] * self.eje_u + vv[..., None] * self.eje_v


def columnas_de_carga(proyecto: Proyecto) -> list[tuple[Perforacion, ColumnaCarga]]:
    columnas = []
    for pozo in proyecto.perforaciones():
        cp = carga_de_pozo(proyecto, pozo)
        if not cp.cargado or not cp.carga_lineal:
            continue
        collar = np.array(pozo.collar())
        d = np.array(pozo.direccion())
        inicio = collar + d * pozo.taco
        fin = collar + d * pozo.longitud
        columnas.append((pozo, ColumnaCarga(tuple(inicio), tuple(fin), cp.carga_lineal,
                                            pozo.diametro_mm / 2000.0)))
    return columnas


def _alcance(pares, cfg: ConfigMapa) -> float:
    """Distancia lateral (m) a la que el pozo más cargado baja del primer umbral."""
    _pozo, col = max(pares, key=lambda par: par[1].carga_lineal)
    a, b = np.array(col.inicio), np.array(col.fin)
    eje = b - a
    medio = (a + b) / 2
    lateral = np.cross(eje, [0, 0, 1.0])
    if np.linalg.norm(lateral) < 1e-9:
        lateral = np.array([1.0, 0, 0])
    lateral /= np.linalg.norm(lateral)
    distancias = np.geomspace(0.1, 300, 120)
    ppv = ppv_holmberg_persson(medio + distancias[:, None] * lateral, [col],
                               k=cfg.k, alfa=cfg.alfa, beta=cfg.beta)
    bajo = np.nonzero(ppv < min(cfg.umbrales))[0]
    return float(distancias[bajo[0]]) if len(bajo) else 300.0


def calcular_mapa(proyecto: Proyecto, cfg: ConfigMapa) -> ResultadoMapa:
    pares = columnas_de_carga(proyecto)
    if not pares:
        raise ValueError("No hay taladros cargados: asigna explosivo a los taladros para ver el mapa.")
    pozos = [p for p, _ in pares]
    collares = np.array([p.collar() for p in pozos])
    direcciones = np.array([p.direccion() for p in pozos])
    d = direcciones.mean(axis=0)
    d /= np.linalg.norm(d) or 1.0

    if cfg.profundidad is None:
        profundidad = float(np.mean([p.taco + (p.longitud - p.taco) / 2 for p in pozos]))
    else:
        profundidad = cfg.profundidad

    if abs(d[2]) > 0.7:  # pozos casi verticales → plano horizontal
        eje_u, eje_v = np.array([1.0, 0, 0]), np.array([0, 1.0, 0])
        cota = float(np.mean(collares[:, 2] + direcciones[:, 2] * profundidad))
        origen = np.array([0.0, 0.0, cota])
        plano = f"Plano horizontal a cota {cota:.2f} m ({profundidad:.2f} m bajo el collar)"
        referencia = collares[:, :2]
    else:  # pozos casi horizontales → plano paralelo al frente
        eje_u = np.cross(d, [0, 0, 1.0])
        eje_u /= np.linalg.norm(eje_u)
        eje_v = np.cross(eje_u, d)
        origen = collares.mean(axis=0) + d * profundidad
        plano = f"Plano paralelo al frente, {profundidad:.2f} m dentro de la roca"
        contornos = [o for o in proyecto.objetos.values() if isinstance(o, Contorno)]
        puntos_ref = collares if not contornos else np.vstack([collares] + [np.array(c.vertices)
                                                                            for c in contornos])
        referencia = np.c_[(puntos_ref - origen) @ eje_u, (puntos_ref - origen) @ eje_v]

    u_ref, v_ref = referencia[:, 0], referencia[:, 1]
    extension = max(np.ptp(u_ref), np.ptp(v_ref), 1.0)
    margen = min(_alcance(pares, cfg) * 1.1, 2 * extension + 5)
    umin, umax = u_ref.min() - margen, u_ref.max() + margen
    vmin, vmax = v_ref.min() - margen, v_ref.max() + margen
    paso = max(umax - umin, vmax - vmin) / max(cfg.resolucion, 20)
    bordes_u = np.arange(umin, umax + paso, paso)
    bordes_v = np.arange(vmin, vmax + paso, paso)
    cu = (bordes_u[:-1] + bordes_u[1:]) / 2
    cv = (bordes_v[:-1] + bordes_v[1:]) / 2
    uu, vv = np.meshgrid(cu, cv)
    puntos = origen + uu[..., None] * eje_u + vv[..., None] * eje_v

    ppv = ppv_holmberg_persson(puntos.reshape(-1, 3), [c for _, c in pares],
                               k=cfg.k, alfa=cfg.alfa, beta=cfg.beta, modo=cfg.modo)
    ppv = ppv.reshape(uu.shape)
    return ResultadoMapa(
        origen=origen, eje_u=eje_u, eje_v=eje_v, bordes_u=bordes_u, bordes_v=bordes_v,
        ppv=ppv, zona=zonas(ppv, cfg.umbrales), plano=plano, area_celda=paso * paso,
        ppv_max=float(ppv.max()),
    )
