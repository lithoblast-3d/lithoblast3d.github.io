"""
Guardar / abrir proyectos (.b3d, formato JSON) e importar / exportar pozos en CSV.
"""

import csv
import io
import json
from dataclasses import asdict, fields
from pathlib import Path

from app.core.modelo import (
    CLASES_OBJETO,
    Capa,
    ConfigMapa,
    DisenoVoladura,
    Explosivo,
    Perforacion,
    Proyecto,
)

FORMATO = "barreno3d-proyecto"
VERSION_FORMATO = 1
EXTENSION = ".b3d"


# ------------------------------------------------------------------ proyectos
def guardar_proyecto(proyecto: Proyecto, ruta: str | Path) -> None:
    datos = {
        "formato": FORMATO,
        "version": VERSION_FORMATO,
        "nombre": proyecto.nombre,
        "escenario_demo": proyecto.escenario_demo,
        "diseno": asdict(proyecto.diseno),
        "mapa": asdict(proyecto.mapa),
        "capas": [asdict(c) for c in proyecto.capas],
        "explosivos": [asdict(e) for e in proyecto.explosivos],
        "objetos": [{"clase": type(o).__name__, **asdict(o)} for o in proyecto.objetos.values()],
    }
    ruta = Path(ruta)
    temporal = ruta.with_suffix(ruta.suffix + ".tmp")
    temporal.write_text(json.dumps(datos, ensure_ascii=False, indent=1), encoding="utf-8")
    temporal.replace(ruta)  # evita dejar un archivo a medias si algo falla


def _solo_campos(clase, datos: dict) -> dict:
    nombres = {f.name for f in fields(clase)}
    return {k: v for k, v in datos.items() if k in nombres}


def abrir_proyecto(ruta: str | Path) -> Proyecto:
    datos = json.loads(Path(ruta).read_text(encoding="utf-8"))
    if datos.get("formato") != FORMATO:
        raise ValueError("El archivo no es un proyecto de LithoBlast3D")
    if datos.get("version", 0) > VERSION_FORMATO:
        raise ValueError("El proyecto fue creado con una versión más nueva del programa")

    proyecto = Proyecto(
        nombre=datos.get("nombre", "Proyecto"),
        escenario_demo=datos.get("escenario_demo", False),
        diseno=DisenoVoladura(**_solo_campos(DisenoVoladura, datos.get("diseno", {}))),
        mapa=ConfigMapa(**_solo_campos(ConfigMapa, datos.get("mapa", {}))),
        capas=[Capa(**_solo_campos(Capa, c)) for c in datos.get("capas", [])],
        explosivos=[Explosivo(**_solo_campos(Explosivo, e)) for e in datos.get("explosivos", [])],
    )
    proyecto.asegurar_capas_base()
    for registro in datos.get("objetos", []):
        clase = CLASES_OBJETO.get(registro.get("clase"))
        if clase is None:
            continue
        valores = _solo_campos(clase, registro)
        for clave in ("vertices", "puntos", "triangulos"):
            if clave in valores:
                valores[clave] = [tuple(v) for v in valores[clave]]
        proyecto.agregar_objeto(clase(**valores))
    return proyecto


# ------------------------------------------------------------------ CSV
COLUMNAS_CSV = [
    "id", "este_x", "norte_y", "cota_z", "azimut", "inclinacion",
    "longitud", "diametro_mm", "explosivo", "taco", "funcion",
]
OBLIGATORIAS = ["id", "este_x", "norte_y", "cota_z", "longitud", "diametro_mm"]


def exportar_pozos_csv(proyecto: Proyecto, ruta: str | Path) -> int:
    """Exporta con ';' y coma decimal (se abre directo en Excel en español)."""

    def n(valor: float) -> str:
        return f"{valor:.3f}".replace(".", ",")

    with open(ruta, "w", newline="", encoding="utf-8-sig") as archivo:
        escritor = csv.writer(archivo, delimiter=";")
        escritor.writerow(COLUMNAS_CSV)
        pozos = proyecto.perforaciones()
        for p in pozos:
            explosivo = proyecto.explosivo(p.explosivo_id)
            escritor.writerow([
                p.id, n(p.x), n(p.y), n(p.z), n(p.azimut), n(p.inclinacion),
                n(p.longitud), n(p.diametro_mm), explosivo.nombre if explosivo else "",
                n(p.taco), p.funcion,
            ])
    return len(pozos)


def _a_numero(texto: str) -> float:
    original = texto
    texto = texto.strip().replace(" ", "")
    if not texto:
        raise ValueError("hay un valor numérico vacío")
    if "," in texto and "." in texto:
        texto = texto.replace(".", "").replace(",", ".")  # 1.234,5 → 1234.5
    else:
        texto = texto.replace(",", ".")
    try:
        return float(texto)
    except ValueError:
        raise ValueError(f"«{original.strip()}» no es un número válido") from None


def importar_pozos_csv(proyecto: Proyecto, ruta: str | Path) -> tuple[list[Perforacion], list[str]]:
    """
    Lee pozos desde CSV (separador ',' o ';', decimales con punto o coma).
    Devuelve (pozos_validos, avisos). No modifica el proyecto.
    """
    contenido = Path(ruta).read_text(encoding="utf-8-sig", errors="replace")
    muestra = contenido[:2000]
    separador = ";" if muestra.count(";") >= muestra.count(",") else ","
    lector = csv.DictReader(io.StringIO(contenido), delimiter=separador)
    if lector.fieldnames is None:
        raise ValueError("El archivo está vacío")
    columnas = {c.strip().lower(): c for c in lector.fieldnames if c}
    faltan = [c for c in OBLIGATORIAS if c not in columnas]
    if faltan:
        raise ValueError(
            "Faltan columnas obligatorias: " + ", ".join(faltan)
            + ". Columnas esperadas: " + ", ".join(COLUMNAS_CSV)
        )

    d = proyecto.diseno
    inclinacion_defecto = 90.0 if d.escenario == "tajo" else 0.0
    pozos, avisos, ids = [], [], set(proyecto.objetos)

    for numero, fila in enumerate(lector, start=2):
        def valor(nombre: str) -> str:
            col = columnas.get(nombre)
            return (fila.get(col) or "").strip() if col else ""

        if not any((v or "").strip() for v in fila.values() if isinstance(v, str)):
            continue
        try:
            ident = valor("id")
            if not ident:
                raise ValueError("falta el id")
            if ident in ids:
                raise ValueError(f"el id '{ident}' ya existe")
            explosivo_id = None
            nombre_exp = valor("explosivo")
            if nombre_exp:
                explosivo = proyecto.explosivo_por_nombre(nombre_exp)
                if explosivo is None:
                    avisos.append(f"Fila {numero}: explosivo «{nombre_exp}» no registrado; "
                                  "el taladro queda sin carga.")
                else:
                    explosivo_id = explosivo.id
            pozo = Perforacion(
                id=ident, nombre=ident, capa_id="perforaciones",
                x=_a_numero(valor("este_x")), y=_a_numero(valor("norte_y")),
                z=_a_numero(valor("cota_z")),
                azimut=_a_numero(valor("azimut")) if valor("azimut") else 0.0,
                inclinacion=_a_numero(valor("inclinacion")) if valor("inclinacion") else inclinacion_defecto,
                longitud=_a_numero(valor("longitud")),
                diametro_mm=_a_numero(valor("diametro_mm")),
                explosivo_id=explosivo_id,
                taco=_a_numero(valor("taco")) if valor("taco") else 0.0,
                funcion=valor("funcion") or ("Producción" if d.escenario == "tajo" else "Ayuda"),
            )
            if pozo.longitud <= 0 or pozo.diametro_mm <= 0:
                raise ValueError("longitud y diámetro deben ser mayores que cero")
            if pozo.taco < 0 or pozo.taco > pozo.longitud:
                raise ValueError("el taco debe estar entre 0 y la longitud del taladro")
            pozos.append(pozo)
            ids.add(ident)
        except ValueError as error:
            avisos.append(f"Fila {numero}: {error}. Fila omitida.")
    return pozos, avisos
