"""
Gestor de selección compartido.

Cuando un panel (visor, capas, tabla...) selecciona un objeto, avisa aquí.
El gestor reenvía el aviso a todos los demás, que se actualizan solos.
Así la selección queda sincronizada sin que los paneles se conozcan entre sí.
"""

from collections.abc import Callable

# Firma de cada oyente: funcion(objeto_id_o_None, origen)
Oyente = Callable[[str | None, str], None]


class GestorSeleccion:
    def __init__(self) -> None:
        self._actual: str | None = None
        self._oyentes: list[Oyente] = []

    @property
    def actual(self) -> str | None:
        return self._actual

    def suscribir(self, funcion: Oyente) -> None:
        self._oyentes.append(funcion)

    def seleccionar(self, objeto_id: str | None, origen: str = "") -> None:
        """Selecciona un objeto por su id (None = quitar selección)."""
        if objeto_id == self._actual:
            return
        self._actual = objeto_id
        for funcion in list(self._oyentes):
            funcion(objeto_id, origen)
