"""Reporte del proyecto en HTML (se abre en el navegador y se puede imprimir a PDF)."""

from __future__ import annotations

import datetime as _dt
import html

from app import NOMBRE_APP, VERSION
from app.core.modelo import (NOMBRES_ESCENARIO, Contorno, PolilineaCAD, PuntosCAD, Proyecto, SuperficieTIN, num)
from app.core.resultados import carga_de_pozo, resumen_voladura

ESTILO = """
body{font-family:Segoe UI,Arial,sans-serif;background:#1b1e22;color:#e4e7eb;margin:28px;}
h1{color:#2bb3a8;margin-bottom:4px} h2{color:#3a8dde;border-bottom:1px solid #363c44;padding-bottom:4px}
table{border-collapse:collapse;margin:8px 0 18px 0;font-size:12px}
th,td{border:1px solid #363c44;padding:4px 8px;text-align:right} th{background:#2a2f35;color:#9aa3ad}
td:first-child,th:first-child{text-align:left}
.aviso{background:#3a3220;color:#e0b341;border:1px solid #6b5a2a;border-radius:4px;padding:8px 12px;margin:10px 0}
.sec{color:#9aa3ad;font-size:12px}
@media print{body{background:#fff;color:#000} th{background:#eee;color:#000} .aviso{background:#fff7e0;color:#6b4e00}}
"""


def _tabla(cab, filas):
    h = "<table><tr>" + "".join(f"<th>{html.escape(str(c))}</th>" for c in cab) + "</tr>"
    for f in filas:
        h += "<tr>" + "".join(f"<td>{html.escape(str(c))}</td>" for c in f) + "</tr>"
    return h + "</table>"


def generar_html(proyecto: Proyecto, ruta_archivo: str = "") -> str:
    d = proyecto.diseno
    r = resumen_voladura(proyecto)
    pozos = proyecto.perforaciones()
    partes = [f"<html><head><meta charset='utf-8'><title>Reporte — {html.escape(proyecto.nombre)}</title>"
              f"<style>{ESTILO}</style></head><body>",
              f"<h1>{html.escape(proyecto.nombre)}</h1>",
              f"<div class='sec'>{NOMBRE_APP} {VERSION} · {_dt.datetime.now():%Y-%m-%d %H:%M} · "
              f"{html.escape(ruta_archivo or 'proyecto sin guardar')}</div>"]
    origenes = sorted({p.origen for p in pozos if getattr(p, "origen", "")})
    if origenes:
        partes.append("<div class='aviso'>⚠ La malla proviene de una REFERENCIA DOCUMENTAL "
                      f"({html.escape('; '.join(origenes))}). No es un diseño validado para condiciones reales "
                      "hasta verificarlo en la mina.</div>")
    partes.append("<h2>Resumen</h2>")
    filas = [("Escenario", NOMBRES_ESCENARIO.get(d.escenario, d.escenario)),
             ("Taladros totales", r.pozos_total), ("Taladros cargados", r.pozos_cargados),
             ("Metros perforados", f"{num(r.metros_perforados)} m"), ("Explosivo total", f"{num(r.carga_total)} kg"),
             ("Densidad de roca", f"{num(d.densidad_roca)} t/m³")]
    if r.volumen:
        filas.append(("Volumen", f"{num(r.volumen)} m³"))
    if r.tonelaje:
        filas.append(("Tonelaje", f"{num(r.tonelaje)} t"))
    if r.factor_carga:
        filas.append(("Factor de carga", f"{num(r.factor_carga)} kg/m³"))
    if r.factor_potencia:
        filas.append(("Factor de potencia", f"{num(r.factor_potencia)} kg/t"))
    if r.error:
        filas.append(("Aviso", r.error))
    partes.append(_tabla(("Concepto", "Valor"), filas))
    partes.append("<h2>Explosivos</h2>")
    partes.append(_tabla(("Nombre", "Tipo", "Densidad g/cm³", "Ø cartucho mm", "Referencial"),
                         [(e.nombre, e.tipo, num(e.densidad_gcc), num(e.diametro_cartucho_mm, 1),
                           "sí" if e.referencial else "no") for e in proyecto.explosivos]))
    if pozos:
        partes.append("<h2>Perforaciones</h2>")
        filas = []
        for p in pozos:
            c = carga_de_pozo(proyecto, p)
            exp = proyecto.explosivo(p.explosivo_id)
            filas.append((p.id, p.funcion, num(p.x, 3), num(p.y, 3), num(p.z, 3), num(p.azimut, 1),
                          num(p.inclinacion, 1), num(p.longitud), num(p.diametro_mm, 0),
                          exp.nombre if exp else "—", num(c.carga) if c.cargado else "—",
                          p.retardo or "—", num(p.tiempo_ms, 0) if p.tiempo_ms is not None else "—"))
        partes.append(_tabla(("Id", "Función", "X", "Y", "Z", "Azimut", "Incl.", "Long. m", "Ø mm", "Explosivo",
                              "Carga kg", "Retardo", "t ms"), filas))
    contornos = [o for o in proyecto.objetos.values() if isinstance(o, Contorno)]
    if contornos:
        partes.append("<h2>Contornos y secciones</h2>")
        partes.append(_tabla(("Id", "Nombre", "Área m²", "Perímetro m"),
                             [(c.id, c.nombre, num(c.area()), num(c.perimetro())) for c in contornos]))
    tins = [o for o in proyecto.objetos.values() if isinstance(o, SuperficieTIN)]
    cad = [o for o in proyecto.objetos.values() if isinstance(o, (PolilineaCAD, PuntosCAD))]
    if tins or cad:
        partes.append("<h2>Topografía y CAD</h2>")
        if tins:
            filas = []
            for t in tins:
                zs = [v[2] for v in t.vertices] or [0]
                filas.append((t.id, t.nombre, len(t.vertices), len(t.triangulos), num(min(zs)), num(max(zs)),
                              t.fuente))
            partes.append(_tabla(("Id", "Superficie", "Vértices", "Triángulos", "Cota mín.", "Cota máx.", "Fuente"),
                                 filas))
        capas = {}
        for o in cad:
            capas[o.capa_cad] = capas.get(o.capa_cad, 0) + 1
        partes.append(_tabla(("Capa CAD", "Objetos"), sorted(capas.items())))
    partes.append("<h2>Notas</h2><div class='aviso'>Diseño preliminar: los cálculos siguen las fuentes citadas en "
                  "el programa; ajústalos con los resultados de campo. Las animaciones 3D (equipo, polvo, bloques) "
                  "son ilustrativas: no predicen fragmentación, proyección ni vibraciones.</div>")
    partes.append("</body></html>")
    return "\n".join(partes)
