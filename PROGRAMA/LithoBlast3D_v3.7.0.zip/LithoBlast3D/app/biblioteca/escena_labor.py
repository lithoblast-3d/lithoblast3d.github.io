"""Escena para la simulación 3D del ciclo de la labor (la misma del teléfono: app/datos/web3d/labor.html).

Toma una opción de la malla automática y arma lo que necesita el visor: contorno, taladros (con explosivo,
cartuchos, kg, retardo y función), longitud, avance, y los equipos de cada método de trabajo:
- mecanizado: el jumbo elegido (si entra) y el scoop más grande que entra;
- convencional: jackleg (stoper en chimenea) y el scoop más pequeño que entra.
"""

from __future__ import annotations

from dataclasses import asdict

from app.core import equipos as eqp


def _eq(e) -> dict | None:
    if e is None:
        return None
    d = asdict(e)
    d["descripcion"] = e.descripcion_corta()
    return {k: (list(v) if isinstance(v, tuple) else v) for k, v in d.items()}


def _sc(s) -> dict | None:
    if s is None:
        return None
    d = asdict(s)
    d["seccion_minima"] = list(s.seccion_minima())
    return d


def escena(op, datos, sistema: str = "carmex") -> dict:
    if op.plano is None:
        raise ValueError("La opción no tiene malla")
    L = datos.longitud
    taladros = []
    for t in op.plano.taladros:
        cargado = t.tipo == "cargado"
        taladros.append({
            "x": round(t.x, 3), "y": round(t.y, 3), "tipo": t.tipo, "retardo": t.detonador or 0,
            "cartuchos": t.cartuchos if cargado else 0, "kg": round(t.kg or 0.0, 3) if cargado else 0.0,
            "explosivo": (t.explosivo or "") if cargado else "", "funcion": t.funcion or ("Alivio" if not cargado else ""),
            "azimut_rel": round(t.azimut_rel or 0.0, 2), "longitud": round(t.longitud or L, 3),
            "diametro": datos.diametro_mm if cargado else datos.diametro_alivio_mm})
    catalogo = eqp.catalogo()
    manual = next((e for e in catalogo if e.tipo == ("stoper" if op.labor == "chimenea" else "jackleg")), None)
    jumbo = op.equipo.equipo if op.equipo is not None and op.equipo.equipo.tipo == "jumbo" else None
    if op.labor == "chimenea":
        sc_mec = sc_conv = None
        nota = "En la chimenea el material cae por gravedad y se limpia desde el nivel inferior."
    else:
        sc_mec, nota = eqp.seleccionar_scoop(datos.ancho, datos.alto)
        caben = [s for s in eqp.CATALOGO_SCOOP if s.seccion_minima()[0] <= datos.ancho + 1e-9 and s.seccion_minima()[1] <= datos.alto + 1e-9]
        sc_conv = min(caben, key=lambda s: s.balde_m3) if caben else None
    return {
        "titulo": op.nombre, "familia": op.familia, "labor": op.labor, "ancho": datos.ancho, "alto": datos.alto,
        "contorno": [[round(x, 3), round(y, 3)] for x, y in op.plano.contorno], "taladros": taladros,
        "L": L, "avance": op.avance or 0.9 * L, "lc": datos.largo_cartucho_m, "sistema": sistema,
        "metodos": {
            "mecanizado": {"equipo": _eq(jumbo or (op.equipo.equipo if op.equipo else manual)), "scoop": _sc(sc_mec),
                           "aviso": "" if jumbo else "Ningún jumbo del catálogo entra en la sección: se perfora con jackleg."},
            "convencional": {"equipo": _eq(manual), "scoop": _sc(sc_conv), "aviso": ""},
        },
        "metodo": "mecanizado" if jumbo else "convencional", "nota_scoop": nota,
    }
