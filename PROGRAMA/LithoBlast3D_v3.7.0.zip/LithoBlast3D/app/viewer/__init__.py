"""Visores gráficos (3D con PyVista; 2D en una etapa posterior)."""
