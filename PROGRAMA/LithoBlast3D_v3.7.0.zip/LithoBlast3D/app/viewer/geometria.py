"""Convierte los objetos del modelo en mallas de PyVista para dibujarlos."""

import numpy as np
import pyvista as pv

from app.core.modelo import Banco, Contorno, Perforacion, Superficie

# Radio mínimo de dibujo para que los pozos se vean y se puedan seleccionar.
# Es solo representación gráfica: los datos conservan el diámetro real.
RADIO_MINIMO = {"tajo": 0.25, "subterraneo": 0.02}  # m

# Las líneas se elevan un poco para que no se oculten dentro de las superficies.
ELEVACION_LINEAS = 0.08  # m


def malla_superficie(s: Superficie) -> pv.StructuredGrid:
    xs = s.x0 + np.arange(s.nx) * s.paso_x
    ys = s.y0 + np.arange(s.ny) * s.paso_y
    malla_x, malla_y = np.meshgrid(xs, ys)
    malla_z = np.asarray(s.cotas, dtype=float).reshape(s.ny, s.nx)
    malla = pv.StructuredGrid(malla_x, malla_y, malla_z)
    malla["Cota"] = np.array(malla.points[:, 2])
    return malla


def malla_perforacion(p: Perforacion, radio_minimo: float, escala_radio: float = 1.0) -> pv.PolyData:
    collar = np.array(p.collar(), dtype=float)
    direccion = np.array(p.direccion(), dtype=float)
    centro = collar + direccion * (p.longitud / 2.0)
    radio = max(p.diametro_mm / 2000.0, radio_minimo) * escala_radio
    return pv.Cylinder(center=centro, direction=direccion, radius=radio,
                       height=p.longitud, resolution=24)


def malla_banco(b: Banco) -> pv.PolyData:
    (p1, p2), (p3, p4) = b.linea_pie(), b.linea_cresta()
    puntos = np.array([p1, p2, p3, p4], dtype=float)
    puntos[:, 2] += ELEVACION_LINEAS
    return pv.PolyData(puntos, lines=np.array([2, 0, 1, 2, 2, 3]))


def malla_contorno(c: Contorno, elevar: bool) -> pv.PolyData:
    n = len(c.vertices)
    puntos = np.array(c.vertices, dtype=float)
    if elevar:
        puntos[:, 2] += ELEVACION_LINEAS
    return pv.PolyData(puntos, lines=np.array([n + 1, *range(n), 0]))


def malla_tin(t) -> pv.PolyData | None:
    """Superficie TIN con escalares de cota (puntos) y pendiente (celdas)."""
    if len(t.vertices) < 3 or not t.triangulos:
        return None
    pts = np.asarray(t.vertices, dtype=float)
    tri = np.asarray(t.triangulos, dtype=np.int64)
    caras = np.hstack([np.full((len(tri), 1), 3), tri]).ravel()
    malla = pv.PolyData(pts, faces=caras)
    malla["Cota"] = pts[:, 2]
    p = pts[tri]
    n = np.cross(p[:, 1] - p[:, 0], p[:, 2] - p[:, 0])
    norma = np.linalg.norm(n, axis=1)
    norma[norma == 0] = 1
    malla.cell_data["Pendiente (°)"] = np.degrees(np.arccos(np.clip(np.abs(n[:, 2]) / norma, 0, 1)))
    return malla


def malla_polilinea(vertices, cerrada: bool) -> pv.PolyData | None:
    n = len(vertices)
    if n < 2:
        return None
    pts = np.asarray(vertices, dtype=float)
    idx = list(range(n)) + ([0] if cerrada else [])
    return pv.PolyData(pts, lines=np.array([len(idx), *idx]))


def malla_polilineas(lista) -> pv.PolyData | None:
    """Varias polilíneas en una sola malla (para capas CAD con miles de curvas)."""
    pts, lineas, base = [], [], 0
    for vertices, cerrada in lista:
        n = len(vertices)
        if n < 2:
            continue
        pts.append(np.asarray(vertices, dtype=float))
        idx = [base + k for k in range(n)] + ([base] if cerrada else [])
        lineas += [len(idx), *idx]
        base += n
    if not pts:
        return None
    return pv.PolyData(np.vstack(pts), lines=np.array(lineas))
