"""
Visor 3D integrado en la ventana (PyVista + pyvistaqt).

Controles del ratón:
- Clic izquierdo (sin arrastrar): seleccionar objeto. En vacío: quitar selección.
- Clic izquierdo y arrastrar: girar.
- Rueda: acercar / alejar.
- Shift + arrastrar, o arrastrar con la rueda pulsada: desplazar.
"""

import os

os.environ.setdefault("QT_API", "pyside6")

import numpy as np  # noqa: E402
import pyvista as pv  # noqa: E402
from PySide6.QtCore import Signal  # noqa: E402
from PySide6.QtWidgets import QVBoxLayout, QWidget  # noqa: E402
from pyvistaqt import QtInteractor  # noqa: E402
from vtkmodules.vtkRenderingCore import vtkCellPicker  # noqa: E402

from app.core.documento import Documento  # noqa: E402
from app.core.modelo import (  # noqa: E402
    ESCENARIO_SUBTERRANEO,
    Banco,
    Contorno,
    Perforacion,
    PolilineaCAD,
    PuntosCAD,
    Superficie,
    SuperficieTIN,
)
from app.calc.energia import ETIQUETAS_ZONAS  # noqa: E402
from app.core.analisis import ResultadoMapa, calcular_mapa  # noqa: E402
from app.core.resultados import carga_de_pozo  # noqa: E402
from app.viewer import geometria  # noqa: E402

COLOR_SELECCION = "#ff5fd2"  # magenta: solo significa "objeto seleccionado"
COLOR_SIN_CARGA = "#4a5058"  # gris oscuro: pozo sin explosivo
MAPA_COTAS = "cividis"
MAPA_CARGA = "plasma"
TITULO_COTAS = "Cota (m)"
TITULO_CARGA = "Carga (kg)"
OPACIDAD_SUPERFICIE = 0.6
OPACIDAD_SUPERFICIE_CON_MAPA = 0.12
COLOR_POZO_CON_MAPA = "#111315"
# Colores del mapa de vibración: azul, verde, amarillo, rojo (de menor a mayor PPV)
COLORES_ZONAS = ("#1f4fd1", "#2fbf4a", "#f2d53c", "#e5322d")
TOLERANCIA_CLIC_PX = 4
LIMITE_ACTORES_CAD = 150  # polilíneas por capa antes de agruparlas en un solo actor


def _clave(actor) -> str:
    """Identificador estable de un actor VTK (su dirección en memoria)."""
    return actor.GetAddressAsString("vtkObject")


class Visor3D(QWidget):
    mensaje_herramienta = Signal(str)

    def __init__(self, documento: Documento, colores: dict, parent=None):
        super().__init__(parent)
        self.herramienta: str | None = None
        self._puntos_medida: list = []
        self._actores_medida: list = []
        self.ultima_medida = None
        self._doc = documento
        self._c = colores
        self._mallas: dict[str, object] = {}
        self._actor_por_objeto: dict[str, object] = {}
        self._objeto_por_clave: dict[str, str] = {}
        self._actor_resaltado = None
        self._pos_presion = None
        self.mapa: ResultadoMapa | None = None
        self.error_mapa: str = ""

        self.plotter = QtInteractor(self)
        diseno = QVBoxLayout(self)
        diseno.setContentsMargins(0, 0, 0, 0)
        diseno.addWidget(self.plotter.interactor)

        pl = self.plotter
        pl.set_background(self._c["visor_fondo_abajo"], top=self._c["visor_fondo_arriba"])
        for activar in (pl.enable_depth_peeling, lambda: pl.enable_anti_aliasing("fxaa")):
            try:
                activar()
            except Exception:
                pass
        pl.add_axes(xlabel="E", ylabel="N", zlabel="Z", color=self._c["texto"])

        self._picker = vtkCellPicker()
        self._picker.SetTolerance(0.004)
        iren = self.plotter.iren.interactor
        iren.AddObserver("LeftButtonPressEvent", self._al_presionar, 10.0)
        iren.AddObserver("LeftButtonReleaseEvent", self._al_soltar, 10.0)

        self._doc.seleccion.suscribir(self._al_cambiar_seleccion)
        self._construir()
        if self._doc.proyecto.diseno.escenario == ESCENARIO_SUBTERRANEO:
            self.vista_frontal()
        else:
            self.vista_isometrica()

    # ------------------------------------------------------------------ escena
    def refrescar(self) -> None:
        """Redibuja todo conservando la posición de la cámara."""
        estaba_vacio = not self._mallas
        camara = self.plotter.camera_position
        self._construir()
        if estaba_vacio:
            self.plotter.reset_camera()
        else:
            self.plotter.camera_position = camara
        self.plotter.render()

    def _limpiar(self) -> None:
        try:
            self.plotter.scalar_bars.clear()
        except Exception:
            pass
        self.plotter.clear_actors()
        try:
            self.plotter.remove_legend()
        except Exception:
            pass
        self._mallas.clear()
        self._actor_por_objeto.clear()
        self._objeto_por_clave.clear()
        self._actor_resaltado = None

    def _construir(self) -> None:
        self._limpiar()
        proyecto = self._doc.proyecto
        pl = self.plotter
        escenario = proyecto.diseno.escenario
        radio_min = geometria.RADIO_MINIMO.get(escenario, 0.1)

        texto = "Proyecto de ejemplo · coordenadas locales (m)" if proyecto.escenario_demo \
            else f"{proyecto.nombre} · coordenadas en m"
        pl.add_text(texto, position="upper_left", font_size=9, color=self._c["texto_secundario"])

        cargas = {p.id: carga_de_pozo(proyecto, p) for p in proyecto.perforaciones()}
        valores = [c.carga for c in cargas.values() if c.cargado]
        if valores:
            minimo, maximo = min(valores), max(valores)
            if maximo - minimo < 1e-6:
                minimo, maximo = minimo * 0.9, maximo * 1.1 + 1e-6
        hay_superficie = any(isinstance(o, (Superficie, SuperficieTIN)) for o in proyecto.objetos.values())
        con_mapa = self._dibujar_mapa()

        # capas CAD con muchas polilíneas se dibujan en un solo actor (rendimiento)
        cuenta_cad: dict[str, int] = {}
        for o in proyecto.objetos.values():
            if isinstance(o, PolilineaCAD):
                cuenta_cad[o.capa_id] = cuenta_cad.get(o.capa_id, 0) + 1
        lotes: dict[str, list] = {}
        for objeto in proyecto.objetos.values():
            capa = proyecto.capa(objeto.capa_id)
            color = capa.color if capa else "#cccccc"
            if isinstance(objeto, Superficie):
                malla = geometria.malla_superficie(objeto)
                actor = pl.add_mesh(
                    malla, scalars="Cota", cmap=MAPA_COTAS,
                    opacity=OPACIDAD_SUPERFICIE_CON_MAPA if con_mapa else OPACIDAD_SUPERFICIE,
                    smooth_shading=True, reset_camera=False,
                    scalar_bar_args=self._args_leyenda(TITULO_COTAS, 0.90, "%.0f"),
                )
            elif isinstance(objeto, Perforacion):
                malla = geometria.malla_perforacion(objeto, radio_min)
                cp = cargas[objeto.id]
                if con_mapa:
                    actor = pl.add_mesh(malla, color=COLOR_POZO_CON_MAPA if cp.cargado
                                        else COLOR_SIN_CARGA, smooth_shading=True, reset_camera=False)
                elif cp.cargado:
                    malla[TITULO_CARGA] = np.full(malla.n_points, cp.carga)
                    actor = pl.add_mesh(
                        malla, scalars=TITULO_CARGA, cmap=MAPA_CARGA, clim=(minimo, maximo),
                        smooth_shading=True, specular=0.3, reset_camera=False,
                        scalar_bar_args=self._args_leyenda(
                            TITULO_CARGA, 0.04 if hay_superficie else 0.90, "%.1f"),
                    )
                else:
                    actor = pl.add_mesh(malla, color=COLOR_SIN_CARGA, smooth_shading=True,
                                        reset_camera=False)
            elif isinstance(objeto, Banco):
                malla = geometria.malla_banco(objeto)
                actor = pl.add_mesh(malla, color=color, line_width=3,
                                    render_lines_as_tubes=True, reset_camera=False)
            elif isinstance(objeto, Contorno):
                malla = geometria.malla_contorno(objeto, elevar=escenario != ESCENARIO_SUBTERRANEO)
                actor = pl.add_mesh(malla, color=color, line_width=3,
                                    render_lines_as_tubes=True, reset_camera=False)
            elif isinstance(objeto, SuperficieTIN):
                malla = geometria.malla_tin(objeto)
                if malla is None:
                    continue
                if objeto.colorear == "pendiente":
                    actor = pl.add_mesh(
                        malla, scalars="Pendiente (°)", cmap=["#3f8f4a", "#d9c34a", "#c8452f"],
                        clim=(0, 90), opacity=OPACIDAD_SUPERFICIE_CON_MAPA if con_mapa else 0.85,
                        reset_camera=False, smooth_shading=False,
                        scalar_bar_args=self._args_leyenda("Pendiente (°)", 0.90, "%.0f"))
                else:
                    actor = pl.add_mesh(
                        malla, scalars="Cota", cmap=MAPA_COTAS,
                        opacity=OPACIDAD_SUPERFICIE_CON_MAPA if con_mapa else 0.85,
                        smooth_shading=True, reset_camera=False,
                        scalar_bar_args=self._args_leyenda(TITULO_COTAS, 0.90, "%.0f"))
            elif isinstance(objeto, PolilineaCAD):
                if cuenta_cad.get(objeto.capa_id, 0) > LIMITE_ACTORES_CAD:
                    lotes.setdefault(objeto.capa_id, []).append(objeto)
                    continue
                malla = geometria.malla_polilinea(objeto.vertices, objeto.cerrada)
                if malla is None:
                    continue
                actor = pl.add_mesh(malla, color=color, line_width=2, reset_camera=False)
            elif isinstance(objeto, PuntosCAD):
                if not objeto.puntos:
                    continue
                malla = pv.PolyData(np.asarray(objeto.puntos, dtype=float))
                actor = pl.add_mesh(malla, color=color, point_size=6, render_points_as_spheres=True,
                                    reset_camera=False)
            else:
                continue
            if capa is not None and not capa.visible:
                actor.SetVisibility(False)
            self._mallas[objeto.id] = malla
            self._actor_por_objeto[objeto.id] = actor
            self._objeto_por_clave[_clave(actor)] = objeto.id

        for capa_id, objetos in lotes.items():
            capa = proyecto.capa(capa_id)
            malla = geometria.malla_polilineas([(o.vertices, o.cerrada) for o in objetos])
            if malla is None:
                continue
            actor = pl.add_mesh(malla, color=capa.color if capa else "#cccccc", line_width=1.5, reset_camera=False)
            if capa is not None and not capa.visible:
                actor.SetVisibility(False)
            for o in objetos:  # la visibilidad por capa sigue funcionando
                self._actor_por_objeto[o.id] = actor
            self._mallas[f"lote:{capa_id}"] = malla
        if self._mallas:
            pl.show_grid(xtitle="Este X (m)", ytitle="Norte Y (m)", ztitle="Cota Z (m)",
                         color=self._c["texto_secundario"], font_size=10, n_zlabels=3)
        self._ajustar_leyenda_cotas()
        self._al_cambiar_seleccion(self._doc.seleccion.actual, "")

    def _dibujar_mapa(self) -> bool:
        """Calcula y dibuja el mapa de vibración si está activo. Devuelve True si se dibujó."""
        self.mapa, self.error_mapa = None, ""
        cfg = self._doc.proyecto.mapa
        if not cfg.activo:
            return False
        try:
            resultado = calcular_mapa(self._doc.proyecto, cfg)
        except ValueError as error:
            self.error_mapa = str(error)
            return False
        self.mapa = resultado
        esquinas = resultado.esquinas()
        malla = pv.StructuredGrid(esquinas[..., 0], esquinas[..., 1], esquinas[..., 2])
        # Zona de cada celda según su centro (independiente del orden interno de la malla)
        centros = np.asarray(malla.cell_centers().points) - resultado.origen
        paso = resultado.bordes_u[1] - resultado.bordes_u[0]
        iu = np.clip(((centros @ resultado.eje_u - resultado.bordes_u[0]) / paso).astype(int),
                     0, resultado.zona.shape[1] - 1)
        iv = np.clip(((centros @ resultado.eje_v - resultado.bordes_v[0]) / paso).astype(int),
                     0, resultado.zona.shape[0] - 1)
        malla.cell_data["Zona"] = resultado.zona[iv, iu].astype(float)
        self.plotter.add_mesh(
            malla, scalars="Zona", cmap=list(COLORES_ZONAS), clim=(-0.5, 3.5), n_colors=4,
            show_scalar_bar=False, lighting=False, pickable=False, reset_camera=False,
        )
        u = cfg.umbrales
        textos = (f"< {u[0]:g} mm/s", f"{u[0]:g} – {u[1]:g} mm/s",
                  f"{u[1]:g} – {u[2]:g} mm/s", f"> {u[2]:g} mm/s")
        etiquetas = [[f"{t}   {e}", c] for t, e, c in zip(textos, ETIQUETAS_ZONAS, COLORES_ZONAS)]
        etiquetas.reverse()
        try:
            self.plotter.add_legend(labels=etiquetas, bcolor=self._c["panel"], border=True,
                                    size=(0.30, 0.18), loc="lower right", face="rectangle")
        except Exception:
            pass
        aviso = "" if cfg.constantes_calibradas else "  ·  ⚠ constantes sin calibrar"
        self.plotter.add_text(f"Vibración Holmberg–Persson (PPV){aviso}", position="upper_right",
                              font_size=9, color=self._c["texto"])
        return True

    def _args_leyenda(self, titulo: str, x: float, formato: str) -> dict:
        return {
            "title": titulo, "color": self._c["texto"], "vertical": True,
            "position_x": x, "position_y": 0.25, "width": 0.05, "height": 0.5,
            "fmt": formato, "n_labels": 5, "title_font_size": 13, "label_font_size": 11,
        }

    def _ajustar_leyenda_cotas(self) -> None:
        capa = self._doc.proyecto.capa("topografia")
        try:
            barra = self.plotter.scalar_bars[TITULO_COTAS]
            barra.SetVisibility(bool(capa is None or capa.visible))
        except Exception:
            pass

    # --------------------------------------------------------------- selección
    def _al_presionar(self, interactor, _evento) -> None:
        self._pos_presion = interactor.GetEventPosition()

    def _al_soltar(self, interactor, _evento) -> None:
        if self._pos_presion is None:
            return
        x, y = interactor.GetEventPosition()
        px, py = self._pos_presion
        self._pos_presion = None
        if abs(x - px) > TOLERANCIA_CLIC_PX or abs(y - py) > TOLERANCIA_CLIC_PX:
            return  # fue un arrastre (giro de cámara), no un clic
        if self.herramienta in ("consultar", "medir"):
            self._usar_herramienta(x, y)
            return
        self._doc.seleccion.seleccionar(self._objeto_en(x, y), origen="visor")

    # --------------------------------------------------------------- herramientas
    def set_herramienta(self, nombre: str | None) -> None:
        """None = seleccionar; "consultar" = coordenadas del punto; "medir" = distancia entre 2 clics."""
        self.herramienta = nombre
        self._puntos_medida = []
        for a in self._actores_medida:
            self.plotter.remove_actor(a, render=False)
        self._actores_medida = []
        self.plotter.render()

    def _punto_en(self, x: int, y: int):
        self._picker.InitializePickList()
        self._picker.PickFromListOff()
        if self._picker.Pick(x, y, 0, self.plotter.renderer) and self._picker.GetActor() is not None:
            return tuple(self._picker.GetPickPosition())
        return None

    def _usar_herramienta(self, x: int, y: int) -> None:
        from app.cad.topografia import medir
        p = self._punto_en(x, y)
        if p is None:
            self.mensaje_herramienta.emit("Haz clic sobre un objeto o superficie visible.")
            return
        marca = self.plotter.add_mesh(pv.Sphere(radius=self._radio_marca(), center=p), color=COLOR_SELECCION,
                                      pickable=False, reset_camera=False)
        self._actores_medida.append(marca)
        if self.herramienta == "consultar":
            self.mensaje_herramienta.emit(f"Punto: X = {p[0]:.3f} m · Y = {p[1]:.3f} m · Z (cota) = {p[2]:.3f} m")
        else:
            self._puntos_medida.append(p)
            if len(self._puntos_medida) == 2:
                a, b = self._puntos_medida
                r = medir(a, b)
                self.ultima_medida = (a, b)
                linea = self.plotter.add_mesh(pv.Line(a, b), color=COLOR_SELECCION, line_width=3,
                                              pickable=False, reset_camera=False)
                self._actores_medida.append(linea)
                self.mensaje_herramienta.emit(
                    f"Distancia 3D {r['distancia_3d']:.3f} m · horizontal {r['horizontal']:.3f} m · "
                    f"desnivel {r['desnivel']:+.3f} m · pendiente {r['pendiente_grados']:.1f}° · "
                    f"azimut {r['azimut']:.1f}°")
                self._puntos_medida = []
            else:
                self.mensaje_herramienta.emit(f"Punto 1: X {p[0]:.3f} · Y {p[1]:.3f} · Z {p[2]:.3f}. "
                                              "Haz clic en el segundo punto.")
        self.plotter.render()

    def _radio_marca(self) -> float:
        try:
            b = self.plotter.bounds
            return max(0.01, 0.006 * max(b[1] - b[0], b[3] - b[2], b[5] - b[4]))
        except Exception:  # noqa: BLE001
            return 0.1

    def _objeto_en(self, x: int, y: int) -> str | None:
        """Busca el objeto bajo el cursor; las superficies se prueban al final."""
        prioritarios, superficies = [], []
        for objeto_id, actor in self._actor_por_objeto.items():
            if not actor.GetVisibility():
                continue
            if isinstance(self._doc.proyecto.objeto(objeto_id), (Superficie, SuperficieTIN)):
                superficies.append(actor)
            else:
                prioritarios.append(actor)
        for grupo in (prioritarios, superficies):
            if not grupo:
                continue
            self._picker.InitializePickList()
            for actor in grupo:
                self._picker.AddPickList(actor)
            self._picker.PickFromListOn()
            if self._picker.Pick(x, y, 0, self.plotter.renderer):
                actor = self._picker.GetActor()
                if actor is not None:
                    objeto_id = self._objeto_por_clave.get(_clave(actor))
                    if objeto_id:
                        return objeto_id
        return None

    def _al_cambiar_seleccion(self, objeto_id: str | None, _origen: str) -> None:
        if self._actor_resaltado is not None:
            self.plotter.remove_actor(self._actor_resaltado, render=False)
            self._actor_resaltado = None
        proyecto = self._doc.proyecto
        objeto = proyecto.objeto(objeto_id)
        if objeto is not None and objeto.id in self._mallas:
            if isinstance(objeto, Perforacion):
                radio_min = geometria.RADIO_MINIMO.get(proyecto.diseno.escenario, 0.1)
                resalte = geometria.malla_perforacion(objeto, radio_min, escala_radio=2.2)
                self._actor_resaltado = self.plotter.add_mesh(
                    resalte, color=COLOR_SELECCION, opacity=0.45, pickable=False, reset_camera=False)
            else:
                malla = self._mallas[objeto.id]
                if isinstance(objeto, (Superficie, SuperficieTIN)):
                    malla = malla.outline()
                self._actor_resaltado = self.plotter.add_mesh(
                    malla, color=COLOR_SELECCION, style="wireframe", line_width=5,
                    render_lines_as_tubes=True, lighting=False, pickable=False, reset_camera=False)
        self.plotter.render()

    # -------------------------------------------------------------- capas
    def set_capa_visible(self, capa_id: str, visible: bool) -> None:
        for objeto in self._doc.proyecto.objetos_de_capa(capa_id):
            actor = self._actor_por_objeto.get(objeto.id)
            if actor is not None:
                actor.SetVisibility(bool(visible))
        self._ajustar_leyenda_cotas()
        seleccionado = self._doc.proyecto.objeto(self._doc.seleccion.actual)
        if not visible and seleccionado is not None and seleccionado.capa_id == capa_id:
            self._doc.seleccion.seleccionar(None, origen="visor")
        self.plotter.render()

    # -------------------------------------------------------------- vistas
    def vista_superior(self) -> None:
        self.plotter.view_xy()

    def vista_frontal(self) -> None:
        self.plotter.view_xz()

    def vista_lateral(self) -> None:
        self.plotter.view_yz()

    def vista_isometrica(self) -> None:
        self.plotter.view_isometric()

    def set_calidad(self, nivel: str) -> None:
        """Calidad gráfica: "baja" (rápida), "media" o "alta" (sombras y suavizado)."""
        pl = self.plotter
        for f in (pl.disable_shadows, pl.disable_anti_aliasing):
            try:
                f()
            except Exception:  # noqa: BLE001
                pass
        try:
            if nivel in ("media", "alta"):
                pl.enable_anti_aliasing("ssaa" if nivel == "alta" else "fxaa")
            if nivel == "alta":
                pl.enable_shadows()
        except Exception:  # noqa: BLE001
            pass
        pl.render()

    def set_cuadricula(self, visible: bool) -> None:
        if visible:
            self.plotter.show_grid(xtitle="Este X (m)", ytitle="Norte Y (m)", ztitle="Cota Z (m)",
                                   color=self._c["texto_secundario"], font_size=10, n_zlabels=3)
        else:
            self.plotter.remove_bounds_axes()
        self.plotter.render()

    def ajustar(self) -> None:
        self.plotter.reset_camera()
        self.plotter.render()

    def guardar_imagen(self, ruta: str) -> None:
        self.plotter.screenshot(ruta)

    def cerrar(self) -> None:
        self.plotter.close()
