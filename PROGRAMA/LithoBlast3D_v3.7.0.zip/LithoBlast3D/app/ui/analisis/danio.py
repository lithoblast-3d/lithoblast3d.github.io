"""Zona de daño alrededor de los taladros (solución de Kirsch/Lamé para un cilindro presurizado).

σr(r) = Pb·(a/r)²  ·  Pb = ρe·VOD²/8 (presión de explosión = ½ de la presión de detonación),
reducida por desacople (dc/dh)^2.6. Zona triturada: σ ≥ resistencia a compresión dinámica;
zona fracturada: σ ≥ resistencia a tracción.
"""

from __future__ import annotations

import numpy as np
from matplotlib.path import Path as RutaMpl
from PySide6.QtWidgets import QCheckBox, QLabel

from app.calc import zona_danio as zd
from app.core.modelo import Contorno
from app.ui.analisis.base import DialogoAnalisis, FilaKpi, Tabla, datos_proyecto, grupo, lista, numero
from app.ui.graficos import Grafico


def plano_local(documento):
    """Collares de los taladros y contorno en un plano 2D: frente (horizontal–cota) o planta (x–y)."""
    pr = documento.proyecto
    pozos = pr.perforaciones()
    contornos = [o for o in pr.objetos.values() if isinstance(o, Contorno) and len(o.vertices) >= 3]
    if not pozos:
        return [], None, "planta"
    zs = np.array([p.z for p in pozos])
    if np.ptp(zs) > 0.3:  # frente subterráneo: los collares están en un plano vertical
        xy = np.array([[p.x, p.y] for p in pozos])
        centro = xy.mean(axis=0)
        u, s, vt = np.linalg.svd(xy - centro)
        eje = vt[0] if s[0] > 1e-6 else np.array([1.0, 0.0])
        if eje[0] < 0:
            eje = -eje

        def a2d(x, y, z):
            return (float(np.dot([x - centro[0], y - centro[1]], eje)), float(z))
        modo = "frente"
    else:
        def a2d(x, y, z):
            return (float(x), float(y))
        modo = "planta"
    pts = [(a2d(p.x, p.y, p.z), p) for p in pozos]
    cont = None
    if contornos:
        c = contornos[-1]
        cont = np.array([a2d(*v) for v in c.vertices])
    return pts, cont, modo


class DialogoZonaDanio(DialogoAnalisis):
    def __init__(self, documento, parent=None):
        super().__init__("Zona de daño (Kirsch)", "Esfuerzo radial alrededor de cada taladro cargado, radios de "
                         "trituración y fracturamiento, y cobertura de la sección.", parent)
        self.doc = documento
        self.p = datos_proyecto(documento)
        exp = self.p["explosivo"]
        self.vod = numero(1500, 8000, (exp.vod_ms if exp and exp.vod_ms else 4500), 0, 100, "m/s")
        self.dens_e = numero(0.5, 1.8, exp.densidad_gcc if exp else 1.1, 2, 0.05, "g/cm³")
        self.usar_proyecto = QCheckBox("Usar densidad y VOD de cada explosivo del proyecto")
        self.usar_proyecto.setChecked(True)
        self.exp = numero(1.0, 4.0, 2.6, 2, 0.1)
        self.form.addWidget(grupo("Explosivo", [("", self.usar_proyecto), ("VOD", self.vod), ("Densidad", self.dens_e),
                                                ("Exponente de desacople", self.exp)]))
        self.ucs = numero(5, 400, 120, 0, 5, "MPa")
        self.fd = numero(1, 10, 1.0, 2, 0.5)
        self.t = numero(0.5, 40, 8, 1, 0.5, "MPa")
        self.form.addWidget(grupo("Roca", [("UCS estático", self.ucs), ("Factor dinámico (σcd = f·UCS)", self.fd),
                                           ("Resistencia a tracción", self.t)]))
        self.modo = lista(["Envolvente (máximo)", "Superposición (suma)"])
        self.res = numero(40, 400, 160, 0, 20)
        self.form.addWidget(grupo("Mapa", [("Combinación", self.modo), ("Resolución (celdas)", self.res)]))
        n = QLabel("La superposición supone que todos los taladros actúan a la vez; la envolvente, uno por retardo. "
                   "El modelo es elástico y estático (orden de magnitud): sirve para comparar mallas y ver zonas "
                   "sin cobertura, no reemplaza mediciones de daño.")
        n.setObjectName("TextoSecundario")
        n.setWordWrap(True)
        self.form.addWidget(n)
        self.form.addStretch(1)

        self.kpi = FilaKpi(["Taladros cargados", "Radio triturado", "Radio fracturado", "Cobertura de la sección"])
        self.zona.addWidget(self.kpi)
        tabs = self.pestanas()
        self.g_mapa = Grafico(alto_min=360)
        tabs.addTab(self.g_mapa, "Mapa de esfuerzos")
        self.g_perfil = Grafico()
        tabs.addTab(self.g_perfil, "Atenuación σ(r)")
        self.tabla = Tabla(["Explosivo", "Ø taladro mm", "Ø carga mm", "Pb MPa", "r triturado cm",
                            "r fracturado cm", "Taladros"], solo_lectura=True)
        tabs.addTab(self.tabla, "Por explosivo")
        for w in (self.vod, self.dens_e, self.exp, self.ucs, self.fd, self.t, self.res):
            w.valueChanged.connect(self._calcular_seguro)
        self.modo.currentIndexChanged.connect(self._calcular_seguro)
        self.usar_proyecto.toggled.connect(self._calcular_seguro)
        self._calcular_seguro()

    def calcular(self) -> None:
        pts, cont, modo_plano = plano_local(self.doc)
        pr = self.doc.proyecto
        cargados = [(xy, p) for xy, p in pts if p.explosivo_id and pr.explosivo(p.explosivo_id)]
        if not cargados:
            for k in self.kpi.kpis.values():
                k.poner("—")
            raise ValueError("El proyecto no tiene taladros cargados. Genera o abre una malla primero.")
        sc = self.ucs.value() * self.fd.value()
        st = self.t.value()
        if st >= sc:
            raise ValueError("La resistencia a tracción debe ser menor que la de compresión dinámica")
        taladros, grupos = [], {}
        for (x, y), p in cargados:
            e = pr.explosivo(p.explosivo_id)
            if self.usar_proyecto.isChecked():
                dens = e.densidad_gcc
                vod = e.vod_ms or self.vod.value()
            else:
                dens, vod = self.dens_e.value(), self.vod.value()
            dc = e.diametro_de_carga(p.diametro_mm)
            pb = zd.presion_taladro_mpa(dens, vod, dc, p.diametro_mm, self.exp.value())
            a = p.diametro_mm / 2000
            taladros.append(zd.TaladroPresion(x, y, a, pb))
            g = grupos.setdefault((e.nombre, p.diametro_mm, dc), [pb, 0, e.vod_ms == 0])
            g[1] += 1
        # rejilla
        xs_all = [t.x for t in taladros] + ([*cont[:, 0]] if cont is not None else [])
        ys_all = [t.y for t in taladros] + ([*cont[:, 1]] if cont is not None else [])
        m = 0.5
        x0, x1 = min(xs_all) - m, max(xs_all) + m
        y0, y1 = min(ys_all) - m, max(ys_all) + m
        n = int(self.res.value())
        paso = max(x1 - x0, y1 - y0) / n
        xs = np.arange(x0, x1 + paso, paso)
        ys = np.arange(y0, y1 + paso, paso)
        modo = "max" if self.modo.currentIndex() == 0 else "suma"
        X, Y, S = zd.mapa_esfuerzos(taladros, xs, ys, modo)
        if cont is not None:
            dentro = RutaMpl(cont).contains_points(np.c_[X.ravel(), Y.ravel()]).reshape(X.shape)
        else:
            dentro = np.ones_like(X, bool)
        cob = float(np.mean(S[dentro] >= st)) * 100 if dentro.any() else 0.0

        filas, rc_l, rf_l = [], [], []
        sin_vod = False
        for (nombre, dh, dc), (pb, cuenta, falta) in grupos.items():
            a = dh / 2000
            rc = zd.radio_critico(a, pb, sc)
            rf = zd.radio_critico(a, pb, st)
            rc_l.append(rc); rf_l.append(rf)
            sin_vod |= falta and self.usar_proyecto.isChecked()
            filas.append([nombre, dh, dc, pb, rc * 100, rf * 100, cuenta])
        self.tabla.poner_filas(filas)
        self.kpi["Taladros cargados"].poner(str(len(taladros)), f"vista {'del frente' if modo_plano == 'frente' else 'en planta'}")
        self.kpi["Radio triturado"].poner(f"{max(rc_l) * 100:.1f} cm", f"σ ≥ {sc:.0f} MPa")
        self.kpi["Radio fracturado"].poner(f"{max(rf_l):.2f} m", f"σ ≥ {st:.1f} MPa")
        self.kpi["Cobertura de la sección"].poner(f"{cob:.0f} %", "área con σ ≥ tracción"
                                                  if cont is not None else "sin contorno: área del rectángulo")
        if sin_vod:
            self.avisar(f"Algún explosivo del proyecto no tiene VOD registrada: se usó {self.vod.value():.0f} m/s. "
                        "Complétala en Editar → Explosivos con la ficha técnica.")

        # mapa
        ax = self.g_mapa.limpiar()
        Sm = np.ma.masked_where(~dentro, S) if cont is not None else S
        niveles = np.geomspace(max(st / 4, 0.1), max(float(S.max()), st * 4), 24)
        from matplotlib.colors import LogNorm
        cf = ax.contourf(X, Y, np.clip(Sm, niveles[0], None), levels=niveles, cmap="turbo", norm=LogNorm())
        ax.contour(X, Y, S, levels=[st], colors="#ffffff", linewidths=1.0, linestyles="--")
        ax.contour(X, Y, S, levels=[sc], colors="#e5534b", linewidths=1.2)
        cb = self.g_mapa.figura.colorbar(cf, ax=ax, fraction=0.04, pad=0.02)
        cb.set_label("σ radial (MPa)")
        marcas = [v * 10 ** k for k in range(-1, 5) for v in (1, 2, 5) if niveles[0] <= v * 10 ** k <= niveles[-1]]
        cb.set_ticks(marcas)
        cb.set_ticklabels([f"{v:g}" for v in marcas])
        cb.minorticks_off()
        if cont is not None:
            c = np.vstack([cont, cont[:1]])
            ax.plot(c[:, 0], c[:, 1], color="#e8ebef", lw=1.6)
        vac = [(xy, p) for xy, p in pts if not (p.explosivo_id and pr.explosivo(p.explosivo_id))]
        ax.scatter([t.x for t in taladros], [t.y for t in taladros], s=10, c="#101317", edgecolors="#ffffff",
                   linewidths=0.6, zorder=5)
        if vac:
            ax.scatter([xy[0] for xy, _ in vac], [xy[1] for xy, _ in vac], s=28, facecolors="none",
                       edgecolors="#9aa4af", linewidths=1.0, zorder=5, label="Alivio / sin carga")
            ax.legend(loc="upper right")
        ax.set_aspect("equal")
        ax.set_title("Línea blanca: límite de fracturamiento · roja: trituración")
        ax.set_xlabel("m"); ax.set_ylabel("m")
        ax.grid(False)
        self.g_mapa.actualizar()

        # perfil
        ax = self.g_perfil.limpiar()
        for (nombre, dh, dc), (pb, _, _) in grupos.items():
            a = dh / 2000
            r = np.geomspace(a, max(a * 60, 1.5), 200)
            ax.loglog(r * 100, pb * (a / r) ** 2, label=f"{nombre} (Ø {dh:.0f} mm)")
        ax.axhline(sc, color="#e5534b", ls="--", lw=1)
        ax.text(r[0] * 100, sc * 1.1, f" compresión dinámica {sc:.0f} MPa",
                color="#e5534b", fontsize=8)
        ax.axhline(st, color="#ffffff", ls="--", lw=1)
        ax.text(r[0] * 100, st * 1.1, f" tracción {st:.1f} MPa", color="#ffffff", fontsize=8)
        ax.set_xlabel("Distancia al eje del taladro (cm)")
        ax.set_ylabel("σ radial (MPa)")
        ax.set_title("Atenuación del esfuerzo")
        ax.legend()
        self.g_perfil.actualizar()
