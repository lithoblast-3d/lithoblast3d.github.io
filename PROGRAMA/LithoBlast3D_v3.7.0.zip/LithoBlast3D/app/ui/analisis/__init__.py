"""Ventanas de análisis técnico (fragmentación, daño, dinámica, cimbra, costos, macizo, burden)."""

from __future__ import annotations

from PySide6.QtWidgets import QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from app.ui.tema import ajustar_a_pantalla

# (clave, título, descripción, módulo, clase)
HERRAMIENTAS = [
    ("fragmentacion", "Fragmentación", "Kuz-Ram + Swebrec, comparar escenarios y ajustar a la granulometría medida.",
     "app.ui.analisis.fragmentacion", "DialogoFragmentacion"),
    ("danio", "Zona de daño (Kirsch)", "Mapa de esfuerzos sobre la malla del proyecto, radios de trituración y "
     "fracturamiento, cobertura.", "app.ui.analisis.danio", "DialogoZonaDanio"),
    ("burden", "Comparador de burden", "Nueve fórmulas (Andersen, Ash, Konya, López Jimeno, Rustan, Olofsson, Pearse, Langefors) lado a lado.",
     "app.ui.analisis.burden", "DialogoBurden"),
    ("macizo", "Macizo rocoso", "RMR89, Q, GSI, módulo de deformación, Hoek-Brown, carga de roca y pernos.",
     "app.ui.analisis.macizo", "DialogoMacizo"),
    ("cimbra", "Cimbra metálica", "Arco con carga de Unal: deformada, N, M y verificación de perfiles W.",
     "app.ui.analisis.cimbra", "DialogoCimbra"),
    ("dinamica", "Respuesta dinámica", "Newmark-β y espectro de respuesta desde un registro de aceleración.",
     "app.ui.analisis.dinamica", "DialogoDinamica"),
    ("costos", "Costos del ciclo", "Costo horario de equipos y costo por disparo, metro, m³ y tonelada.",
     "app.ui.analisis.costos", "DialogoCostos"),
]


def abrir(clave: str, documento, parent=None):
    import importlib
    for k, _, _, modulo, clase in HERRAMIENTAS:
        if k == clave:
            cls = getattr(importlib.import_module(modulo), clase)
            dlg = cls(documento, parent)
            dlg.exec()
            return dlg
    raise KeyError(clave)


class DialogoCentroAnalisis(QDialog):
    """Inicio de las herramientas de análisis: una tarjeta por herramienta."""

    def __init__(self, documento, parent=None):
        super().__init__(parent)
        self.doc = documento
        self.setWindowTitle("Centro de análisis")
        v = QVBoxLayout(self)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(12)
        cab = QHBoxLayout()
        t = QLabel("Centro de análisis")
        t.setObjectName("TituloGrande")
        cab.addWidget(t, 1)
        cerrar = QPushButton("Cerrar")
        cerrar.clicked.connect(self.reject)
        cab.addWidget(cerrar)
        v.addLayout(cab)
        s = QLabel("Herramientas de cálculo con los datos del proyecto abierto como punto de partida.")
        s.setObjectName("TextoSecundario")
        v.addWidget(s)
        g = QGridLayout()
        g.setSpacing(12)
        for i, (clave, titulo, desc, _, _) in enumerate(HERRAMIENTAS):
            tarjeta = QFrame()
            tarjeta.setObjectName("Tarjeta")
            tv = QVBoxLayout(tarjeta)
            tv.setContentsMargins(16, 14, 16, 14)
            et = QLabel(titulo)
            et.setObjectName("TituloTarjeta")
            d = QLabel(desc)
            d.setObjectName("TextoSecundario")
            d.setWordWrap(True)
            b = QPushButton("Abrir")
            b.setObjectName("Primario")
            b.clicked.connect(lambda _=False, k=clave: abrir(k, self.doc, self))
            tv.addWidget(et)
            tv.addWidget(d, 1)
            tv.addWidget(b)
            g.addWidget(tarjeta, i // 3, i % 3)
        v.addLayout(g, 1)
        ajustar_a_pantalla(self, 980, 560)
