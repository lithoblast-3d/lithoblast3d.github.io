"""Cimbra metálica: pórtico de patas rectas y arco semicircular, carga de roca de Unal (RMR) y método de rigidez."""

from __future__ import annotations

import math

import numpy as np
from PySide6.QtWidgets import QCheckBox, QLabel

from app.calc import cimbra as cb
from app.calc.macizo import clase
from app.ui.analisis.base import DialogoAnalisis, FilaKpi, Tabla, datos_proyecto, entero, grupo, lista, numero
from app.ui.graficos import Grafico


class DialogoCimbra(DialogoAnalisis):
    def __init__(self, documento=None, parent=None):
        super().__init__("Cimbra metálica", "Análisis del arco con la carga de roca de Unal: deformada, fuerza "
                         "axial, momento flector y verificación del perfil.", parent)
        ancho, alto = 4.0, 4.0
        if documento is not None:
            p = datos_proyecto(documento)
            if not p["tajo"] and p["pozos"]:
                from app.ui.analisis.danio import plano_local
                pts, cont, modo = plano_local(documento)
                if cont is not None and modo == "frente":
                    ancho = round(float(np.ptp(cont[:, 0])), 2) or ancho
                    alto = round(float(np.ptp(cont[:, 1])), 2) or alto
        self.ancho = numero(1.5, 20, ancho, 2, 0.1, "m")
        self.alto = numero(1.5, 20, max(alto, ancho / 2), 2, 0.1, "m")
        self.form.addWidget(grupo("Sección", [("Ancho", self.ancho), ("Alto (piso a clave)", self.alto)]))
        self.perfil = lista(cb.PERFILES, "W6x20")
        self.esp = numero(0.3, 3, 1.0, 2, 0.1, "m")
        self.e = numero(150, 220, 200, 0, 5, "GPa")
        self.fy = numero(200, 500, 250, 0, 5, "MPa")
        self.apoyos = lista(["empotrados", "articulados"])
        self.form.addWidget(grupo("Cimbra", [("Perfil", self.perfil), ("Espaciamiento", self.esp),
                                             ("Módulo E", self.e), ("Fluencia fy", self.fy), ("Apoyos", self.apoyos)]))
        self.rmr = numero(0, 100, 45, 0, 1)
        self.gamma = numero(15, 35, 27, 1, 0.5, "kN/m³")
        self.k = numero(0, 2, 0.0, 2, 0.05)
        self.manual = QCheckBox("Carga distribuida manual")
        self.qman = numero(0, 2000, 50, 1, 5, "kN/m")
        self.l_clase = QLabel("")
        self.l_clase.setObjectName("TextoSecundario")
        self.form.addWidget(grupo("Carga de roca", [("RMR", self.rmr), ("", self.l_clase), ("Peso unitario γ", self.gamma),
                                                    ("Empuje lateral k = qh/q", self.k), ("", self.manual),
                                                    ("q manual", self.qman)]))
        self.narco = entero(8, 60, 16)
        self.npata = entero(2, 20, 4)
        self.escala = numero(0, 5000, 0, 0, 10)
        self.escala.setSpecialValueText("automática")
        self.form.addWidget(grupo("Modelo", [("Elementos en el arco", self.narco), ("Elementos por pata", self.npata),
                                             ("Escala de la deformada", self.escala)]))
        n = QLabel("Carga de Unal: hp = (100 − RMR)/100 · B; q = γ·hp·s (kN/m sobre la proyección horizontal del arco). "
                   "Las cargas se reparten a los nudos (reparto simple). La verificación es σ = N/A + M/S contra fy; "
                   "no incluye pandeo, bloqueo ni uniones.")
        n.setObjectName("TextoSecundario")
        n.setWordWrap(True)
        self.form.addWidget(n)
        self.form.addStretch(1)

        self.kpi = FilaKpi(["Carga q", "N máx (compresión)", "M máx", "σ máx", "Utilización"])
        self.zona.addWidget(self.kpi)
        tabs = self.pestanas()
        self.g_def = Grafico(alto_min=380)
        tabs.addTab(self.g_def, "Geometría y deformada")
        self.g_esf = Grafico(alto_min=380)
        tabs.addTab(self.g_esf, "Diagramas N y M")
        self.t_tabla = Tabla(["Perfil", "A cm²", "Ix cm⁴", "Sx cm³", "kg/m", "σ máx MPa", "Utilización"], solo_lectura=True)
        tabs.addTab(self.t_tabla, "Comparar perfiles")
        for w in (self.ancho, self.alto, self.esp, self.e, self.fy, self.rmr, self.gamma, self.k, self.qman, self.narco,
                  self.npata, self.escala):
            w.valueChanged.connect(self._calcular_seguro)
        for w in (self.perfil, self.apoyos):
            w.currentIndexChanged.connect(self._calcular_seguro)
        self.manual.toggled.connect(self._calcular_seguro)
        self._calcular_seguro()

    def entrada(self, perfil: str | None = None) -> cb.EntradaCimbra:
        return cb.EntradaCimbra(ancho=self.ancho.value(), alto=self.alto.value(), perfil=perfil or self.perfil.currentText(),
                                e_gpa=self.e.value(), fy_mpa=self.fy.value(), espaciamiento=self.esp.value(),
                                rmr=self.rmr.value(), peso_unitario=self.gamma.value(), k_lateral=self.k.value(),
                                apoyos=self.apoyos.currentText(), n_arco=self.narco.value(), n_pata=self.npata.value(),
                                carga_manual=self.qman.value() if self.manual.isChecked() else None)

    def calcular(self) -> None:
        self.l_clase.setText(f"Clase {clase(self.rmr.value())}")
        e = self.entrada()
        r = cb.analizar(e)
        self.kpi["Carga q"].poner(f"{r.q:.1f} kN/m", f"hp = {r.hp:.2f} m")
        self.kpi["N máx (compresión)"].poner(f"{r.n_max:.1f} kN")
        self.kpi["M máx"].poner(f"{r.m_max:.2f} kN·m")
        self.kpi["σ máx"].poner(f"{r.sigma_max:.0f} MPa", f"fy = {e.fy_mpa:.0f} MPa")
        self.kpi["Utilización"].poner(f"{r.utilizacion * 100:.0f} %", "✔ cumple" if r.utilizacion <= 1 else "✖ no cumple")
        if r.utilizacion > 1:
            self.avisar("El perfil no resiste la carga: aumenta el perfil, reduce el espaciamiento o considera "
                        "sostenimiento adicional.")

        # deformada
        nud = r.nudos
        dsp = r.desplazamientos[:, :2]
        umax = float(np.max(np.abs(dsp))) or 1e-9
        esc = self.escala.value() or 0.12 * max(e.ancho, e.alto) / umax
        ax = self.g_def.limpiar()
        ax.plot(nud[:, 0], nud[:, 1], color="#9aa4af", lw=4, alpha=0.45, label="Geometría")
        df = nud + esc * dsp
        ax.plot(df[:, 0], df[:, 1], color="#2ec4b6", lw=2, label=f"Deformada ×{esc:.0f}")
        # flechas de carga sobre el arco
        R = e.ancho / 2
        hw = e.alto - R
        for xx in np.linspace(-R * 0.9, R * 0.9, 9):
            yy = hw + math.sqrt(max(R * R - xx * xx, 0))
            ax.annotate("", (xx, yy), (xx, yy + 0.35 * R), arrowprops=dict(arrowstyle="->", color="#e6b84a", lw=1))
        ax.text(0, e.alto + 0.4 * R, f"q = {r.q:.1f} kN/m", ha="center", color="#e6b84a", fontsize=9)
        ax.plot([-R * 1.3, R * 1.3], [0, 0], color="#5d6670", lw=1)
        ax.set_aspect("equal")
        ax.set_title(f"Desplazamiento máximo {umax * 1000:.2f} mm")
        ax.legend(loc="lower center")
        self.g_def.actualizar()

        # diagramas a lo largo del desarrollo
        s_acum, n_l, m_l = [0.0], [], []
        for (i, j), f in zip(r.elementos, r.fuerzas):
            L = float(np.hypot(*(nud[j] - nud[i])))
            s0 = s_acum[-1]
            s_acum.append(s0 + L)
            n_l += [(s0, f[0]), (s0 + L, -f[3])]
            m_l += [(s0, -f[2]), (s0 + L, f[5])]
        ejes = self.g_esf.limpiar(2, 1, sharex=True)
        a1, a2 = ejes[0][0], ejes[1][0]
        sx, sn = zip(*n_l)
        a1.fill_between(sx, sn, color="#3d8fe0", alpha=0.25)
        a1.plot(sx, sn, color="#3d8fe0")
        a1.set_ylabel("N (kN) · compresión +")
        a1.set_title("Fuerza axial a lo largo de la cimbra")
        sx, sm = zip(*m_l)
        a2.fill_between(sx, sm, color="#e6b84a", alpha=0.25)
        a2.plot(sx, sm, color="#e6b84a")
        a2.set_ylabel("M (kN·m)")
        a2.set_xlabel("Desarrollo desde el apoyo izquierdo (m)")
        a2.set_title("Momento flector")
        for a in (a1, a2):
            for s in (s_acum[e.n_pata], s_acum[e.n_pata + e.n_arco]):
                a.axvline(s, color="#5d6670", ls=":", lw=1)
        self.g_esf.actualizar()

        filas = []
        for nombre, (A, I, S, kg) in cb.PERFILES.items():
            try:
                rr = cb.analizar(self.entrada(nombre))
                filas.append([nombre, A, I, S, kg, rr.sigma_max, f"{rr.utilizacion * 100:.0f} %"
                              + (" ✔" if rr.utilizacion <= 1 else " ✖")])
            except (ValueError, np.linalg.LinAlgError):
                continue
        self.t_tabla.poner_filas(filas)
