"""Fragmentación: predicción Kuz-Ram / Swebrec, comparación de escenarios y ajuste a granulometría medida."""

from __future__ import annotations

import math

import numpy as np
from PySide6.QtWidgets import (
    QCheckBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.calc import fragmentacion as fr
from app.ui.analisis.base import (
    DialogoAnalisis,
    FilaKpi,
    Tabla,
    datos_proyecto,
    exportar_csv,
    grupo,
    lista,
    numero,
)
from app.ui.graficos import Grafico

COL_ESC = ["Escenario", "A", "K kg/m³", "Q kg", "RWS", "B m", "S m", "Ø mm", "W m", "L carga m", "H m"]


class DialogoFragmentacion(DialogoAnalisis):
    def __init__(self, documento, parent=None):
        super().__init__("Fragmentación", "Kuz-Ram (Cunningham 1987) con curva Swebrec (KCO), comparación de "
                         "escenarios y ajuste a una granulometría medida.", parent)
        self.doc = documento
        p = datos_proyecto(documento)
        self.p = p
        exp = p["explosivo"]
        rws = 100.0 * (exp.prp if exp else 1.0)

        # ---------------- datos
        self.rmd = lista(fr.RMD, "Diaclasada verticalmente")
        self.jps = lista(fr.JPS, "0.1 m a tamaño de malla")
        self.jpa = lista(fr.JPA, "Rumbo perpendicular al frente")
        self.dens = numero(1.5, 5.0, p["densidad_roca"], 2, sufijo="t/m³")
        self.ucs = numero(1, 400, 100, 0, 5, "MPa")
        self.e = numero(1, 150, 40, 0, 1, "GPa")
        self.a_manual = QCheckBox("Ingresar A directamente")
        self.a = numero(0.5, 25, 7.0, 2, 0.5)
        self.a_calc = QLabel("A = —")
        self.a_calc.setObjectName("Subtitulo")
        self.form.addWidget(grupo("Factor de roca A", [
            ("Descripción del macizo", self.rmd), ("Espaciado de juntas", self.jps),
            ("Orientación de juntas", self.jpa), ("Densidad", self.dens), ("UCS", self.ucs),
            ("Módulo de Young", self.e), ("", self.a_calc), ("", self.a_manual), ("A", self.a)]))

        k0 = p["factor_carga"] or 0.6
        q0 = p["kg_taladro"] or 2.0
        self.k = numero(0.05, 10, k0, 3, 0.05, "kg/m³")
        self.q = numero(0.1, 5000, q0, 2, 1, "kg")
        self.rws = numero(20, 250, rws, 0, 5)
        self.b = numero(0.1, 20, p["burden"] if p["tajo"] else 0.8, 2, 0.1, "m")
        self.s = numero(0.1, 25, p["espaciamiento"] if p["tajo"] else 0.9, 2, 0.1, "m")
        self.d = numero(20, 400, p["diametro_mm"], 0, 1, "mm")
        self.w = numero(0, 2, 0.05 if not p["tajo"] else 0.2, 3, 0.01, "m")
        self.lcar = numero(0.1, 60, p["long_carga"], 2, 0.1, "m")
        self.bcl = numero(0, 60, 0.0, 2, 0.1, "m")
        self.h = numero(0.3, 60, p["altura"], 2, 0.1, "m")
        self.xmax = numero(0, 5000, 0, 0, 10, "mm")
        self.xmax.setSpecialValueText("automático (mín. B, S)")
        self.form.addWidget(grupo("Voladura", [
            ("Factor de carga K", self.k), ("Carga por taladro Q", self.q), ("RWS (ANFO = 100)", self.rws),
            ("Burden B", self.b), ("Espaciamiento S", self.s), ("Diámetro", self.d),
            ("Desviación W", self.w), ("Longitud de carga L", self.lcar), ("Carga de fondo BCL", self.bcl),
            ("Altura / largo H", self.h), ("Tamaño máximo xmax", self.xmax)]))
        self.parrilla = numero(10, 3000, 600 if p["tajo"] else 300, 0, 10, "mm")
        self.form.addWidget(grupo("Criterio", [("Abertura de parrilla / chancado", self.parrilla)]))
        nota = QLabel("Valores iniciales tomados del proyecto abierto (factor de carga, kg por taladro, "
                      "diámetro y explosivo). Cámbialos libremente.")
        nota.setObjectName("TextoSecundario")
        nota.setWordWrap(True)
        self.form.addWidget(nota)
        self.form.addStretch(1)

        # ---------------- resultados
        self.kpi = FilaKpi(["x50", "x80 (Swebrec)", "n", "b", "% bajo parrilla"])
        self.zona.addWidget(self.kpi)
        tabs = self.pestanas()
        # Curva
        pag = QWidget(); v = QVBoxLayout(pag)
        self.g_curva = Grafico()
        v.addWidget(self.g_curva, 3)
        self.t_pasos = Tabla(["Paso", "Resultado"], solo_lectura=True)
        self.t_pasos.setMaximumHeight(170)
        v.addWidget(self.t_pasos, 1)
        tabs.addTab(pag, "Curva granulométrica")
        # Escenarios
        pag = QWidget(); v = QVBoxLayout(pag)
        fila = QHBoxLayout()
        for texto, fn in (("+ Agregar el actual", self._agregar_actual), ("− Quitar", lambda: self.t_esc.quitar_seleccion()),
                          ("Comparar", self._comparar), ("Exportar CSV", lambda: exportar_csv(self, self.t_res_esc,
                                                                                               "escenarios.csv"))):
            b = QPushButton(texto); b.clicked.connect(fn); fila.addWidget(b)
        fila.addStretch(1)
        v.addLayout(fila)
        self.t_esc = Tabla(COL_ESC)
        self.t_esc.setMaximumHeight(190)
        v.addWidget(self.t_esc)
        self.g_esc = Grafico()
        v.addWidget(self.g_esc, 2)
        self.t_res_esc = Tabla(["Escenario", "x20 mm", "x50 mm", "x80 mm", "xmax mm", "n", "b", "% < parrilla"],
                               solo_lectura=True)
        self.t_res_esc.setMaximumHeight(170)
        v.addWidget(self.t_res_esc)
        tabs.addTab(pag, "Comparar escenarios")
        # Ajuste
        pag = QWidget(); v = QVBoxLayout(pag)
        fila = QHBoxLayout()
        for texto, fn in (("+ Fila", lambda: self.t_med.agregar_fila()), ("− Quitar", lambda: self.t_med.quitar_seleccion()),
                          ("Ajustar curvas", self._ajustar)):
            b = QPushButton(texto); b.clicked.connect(fn); fila.addWidget(b)
        self.btn_calibrar = QPushButton("Usar A calibrado")
        self.btn_calibrar.setEnabled(False)
        self.btn_calibrar.clicked.connect(self._usar_calibrado)
        fila.addWidget(self.btn_calibrar)
        self.con_prediccion = QCheckBox("Mostrar también la predicción Kuz-Ram")
        self.con_prediccion.setChecked(True)
        fila.addWidget(self.con_prediccion)
        fila.addStretch(1)
        v.addLayout(fila)
        h = QHBoxLayout()
        self.t_med = Tabla(["Abertura mm", "% pasante"])
        self.t_med.setMaximumWidth(260)
        h.addWidget(self.t_med)
        self.g_aj = Grafico()
        h.addWidget(self.g_aj, 1)
        v.addLayout(h, 1)
        self.l_aj = QLabel("Ingresa las aberturas de tamiz (o del análisis de imágenes) y el % pasante acumulado, "
                           "luego pulsa «Ajustar curvas».")
        self.l_aj.setObjectName("TextoSecundario")
        self.l_aj.setWordWrap(True)
        v.addWidget(self.l_aj)
        tabs.addTab(pag, "Ajuste a datos medidos")

        for w in (self.rmd, self.jps, self.jpa):
            w.currentIndexChanged.connect(self._calcular_seguro)
        for w in (self.dens, self.ucs, self.e, self.a, self.k, self.q, self.rws, self.b, self.s, self.d, self.w,
                  self.lcar, self.bcl, self.h, self.xmax, self.parrilla):
            w.valueChanged.connect(self._calcular_seguro)
        self.a_manual.toggled.connect(self._calcular_seguro)
        self._calcular_seguro()
        self._agregar_actual()

    # ------------------------------------------------------------------
    def factor_a(self) -> float:
        if self.a_manual.isChecked():
            self.a_calc.setText("A ingresado manualmente")
            return self.a.value()
        r = fr.factor_roca(self.rmd.currentText(), self.jps.currentText(), self.jpa.currentText(),
                           self.dens.value(), self.ucs.value(), self.e.value())
        self.a_calc.setText(f"A = 0.06·(RMD + JF + RDI + HF) = {r['A']:.2f}")
        return r["A"]

    def entrada(self) -> fr.EntradaKuzRam:
        lc = self.lcar.value()
        bcl = min(self.bcl.value(), lc)
        return fr.EntradaKuzRam(a_roca=self.factor_a(), factor_carga=self.k.value(), carga_taladro=self.q.value(),
                                rws=self.rws.value(), burden=self.b.value(), espaciamiento=self.s.value(),
                                diametro_mm=self.d.value(), desviacion=self.w.value(), long_carga=lc,
                                carga_fondo=bcl, carga_columna=lc - bcl, altura=self.h.value(),
                                xmax_mm=self.xmax.value() or None)

    def calcular(self) -> None:
        e = self.entrada()
        r = fr.kuz_ram(e)
        self.res = r
        self.res_a = e.a_roca
        x = fr.tamices_log(1, max(r.xmax_mm * 1.05, 50), 220)
        prr = fr.pasante_rosin(x, r.x50_mm, r.n) * 100
        psw = fr.pasante_swebrec(x, r.x50_mm, r.xmax_mm, r.b) * 100
        par = self.parrilla.value()
        bajo = float(fr.pasante_swebrec([par], r.x50_mm, r.xmax_mm, r.b)[0]) * 100
        self.kpi["x50"].poner(f"{r.x50_mm / 10:.1f} cm", f"{r.x50_mm:.0f} mm")
        self.kpi["x80 (Swebrec)"].poner(f"{r.x80_sw_mm / 10:.1f} cm", f"Rosin-Rammler: {r.x80_rr_mm / 10:.1f} cm")
        self.kpi["n"].poner(f"{r.n:.2f}", "uniformidad")
        self.kpi["b"].poner(f"{r.b:.2f}", f"xmax {r.xmax_mm / 10:.0f} cm")
        self.kpi["% bajo parrilla"].poner(f"{bajo:.0f} %", f"abertura {par:.0f} mm")
        ax = self.g_curva.limpiar()
        ax.semilogx(x, psw, label="Swebrec (KCO)")
        ax.semilogx(x, prr, "--", label="Rosin-Rammler (Kuz-Ram)")
        ax.axvline(par, color="#e6b84a", lw=1, ls=":")
        ax.text(par, 3, f" parrilla {par:.0f} mm", color="#e6b84a", fontsize=8)
        for pct, xx in ((50, r.x50_mm), (80, r.x80_sw_mm)):
            ax.plot([xx], [pct], "o", color="#ffffff", ms=4)
            ax.annotate(f"x{pct} = {xx:.0f} mm", (xx, pct), textcoords="offset points", xytext=(6, -12), fontsize=8)
        ax.set_xlabel("Tamaño (mm)")
        ax.set_ylabel("% pasante acumulado")
        ax.set_ylim(0, 102)
        ax.set_title("Distribución de tamaños predicha")
        ax.legend(loc="upper left")
        self.g_curva.actualizar()
        self.t_pasos.poner_filas([list(p) for p in r.pasos] +
                                 [["x80 Rosin-Rammler / Swebrec", f"{r.x80_rr_mm:.0f} mm / {r.x80_sw_mm:.0f} mm"]])
        if r.n < 0.8:
            self.avisar("Índice de uniformidad bajo (n < 0.8): mucha proporción de finos y bolones; revisa B/d y W.")

    # ------------------------------------------------------------------ escenarios
    def _agregar_actual(self):
        e = self.entrada()
        n = self.t_esc.rowCount() + 1
        self.t_esc.agregar_fila([f"Escenario {n}", round(e.a_roca, 2), e.factor_carga, e.carga_taladro, e.rws,
                                 e.burden, e.espaciamiento, e.diametro_mm, e.desviacion, e.long_carga, e.altura])
        self._comparar()

    def _comparar(self):
        try:
            self.avisar("")
            self._comparar_()
        except (ValueError, ZeroDivisionError) as err:
            self.avisar(str(err), error=True)

    def _comparar_(self):
        ax = self.g_esc.limpiar()
        filas = []
        par = self.parrilla.value()
        x = fr.tamices_log(1, 5000, 240)
        for i in range(self.t_esc.rowCount()):
            v = [self.t_esc.valor(i, j) for j in range(1, len(COL_ESC))]
            if any(a is None for a in v):
                raise ValueError(f"Fila {i + 1}: completa todos los valores numéricos")
            a, k, q, rws, b, s, d, w, lc, h = v
            e = fr.EntradaKuzRam(a_roca=a, factor_carga=k, carga_taladro=q, rws=rws, burden=b, espaciamiento=s,
                                 diametro_mm=d, desviacion=w, long_carga=lc, carga_fondo=0, carga_columna=lc, altura=h)
            r = fr.kuz_ram(e)
            nombre = self.t_esc.texto(i, 0) or f"Escenario {i + 1}"
            xs = x[x <= r.xmax_mm]
            ax.semilogx(xs, fr.pasante_swebrec(xs, r.x50_mm, r.xmax_mm, r.b) * 100, label=nombre)
            filas.append([nombre, fr.tamano_swebrec(0.2, r.x50_mm, r.xmax_mm, r.b), r.x50_mm, r.x80_sw_mm, r.xmax_mm,
                          r.n, r.b, float(fr.pasante_swebrec([par], r.x50_mm, r.xmax_mm, r.b)[0]) * 100])
        ax.axvline(par, color="#e6b84a", lw=1, ls=":")
        ax.set_xlabel("Tamaño (mm)")
        ax.set_ylabel("% pasante")
        ax.set_ylim(0, 102)
        ax.set_title("Curvas Swebrec por escenario")
        if filas:
            ax.legend(loc="upper left")
        self.g_esc.actualizar()
        self.t_res_esc.poner_filas(filas)

    # ------------------------------------------------------------------ ajuste
    def _ajustar(self):
        try:
            self.avisar("")
            self._ajustar_()
        except (ValueError, ZeroDivisionError) as err:
            self.avisar(str(err), error=True)

    def _ajustar_(self):
        xs, ps = [], []
        for i in range(self.t_med.rowCount()):
            a, b = self.t_med.valor(i, 0), self.t_med.valor(i, 1)
            if a is not None and b is not None:
                xs.append(a); ps.append(b)
        if len(xs) < 3:
            raise ValueError("Ingresa al menos 3 puntos (abertura y % pasante)")
        orden = np.argsort(xs)
        xs = np.array(xs)[orden]; ps = np.array(ps)[orden]
        x50s, xmax, b, r2s = fr.ajustar_swebrec(xs, ps)
        x50r, n, r2r = fr.ajustar_rosin(xs, ps)
        ax = self.g_aj.limpiar()
        x = fr.tamices_log(max(xs.min() / 3, 0.1), xmax * 1.05, 220)
        ax.semilogx(xs, ps, "o", color="#ffffff", ms=5, label="Medido")
        ax.semilogx(x, fr.pasante_swebrec(x, x50s, xmax, b) * 100, label=f"Swebrec  R² = {r2s:.3f}")
        ax.semilogx(x, fr.pasante_rosin(x, x50r, n) * 100, "--", label=f"Rosin-Rammler  R² = {r2r:.3f}")
        if self.con_prediccion.isChecked() and getattr(self, "res", None):
            r = self.res
            ax.semilogx(x, fr.pasante_swebrec(x, r.x50_mm, r.xmax_mm, r.b) * 100, ":", color="#e6b84a",
                        label="Predicción Kuz-Ram")
        ax.set_xlabel("Tamaño (mm)"); ax.set_ylabel("% pasante"); ax.set_ylim(0, 102)
        ax.set_title("Ajuste a la granulometría medida")
        ax.legend(loc="upper left")
        self.g_aj.actualizar()
        x80 = fr.tamano_swebrec(0.8, x50s, xmax, b)
        self.l_aj.setText(
            f"Swebrec: x50 = {x50s:.1f} mm · xmax = {xmax:.0f} mm · b = {b:.3f} · x80 = {x80:.1f} mm · R² = {r2s:.4f}\n"
            f"Rosin-Rammler: x50 = {x50r:.1f} mm · n = {n:.3f} · R² = {r2r:.4f}"
            + (f"\nx50 medido / predicho = {x50s / self.res.x50_mm:.2f} → A calibrado = "
               f"{self.res_a * x50s / self.res.x50_mm:.2f} (x50 es proporcional a A)"
               if getattr(self, "res", None) else ""))
        if getattr(self, "res", None) and math.isfinite(x50s):
            self.a_calibrado = self.res_a * x50s / self.res.x50_mm
            self.btn_calibrar.setEnabled(True)

    def _usar_calibrado(self):
        if getattr(self, "a_calibrado", None):
            self.a_manual.setChecked(True)
            self.a.setValue(round(self.a_calibrado, 2))
