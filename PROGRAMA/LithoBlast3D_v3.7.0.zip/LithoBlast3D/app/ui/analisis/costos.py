"""Costos del ciclo de minado: costo horario de equipos y costo por tarea, por disparo, por metro, m³ y tonelada."""

from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtWidgets import QFileDialog, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTableWidgetItem, QVBoxLayout, QWidget

from app.calc import costos as co
from app.ui.analisis.base import DialogoAnalisis, FilaKpi, Tabla, datos_proyecto, exportar_csv, grupo, numero
from app.ui.graficos import Grafico

COL_EQ = ["Equipo", "Precio", "V. residual %", "Neumáticos", "Vida neum. h", "Vida útil h", "Años", "h/año",
          "Interés %", "Seguro %", "F. reparación", "Consumo/h", "Precio energía", "Costo $/h"]
COL_TA = ["Tarea", "Horas", "Trabajadores", "Salario $/h", "Equipos (nombre:h; …)", "Materiales (nombre:cant:precio; …)"]


def _equipos_texto(eq):
    return "; ".join(f"{n}:{h:g}" for n, h in eq)


def _materiales_texto(mat):
    return "; ".join(f"{n}:{c:g}:{p:g}" for n, c, p in mat)


def _leer_equipos(texto):
    res = []
    for parte in filter(None, (t.strip() for t in texto.split(";"))):
        nombre, _, h = parte.rpartition(":")
        if not nombre:
            raise ValueError(f"Equipo mal escrito: «{parte}» (usa nombre:horas)")
        res.append((nombre.strip(), float(h)))
    return res


def _leer_materiales(texto):
    res = []
    for parte in filter(None, (t.strip() for t in texto.split(";"))):
        trozos = parte.rsplit(":", 2)
        if len(trozos) != 3:
            raise ValueError(f"Material mal escrito: «{parte}» (usa nombre:cantidad:precio)")
        res.append((trozos[0].strip(), float(trozos[1]), float(trozos[2])))
    return res


class DialogoCostos(DialogoAnalisis):
    def __init__(self, documento, parent=None):
        super().__init__("Costos del ciclo", "Costo horario de equipos (amortización, interés y seguros, reparaciones, "
                         "neumáticos, energía) y costo de cada tarea del ciclo.", parent, 1400, 860)
        self.doc = documento
        p = datos_proyecto(documento)
        self.avance = numero(0, 100, p["avance"] or 0.0, 2, 0.1, "m")
        self.volumen = numero(0, 1e7, p["volumen"], 1, 1, "m³")
        self.ton = numero(0, 1e8, p["toneladas"], 1, 1, "t")
        self.moneda = QLineEdit("US$")
        self.form.addWidget(grupo("Producción por disparo (del proyecto)", [
            ("Avance", self.avance), ("Volumen", self.volumen), ("Toneladas", self.ton), ("Moneda", self.moneda)]))
        info = QLabel(f"Cantidades del proyecto: {p['kg_total']:.1f} kg de explosivo · {p['n_cargados']} taladros "
                      f"cargados · {p['metros']:.1f} m perforados. Se usan en «Cargar ejemplo» para las tareas de "
                      "perforación y voladura.")
        info.setObjectName("TextoSecundario")
        info.setWordWrap(True)
        self.form.addWidget(info)
        for texto, fn in (("Cargar ejemplo con cantidades del proyecto", self._ejemplo),
                          ("Abrir plantilla de costos…", self._abrir), ("Guardar plantilla de costos…", self._guardar)):
            b = QPushButton(texto)
            b.clicked.connect(fn)
            self.form.addWidget(b)
        n = QLabel("Fórmulas: A = (pa − vr − vn)/vu · Im = pa(n+1)/(2n) · I+S = Im·(i+s)/h año · "
                   "Reparación = f·(pa − vn)/vu · Neumáticos = vn/vida. Los precios del ejemplo son referenciales: "
                   "reemplázalos por tus cotizaciones y salarios.")
        n.setObjectName("TextoSecundario")
        n.setWordWrap(True)
        self.form.addWidget(n)
        self.form.addStretch(1)
        self.p = p

        self.kpi = FilaKpi(["Costo por disparo", "Por metro de avance", "Por m³", "Por tonelada"])
        self.zona.addWidget(self.kpi)
        tabs = self.pestanas()
        pag = QWidget(); v = QVBoxLayout(pag)
        v.addLayout(self._fila_botones(lambda: self.t_eq.agregar_fila(["Nuevo equipo", 10000.0, 20.0, 0.0, 2000.0,
                                                                       10000.0, 5.0, 2000.0, 10.0, 2.0, 0.8, 0.0, 0.0,
                                                                       ""]),
                                       lambda: self.t_eq.quitar_seleccion(), lambda: exportar_csv(self, self.t_eq,
                                                                                                  "equipos.csv")))
        self.t_eq = Tabla(COL_EQ)
        v.addWidget(self.t_eq)
        tabs.addTab(pag, "Equipos")
        pag = QWidget(); v = QVBoxLayout(pag)
        v.addLayout(self._fila_botones(lambda: self.t_ta.agregar_fila(["Nueva tarea", 1.0, 1, 6.0, "", ""]),
                                       lambda: self.t_ta.quitar_seleccion(), lambda: exportar_csv(self, self.t_ta,
                                                                                                  "tareas.csv")))
        self.t_ta = Tabla(COL_TA)
        v.addWidget(self.t_ta)
        tabs.addTab(pag, "Tareas del ciclo")
        pag = QWidget(); v = QVBoxLayout(pag)
        self.g = Grafico(alto_min=300)
        v.addWidget(self.g, 2)
        self.t_res = Tabla(["Tarea", "Personal", "Equipos", "Materiales", "Total", "% del total"], solo_lectura=True)
        v.addWidget(self.t_res, 1)
        b = QPushButton("Exportar resumen CSV")
        b.clicked.connect(lambda: exportar_csv(self, self.t_res, "costos_ciclo.csv"))
        v.addWidget(b)
        tabs.addTab(pag, "Resumen")
        self.tabs = tabs
        self._ejemplo()
        for w in (self.avance, self.volumen, self.ton):
            w.valueChanged.connect(self._calcular_seguro)
        self.t_eq.itemChanged.connect(lambda *_: self._calcular_seguro())
        self.t_ta.itemChanged.connect(lambda *_: self._calcular_seguro())

    def _fila_botones(self, agregar, quitar, exportar):
        h = QHBoxLayout()
        for texto, fn in (("+ Agregar", agregar), ("− Quitar", quitar), ("Exportar CSV", exportar)):
            b = QPushButton(texto); b.clicked.connect(fn); h.addWidget(b)
        h.addStretch(1)
        return h

    # ---------------------------------------------------------------- datos
    def _poner(self, tareas, catalogo):
        self.t_eq.blockSignals(True); self.t_ta.blockSignals(True)
        self.t_eq.setRowCount(0); self.t_ta.setRowCount(0)
        for e in catalogo.values():
            self.t_eq.agregar_fila([e.nombre, e.precio, e.valor_residual_pct, e.neumaticos, e.vida_neumaticos_h,
                                    e.vida_util_h, e.anios, e.horas_anio, e.interes_pct, e.seguro_pct,
                                    e.factor_reparacion, e.consumo_h, e.precio_energia, ""])
        for t in tareas:
            self.t_ta.agregar_fila([t.nombre, t.horas, t.trabajadores, t.salario_h, _equipos_texto(t.equipos),
                                    _materiales_texto(t.materiales)])
        self.t_eq.blockSignals(False); self.t_ta.blockSignals(False)
        self._calcular_seguro()

    def _ejemplo(self):
        p = self.p
        tareas, cat = co.ejemplo(round(p["kg_total"], 2) or 30.0, p["n_cargados"] or 40, round(p["metros"], 1) or 70.0)
        self._poner(tareas, cat)

    def leer(self):
        catalogo = {}
        for i in range(self.t_eq.rowCount()):
            nombre = self.t_eq.texto(i, 0)
            if not nombre:
                continue
            v = [self.t_eq.valor(i, j) for j in range(1, 13)]
            if any(x is None for x in v):
                raise ValueError(f"Equipo «{nombre}»: completa todos los valores numéricos")
            catalogo[nombre] = co.Equipo(nombre, *v)
            if catalogo[nombre].vida_util_h <= 0 or catalogo[nombre].anios <= 0 or catalogo[nombre].horas_anio <= 0:
                raise ValueError(f"Equipo «{nombre}»: vida útil, años y horas/año deben ser mayores que cero")
        tareas = []
        for i in range(self.t_ta.rowCount()):
            nombre = self.t_ta.texto(i, 0)
            if not nombre:
                continue
            h, tr, sal = self.t_ta.valor(i, 1, 0.0), self.t_ta.valor(i, 2, 0.0), self.t_ta.valor(i, 3, 0.0)
            eq = _leer_equipos(self.t_ta.texto(i, 4))
            faltan = [n for n, _ in eq if n not in catalogo]
            if faltan:
                raise ValueError(f"Tarea «{nombre}»: el equipo «{faltan[0]}» no está en la tabla de equipos")
            tareas.append(co.Tarea(nombre, h, int(tr), sal, eq, _leer_materiales(self.t_ta.texto(i, 5))))
        return tareas, catalogo

    def calcular(self) -> None:
        tareas, catalogo = self.leer()
        self.t_eq.blockSignals(True)
        for i in range(self.t_eq.rowCount()):
            nombre = self.t_eq.texto(i, 0)
            if nombre in catalogo:
                self.t_eq.setItem(i, 13, QTableWidgetItem(f"{catalogo[nombre].costo_horario()['Total']:.2f}"))
        self.t_eq.blockSignals(False)
        r = co.resumen(tareas, catalogo, self.avance.value(), self.volumen.value(), self.ton.value())
        m = self.moneda.text().strip() or "$"
        self.kpi["Costo por disparo"].poner(f"{m} {r['total']:,.0f}", f"{len(tareas)} tareas")
        for clave, k, u in (("por_m", "Por metro de avance", "m"), ("por_m3", "Por m³", "m³"), ("por_t", "Por tonelada", "t")):
            self.kpi[k].poner(f"{m} {r[clave]:,.2f}" if r[clave] is not None else "—", f"/{u}" if r[clave] else "falta el dato")
        tot = r["total"] or 1.0
        self.t_res.poner_filas([[n, c["Personal"], c["Equipos"], c["Materiales"], c["Total"],
                                 f"{c['Total'] / tot * 100:.1f} %"] for n, c in r["filas"]] +
                               [["TOTAL", sum(c["Personal"] for _, c in r["filas"]),
                                 sum(c["Equipos"] for _, c in r["filas"]), sum(c["Materiales"] for _, c in r["filas"]),
                                 r["total"], "100 %"]])
        ejes = self.g.limpiar(1, 2, gridspec_kw={"width_ratios": [3, 2]})
        a1, a2 = ejes[0][0], ejes[0][1]
        nombres = [n for n, _ in r["filas"]]
        izq = [0.0] * len(nombres)
        for comp, col in (("Personal", "#3d8fe0"), ("Equipos", "#2ec4b6"), ("Materiales", "#e6b84a")):
            vals = [c[comp] for _, c in r["filas"]]
            a1.barh(nombres, vals, left=izq, color=col, label=comp)
            izq = [a + b for a, b in zip(izq, vals)]
        a1.invert_yaxis()
        a1.set_xlabel(m)
        a1.set_title("Costo por tarea")
        a1.legend(loc="lower right")
        comps = {k: sum(c[k] for _, c in r["filas"]) for k in ("Personal", "Equipos", "Materiales")}
        if sum(comps.values()) > 0:
            a2.pie(list(comps.values()), labels=list(comps), colors=["#3d8fe0", "#2ec4b6", "#e6b84a"],
                   autopct="%1.0f%%", startangle=90, wedgeprops={"width": 0.42, "edgecolor": "#1b1f24"},
                   textprops={"color": "#e8ebef", "fontsize": 8.5})
        a2.set_title("Distribución")
        a2.set_aspect("equal")
        self.g.actualizar()

    # ---------------------------------------------------------------- plantillas
    def _guardar(self):
        try:
            tareas, cat = self.leer()
        except ValueError as e:
            self.avisar(str(e), error=True)
            return
        ruta, _ = QFileDialog.getSaveFileName(self, "Guardar plantilla de costos", "costos_ciclo.json", "JSON (*.json)")
        if not ruta:
            return
        datos = {"moneda": self.moneda.text(),
                 "equipos": [vars(e) for e in cat.values()],
                 "tareas": [{"nombre": t.nombre, "horas": t.horas, "trabajadores": t.trabajadores,
                             "salario_h": t.salario_h, "equipos": t.equipos, "materiales": t.materiales} for t in tareas]}
        Path(ruta).write_text(json.dumps(datos, ensure_ascii=False, indent=1), encoding="utf-8")

    def _abrir(self):
        ruta, _ = QFileDialog.getOpenFileName(self, "Abrir plantilla de costos", "", "JSON (*.json)")
        if not ruta:
            return
        try:
            d = json.loads(Path(ruta).read_text(encoding="utf-8"))
            cat = {e["nombre"]: co.Equipo(**e) for e in d["equipos"]}
            tareas = [co.Tarea(t["nombre"], t["horas"], t["trabajadores"], t["salario_h"],
                               [tuple(x) for x in t["equipos"]], [tuple(x) for x in t["materiales"]]) for t in d["tareas"]]
        except (OSError, ValueError, KeyError, TypeError) as e:
            self.avisar(f"No se pudo leer la plantilla: {e}", error=True)
            return
        self.moneda.setText(d.get("moneda", "US$"))
        self._poner(tareas, cat)
