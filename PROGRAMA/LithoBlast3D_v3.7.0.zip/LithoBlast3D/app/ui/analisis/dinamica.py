"""Respuesta dinámica de un oscilador de 1 GDL (Newmark-β, aceleración promedio) y espectro de respuesta."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from PySide6.QtWidgets import QFileDialog, QLabel, QPushButton

from app.calc import dinamica as dn
from app.ui.analisis.base import DialogoAnalisis, FilaKpi, grupo, lista, numero, entero
from app.ui.graficos import Grafico


class DialogoDinamica(DialogoAnalisis):
    def __init__(self, documento=None, parent=None):
        super().__init__("Respuesta dinámica (Newmark)", "Respuesta en el tiempo de una estructura de 1 GDL ante "
                         "un registro de aceleración y su espectro de respuesta (Sd, Sv, Sa).", parent)
        self.registro = None  # (dt, ag m/s², nombre)
        self.fuente = lista(["Registro de ejemplo (voladura sintética)", "Archivo CSV / TXT (t [s], a [g])"])
        self.btn_archivo = QPushButton("Abrir registro…")
        self.btn_archivo.clicked.connect(self._abrir)
        self.l_archivo = QLabel("Ningún archivo cargado")
        self.l_archivo.setObjectName("TextoSecundario")
        self.l_archivo.setWordWrap(True)
        self.form.addWidget(grupo("Registro", [("Fuente", self.fuente), ("", self.btn_archivo), ("", self.l_archivo)]))
        self.ppv = numero(0.5, 500, 20, 1, 1, "mm/s")
        self.frec = numero(2, 200, 30, 1, 1, "Hz")
        self.nret = entero(1, 60, 8)
        self.interv = numero(1, 500, 25, 0, 1, "ms")
        self.dur = numero(0.2, 10, 1.0, 2, 0.1, "s")
        self.form.addWidget(grupo("Registro de ejemplo", [("PPV", self.ppv), ("Frecuencia dominante", self.frec),
                                                          ("N.º de retardos", self.nret), ("Intervalo", self.interv),
                                                          ("Duración", self.dur)]))
        self.periodo = numero(0.005, 10, 0.1, 3, 0.01, "s")
        self.xi = numero(0, 50, 5, 1, 0.5, "%")
        self.form.addWidget(grupo("Estructura (oscilador)", [("Periodo T", self.periodo), ("Amortiguamiento ξ", self.xi)]))
        self.tmin = numero(0.005, 1, 0.01, 3, 0.005, "s")
        self.tmax = numero(0.05, 20, 2.0, 2, 0.1, "s")
        self.npt = entero(10, 400, 120)
        self.form.addWidget(grupo("Espectro", [("T mínimo", self.tmin), ("T máximo", self.tmax), ("Puntos", self.npt)]))
        n = QLabel("Newmark-β con γ = 1/2 y β = 1/4 (aceleración promedio, incondicionalmente estable). "
                   "El registro de ejemplo es sintético (suma de pulsos amortiguados): sirve para practicar; "
                   "carga un registro medido del sismógrafo para resultados reales.")
        n.setObjectName("TextoSecundario")
        n.setWordWrap(True)
        self.form.addWidget(n)
        self.form.addStretch(1)

        self.kpi = FilaKpi(["PGA del registro", "Desplazamiento máx.", "Aceleración abs. máx.", "Sa máx. espectro"])
        self.zona.addWidget(self.kpi)
        tabs = self.pestanas()
        self.g_tiempo = Grafico(alto_min=380)
        tabs.addTab(self.g_tiempo, "Respuesta en el tiempo")
        self.g_esp = Grafico(alto_min=380)
        tabs.addTab(self.g_esp, "Espectro de respuesta")
        self.fuente.currentIndexChanged.connect(self._calcular_seguro)
        for w in (self.ppv, self.frec, self.nret, self.interv, self.dur, self.periodo, self.xi, self.tmin, self.tmax,
                  self.npt):
            w.valueChanged.connect(self._calcular_seguro)
        self._calcular_seguro()

    def _abrir(self):
        ruta, _ = QFileDialog.getOpenFileName(self, "Registro de aceleración", "", "Texto (*.csv *.txt *.dat);;Todos (*)")
        if not ruta:
            return
        try:
            dt, ag = dn.leer_registro_csv(Path(ruta).read_text(encoding="utf-8", errors="ignore"))
        except ValueError as e:
            self.avisar(str(e), error=True)
            return
        self.registro = (dt, ag, Path(ruta).name)
        self.l_archivo.setText(f"{Path(ruta).name}: {len(ag)} muestras, dt = {dt * 1000:.2f} ms")
        self.fuente.setCurrentIndex(1)
        self._calcular_seguro()

    def senal(self):
        if self.fuente.currentIndex() == 1:
            if not self.registro:
                raise ValueError("Abre un archivo con dos columnas: tiempo (s) y aceleración (g)")
            dt, ag, nombre = self.registro
            return dt, ag, nombre
        t, ag, _ = dn.registro_sintetico(self.dur.value(), 0.0005, self.frec.value(), self.ppv.value(),
                                         self.nret.value(), self.interv.value())
        return 0.0005, ag, "Ejemplo sintético"

    def calcular(self) -> None:
        dt, ag, nombre = self.senal()
        xi = self.xi.value() / 100
        r = dn.newmark_sdof(ag, dt, self.periodo.value(), xi)
        if self.tmax.value() <= self.tmin.value():
            raise ValueError("El periodo máximo debe ser mayor que el mínimo")
        T = np.geomspace(self.tmin.value(), self.tmax.value(), self.npt.value())
        T, sd, sv, sa = dn.espectro(ag, dt, T, xi)
        g = dn.G
        self.kpi["PGA del registro"].poner(f"{np.max(np.abs(ag)) / g:.3f} g", nombre)
        self.kpi["Desplazamiento máx."].poner(f"{np.max(np.abs(r.u)) * 1000:.3f} mm", f"T = {self.periodo.value():g} s")
        self.kpi["Aceleración abs. máx."].poner(f"{np.max(np.abs(r.a_abs)) / g:.3f} g", f"ξ = {self.xi.value():g} %")
        i = int(np.argmax(sa))
        self.kpi["Sa máx. espectro"].poner(f"{sa[i] / g:.3f} g", f"en T = {T[i]:.3f} s")

        ejes = self.g_tiempo.limpiar(3, 1, sharex=True)
        t = r.t
        ejes[0][0].plot(t, ag / g, lw=0.9)
        ejes[0][0].set_ylabel("üg (g)")
        ejes[0][0].set_title("Aceleración del terreno")
        ejes[1][0].plot(t, r.u * 1000, lw=1.1, color="#3d8fe0")
        ejes[1][0].set_ylabel("u (mm)")
        ejes[1][0].set_title("Desplazamiento relativo")
        ejes[2][0].plot(t, r.a_abs / g, lw=0.9, color="#e6b84a")
        ejes[2][0].set_ylabel("ü abs (g)")
        ejes[2][0].set_xlabel("Tiempo (s)")
        ejes[2][0].set_title("Aceleración absoluta")
        self.g_tiempo.actualizar()

        ejes = self.g_esp.limpiar(1, 3)
        for ax, y, et, c in ((ejes[0][0], sd * 1000, "Sd (mm)", "#3d8fe0"), (ejes[0][1], sv * 1000, "Sv (mm/s)", "#2ec4b6"),
                             (ejes[0][2], sa / g, "Sa (g)", "#e6b84a")):
            ax.plot(T, y, color=c)
            ax.axvline(self.periodo.value(), color="#9aa4af", ls=":", lw=1)
            ax.set_xscale("log")
            ax.set_xlabel("Periodo T (s)")
            ax.set_title(et)
        self.g_esp.actualizar()
