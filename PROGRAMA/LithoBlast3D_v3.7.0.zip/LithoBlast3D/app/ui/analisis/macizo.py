"""Clasificación del macizo rocoso: RMR89, Q de Barton, GSI, módulo de deformación, Hoek-Brown y sostenimiento."""

from __future__ import annotations

import numpy as np
from PySide6.QtWidgets import QLabel

from app.calc import macizo as mz
from app.ui.analisis.base import DialogoAnalisis, FilaKpi, Tabla, grupo, lista, numero
from app.ui.graficos import Grafico


class DialogoMacizo(DialogoAnalisis):
    def __init__(self, documento=None, parent=None):
        super().__init__("Macizo rocoso", "RMR89 (Bieniawski), Q (Barton), GSI, módulo de deformación, parámetros "
                         "de Hoek-Brown, carga de roca y longitud de pernos.", parent)
        self.ucs = numero(0.5, 400, 80, 1, 5, "MPa")
        self.rqd = numero(0, 100, 65, 0, 5, "%")
        self.esp = numero(0.01, 5, 0.4, 2, 0.05, "m")
        self.cond = lista(mz.CONDICION_JUNTAS, list(mz.CONDICION_JUNTAS)[1])
        self.agua = lista(mz.AGUA, "Húmedo")
        self.orient = lista(mz.ORIENTACION_TUNEL, "Favorable")
        self.form.addWidget(grupo("RMR89", [("UCS (roca intacta)", self.ucs), ("RQD", self.rqd),
                                            ("Espaciado de juntas", self.esp), ("Condición de juntas", self.cond),
                                            ("Agua subterránea", self.agua), ("Orientación (túnel)", self.orient)]))
        self.jn = numero(0.5, 20, 9, 1, 0.5)
        self.jr = numero(0.5, 4, 1.5, 1, 0.5)
        self.ja = numero(0.75, 20, 2, 2, 0.25)
        self.jw = numero(0.05, 1, 1, 2, 0.05)
        self.srf = numero(0.5, 400, 1, 1, 0.5)
        self.form.addWidget(grupo("Q de Barton", [("Jn (n.º de familias)", self.jn), ("Jr (rugosidad)", self.jr),
                                                  ("Ja (alteración)", self.ja), ("Jw (agua)", self.jw),
                                                  ("SRF (esfuerzos)", self.srf)]))
        self.ei = numero(1, 150, 40, 0, 1, "GPa")
        self.mi = numero(4, 35, 15, 0, 1)
        self.d = numero(0, 1, 0.5, 2, 0.1)
        self.form.addWidget(grupo("Roca intacta y voladura", [("Ei (módulo intacto)", self.ei), ("mi (Hoek-Brown)", self.mi),
                                                              ("D (daño por voladura)", self.d)]))
        self.ancho = numero(1, 30, 4, 1, 0.5, "m")
        self.esr = lista(mz.ESR, "Labores permanentes")
        self.gamma = numero(15, 35, 27, 1, 0.5, "kN/m³")
        self.form.addWidget(grupo("Excavación", [("Ancho (luz)", self.ancho), ("Tipo de labor (ESR)", self.esr),
                                                 ("Peso unitario", self.gamma)]))
        n = QLabel("Correlaciones: RMR = 9·lnQ + 44 · GSI = RMR89 − 5 · Em de Bieniawski (RMR > 50), Serafim-Pereira, "
                   "Nicholson-Bieniawski y Hoek-Diederichs · carga de Unal hp = (100 − RMR)/100·B · "
                   "perno L = 2 + 0.15·B/ESR. D = 0 voladura controlada excelente; 0.5–0.8 voladura convencional.")
        n.setObjectName("TextoSecundario")
        n.setWordWrap(True)
        self.form.addWidget(n)
        self.form.addStretch(1)

        self.kpi = FilaKpi(["RMR89", "Q", "GSI", "Em (Hoek-Diederichs)", "Perno"])
        self.zona.addWidget(self.kpi)
        tabs = self.pestanas()
        self.t_res = Tabla(["Parámetro", "Valor", "Nota"], solo_lectura=True)
        tabs.addTab(self.t_res, "Resultados")
        self.g_em = Grafico(alto_min=340)
        tabs.addTab(self.g_em, "Módulo de deformación")
        self.g_hb = Grafico(alto_min=340)
        tabs.addTab(self.g_hb, "Envolvente Hoek-Brown")
        for w in (self.ucs, self.rqd, self.esp, self.jn, self.jr, self.ja, self.jw, self.srf, self.ei, self.mi, self.d,
                  self.ancho, self.gamma):
            w.valueChanged.connect(self._calcular_seguro)
        for w in (self.cond, self.agua, self.orient, self.esr):
            w.currentIndexChanged.connect(self._calcular_seguro)
        self._calcular_seguro()

    def calcular(self) -> None:
        r = mz.rmr89(self.ucs.value(), self.rqd.value(), self.esp.value(), self.cond.currentText(),
                     self.agua.currentText(), self.orient.currentText())
        rmr = r["RMR89"]
        q = mz.q_barton(self.rqd.value(), self.jn.value(), self.jr.value(), self.ja.value(), self.jw.value(),
                        self.srf.value())
        gsi = mz.gsi_desde_rmr(r["RMR básico"])
        d = self.d.value()
        em_hd = mz.em_hoek_diederichs(gsi, d)
        em_b = mz.em_bieniawski(rmr)
        em_s = mz.em_serafim(rmr)
        em_n = mz.em_nicholson(rmr, self.ei.value())
        hb = mz.hoek_brown(gsi, self.mi.value(), d)
        esr = mz.ESR[self.esr.currentText()]
        hp = mz.carga_unal(rmr, self.ancho.value())
        lp = mz.longitud_perno(self.ancho.value(), esr)
        self.kpi["RMR89"].poner(f"{rmr:.0f}", f"Clase {mz.clase(rmr)}")
        self.kpi["Q"].poner(f"{q:.2f}" if q < 100 else f"{q:.0f}", f"RMR desde Q = {mz.rmr_desde_q(q):.0f}")
        self.kpi["GSI"].poner(f"{gsi:.0f}", "RMR89 básico − 5")
        self.kpi["Em (Hoek-Diederichs)"].poner(f"{em_hd:.1f} GPa", f"D = {d:g}")
        self.kpi["Perno"].poner(f"{lp:.2f} m", f"ESR = {esr:g}")
        filas = [[k, f"{v:g}", "puntaje"] for k, v in r.items() if k not in ("RMR89",)]
        filas += [
            ["RMR89 (ajustado)", f"{rmr:.0f}", mz.clase(rmr)],
            ["Q de Barton", f"{q:.3f}", f"RQD/Jn · Jr/Ja · Jw/SRF"],
            ["Q estimado desde RMR", f"{mz.q_desde_rmr(rmr):.3f}", "Q = exp((RMR − 44)/9)"],
            ["GSI", f"{gsi:.0f}", "GSI = RMR89 básico − 5 (seco)"],
            ["Em Bieniawski", f"{em_b:.1f} GPa" if em_b is not None else "—", "2·RMR − 100 (válido RMR > 50)"],
            ["Em Serafim-Pereira", f"{em_s:.1f} GPa", "10^((RMR − 10)/40)"],
            ["Em Nicholson-Bieniawski", f"{em_n:.1f} GPa", "Ei·(0.0028·RMR² + 0.9·e^(RMR/22.82))/100"],
            ["Em Hoek-Diederichs", f"{em_hd:.1f} GPa", "100 000·(1 − D/2)/(1 + e^((75 + 25D − GSI)/11)) MPa"],
            ["mb", f"{hb['mb']:.3f}", "mi·e^((GSI − 100)/(28 − 14D))"],
            ["s", f"{hb['s']:.5f}", "e^((GSI − 100)/(9 − 3D))"],
            ["a", f"{hb['a']:.3f}", "½ + (e^(−GSI/15) − e^(−20/3))/6"],
            ["Resistencia del macizo σcm (a compresión simple)", f"{self.ucs.value() * hb['s'] ** hb['a']:.2f} MPa",
             "σci·s^a"],
            ["Altura de carga de roca hp (Unal)", f"{hp:.2f} m", "(100 − RMR)/100 · B"],
            ["Presión de soporte", f"{hp * self.gamma.value():.1f} kPa", "γ·hp"],
            ["Longitud de perno", f"{lp:.2f} m", "2 + 0.15·B/ESR (Barton)"],
            ["Luz máxima sin soporte (Barton)", f"{2 * esr * q ** 0.4:.1f} m", "2·ESR·Q^0.4"],
        ]
        self.t_res.poner_filas(filas)

        ax = self.g_em.limpiar()
        R = np.linspace(5, 100, 200)
        ax.plot(R, [mz.em_serafim(x) for x in R], label="Serafim-Pereira")
        ax.plot(R, [mz.em_nicholson(x, self.ei.value()) for x in R], label="Nicholson-Bieniawski")
        ax.plot(R, [mz.em_hoek_diederichs(x - 5, d) for x in R], label=f"Hoek-Diederichs (D = {d:g})")
        rb = R[R > 50]
        ax.plot(rb, 2 * rb - 100, label="Bieniawski")
        ax.axvline(rmr, color="#9aa4af", ls=":", lw=1)
        ax.plot([rmr], [em_hd], "o", color="#ffffff")
        ax.set_yscale("log")
        ax.set_xlabel("RMR")
        ax.set_ylabel("Em (GPa)")
        ax.set_title("Módulo de deformación del macizo")
        ax.legend()
        self.g_em.actualizar()

        ax = self.g_hb.limpiar()
        sci = self.ucs.value()
        s3 = np.linspace(-sci * hb["s"] / hb["mb"] * 0.999, 0.25 * sci, 200)
        s1 = s3 + sci * np.clip(hb["mb"] * s3 / sci + hb["s"], 0, None) ** hb["a"]
        ax.plot(s3, s1, label=f"Macizo (GSI {gsi:.0f})")
        hi = mz.hoek_brown(100, self.mi.value(), 0)
        s3i = np.linspace(-sci / self.mi.value() * 0.999, 0.25 * sci, 200)
        ax.plot(s3i, s3i + sci * np.clip(hi["mb"] * s3i / sci + 1, 0, None) ** 0.5, "--", label="Roca intacta")
        ax.axhline(0, color="#5d6670", lw=0.8)
        ax.axvline(0, color="#5d6670", lw=0.8)
        ax.set_xlabel("σ3 (MPa)")
        ax.set_ylabel("σ1 (MPa)")
        ax.set_title("Criterio de Hoek-Brown generalizado")
        ax.legend()
        self.g_hb.actualizar()
