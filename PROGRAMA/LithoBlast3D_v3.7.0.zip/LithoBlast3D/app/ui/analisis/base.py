"""Piezas comunes de las ventanas de análisis: formulario a la izquierda, gráficos y resultados a la derecha."""

from __future__ import annotations

import csv

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.ui.tema import ajustar_a_pantalla


def numero(minimo: float, maximo: float, valor: float, decimales: int = 2, paso: float | None = None,
           sufijo: str = "") -> QDoubleSpinBox:
    c = QDoubleSpinBox()
    c.setRange(minimo, maximo)
    c.setDecimals(decimales)
    c.setValue(valor)
    c.setSingleStep(paso if paso is not None else 10 ** -max(decimales - 1, 0))
    if sufijo:
        c.setSuffix(" " + sufijo)
    c.setKeyboardTracking(False)
    return c


def entero(minimo: int, maximo: int, valor: int, sufijo: str = "") -> QSpinBox:
    c = QSpinBox()
    c.setRange(minimo, maximo)
    c.setValue(valor)
    if sufijo:
        c.setSuffix(" " + sufijo)
    c.setKeyboardTracking(False)
    return c


def lista(opciones, actual=None) -> QComboBox:
    c = QComboBox()
    c.addItems([str(o) for o in opciones])
    if actual is not None:
        c.setCurrentText(str(actual))
    return c


def grupo(titulo: str, filas: list[tuple[str, QWidget]]) -> QGroupBox:
    g = QGroupBox(titulo)
    f = QFormLayout(g)
    f.setLabelAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    f.setHorizontalSpacing(10)
    f.setVerticalSpacing(7)
    for texto, w in filas:
        if texto:
            f.addRow(texto, w)
        else:
            f.addRow(w)
    return g


class Kpi(QFrame):
    """Tarjeta con un número grande y su título."""

    def __init__(self, titulo: str, parent=None):
        super().__init__(parent)
        self.setObjectName("Tarjeta")
        v = QVBoxLayout(self)
        v.setContentsMargins(14, 10, 14, 10)
        v.setSpacing(2)
        t = QLabel(titulo)
        t.setObjectName("KpiTitulo")
        self.valor = QLabel("—")
        self.valor.setObjectName("Kpi")
        self.nota = QLabel("")
        self.nota.setObjectName("TextoSecundario")
        v.addWidget(t)
        v.addWidget(self.valor)
        v.addWidget(self.nota)

    def poner(self, valor: str, nota: str = "") -> None:
        self.valor.setText(valor)
        self.nota.setText(nota)


class FilaKpi(QWidget):
    def __init__(self, titulos: list[str], parent=None):
        super().__init__(parent)
        g = QGridLayout(self)
        g.setContentsMargins(0, 0, 0, 0)
        g.setSpacing(10)
        self.kpis = {}
        for i, t in enumerate(titulos):
            k = Kpi(t)
            g.addWidget(k, 0, i)
            self.kpis[t] = k

    def __getitem__(self, titulo: str) -> Kpi:
        return self.kpis[titulo]


class Tabla(QTableWidget):
    """Tabla editable de números/texto con utilidades de lectura y exportación."""

    def __init__(self, columnas: list[str], parent=None, solo_lectura: bool = False):
        super().__init__(0, len(columnas), parent)
        self.setHorizontalHeaderLabels(columnas)
        self.verticalHeader().setVisible(False)
        self.setAlternatingRowColors(True)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.solo_lectura = solo_lectura
        if solo_lectura:
            self.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)

    def poner_filas(self, filas: list[list]) -> None:
        self.blockSignals(True)
        self.setRowCount(len(filas))
        for i, fila in enumerate(filas):
            for j, v in enumerate(fila):
                if isinstance(v, float):
                    texto = f"{v:,.2f}" if self.solo_lectura else f"{v:g}"
                else:
                    texto = "" if v is None else str(v)
                it = QTableWidgetItem(texto)
                if isinstance(v, (int, float)):
                    it.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                self.setItem(i, j, it)
        self.blockSignals(False)

    def texto(self, fila: int, col: int) -> str:
        it = self.item(fila, col)
        return it.text().strip() if it else ""

    def valor(self, fila: int, col: int, defecto: float | None = None) -> float | None:
        t = self.texto(fila, col).replace(",", "")
        try:
            return float(t)
        except ValueError:
            return defecto

    def agregar_fila(self, valores: list | None = None) -> None:
        n = self.rowCount()
        self.insertRow(n)
        for j, v in enumerate(valores or [""] * self.columnCount()):
            self.setItem(n, j, QTableWidgetItem("" if v is None else (f"{v:g}" if isinstance(v, float) else str(v))))

    def quitar_seleccion(self) -> None:
        filas = sorted({i.row() for i in self.selectedIndexes()}, reverse=True)
        if not filas and self.rowCount():
            filas = [self.rowCount() - 1]
        for f in filas:
            self.removeRow(f)

    def filas_texto(self) -> list[list[str]]:
        cab = [self.horizontalHeaderItem(j).text() for j in range(self.columnCount())]
        return [cab] + [[self.texto(i, j) for j in range(self.columnCount())] for i in range(self.rowCount())]


def exportar_csv(parent, tabla: Tabla, nombre: str) -> None:
    ruta, _ = QFileDialog.getSaveFileName(parent, "Exportar tabla", nombre, "CSV (*.csv)")
    if not ruta:
        return
    with open(ruta, "w", newline="", encoding="utf-8-sig") as f:
        csv.writer(f, delimiter=";").writerows(tabla.filas_texto())


class DialogoAnalisis(QDialog):
    """Ventana con barra superior (título + botones), panel de datos con desplazamiento y zona de resultados."""

    def __init__(self, titulo: str, subtitulo: str, parent=None, ancho: int = 1320, alto: int = 820):
        super().__init__(parent)
        self.setWindowTitle(titulo)
        raiz = QVBoxLayout(self)
        raiz.setContentsMargins(14, 12, 14, 12)
        raiz.setSpacing(10)

        barra = QHBoxLayout()
        textos = QVBoxLayout()
        textos.setSpacing(0)
        t = QLabel(titulo)
        t.setObjectName("TituloGrande")
        s = QLabel(subtitulo)
        s.setObjectName("TextoSecundario")
        s.setWordWrap(True)
        textos.addWidget(t)
        textos.addWidget(s)
        barra.addLayout(textos, 1)
        self.botonera = QHBoxLayout()
        self.botonera.setSpacing(8)
        barra.addLayout(self.botonera)
        self.btn_calcular = QPushButton("▶  Calcular")
        self.btn_calcular.setObjectName("Primario")
        self.btn_calcular.clicked.connect(self._calcular_seguro)
        cerrar = QPushButton("Cerrar")
        cerrar.clicked.connect(self.reject)
        self.botonera.addWidget(self.btn_calcular)
        self.botonera.addWidget(cerrar)
        raiz.addLayout(barra)

        self.divisor = QSplitter(Qt.Orientation.Horizontal)
        self.panel = QWidget()
        self.form = QVBoxLayout(self.panel)
        self.form.setContentsMargins(0, 0, 6, 0)
        self.form.setSpacing(10)
        desplaza = QScrollArea()
        desplaza.setWidgetResizable(True)
        desplaza.setFrameShape(QFrame.Shape.NoFrame)
        desplaza.setWidget(self.panel)
        desplaza.setMinimumWidth(330)
        self.divisor.addWidget(desplaza)

        self.derecha = QWidget()
        self.zona = QVBoxLayout(self.derecha)
        self.zona.setContentsMargins(6, 0, 0, 0)
        self.zona.setSpacing(10)
        self.mensaje = QLabel("")
        self.mensaje.setWordWrap(True)
        self.mensaje.setVisible(False)
        self.zona.addWidget(self.mensaje)
        self.divisor.addWidget(self.derecha)
        self.divisor.setStretchFactor(0, 0)
        self.divisor.setStretchFactor(1, 1)
        self.divisor.setSizes([370, 950])
        raiz.addWidget(self.divisor, 1)
        ajustar_a_pantalla(self, ancho, alto)

    # ----- utilidades
    def pestanas(self) -> QTabWidget:
        t = QTabWidget()
        self.zona.addWidget(t, 1)
        return t

    def boton(self, texto: str, funcion, primario: bool = False) -> QPushButton:
        b = QPushButton(texto)
        if primario:
            b.setObjectName("Primario")
        b.clicked.connect(funcion)
        self.botonera.insertWidget(max(self.botonera.count() - 2, 0), b)
        return b

    def avisar(self, texto: str = "", error: bool = False) -> None:
        self.mensaje.setObjectName("Error" if error else "Aviso")
        self.mensaje.style().unpolish(self.mensaje)  # vuelve a aplicar el estilo por nombre
        self.mensaje.style().polish(self.mensaje)
        self.mensaje.setText(("✖ " if error else "⚠ ") + texto if texto else "")
        self.mensaje.setVisible(bool(texto))

    def _calcular_seguro(self, *_):
        try:
            self.avisar("")
            self.calcular()
        except (ValueError, ZeroDivisionError, KeyError, OverflowError) as e:
            self.avisar(str(e) or e.__class__.__name__, error=True)

    def calcular(self) -> None:  # para sobrescribir
        raise NotImplementedError


def datos_proyecto(documento) -> dict:
    """Cantidades del proyecto abierto que sirven de valores iniciales en los análisis."""
    from app.core.modelo import ESCENARIO_TAJO
    from app.core.resultados import carga_de_pozo, resumen_voladura

    pr = documento.proyecto
    d = pr.diseno
    pozos = pr.perforaciones()
    r = resumen_voladura(pr)
    cargas = [carga_de_pozo(pr, p) for p in pozos]
    cargados = [(p, c) for p, c in zip(pozos, cargas) if c.cargado and c.carga > 0]
    usos: dict[str, int] = {}
    for p, _ in cargados:
        usos[p.explosivo_id] = usos.get(p.explosivo_id, 0) + 1
    principal = pr.explosivo(max(usos, key=usos.get)) if usos else (pr.explosivos[0] if pr.explosivos else None)
    tajo = d.escenario == ESCENARIO_TAJO
    largo = (sum(p.longitud for p, _ in cargados) / len(cargados)) if cargados else (
        d.altura_banco * 1.1 if tajo else d.avance / 0.9)
    def long_carga(p, c):
        if c.longitud_carga > 0:
            return c.longitud_carga
        dc = (c.diametro_carga_mm or p.diametro_mm) / 1000
        q = 3.14159 / 4 * dc * dc * (c.densidad_gcc or 1.0) * 1000  # kg/m
        return min(c.carga / q, p.longitud * 0.9) if q > 0 else p.longitud * 0.7
    lc = (sum(long_carga(p, c) for p, c in cargados) / len(cargados)) if cargados else largo * 0.7
    return {
        "tajo": tajo,
        "n_taladros": len(pozos),
        "n_cargados": len(cargados),
        "kg_total": r.carga_total,
        "kg_taladro": (r.carga_total / len(cargados)) if cargados else 0.0,
        "metros": r.metros_perforados,
        "diametro_mm": (sum(p.diametro_mm for p, _ in cargados) / len(cargados)) if cargados else (
            pozos[0].diametro_mm if pozos else 45.0),
        "largo": largo,
        "long_carga": lc,
        "burden": d.burden,
        "espaciamiento": d.espaciamiento,
        "altura": d.altura_banco if tajo else largo,
        "densidad_roca": d.densidad_roca,
        "avance": d.avance if not tajo else 0.0,
        "volumen": r.volumen or 0.0,
        "toneladas": r.tonelaje or 0.0,
        "factor_carga": r.factor_carga or 0.0,
        "explosivo": principal,
        "pozos": pozos,
        "cargas": cargas,
    }
