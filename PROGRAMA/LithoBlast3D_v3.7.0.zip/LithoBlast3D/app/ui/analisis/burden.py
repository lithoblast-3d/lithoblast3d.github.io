"""Comparador de fórmulas de burden (tajo abierto y, con Rustan, subterráneo)."""

from __future__ import annotations

import math
from dataclasses import replace

import numpy as np
from PySide6.QtWidgets import QLabel, QPushButton

from app.calc import burden_formulas as bf
from app.ui.analisis.base import DialogoAnalisis, FilaKpi, Tabla, datos_proyecto, grupo, lista, numero
from app.ui.graficos import Grafico


class DialogoBurden(DialogoAnalisis):
    def __init__(self, documento, parent=None):
        super().__init__("Comparador de burden", "Burden según Andersen, Ash, Konya, López Jimeno, Rustan, Olofsson, Pearse y Langefors "
                         "para el mismo diámetro, explosivo y roca.", parent, 1250, 780)
        self.doc = documento
        p = datos_proyecto(documento)
        exp = p["explosivo"]
        self.d = numero(25, 400, p["diametro_mm"] if p["tajo"] else 102, 0, 1, "mm")
        self.h = numero(1, 40, p["altura"] if p["tajo"] else 10, 1, 0.5, "m")
        self.form.addWidget(grupo("Taladro", [("Diámetro", self.d), ("Altura de banco", self.h)]))
        self.rho_e = numero(0.5, 1.8, exp.densidad_gcc if exp else 0.85, 2, 0.05, "g/cm³")
        self.vod = numero(1500, 7500, exp.vod_ms if exp and exp.vod_ms else 4000, 0, 100, "m/s")
        self.tipo = lista(bf.K_OLOFSSON, "ANFO")
        self.form.addWidget(grupo("Explosivo", [("Densidad", self.rho_e), ("VOD", self.vod),
                                                ("Tipo (Olofsson)", self.tipo)]))
        self.rho_r = numero(1.5, 5, p["densidad_roca"], 2, 0.05, "t/m³")
        self.vc = numero(1000, 7000, 3500, 0, 100, "m/s")
        self.kb = numero(15, 45, 30, 0, 1)
        self.incl = lista(bf.R1_OLOFSSON, "Vertical")
        self.c = lista([0.3, 0.4, 0.5], 0.4)
        self.form.addWidget(grupo("Roca", [("Densidad", self.rho_r), ("Velocidad sísmica", self.vc),
                                           ("Kb de Ash", self.kb), ("Inclinación (Olofsson)", self.incl),
                                           ("Constante de roca c", self.c)]))
        n = QLabel("Kb de Ash: 25 roca densa, 30 media, 35 liviana. La concentración q (kg/m) para Olofsson se calcula "
                   "con el diámetro y la densidad del explosivo (carguío a granel). Cada fórmula tiene su rango de "
                   "validez: úsalas como referencia y ajusta con pruebas de campo.")
        n.setObjectName("TextoSecundario")
        n.setWordWrap(True)
        self.form.addWidget(n)
        self.form.addStretch(1)
        self.btn_usar = self.boton("Usar la mediana en el diseño", self._usar)

        self.kpi = FilaKpi(["Mediana", "Mínimo", "Máximo", "q (kg/m)"])
        self.zona.addWidget(self.kpi)
        self.g = Grafico(alto_min=300)
        self.zona.addWidget(self.g, 2)
        self.tabla = Tabla(["Fórmula", "Burden m", "Espaciamiento 1.15·B m", "Expresión"], solo_lectura=True)
        self.zona.addWidget(self.tabla, 1)
        for w in (self.d, self.h, self.rho_e, self.vod, self.rho_r, self.vc, self.kb):
            w.valueChanged.connect(self._calcular_seguro)
        for w in (self.tipo, self.incl, self.c):
            w.currentIndexChanged.connect(self._calcular_seguro)
        self._calcular_seguro()

    def calcular(self) -> None:
        q = math.pi / 4 * (self.d.value() / 1000) ** 2 * self.rho_e.value() * 1000
        filas = bf.comparar(self.d.value(), self.h.value(), self.rho_e.value(), self.rho_r.value(), self.vod.value(),
                            self.vc.value(), self.kb.value(), q, self.tipo.currentText(), self.incl.currentText(),
                            float(self.c.currentText()))
        bs = np.array([b for _, b, _ in filas])
        self.mediana = float(np.median(bs))
        self.kpi["Mediana"].poner(f"{self.mediana:.2f} m", f"S ≈ {1.15 * self.mediana:.2f} m")
        i, j = int(np.argmin(bs)), int(np.argmax(bs))
        self.kpi["Mínimo"].poner(f"{bs[i]:.2f} m", filas[i][0])
        self.kpi["Máximo"].poner(f"{bs[j]:.2f} m", filas[j][0])
        self.kpi["q (kg/m)"].poner(f"{q:.2f}", f"Ø {self.d.value():.0f} mm")
        self.tabla.poner_filas([[n, b, 1.15 * b, f] for n, b, f in filas])
        ax = self.g.limpiar()
        nombres = [n for n, _, _ in filas]
        ax.barh(nombres, bs, color=["#2ec4b6" if abs(b - self.mediana) <= 0.2 * self.mediana else "#3d8fe0" for b in bs])
        ax.axvline(self.mediana, color="#e6b84a", ls="--", lw=1.2)
        ax.text(self.mediana, -0.7, f" mediana {self.mediana:.2f} m", color="#e6b84a", fontsize=8.5)
        for k, b in enumerate(bs):
            ax.text(b, k, f" {b:.2f}", va="center", fontsize=8.5)
        ax.invert_yaxis()
        ax.set_xlabel("Burden (m)")
        ax.set_title("Burden por fórmula")
        self.g.actualizar()

    def _usar(self):
        if not getattr(self, "mediana", None):
            return
        d = self.doc.proyecto.diseno
        b = round(self.mediana, 2)
        self.doc.actualizar_diseno(replace(d, burden=b, espaciamiento=round(1.15 * b, 2)))
        self.avisar(f"Diseño actualizado: burden {b:.2f} m y espaciamiento {1.15 * b:.2f} m (Ctrl+Z para deshacer).")
