"""Gráficos 2D (matplotlib) con el estilo oscuro del programa.

Usa el lienzo Qt de matplotlib si está disponible; si no, dibuja con Agg y muestra la imagen
(los gráficos se ven igual, solo que sin zoom interactivo).
"""

from __future__ import annotations

import io

import matplotlib

matplotlib.use("Agg", force=False)
from matplotlib.figure import Figure  # noqa: E402
from PySide6.QtWidgets import QLabel, QSizePolicy, QVBoxLayout, QWidget  # noqa: E402

from app.ui.tema import COLORES  # noqa: E402

PALETA = ["#2ec4b6", "#3d8fe0", "#e6b84a", "#e5534b", "#b07cf0", "#7fd47a", "#f08bb0", "#9aa4af"]

ESTILO = {
    "figure.facecolor": COLORES["panel"],
    "axes.facecolor": "#15191e",
    "axes.edgecolor": COLORES["borde"],
    "axes.labelcolor": COLORES["texto_secundario"],
    "axes.titlecolor": COLORES["texto"],
    "axes.titleweight": "bold",
    "axes.titlesize": 10.5,
    "axes.labelsize": 9,
    "axes.grid": True,
    "axes.prop_cycle": matplotlib.cycler(color=PALETA),
    "axes.spines.top": False,
    "axes.spines.right": False,
    "grid.color": "#2a3038",
    "grid.linewidth": 0.6,
    "xtick.color": COLORES["texto_secundario"],
    "ytick.color": COLORES["texto_secundario"],
    "xtick.labelsize": 8.5,
    "ytick.labelsize": 8.5,
    "legend.facecolor": COLORES["panel_alto"],
    "legend.edgecolor": COLORES["borde"],
    "legend.labelcolor": COLORES["texto"],
    "legend.fontsize": 8.5,
    "text.color": COLORES["texto"],
    "lines.linewidth": 2.0,
    "font.family": "sans-serif",
    "font.sans-serif": ["Segoe UI", "Inter", "Roboto", "DejaVu Sans", "Arial"],
}


matplotlib.rcParams.update(ESTILO)


def _lienzo_qt():
    try:
        from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
        return FigureCanvasQTAgg
    except Exception:  # noqa: BLE001 - sin backend Qt: se usa imagen
        return None


class Grafico(QWidget):
    """Contenedor de una figura. Uso: g.limpiar(filas, cols) → ejes; dibujar; g.actualizar()."""

    def __init__(self, parent=None, alto_min: int = 260):
        super().__init__(parent)
        self.figura = Figure(figsize=(6, 4), dpi=100)
        capa = QVBoxLayout(self)
        capa.setContentsMargins(0, 0, 0, 0)
        clase = _lienzo_qt()
        self._imagen = None
        if clase is not None:
            try:
                self.lienzo = clase(self.figura)
            except Exception:  # noqa: BLE001
                clase = None
        if clase is None:
            self.lienzo = QLabel()
            self._imagen = self.lienzo
            self.lienzo.setScaledContents(True)
        self.lienzo.setMinimumHeight(alto_min)
        self.lienzo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        capa.addWidget(self.lienzo)

    def limpiar(self, filas: int = 1, cols: int = 1, **kw):
        self.figura.clear()
        ejes = self.figura.subplots(filas, cols, squeeze=False, **kw)
        return ejes[0][0] if filas == cols == 1 else ejes

    def actualizar(self) -> None:
        try:
            self.figura.tight_layout()
        except Exception:  # noqa: BLE001
            pass
        if self._imagen is None:
            self.lienzo.draw_idle()
            return
        from PySide6.QtGui import QPixmap
        buf = io.BytesIO()
        self.figura.savefig(buf, format="png", facecolor=self.figura.get_facecolor())
        pix = QPixmap()
        pix.loadFromData(buf.getvalue())
        self._imagen.setPixmap(pix)

    def guardar_png(self, ruta: str) -> None:
        self.figura.savefig(ruta, dpi=150, facecolor=self.figura.get_facecolor())
