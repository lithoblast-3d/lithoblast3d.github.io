"""Panel inferior: registro de mensajes del programa."""

from datetime import datetime

from PySide6.QtGui import QFont
from PySide6.QtWidgets import QPlainTextEdit

SIMBOLOS = {"info": "•", "aviso": "⚠", "error": "✖"}


class PanelMensajes(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setMaximumBlockCount(1000)
        fuente = QFont("Consolas", 9)
        fuente.setStyleHint(QFont.StyleHint.Monospace)
        self.setFont(fuente)

    def agregar(self, texto: str, nivel: str = "info") -> None:
        hora = datetime.now().strftime("%H:%M:%S")
        simbolo = SIMBOLOS.get(nivel, "•")
        self.appendPlainText(f"[{hora}]  {simbolo}  {texto}")
