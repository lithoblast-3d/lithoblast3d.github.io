"""Referencias de minas específicas: mallas Volcan SC-CR (dibujo y tabla), chimeneas y tajeos de Retamas."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QPushButton,
    QSplitter,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from app.biblioteca import referencias as ref
from app.ui.editor_malla import EditorMalla
from app.ui.tema import ajustar_a_pantalla


def _html_volcan(d: dict) -> str:
    tb = d["tabla"]
    cart = "".join(f"<tr><td>{k}</td><td align=right>{v} cart.</td></tr>" for k, v in tb.get("cart", {}).items())
    filas = [("Longitud de perforación", f"{tb['L']:.2f} m"), ("Taladros cargados", tb["cargados"]),
             ("Taladros rimados", tb["rimados"]), ("Taladros de alivio", tb["alivios"]),
             ("Diámetro de broca", f"{tb['broca']} mm"),
             ("Diámetro de rimadora", f"{tb['rimadora']} mm" if tb.get("rimadora") else "—"),
             ("Explosivo total", f"{tb['kg']} kg"), ("Cordón detonante 3P", f"{tb['cordon']} m"),
             ("Fanel LP", f"{tb['fanel']} pzas"), ("Carmex 7'", f"{tb['carmex']} pzas"),
             ("Avance", f"{tb['avance']:.2f} m ({tb['eficiencia']:.0%})"), ("Densidad del mineral", f"{tb['densidad']} t/m³"),
             ("Factor de avance", f"{tb['fa']} kg/m"), ("Factor de carga", f"{tb['fc']} kg/m³"),
             ("Factor de potencia", f"{tb['fp']} kg/t"), ("Factor de energía", f"{tb['fe']} MJ/m³")]
    t = "".join(f"<tr><td>{a}</td><td align=right><b>{b}</b></td></tr>" for a, b in filas)
    return (f"<h3>{d['codigo'] or 'Malla'} · {d['ancho']} × {d['alto']} m · roca {d['clase']} "
            f"(RMR {d['rmr'][0]}–{d['rmr'][1]})</h3><table width=100%>{t}{cart}</table>"
            f"<p><i>{ref.volcan()['aviso']}</i><br>Fuente: {ref.volcan()['fuente']}, pág. {d['pagina']}. "
            "Taladros y retardos digitalizados del dibujo vectorial; la tabla es la columna de mayor longitud.</p>")


class DialogoReferencias(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Referencias de minas")
        v = QVBoxLayout(self)
        t = QLabel("Referencias de minas específicas")
        t.setObjectName("TituloGrande")
        v.addWidget(t)
        n = QLabel("Diseños usados por una mina concreta, con su roca, explosivos y equipos. Sirven para comparar y "
                   "aprender; no son reglas generales. La malla automática ofrece la de Volcan adaptada y compara cada "
                   "opción con estas referencias.")
        n.setObjectName("TextoSecundario")
        n.setWordWrap(True)
        v.addWidget(n)
        tabs = QTabWidget()
        v.addWidget(tabs, 1)

        # Volcan
        w = QWidget()
        h = QHBoxLayout(w)
        div = QSplitter(Qt.Orientation.Horizontal)
        self.lista = QListWidget()
        self.disenos = ref.volcan()["disenos"]
        for d in self.disenos:
            self.lista.addItem(f"{d['codigo'] or 'Malla'} · {d['ancho']}×{d['alto']} m · {d['clase']} "
                               f"(RMR {d['rmr'][0]}–{d['rmr'][1]})")
        div.addWidget(self.lista)
        self.editor = EditorMalla()
        div.addWidget(self.editor)
        self.info = QTextBrowser()
        div.addWidget(self.info)
        div.setSizes([280, 700, 360])
        h.addWidget(div)
        tabs.addTab(w, "Avances — Volcan SC-CR (13 mallas)")
        self.lista.currentRowChanged.connect(self._mostrar)

        # chimeneas
        ch = QTextBrowser()
        filas = "".join(f"<tr><td>{c.seccion}</td><td>{c.rmr[0]}–{c.rmr[1]}</td><td>{c.longitud:.1f}</td>"
                        f"<td>{c.cargados}</td><td>{c.rimados}</td><td>{c.alivios}</td>"
                        f"<td>{'—' if c.kg is None else c.kg}</td><td>{'—' if c.factor_carga is None else c.factor_carga}</td></tr>"
                        for c in ref.CHIMENEAS)
        ch.setHtml("<h3>Chimeneas — Retamas E-MIN-8 v11</h3><table border=1 cellpadding=4>"
                   "<tr><th>Sección</th><th>RMR</th><th>Barra m</th><th>Cargados</th><th>Rimados</th><th>Alivios</th>"
                   f"<th>kg</th><th>FC kg/m³</th></tr>{filas}</table><p>{ref.FUENTE_CHIMENEAS}.</p>"
                   "<p>Observa que en roca mejor (RMR alto) se perforan MÁS taladros: la roca masiva necesita más "
                   "energía por m³. En el documento disponible varias figuras están ocultas; por eso se registran "
                   "solo las tablas.</p>")
        tabs.addTab(ch, "Chimeneas — Retamas")
        tj = QTextBrowser()
        filas = "".join(f"<tr><td>{t.rmr[0]}–{t.rmr[1]}</td><td>{t.ancho} × {t.alto}</td><td>{t.pies}'</td>"
                        f"<td>{t.long_corte}</td><td>{', '.join(f'{k}: {n} × {c}' for k, (n, c) in t.filas.items())}</td>"
                        f"<td>{t.kg}</td><td>{t.factor_carga}</td><td>{t.mecha_rapida_m}</td><td>{t.carmex}</td></tr>"
                        for t in ref.TAJEOS)
        tj.setHtml("<h3>Tajeos de corte y relleno — tesis Retamas (UNCP 2021)</h3><table border=1 cellpadding=4>"
                   "<tr><th>RMR</th><th>Corte m</th><th>Barra</th><th>Long. corte m</th><th>Taladros × cartuchos</th>"
                   f"<th>kg</th><th>FC kg/m³</th><th>Mecha rápida m</th><th>Carmex</th></tr>{filas}</table>"
                   f"<p>{ref.FUENTE_TAJEOS}.</p>")
        tabs.addTab(tj, "Tajeos — Retamas")
        fila = QHBoxLayout()
        fila.addStretch(1)
        c = QPushButton("Cerrar")
        c.clicked.connect(self.reject)
        fila.addWidget(c)
        v.addLayout(fila)
        ajustar_a_pantalla(self, 1400, 860)
        self.lista.setCurrentRow(0)
        self._mostrar(0)

    def _mostrar(self, i: int):
        if not 0 <= i < len(self.disenos):
            return
        d = self.disenos[i]
        self.editor.set_plano(ref.plano_volcan(d))
        self.html_actual = _html_volcan(d)
        self.info.setHtml(self.html_actual)

    def done(self, r):
        self.editor.cerrar()
        super().done(r)
