"""
Malla automática: escribe la sección, la roca y las medidas de los taladros y elige entre
varias mallas completas, cada una con su tipo de arranque. La elegida se puede editar y usar.
"""

from __future__ import annotations

from dataclasses import replace

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QFormLayout, QFrame, QGridLayout, QGroupBox, QHBoxLayout, QLabel, QMessageBox,
    QPushButton, QScrollArea, QSplitter, QStackedWidget, QVBoxLayout, QWidget,
)

from app.biblioteca import estandar as est
from app.biblioteca import opciones as opc
from app.core.malla_auto import FORMAS_SECCION
from app.ui.dialogo_biblioteca import DialogoUsarPlano, aplicar_plano_en_proyecto, colores_leyenda
from app.ui.dialogos import CampoNumero
from app.ui.editor_malla import MiniMalla, EditorMalla
from app.ui.tema import COLORES, ajustar_a_pantalla, con_desplazamiento


class Tarjeta(QFrame):
    """Tarjeta de una opción de malla (vista previa + datos + botón)."""

    def __init__(self, op: opc.OpcionMalla, al_elegir, parent=None):
        super().__init__(parent)
        self.setObjectName("Tarjeta")
        parent = parent if parent is not None else getattr(al_elegir, "__self__", None)
        self.op = op
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 12)
        fam = QLabel(op.familia.upper()); fam.setObjectName("Etiqueta")
        nom = QLabel(op.nombre); nom.setObjectName("TituloTarjeta"); nom.setWordWrap(True)
        lay.addWidget(fam); lay.addWidget(nom)
        lay.addWidget(MiniMalla(op.plano), 1)
        if op.error:
            e = QLabel(f"No se pudo generar: {op.error}"); e.setWordWrap(True); e.setObjectName("Error")
            lay.addWidget(e)
        else:
            r = op.resumen()
            fc = f"{r['factor_carga']:.2f} kg/m³" if r.get("factor_carga") else "—"
            datos = QLabel(f"<b>{r['taladros']}</b> taladros · {r['cargados']} cargados · {r['alivios']} alivios<br>"
                           f"Explosivo <b>{r['kg']:.1f} kg</b> · factor de carga <b>{fc}</b><br>"
                           f"Avance ≈ <b>{r['avance']:.2f} m</b> · perforado {r['metros']:.0f} m")
            datos.setTextFormat(Qt.TextFormat.RichText)
            lay.addWidget(datos)
            desc = QLabel(op.descripcion); desc.setWordWrap(True); desc.setObjectName("TextoSecundario")
            lay.addWidget(desc)
            extra = []
            if op.equipo is not None:
                extra.append(f"<b>Equipo:</b> {op.equipo.equipo.nombre}")
            acc = op.accesorios(getattr(parent, "sistema_actual", "carmex")) if hasattr(op, "accesorios") else []
            if acc:
                extra.append("<b>Iniciación:</b> " + " · ".join(f"{a.cantidad:g} {a.unidad} {a.item}"
                                                                for a in acc[:2]))
            if op.comparacion:
                extra.append("<b>Referencia:</b> " + op.comparacion[0])
            if extra:
                ex = QLabel("<br>".join(extra)); ex.setWordWrap(True); ex.setTextFormat(Qt.TextFormat.RichText)
                ex.setToolTip("\n".join([op.equipo.motivo if op.equipo else ""] + op.comparacion
                                        + [f"{a.item}: {a.cantidad:g} {a.unidad} — {a.nota}" for a in acc]))
                lay.addWidget(ex)
            if op.avisos:
                av = QLabel("⚠ " + op.avisos[0] + (f"  (+{len(op.avisos) - 1})" if len(op.avisos) > 1 else ""))
                av.setWordWrap(True); av.setObjectName("Aviso"); av.setToolTip("\n".join(op.avisos))
                lay.addWidget(av)
            b = QPushButton("Elegir esta malla"); b.setObjectName("Primario")
            b.clicked.connect(lambda: al_elegir(op))
            lay.addWidget(b)


class DialogoOpcionesMalla(QDialog):
    def __init__(self, documento, parent=None):
        super().__init__(parent)
        self.doc = documento
        self.descripcion = ""
        self.opciones: list[opc.OpcionMalla] = []
        self.elegida: opc.OpcionMalla | None = None
        self.setWindowTitle("Malla automática — elige el tipo de arranque")
        ajustar_a_pantalla(self, 1480, 900)
        self.planos = est.cargar_biblioteca()

        raiz = QVBoxLayout(self)
        barra = QHBoxLayout()
        titulo = QLabel("Malla automática"); titulo.setObjectName("TituloGrande")
        barra.addWidget(titulo); barra.addStretch(1)
        self.b_generar = QPushButton("⚙ Generar opciones"); self.b_generar.setObjectName("Primario")
        self.b_volver = QPushButton("← Volver a las opciones"); self.b_volver.setVisible(False)
        self.b_usar = QPushButton("✔ Usar en el proyecto…"); self.b_usar.setObjectName("Primario")
        self.b_usar.setVisible(False)
        self.b_simular = QPushButton("🎬 Simular ciclo 3D"); self.b_simular.setObjectName("Primario")
        self.b_simular.setToolTip("Perforación, carguío, amarre, voladura y limpieza con el método mecanizado o convencional "
                                  "(se abre en el navegador; funciona sin internet)")
        self.b_simular.setVisible(False); self.b_simular.clicked.connect(self.simular_ciclo)
        b_cerrar = QPushButton("Cerrar"); b_cerrar.clicked.connect(self.reject)
        for b in (self.b_generar, self.b_volver, self.b_simular, self.b_usar, b_cerrar):
            barra.addWidget(b)
        raiz.addLayout(barra)

        div = QSplitter(Qt.Orientation.Horizontal)
        raiz.addWidget(div, 1)
        div.addWidget(con_desplazamiento(self._panel_datos()))
        self.pila = QStackedWidget()
        self.pagina_opciones = QWidget()
        self.rejilla = QGridLayout(self.pagina_opciones)
        self.rejilla.setSpacing(14)
        area = QScrollArea(); area.setWidgetResizable(True); area.setWidget(self.pagina_opciones)
        area.setFrameShape(QFrame.Shape.NoFrame)
        self.pila.addWidget(area)
        self.editor = EditorMalla()
        self.pila.addWidget(self.editor)
        div.addWidget(self.pila)
        div.setSizes([330, 1150])

        self.b_generar.clicked.connect(self.generar)
        self.b_volver.clicked.connect(self._volver)
        self.b_usar.clicked.connect(self._usar)
        self.generar()

    # ------------------------------------------------------------ datos
    def _panel_datos(self):
        w = QWidget(); lay = QVBoxLayout(w)
        sec0 = self._seccion_inicial()
        from app.calc.accesorios import SISTEMAS
        from app.core import equipos as eqm
        g = QGroupBox("Labor y equipo"); f = QFormLayout(g)
        self.labor = QComboBox()
        for k, txt in eqm.LABORES.items():
            self.labor.addItem(txt, k)
        self.labor.addItem("Tajo abierto (banco sobre la topografía) →", "tajo_abierto")
        self.equipo = QComboBox()
        self.equipo.addItem("Automático (según la sección)", None)
        for e in eqm.catalogo():
            self.equipo.addItem(e.nombre, e.clave)
        self.sistema = QComboBox()
        for k, txt in SISTEMAS.items():
            self.sistema.addItem(txt, k)
        self.b_tajeo = CampoNumero(0.15, 2.0, 2, "m", 0.40, "Burden (tajeo)")
        self.s_tajeo = CampoNumero(0.15, 2.0, 2, "m", 0.30, "Espaciamiento (tajeo)")
        self.motivo_equipo = QLabel(""); self.motivo_equipo.setWordWrap(True)
        self.motivo_equipo.setObjectName("TextoSecundario")
        f.addRow("Labor", self.labor); f.addRow("Equipo", self.equipo); f.addRow("Iniciación", self.sistema)
        f.addRow(self.b_tajeo.nombre, self.b_tajeo); f.addRow(self.s_tajeo.nombre, self.s_tajeo)
        f.addRow(self.motivo_equipo)
        lay.addWidget(g)
        g = QGroupBox("Sección"); f = QFormLayout(g)
        self.ancho = CampoNumero(0.8, 15, 2, "m", sec0[0], "Ancho")
        self.alto = CampoNumero(1.2, 15, 2, "m", sec0[1], "Alto")
        self.forma = QComboBox(); self.forma.addItems(FORMAS_SECCION)
        self.flecha = CampoNumero(0.0, 8, 2, "m", round(min(sec0[0] / 3, sec0[1] / 3), 2), "Flecha del arco / radio")
        for c in (self.ancho, self.alto):
            f.addRow(c.nombre, c)
        f.addRow("Forma", self.forma); f.addRow(self.flecha.nombre, self.flecha)
        lay.addWidget(g)

        g = QGroupBox("Roca"); f = QFormLayout(g)
        self.roca = QComboBox(); self.roca.addItems(["Buena (RMR 61-80)", "Regular (RMR 41-60)", "Mala (RMR 21-40)"])
        self.roca.setCurrentIndex(1)
        self.usar_rmr = QCheckBox("Usar mis datos de roca (RMR, RQD)")
        self.rmr = CampoNumero(0, 100, 0, "", 50, "RMR")
        self.rqd = CampoNumero(0, 100, 0, "%", 60, "RQD")
        self.dens = CampoNumero(1.5, 5, 2, "t/m³", 2.7, "Densidad")
        f.addRow("Calidad", self.roca); f.addRow(self.usar_rmr)
        for c in (self.rmr, self.rqd, self.dens):
            f.addRow(c.nombre, c)
        lay.addWidget(g)

        g = QGroupBox("Taladros"); f = QFormLayout(g)
        self.d = CampoNumero(20, 150, 0, "mm", 38, "Ø de perforación")
        self.da = CampoNumero(20, 250, 0, "mm", 64, "Ø de alivio")
        self.na = CampoNumero(1, 8, 0, "", 1, "N.º de alivios")
        self.lp = CampoNumero(2, 20, 1, "pies", 6, "Longitud de barra")
        for c in (self.d, self.da, self.na, self.lp):
            f.addRow(c.nombre, c)
        lay.addWidget(g)

        g = QGroupBox("Explosivo"); f = QFormLayout(g)
        self.exp = QComboBox(); self.exp_c = QComboBox()
        self.exp_c.addItem("El mismo", None)
        from app.core.ejemplos import explosivos_referenciales
        self.lista_exp = list(self.doc.proyecto.explosivos) if self.doc else []
        self.exp_genericos = not self.lista_exp
        if self.exp_genericos:  # proyecto sin explosivos: valores genéricos (se agregan al usar la malla)
            self.lista_exp = explosivos_referenciales()
        from app.biblioteca.productos import catalogo_explosivos
        nombres = {e.nombre for e in self.lista_exp}
        self.lista_exp += [e for e in catalogo_explosivos() if e.nombre not in nombres]  # ficha FAMESA
        for e in self.lista_exp:
            etiqueta = e.nombre + ("  · ficha FAMESA" if e.fuente and e not in self.doc.proyecto.explosivos else "")
            self.exp.addItem(etiqueta, e.id); self.exp_c.addItem(etiqueta, e.id)
        i = next((k for k in range(self.exp.count()) if "encartuch" in self.exp.itemText(k).lower()), 0)
        self.exp.setCurrentIndex(i)
        self.cart = CampoNumero(2, 30, 0, "pulg", 8, "Largo del cartucho")
        f.addRow("Principal", self.exp); f.addRow("Contorno", self.exp_c); f.addRow(self.cart.nombre, self.cart)
        if self.exp_genericos:
            nota = QLabel("⚠ El proyecto no tiene explosivos: se usan valores genéricos que se agregarán al usar "
                          "la malla. Cámbialos luego por la ficha técnica (Editar → Explosivos).")
            nota.setObjectName("Aviso"); nota.setWordWrap(True)
            f.addRow(nota)
        lay.addWidget(g)

        g = QGroupBox("Corte en V y cuneta"); f = QFormLayout(g)
        self.ang = CampoNumero(50, 80, 0, "°", 65, "Ángulo del corte en V con el frente")
        self.cuneta = QCheckBox("Poner cuneta"); self.cuneta.setChecked(True)
        self.labor.currentIndexChanged.connect(self._cambio_labor)
        self.lado = QComboBox(); self.lado.addItems(["izquierda", "derecha"])
        self.c_ancho = CampoNumero(0.15, 1.5, 2, "m", 0.35, "Ancho de cuneta")
        self.c_prof = CampoNumero(0.1, 1.0, 2, "m", 0.30, "Profundidad de cuneta")
        f.addRow(self.ang.nombre, self.ang); f.addRow(self.cuneta); f.addRow("Lado", self.lado)
        f.addRow(self.c_ancho.nombre, self.c_ancho); f.addRow(self.c_prof.nombre, self.c_prof)
        lay.addWidget(g)
        lay.addStretch(1)
        return w

    def _seccion_inicial(self):
        from app.core.modelo import Contorno
        import math
        cs = [o for o in self.doc.proyecto.objetos.values() if isinstance(o, Contorno)] if self.doc else []
        if cs:
            v = cs[0].vertices
            zs = [p[2] for p in v]
            xy = [(p[0], p[1]) for p in v]
            ancho = max(math.dist(a, b) for a in xy for b in xy)
            alto = max(zs) - min(zs)
            if 0.8 <= ancho <= 15 and 1.2 <= alto <= 15:
                return round(ancho, 2), round(alto, 2)
        return 3.0, 3.0

    def _cambio_labor(self, *_):
        """Chimenea y tajeo: sección rectangular, sin arco ni cuneta. Tajo abierto: malla sobre la topografía."""
        lab = self.labor.currentData() or "frente"
        if lab == "tajo_abierto":
            self.labor.setCurrentIndex(0)
            ventana = self.parent()
            if ventana is not None and hasattr(ventana, "malla_topografica"):
                r = QMessageBox.question(self, "Tajo abierto",
                                         "La malla de tajo abierto se diseña sobre las curvas de nivel (DWG/DXF): "
                                         "burden, espaciamiento, sobreperforación y altura de banco sobre el terreno.\n\n"
                                         "¿Abrir «Malla sobre topografía»? (si aún no cargaste la topografía, primero "
                                         "usa Topografía → Importar DWG/DXF)")
                if r == QMessageBox.StandardButton.Yes:
                    self.reject()
                    ventana.malla_topografica()
            return
        rect = lab in ("chimenea", "tajeo")
        for w in (self.forma, self.flecha, self.cuneta):
            w.setEnabled(not rect)
        if rect:
            self.forma.setToolTip("En chimenea y tajeo la sección es rectangular (ancho × alto)")
            self.cuneta.setChecked(False)

    def datos(self) -> opc.DatosFrente:
        por_id = {e.id: e for e in self.lista_exp}
        exp = por_id.get(self.exp.currentData())
        exp_c = por_id.get(self.exp_c.currentData()) if self.exp_c.currentData() else None
        roca = est.ROCAS[self.roca.currentIndex()]
        rmr = self.rmr.value() if self.usar_rmr.isChecked() else None
        if rmr is not None:
            from app.biblioteca.generador import roca_desde_rmr
            roca = roca_desde_rmr(rmr)
        return opc.DatosFrente(
            ancho=self.ancho.value(), alto=self.alto.value(), flecha=self.flecha.value(),
            forma=self.forma.currentText(), roca=roca, rmr=rmr,
            rqd=self.rqd.value() if self.usar_rmr.isChecked() else None, densidad_roca=self.dens.value(),
            diametro_mm=self.d.value(), diametro_alivio_mm=self.da.value(), n_alivios=int(self.na.value()),
            longitud=self.lp.value() * est.PIE, explosivo=exp, explosivo_contorno=exp_c,
            largo_cartucho_m=self.cart.value() * 0.0254, angulo_v=self.ang.value(), cuneta=self.cuneta.isChecked(),
            cuneta_lado=self.lado.currentText(), cuneta_ancho=self.c_ancho.value(),
            cuneta_profundidad=self.c_prof.value(), labor=self.labor.currentData() or "frente",
            burden_tajeo=self.b_tajeo.value(), espaciamiento_tajeo=self.s_tajeo.value(),
            equipo=self.equipo.currentData())

    # ------------------------------------------------------------ opciones
    def generar(self, *_):
        if self.doc is None or not self.lista_exp:
            QMessageBox.information(self, "Malla automática", "Registra al menos un explosivo (Editar → Explosivos).")
            return
        self.sistema_actual = self.sistema.currentData() or "carmex"
        try:
            self.opciones = opc.generar_opciones(self.datos(), self.planos)
            sel = next((o.equipo for o in self.opciones if o.equipo is not None), None)
            if sel is not None:
                self.motivo_equipo.setText(f"→ {sel.equipo.nombre}: {sel.motivo}"
                                           + ("".join(f"\n⚠ {a}" for a in sel.avisos) if sel.avisos else ""))
        except ValueError as error:
            QMessageBox.warning(self, "Malla automática", str(error))
            return
        while self.rejilla.count():
            it = self.rejilla.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        cols = 3
        for k, op in enumerate(self.opciones):
            if op.plano is not None and op.plano.plantilla is not None:
                op.plano._colores = colores_leyenda(op.plano.plantilla)
            self.rejilla.addWidget(Tarjeta(op, self._elegir), k // cols, k % cols)
        self._volver()

    def _elegir(self, op: opc.OpcionMalla):
        self.elegida = op
        if getattr(self, "simular_al_elegir", False) and op.plano is not None and not op.error:
            self.simular_ciclo()
        self.editor.set_plano(op.plano)
        self.pila.setCurrentIndex(1)
        self.b_volver.setVisible(True); self.b_usar.setVisible(True); self.b_simular.setVisible(True)

    def _volver(self):
        self.pila.setCurrentIndex(0)
        self.b_volver.setVisible(False); self.b_usar.setVisible(False); self.b_simular.setVisible(False)

    def simular_ciclo(self):
        if self.elegida is None or self.elegida.plano is None:
            return
        from app.biblioteca.escena_labor import escena
        from app.ui import simulador_web
        try:
            self.url_simulacion = simulador_web.abrir(escena(self.elegida, self.datos(), getattr(self, "sistema_actual", "carmex")))
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, "Simulación del ciclo", f"No se pudo abrir la simulación: {error}")

    def _usar(self):
        if self.elegida is None:
            return
        from app.core.documento import ErrorEdicion
        pl = self.elegida.plano
        dlg = DialogoUsarPlano(pl, self, self.d.value(), self.da.value())
        if not dlg.exec():
            return
        # explosivos elegidos que aún no están en el proyecto (genéricos o de la ficha FAMESA)
        usados = {t.explosivo for t in pl.cargados() if t.explosivo}
        actuales = list(self.doc.proyecto.explosivos)
        nombres = {e.nombre for e in actuales}
        nuevos = []
        for e in self.lista_exp:
            if e.nombre in usados and e.nombre not in nombres:
                n = len(actuales) + len(nuevos) + 1
                while any(x.id == f"EXP-{n:02d}" for x in actuales + nuevos):
                    n += 1
                nuevos.append(replace(e, id=f"EXP-{n:02d}"))
        if nuevos:
            self.doc.reemplazar_explosivos(actuales + nuevos)
        try:
            self.descripcion = aplicar_plano_en_proyecto(self.doc, pl, dlg.d.value(), dlg.da.value(), dlg.x0.value(),
                                                         dlg.y0.value(), dlg.z0.value(), dlg.az.value(),
                                                         dlg.reemplazar.isChecked(),
                                                         longitud_m=self.lp.value() * est.PIE,
                                                         labor=self.elegida.labor)
        except ErrorEdicion as error:
            QMessageBox.warning(self, "Usar malla", str(error))
            return
        self.descripcion = f"{self.elegida.nombre}: {self.descripcion}"
        self.accept()

    def done(self, r):
        self.editor.cerrar()
        super().done(r)
