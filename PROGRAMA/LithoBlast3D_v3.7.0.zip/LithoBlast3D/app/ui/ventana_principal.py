"""Ventana principal: une el visor 3D con los paneles, menús y barras de herramientas."""

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import (
    QDockWidget,
    QFileDialog,
    QLabel,
    QMainWindow,
    QMessageBox,
    QSizePolicy,
    QTabWidget,
    QToolBar,
    QWidget,
)

from app import NOMBRE_APP, VERSION
from app.core import archivos
from app.core.documento import Documento, ErrorEdicion
from app.core.modelo import Contorno
from app.core.resultados import resumen_voladura
from dataclasses import replace

from app.ui.dialogo_malla import DialogoMalla
from app.ui.dialogo_malla_auto import DialogoMallaAutomatica
from app.ui.dialogo_mapa import DialogoMapa
from app.ui.dialogo_simulacion import DialogoSimulacion
from app.ui.dialogos import DialogoDiseno, DialogoExplosivos
from app.ui.panel_capas import PanelCapas
from app.ui.panel_mensajes import PanelMensajes
from app.ui.panel_propiedades import PanelPropiedades
from app.ui.panel_tabla import PanelTabla
from app.ui.tema import COLORES
from app.viewer.visor3d import Visor3D

FILTRO_PROYECTO = f"Proyecto LithoBlast3D (*{archivos.EXTENSION})"
FILTRO_CSV = "Archivo CSV (*.csv)"


class VentanaPrincipal(QMainWindow):
    def __init__(self, documento: Documento, controlador):
        super().__init__()
        self.doc = documento
        self.controlador = controlador
        self.cerrar_sin_preguntar = False
        self._refresco_pendiente = False
        self._informar_mapa = False

        from app.ui.tema import ajustar_a_pantalla
        ajustar_a_pantalla(self, 1480, 900)
        self.setDockNestingEnabled(True)
        self.setCorner(Qt.Corner.BottomLeftCorner, Qt.DockWidgetArea.LeftDockWidgetArea)
        self.setCorner(Qt.Corner.BottomRightCorner, Qt.DockWidgetArea.RightDockWidgetArea)

        self.mensajes = PanelMensajes()
        self.visor = Visor3D(documento, COLORES, self)
        self.setCentralWidget(self.visor)
        self._crear_acciones()

        self.panel_capas = PanelCapas(documento, self._cambiar_visibilidad_capa)
        self.panel_propiedades = PanelPropiedades(documento, COLORES)
        self.panel_tabla = PanelTabla(
            documento, COLORES,
            [self.acc_malla_auto, self.acc_agregar, self.acc_eliminar, None,
             self.acc_importar, self.acc_exportar_csv],
            self.mensajes.agregar,
        )
        self.pestanas = QTabWidget()
        self.pestanas.setDocumentMode(True)
        self.pestanas.addTab(self.panel_tabla, "Perforaciones")
        self.pestanas.addTab(self.mensajes, "Mensajes")

        self.dock_capas = self._crear_dock("Proyecto y capas", "dock_capas", self.panel_capas,
                                           Qt.DockWidgetArea.LeftDockWidgetArea)
        self.dock_propiedades = self._crear_dock("Propiedades", "dock_propiedades",
                                                 self.panel_propiedades,
                                                 Qt.DockWidgetArea.RightDockWidgetArea)
        self.dock_datos = self._crear_dock("Datos", "dock_datos", self.pestanas,
                                           Qt.DockWidgetArea.BottomDockWidgetArea)
        self.resizeDocks([self.dock_capas, self.dock_propiedades], [260, 360], Qt.Orientation.Horizontal)
        self.resizeDocks([self.dock_datos], [250], Qt.Orientation.Vertical)

        self._crear_menus()
        self._crear_barras()
        self._crear_barra_estado()

        self.doc.suscribir_cambios(self._programar_refresco)
        self.doc.seleccion.suscribir(self._al_cambiar_seleccion)
        self._actualizar_titulo()
        self._actualizar_acciones()

        self.mensajes.agregar(f"{NOMBRE_APP} {VERSION} iniciado.")
        self.mensajes.agregar(f"Proyecto «{documento.proyecto.nombre}»: "
                              f"{len(documento.proyecto.perforaciones())} taladros.")
        if documento.proyecto.escenario_demo:
            self.mensajes.agregar("Este es un proyecto de EJEMPLO con datos inventados. "
                                  "Para tus datos: Archivo → Nuevo proyecto.", "aviso")

    # ================================================================ armado
    def _crear_dock(self, titulo, nombre, contenido: QWidget, area) -> QDockWidget:
        dock = QDockWidget(titulo, self)
        dock.setObjectName(nombre)
        dock.setWidget(contenido)
        self.addDockWidget(area, dock)
        return dock

    def _accion(self, texto, atajo, ayuda, funcion) -> QAction:
        accion = QAction(texto, self)
        if atajo:
            accion.setShortcut(QKeySequence(atajo))
        accion.setToolTip(f"{ayuda}  ({atajo})" if atajo else ayuda)
        accion.setStatusTip(ayuda)
        accion.triggered.connect(funcion)
        return accion

    def _crear_acciones(self) -> None:
        c = self.controlador
        a = self._accion
        self.acc_nuevo = a("Nuevo", "Ctrl+N", "Crear un proyecto vacío para tus datos", lambda: c.nuevo(self))
        self.acc_abrir = a("Abrir…", "Ctrl+O", "Abrir un proyecto guardado", lambda: c.abrir(self))
        self.acc_guardar = a("Guardar", "Ctrl+S", "Guardar el proyecto", self.guardar)
        self.acc_guardar_como = a("Guardar como…", "Ctrl+Shift+S", "Guardar con otro nombre",
                                  self.guardar_como)
        self.acc_importar = a("Importar CSV…", "", "Agregar taladros desde un archivo CSV", self.importar_csv)
        self.acc_exportar_csv = a("Exportar CSV…", "", "Guardar los taladros en un archivo CSV",
                                  self.exportar_csv)
        self.acc_exportar_imagen = a("Exportar imagen…", "", "Guardar la vista 3D como imagen PNG",
                                     self.exportar_imagen)
        self.acc_ejemplo_tajo = a("Ejemplo: tajo abierto", "", "Abrir el proyecto de ejemplo de tajo",
                                  lambda: c.ejemplo(self, "tajo"))
        self.acc_ejemplo_sub = a("Ejemplo: frente subterráneo", "",
                                 "Abrir el proyecto de ejemplo subterráneo",
                                 lambda: c.ejemplo(self, "subterraneo"))
        self.acc_salir = a("Salir", "Ctrl+Q", "Cerrar el programa", self.close)

        self.acc_deshacer = a("Deshacer", "Ctrl+Z", "Deshacer el último cambio", self.deshacer)
        self.acc_rehacer = a("Rehacer", "Ctrl+Y", "Rehacer el cambio deshecho", self.rehacer)
        self.acc_agregar = a("+ Agregar taladro", "Ctrl+Shift+A",
                             "Agregar un taladro (copia del seleccionado)", self.agregar_pozo)
        self.acc_eliminar = a("Eliminar taladro", "Del", "Eliminar el taladro seleccionado", self.eliminar_seleccion)
        self.acc_malla_auto = a("Malla automática (elegir tipo de arranque)…", "Ctrl+M",
                                "Sección + roca + medidas de taladros: varias mallas completas para elegir",
                                self.malla_opciones)
        self.acc_malla_real = a("Adaptar una malla del estándar…", "",
                                "Malla del estándar de 6 pies adaptada a tu sección (con cuneta)", self.malla_real)
        self.acc_malla_teorica = a("Malla automática teórica (Yilmaz / Holmberg / tajo)…", "Ctrl+Alt+M",
                                   "Malla calculada con fórmulas (frente o banco de tajo abierto)",
                                   self.malla_automatica)
        self.acc_malla = a("Diseño manual de malla…", "Ctrl+Shift+M",
                           "Colocar la malla con tus propios burden y espaciamiento", self.disenar_malla)
        self.acc_simular = a("Simular voladura…", "Ctrl+B",
                             "Secuencia de salida animada, carga por retardo y burden efectivo",
                             self.simular_voladura)
        self.acc_mapa = a("Mapa de vibración…", "Ctrl+G",
                          "Simular el mapa de colores de vibración (Holmberg–Persson)", self.configurar_mapa)
        self.acc_ver_mapa = a("Mostrar mapa", "Ctrl+Shift+G", "Mostrar u ocultar el mapa de colores",
                              self.alternar_mapa)
        self.acc_ver_mapa.setCheckable(True)
        self.acc_diseno = a("Parámetros de voladura…", "Ctrl+P",
                            "Burden, espaciamiento, altura de banco, sección, avance, densidad de roca",
                            self.editar_diseno)
        self.acc_explosivos = a("Explosivos…", "Ctrl+E", "Registrar explosivos y sus densidades",
                                self.editar_explosivos)

        self.acc_superior = a("Superior", "Ctrl+1", "Vista en planta", lambda: self.visor.vista_superior())
        self.acc_frontal = a("Frontal", "Ctrl+2", "Vista frontal (plano X–Z)", lambda: self.visor.vista_frontal())
        self.acc_lateral = a("Lateral", "Ctrl+3", "Vista lateral (plano Y–Z)", lambda: self.visor.vista_lateral())
        self.acc_isometrica = a("Isométrica", "Ctrl+4", "Vista isométrica",
                                lambda: self.visor.vista_isometrica())
        self.acc_ajustar = a("Ajustar", "Ctrl+0", "Encuadrar toda la escena", lambda: self.visor.ajustar())
        self.acc_quitar_sel = a("Quitar selección", "Esc", "Deseleccionar",
                                lambda: self.doc.seleccion.seleccionar(None, origen="menu"))
        self.acc_ciclo = a("🎬 Ciclo completo 3D (jackleg / jumbo, amarre, scoop)…", "F7",
                           "Perforación, carguío, amarre, voladura y limpieza; método convencional o mecanizado",
                           self.ciclo_completo)
        self.acc_inicio = a("Pantalla de inicio…", "", "Accesos por tipo de labor y el ciclo de minado", self.pantalla_inicio)
        self.acc_acerca = a("Acerca de", "", f"Información de {NOMBRE_APP}", self._acerca_de)

        # --- Topografía y CAD
        self.acc_importar_cad = a("Importar DXF / DWG…", "Ctrl+Shift+I",
                                  "Curvas de nivel, polilíneas 3D, puntos y caras 3D con sus capas", self.importar_cad)
        self.acc_tin = a("Crear superficie TIN…", "", "Triangular curvas y puntos importados", self.crear_tin)
        self.acc_perfil = a("Perfil topográfico…", "", "Cotas a lo largo de una línea (usa la última medición)",
                            self.perfil_topografico)
        self.acc_pendientes = a("Pendientes, bancos y taludes…", "", "Colorear la superficie por pendiente",
                                self.pendientes)
        self.acc_consultar = a("Consultar coordenadas", "Ctrl+K", "Clic en la vista 3D: X, Y y cota del punto",
                               lambda v: self._herramienta("consultar", v))
        self.acc_consultar.setCheckable(True)
        self.acc_medir = a("Medir distancia", "Ctrl+Shift+D", "Dos clics en la vista 3D: distancia, desnivel y pendiente",
                           lambda v: self._herramienta("medir", v))
        self.acc_medir.setCheckable(True)
        self.acc_malla_topo = a("Diseñar malla sobre la topografía…", "Ctrl+T",
                                "Malla de banco sobre las curvas de nivel (cota de collar del terreno)",
                                self.malla_topografica)
        self.acc_exportar_cad = a("Exportar malla a DWG / DXF…", "Ctrl+Shift+E",
                                  "Guardar taladros, textos y topografía para abrir en AutoCAD", self.exportar_cad)
        self.acc_config_dwg = a("Configurar conversor DWG…", "", "Ubicación de ODA File Converter", self.config_dwg)
        # --- Biblioteca
        self.acc_biblioteca = a("Biblioteca de mallas del estándar…", "Ctrl+L",
                                "Mallas del estándar de voladura en avances de 6 pies (referencias documentales)",
                                self.biblioteca)
        # --- Visualizador
        self.acc_rejilla = a("Cuadrícula", "", "Mostrar u ocultar la cuadrícula con cotas", self.visor.set_cuadricula)
        self.acc_rejilla.setCheckable(True)
        self.acc_rejilla.setChecked(True)
        self.acciones_calidad = []
        for nivel in ("Baja", "Media", "Alta"):
            acc = a(f"Calidad {nivel.lower()}", "", "Calidad gráfica del visor",
                    lambda _=False, n=nivel: self._calidad(n))
            acc.setCheckable(True)
            acc.setChecked(nivel == "Media")
            self.acciones_calidad.append(acc)
        # --- Simulación 3D (cada acción abre el simulador en su etapa)
        self.acc_referencias = a("Referencias de minas (Volcan, Retamas)…", "",
                                 "Mallas de avance, chimeneas y tajeos de minas específicas", self.referencias_minas)
        self.acc_equipos = a("Equipos de perforación (jumbo, jackleg, stoper)…", "",
                             "Catálogo editable de equipos y qué equipo corresponde a cada sección", self.equipos_perforacion)
        self.acc_sim_completa = a("Simulación completa (10 etapas)…", "Ctrl+Shift+B",
                                  "Labor → malla → jumbo → perforación → carguío → voladura → resultado",
                                  lambda: self.simulador_3d(0))
        self.acc_sim_jumbo = a("Simulador de jumbo…", "", "Ingreso y posicionamiento del equipo con sus restricciones",
                               lambda: self.simulador_3d(2))
        self.acc_sim_perf = a("Simulación de perforación…", "", "Brazos, barras y brocas sobre la malla del proyecto",
                              lambda: self.simulador_3d(3))
        self.acc_sim_carguio = a("Carguío (ilustrativo)…", "", "Vista en corte de taladros vacíos y cargados",
                                 lambda: self.simulador_3d(5))
        self.acc_sim_voladura = a("Voladura 3D…", "", "Secuencia de salida y detonación (visual)",
                                  lambda: self.simulador_3d(6))
        self.acc_sim_frag = a("Fragmentación (cinematográfica)…", "", "Bloques con física simplificada",
                              lambda: self.simulador_3d(8))
        self.acc_sim_comparar = a("Comparación antes / después…", "", "Frente original vs. nuevo frente y pila",
                                  lambda: self.simulador_3d(9, comparar=True))
        from app.biblioteca.estandar import hay_estandar
        if not hay_estandar():  # edición pública: sin las mallas del estándar
            for acc in (self.acc_biblioteca, self.acc_malla_real):
                acc.setVisible(False)
                acc.setEnabled(False)
        # --- Análisis técnico
        from app.ui.analisis import HERRAMIENTAS
        self.acc_centro_analisis = a("Centro de análisis…", "F9", "Todas las herramientas de cálculo en un solo lugar",
                                     self.centro_analisis)
        self.acciones_analisis = []
        for clave, titulo, desc, _, _ in HERRAMIENTAS:
            self.acciones_analisis.append(a(titulo + "…", "", desc, lambda _=False, k=clave: self.analisis(k)))
        # --- Reportes
        self.acc_reporte = a("Reporte del proyecto (HTML)…", "Ctrl+R", "Resumen, taladros, explosivos, topografía",
                             self.reporte)

    def _crear_menus(self) -> None:
        barra = self.menuBar()
        m = barra.addMenu("&Archivo")
        for acc in (self.acc_nuevo, self.acc_abrir, None, self.acc_guardar, self.acc_guardar_como,
                    None, self.acc_importar, self.acc_exportar_csv, self.acc_exportar_imagen, None):
            m.addSeparator() if acc is None else m.addAction(acc)
        ejemplos = m.addMenu("Abrir ejemplo")
        ejemplos.addAction(self.acc_ejemplo_tajo)
        ejemplos.addAction(self.acc_ejemplo_sub)
        m.addSeparator()
        m.addAction(self.acc_salir)

        m = barra.addMenu("&Editar")
        for acc in (self.acc_deshacer, self.acc_rehacer, None, self.acc_malla_auto, self.acc_malla_teorica,
                    self.acc_malla,
                    self.acc_agregar, self.acc_eliminar,
                    None, self.acc_diseno, self.acc_explosivos):
            m.addSeparator() if acc is None else m.addAction(acc)

        m = barra.addMenu("A&nálisis")
        m.addAction(self.acc_centro_analisis)
        m.addSeparator()
        for acc in self.acciones_analisis:
            m.addAction(acc)
        m.addSeparator()
        m.addAction(self.acc_simular)
        m.addAction(self.acc_mapa)
        m.addAction(self.acc_ver_mapa)

        m = barra.addMenu("&Ver")
        vistas = m.addMenu("Vistas")
        for acc in (self.acc_superior, self.acc_frontal, self.acc_lateral, self.acc_isometrica,
                    None, self.acc_ajustar):
            vistas.addSeparator() if acc is None else vistas.addAction(acc)
        paneles = m.addMenu("Paneles")
        for dock in (self.dock_capas, self.dock_propiedades, self.dock_datos):
            paneles.addAction(dock.toggleViewAction())
        m.addSeparator()
        m.addAction(self.acc_quitar_sel)

        m = barra.addMenu("&Topografía y CAD")
        for acc in (self.acc_importar_cad, self.acc_tin, None, self.acc_malla_topo, self.acc_exportar_cad, None,
                    self.acc_perfil, self.acc_pendientes, None,
                    self.acc_consultar, self.acc_medir, None, self.acc_config_dwg):
            m.addSeparator() if acc is None else m.addAction(acc)

        m = barra.addMenu("&Biblioteca de mallas")
        m.addAction(self.acc_malla_auto)
        m.addAction(self.acc_biblioteca)
        m.addAction(self.acc_malla_real)
        m.addSeparator()
        m.addAction(self.acc_referencias)

        m = barra.addMenu("Visuali&zador 2D/3D")
        for acc in (self.acc_superior, self.acc_frontal, self.acc_lateral, self.acc_isometrica, self.acc_ajustar,
                    None, self.acc_rejilla, self.acc_consultar, self.acc_medir, None):
            m.addSeparator() if acc is None else m.addAction(acc)
        cal = m.addMenu("Calidad gráfica")
        for acc in self.acciones_calidad:
            cal.addAction(acc)

        m = barra.addMenu("Simulación &3D")
        for acc in (self.acc_ciclo, None, self.acc_sim_completa, None, self.acc_sim_jumbo, self.acc_sim_perf, self.acc_sim_carguio,
                    self.acc_sim_voladura, self.acc_sim_frag, self.acc_sim_comparar, None, self.acc_equipos):
            m.addSeparator() if acc is None else m.addAction(acc)

        m = barra.addMenu("&Reportes")
        m.addAction(self.acc_reporte)
        m.addAction(self.acc_exportar_imagen)
        m.addAction(self.acc_exportar_csv)
        m.addAction(self.acc_exportar_cad)

        ayuda = barra.addMenu("A&yuda")
        ayuda.addAction(self.acc_inicio)
        ayuda.addAction(self.acc_acerca)

    def _crear_barras(self) -> None:
        archivo = QToolBar("Archivo", self)
        archivo.setObjectName("barra_archivo")
        archivo.setMovable(False)
        archivo.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self._iconos_barra()
        try:
            from PySide6.QtCore import QSize
            archivo.setIconSize(QSize(26, 26))
        except Exception:  # noqa: BLE001
            pass
        for acc in (self.acc_nuevo, self.acc_abrir, self.acc_guardar, None,
                    self.acc_deshacer, self.acc_rehacer, None, self.acc_malla_auto, self.acc_diseno,
                    self.acc_explosivos, None, self.acc_biblioteca, self.acc_importar_cad, self.acc_malla_topo,
                    self.acc_exportar_cad, None,
                    self.acc_simular, self.acc_mapa, self.acc_ver_mapa, self.acc_sim_completa, self.acc_ciclo, self.acc_inicio, None,
                    self.acc_centro_analisis):
            archivo.addSeparator() if acc is None else archivo.addAction(acc)
        self.addToolBar(Qt.ToolBarArea.TopToolBarArea, archivo)

        vistas = QToolBar("Vistas", self)
        vistas.setObjectName("barra_vistas")
        vistas.setMovable(False)
        vistas.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        titulo = QLabel("  Vista 3D:  ")
        titulo.setObjectName("TextoSecundario")
        vistas.addWidget(titulo)
        for acc in (self.acc_superior, self.acc_frontal, self.acc_lateral, self.acc_isometrica,
                    None, self.acc_ajustar, self.acc_quitar_sel):
            vistas.addSeparator() if acc is None else vistas.addAction(acc)
        espacio = QWidget()
        espacio.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        vistas.addWidget(espacio)
        self.chip = QLabel()
        self.chip.setObjectName("Chip")
        vistas.addWidget(self.chip)
        self.addToolBar(Qt.ToolBarArea.TopToolBarArea, vistas)

    def _iconos_barra(self) -> None:
        """Iconos y nombres cortos para la barra de herramientas (el menú conserva el texto completo)."""
        from app.ui.iconos import icono_simbolo
        iconos = [
            ("acc_nuevo", "✚", "Nuevo"), ("acc_abrir", "📂", "Abrir"), ("acc_guardar", "💾", "Guardar"),
            ("acc_deshacer", "↶", "Deshacer"), ("acc_rehacer", "↷", "Rehacer"),
            ("acc_malla_auto", "▦", "Malla auto"), ("acc_diseno", "⚙", "Diseño"), ("acc_explosivos", "🧨", "Explosivos"),
            ("acc_biblioteca", "📚", "Biblioteca"), ("acc_importar_cad", "⛰", "Topografía"), ("acc_malla_topo", "◭", "Malla tajo"),
            ("acc_exportar_cad", "⇪", "Exportar"), ("acc_simular", "💥", "Voladura"), ("acc_mapa", "◉", "Vibración"),
            ("acc_ver_mapa", "◎", "Ver mapa"), ("acc_sim_completa", "🎞", "Simulador"), ("acc_ciclo", "🎬", "Ciclo 3D"),
            ("acc_inicio", "⌂", "Inicio"), ("acc_centro_analisis", "📊", "Análisis"),
        ]
        destacados = {"acc_ciclo": "#1a6e67", "acc_malla_auto": "#1a6e67", "acc_inicio": "#24303a"}
        for nombre, simbolo, corto in iconos:
            acc = getattr(self, nombre, None)
            if acc is None:
                continue
            try:
                acc.setIcon(icono_simbolo(simbolo, "#e8ebef", 44, destacados.get(nombre)))
                acc.setIconText(corto)
            except Exception:  # noqa: BLE001 — sin icono si la fuente no está
                pass

    def _crear_barra_estado(self) -> None:
        self.etiqueta_seleccion = QLabel("Sin selección")
        self.etiqueta_resumen = QLabel()
        self.statusBar().addWidget(self.etiqueta_seleccion, 1)
        self.statusBar().addPermanentWidget(self.etiqueta_resumen)
        self.statusBar().addPermanentWidget(QLabel("Unidades: m · ° · mm · kg"))
        ver = QLabel(f"  {NOMBRE_APP} {VERSION}  ")
        ver.setObjectName("Chip")
        self.statusBar().addPermanentWidget(ver)
        self.visor.mensaje_herramienta.connect(lambda texto: (self.statusBar().showMessage(texto),
                                                              self.mensajes.agregar(texto)))

    # ================================================================ refresco
    def _programar_refresco(self) -> None:
        """Agrupa varios cambios seguidos en un solo redibujado."""
        if not self._refresco_pendiente:
            self._refresco_pendiente = True
            QTimer.singleShot(0, self._refrescar_todo)

    def _refrescar_todo(self) -> None:
        self._refresco_pendiente = False
        self.visor.refrescar()
        self.panel_capas.refrescar()
        self.panel_tabla.refrescar()
        self.panel_propiedades.refrescar()
        self._actualizar_titulo()
        self._actualizar_acciones()
        if self._informar_mapa:
            self._informar_mapa = False
            self._reportar_mapa()

    def _reportar_mapa(self) -> None:
        if self.visor.error_mapa:
            self.mensajes.agregar(f"Mapa de vibración: {self.visor.error_mapa}", "aviso")
            QMessageBox.information(self, "Mapa de vibración", self.visor.error_mapa)
            return
        r = self.visor.mapa
        if r is None:
            return
        nombres = ("azul", "verde", "amarillo", "rojo")
        areas = " · ".join(f"{n}: {a:.1f} m²" for n, a in zip(nombres, r.areas_por_zona()))
        self.mensajes.agregar(f"Mapa de vibración: {r.plano}. PPV máx. {r.ppv_max:,.0f} mm/s.")
        self.mensajes.agregar(f"Área por zona en el plano → {areas}")
        if not self.doc.proyecto.mapa.constantes_calibradas:
            self.mensajes.agregar("Constantes K, α, β sin calibrar: el mapa es orientativo.", "aviso")

    def _actualizar_titulo(self) -> None:
        nombre = self.doc.ruta.name if self.doc.ruta else self.doc.proyecto.nombre
        marca = " •" if self.doc.modificado else ""
        self.setWindowTitle(f"{nombre}{marca} — {NOMBRE_APP} {VERSION}")
        self.chip.setText(("⚠ Ejemplo · " if self.doc.proyecto.escenario_demo else "")
                          + self.doc.proyecto.nombre)
        r = resumen_voladura(self.doc.proyecto)
        fc = f"{r.factor_carga:.3f} kg/m³" if r.factor_carga is not None else "—"
        fp = f"{r.factor_potencia:.3f} kg/t" if r.factor_potencia is not None else "—"
        self.etiqueta_resumen.setText(f"Explosivo: {r.carga_total:.1f} kg · FC: {fc} · FP: {fp}")

    def _actualizar_acciones(self) -> None:
        d, r = self.doc.puede_deshacer(), self.doc.puede_rehacer()
        self.acc_deshacer.setEnabled(d is not None)
        self.acc_deshacer.setText(f"Deshacer: {d}" if d else "Deshacer")
        self.acc_rehacer.setEnabled(r is not None)
        self.acc_rehacer.setText(f"Rehacer: {r}" if r else "Rehacer")
        hay_sel = self.doc.proyecto.objeto(self.doc.seleccion.actual) is not None
        self.acc_eliminar.setEnabled(hay_sel)
        self.acc_ver_mapa.setChecked(self.doc.proyecto.mapa.activo)

    # ================================================================ acciones
    def guardar(self) -> bool:
        if self.doc.ruta is None:
            return self.guardar_como()
        try:
            archivos.guardar_proyecto(self.doc.proyecto, self.doc.ruta)
        except OSError as error:
            QMessageBox.critical(self, "Guardar", f"No se pudo guardar:\n{error}")
            return False
        self.doc.marcar_guardado(self.doc.ruta)
        self.mensajes.agregar(f"Proyecto guardado en {self.doc.ruta}")
        return True

    def guardar_como(self) -> bool:
        sugerido = self.doc.proyecto.nombre.replace(" ", "_").replace(":", "") + archivos.EXTENSION
        ruta, _ = QFileDialog.getSaveFileName(self, "Guardar proyecto", sugerido, FILTRO_PROYECTO)
        if not ruta:
            return False
        if not ruta.lower().endswith(archivos.EXTENSION):
            ruta += archivos.EXTENSION
        self.doc.ruta = None
        try:
            archivos.guardar_proyecto(self.doc.proyecto, ruta)
        except OSError as error:
            QMessageBox.critical(self, "Guardar", f"No se pudo guardar:\n{error}")
            return False
        self.doc.marcar_guardado(ruta)
        self.mensajes.agregar(f"Proyecto guardado en {ruta}")
        return True

    def confirmar_descartar(self) -> bool:
        """True si se puede cerrar el documento actual (guardado o descartado)."""
        if not self.doc.modificado or self.doc.proyecto.escenario_demo and self.doc.ruta is None:
            return True
        r = QMessageBox.question(
            self, "Cambios sin guardar", "El proyecto tiene cambios sin guardar. ¿Guardarlos?",
            QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard
            | QMessageBox.StandardButton.Cancel)
        if r == QMessageBox.StandardButton.Save:
            return self.guardar()
        return r == QMessageBox.StandardButton.Discard

    def importar_csv(self) -> None:
        ruta, _ = QFileDialog.getOpenFileName(self, "Importar taladros", "", FILTRO_CSV)
        if not ruta:
            return
        try:
            pozos, avisos = archivos.importar_pozos_csv(self.doc.proyecto, ruta)
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, "Importar CSV", str(error))
            return
        for aviso in avisos:
            self.mensajes.agregar(aviso, "aviso")
        if pozos:
            self.doc.agregar_pozos(pozos, f"Importar {len(pozos)} taladros")
        texto = f"Importados {len(pozos)} taladros."
        if avisos:
            texto += f" {len(avisos)} aviso(s): revisa la pestaña Mensajes."
        self.mensajes.agregar(texto)
        QMessageBox.information(self, "Importar CSV", texto)
        if pozos:
            self.visor.ajustar()

    def exportar_csv(self) -> None:
        ruta, _ = QFileDialog.getSaveFileName(self, "Exportar taladros", "taladros.csv", FILTRO_CSV)
        if not ruta:
            return
        try:
            n = archivos.exportar_pozos_csv(self.doc.proyecto, ruta)
        except OSError as error:
            QMessageBox.critical(self, "Exportar CSV", str(error))
            return
        self.mensajes.agregar(f"Exportados {n} taladros a {ruta}")

    def exportar_imagen(self) -> None:
        ruta, _ = QFileDialog.getSaveFileName(self, "Exportar imagen", "vista_3d.png", "Imagen PNG (*.png)")
        if not ruta:
            return
        try:
            self.visor.guardar_imagen(ruta)
            self.mensajes.agregar(f"Imagen guardada en {ruta}")
        except Exception as error:  # el error exacto depende del sistema gráfico
            QMessageBox.critical(self, "Exportar imagen", str(error))

    def deshacer(self) -> None:
        texto = self.doc.deshacer()
        if texto:
            self.mensajes.agregar(f"Deshecho: {texto}")

    def rehacer(self) -> None:
        texto = self.doc.rehacer()
        if texto:
            self.mensajes.agregar(f"Rehecho: {texto}")

    def agregar_pozo(self) -> None:
        pozo = self.doc.nuevo_pozo(self.doc.seleccion.actual)
        self.doc.agregar_pozos([pozo], f"Agregar {pozo.id}")
        self.doc.seleccion.seleccionar(pozo.id, origen="menu")
        self.pestanas.setCurrentWidget(self.panel_tabla)
        self.mensajes.agregar(f"Taladro {pozo.id} agregado. Edita sus valores en la tabla.")

    def eliminar_seleccion(self) -> None:
        objeto = self.doc.proyecto.objeto(self.doc.seleccion.actual)
        if objeto is None:
            return
        self.doc.eliminar_objetos([objeto.id])
        self.mensajes.agregar(f"Eliminado {objeto.id} (Ctrl+Z para deshacer).")

    def configurar_mapa(self) -> None:
        dialogo = DialogoMapa(self.doc.proyecto.mapa, self)
        if dialogo.exec():
            self._informar_mapa = True
            self.doc.actualizar_mapa(dialogo.valor())
            self._programar_refresco()
            escenario = self.doc.proyecto.diseno.escenario
            QTimer.singleShot(60, self.visor.vista_superior if escenario == "tajo"
                              else self.visor.vista_frontal)

    def alternar_mapa(self) -> None:
        cfg = self.doc.proyecto.mapa
        if not cfg.activo and cfg == type(cfg)():
            self.acc_ver_mapa.setChecked(False)
            self.configurar_mapa()  # primera vez: mostrar la configuración
            return
        self._informar_mapa = not cfg.activo
        self.doc.actualizar_mapa(replace(cfg, activo=not cfg.activo))

    def simular_voladura(self) -> None:
        if not self.doc.proyecto.perforaciones():
            QMessageBox.information(self, "Simular voladura",
                                    "Primero crea la malla (Editar → Malla automática).")
            return
        DialogoSimulacion(self.doc, self).exec()

    def malla_opciones(self, labor: str | None = None, simular: bool = False) -> None:
        from app.ui.dialogo_opciones_malla import DialogoOpcionesMalla
        dialogo = DialogoOpcionesMalla(self.doc, self)
        dialogo.simular_al_elegir = simular
        if labor:
            from app.core.equipos import LABORES
            dialogo.labor.setCurrentIndex(list(LABORES).index(labor))
        if dialogo.exec() and dialogo.descripcion:
            self.mensajes.agregar(f"{dialogo.descripcion} (Ctrl+Z para deshacer).")
            QTimer.singleShot(60, self.visor.vista_frontal)

    def ciclo_completo(self) -> None:
        """Abre la malla automática ya con las opciones generadas; al elegir una se simula el ciclo."""
        if not self.doc.proyecto.explosivos:
            QMessageBox.information(self, "Ciclo completo 3D", "Primero registra al menos un explosivo (Editar → Explosivos; "
                                                               "puedes agregarlos desde la ficha técnica Emulnor).")
            self.editar_explosivos()
            if not self.doc.proyecto.explosivos:
                return
        self.malla_opciones(simular=True)

    def pantalla_inicio(self) -> None:
        from app.ui.dialogo_inicio import DialogoInicio
        d = DialogoInicio(self)
        if not d.exec() or not d.eleccion:
            return
        c = d.eleccion
        if c in ("frente", "chimenea", "tajeo"):
            if not self.doc.proyecto.explosivos:
                QMessageBox.information(self, "Malla", "Primero registra al menos un explosivo (Editar → Explosivos; "
                                                       "puedes agregarlos desde la ficha técnica Emulnor).")
                self.editar_explosivos()
                if not self.doc.proyecto.explosivos:
                    return
            self.malla_opciones(c)
        elif c == "simular":
            self.ciclo_completo()
        elif c == "tajo":
            self.importar_cad()
        elif c == "explosivos":
            self.editar_explosivos()
        elif c == "equipos":
            self.equipos_perforacion()
        elif c == "referencias":
            self.referencias_minas()

    def referencias_minas(self) -> None:
        from app.ui.dialogo_referencias import DialogoReferencias
        DialogoReferencias(self).exec()

    def equipos_perforacion(self) -> None:
        from app.ui.dialogo_equipos import DialogoEquipos
        d = self.doc.proyecto.diseno
        lado = max(d.area_seccion, 1.0) ** 0.5
        DialogoEquipos(self, lado, lado).exec()

    def centro_analisis(self) -> None:
        from app.ui.analisis import DialogoCentroAnalisis
        DialogoCentroAnalisis(self.doc, self).exec()

    def analisis(self, clave: str) -> None:
        from app.ui.analisis import abrir
        abrir(clave, self.doc, self)

    def malla_real(self) -> None:
        from app.core.modelo import ESCENARIO_TAJO
        if self.doc.proyecto.diseno.escenario == ESCENARIO_TAJO and self.doc.proyecto.perforaciones():
            r = QMessageBox.question(self, "Malla automática",
                                     "El estándar es para labores subterráneas de avance. ¿Abrir la malla automática "
                                     "teórica (que también hace bancos de tajo abierto)?")
            if r == QMessageBox.StandardButton.Yes:
                self.malla_automatica()
                return
        from app.ui.dialogo_malla_real import DialogoMallaReal
        dialogo = DialogoMallaReal(self.doc, self)
        if dialogo.exec() and dialogo.descripcion:
            self.mensajes.agregar(f"{dialogo.descripcion} (Ctrl+Z para deshacer).", "aviso")
            QTimer.singleShot(60, self.visor.vista_frontal)

    def malla_automatica(self) -> None:
        if not self.doc.proyecto.explosivos:
            QMessageBox.information(self, "Malla automática",
                                    "Primero registra al menos un explosivo en Editar → Explosivos.")
            return
        dialogo = DialogoMallaAutomatica(self.doc, self)
        if dialogo.exec():
            self.mensajes.agregar(f"{dialogo.descripcion} (Ctrl+Z para deshacer).")
            vista = (self.visor.vista_isometrica if self.doc.proyecto.diseno.escenario == "tajo"
                     else self.visor.vista_frontal)
            QTimer.singleShot(60, vista)

    def disenar_malla(self) -> None:
        if not self.doc.proyecto.explosivos:
            self.mensajes.agregar("Consejo: registra tus explosivos en Editar → Explosivos "
                                  "para que la malla salga cargada.", "aviso")
        es_tajo = None
        while True:
            dialogo = DialogoMalla(self.doc, self, es_tajo=es_tajo)
            resultado = dialogo.exec()
            if resultado == DialogoMalla.CAMBIAR_TIPO:
                es_tajo = dialogo.es_tajo_pedido
                continue
            break
        if resultado == 1:
            self.mensajes.agregar(f"Malla creada: {len(self.doc.proyecto.perforaciones())} taladros en "
                                  "el proyecto (Ctrl+Z para deshacer).")
            vista = (self.visor.vista_isometrica if self.doc.proyecto.diseno.escenario == "tajo"
                     else self.visor.vista_frontal)
            QTimer.singleShot(60, vista)

    def editar_diseno(self) -> None:
        contornos = [o for o in self.doc.proyecto.objetos.values() if isinstance(o, Contorno)]
        area = round(contornos[0].area(), 2) if contornos else None
        dialogo = DialogoDiseno(self.doc.proyecto.diseno, area, self)
        if dialogo.exec():
            self.doc.actualizar_diseno(dialogo.formulario.valor())
            self.mensajes.agregar("Parámetros de voladura actualizados.")

    def editar_explosivos(self) -> None:
        dialogo = DialogoExplosivos(self.doc.proyecto.explosivos, self)
        if dialogo.exec():
            try:
                self.doc.reemplazar_explosivos(dialogo.explosivos())
                self.mensajes.agregar("Explosivos actualizados.")
            except ErrorEdicion as error:
                QMessageBox.warning(self, "Explosivos", str(error))

    # ================================================================ topografía y CAD
    def importar_cad(self) -> None:
        from app.ui.dialogo_cad import DialogoImportarCAD
        dialogo = DialogoImportarCAD(self.doc, self)
        if dialogo.exec():
            self.mensajes.agregar(f"{dialogo.descripcion} (Ctrl+Z para deshacer).")
            QTimer.singleShot(60, self.visor.vista_isometrica)
            QTimer.singleShot(80, self.visor.ajustar)

    def crear_tin(self) -> None:
        from app.ui.dialogo_cad import DialogoCrearTIN
        dialogo = DialogoCrearTIN(self.doc, self)
        if dialogo.exec():
            self.mensajes.agregar(dialogo.descripcion)

    def perfil_topografico(self) -> None:
        from app.ui.dialogo_cad import DialogoPerfil, tins_del_proyecto
        if not tins_del_proyecto(self.doc.proyecto):
            QMessageBox.information(self, "Perfil", "Primero crea o importa una superficie TIN "
                                    "(Topografía y CAD → Importar DXF / DWG).")
            return
        DialogoPerfil(self.doc, self.visor, self).exec()

    def pendientes(self) -> None:
        from app.ui.dialogo_cad import DialogoPendientes
        if DialogoPendientes(self.doc, self).exec():
            self.mensajes.agregar("Coloreado de la superficie actualizado.")

    def malla_topografica(self) -> None:
        from app.ui.dialogo_malla_topo import DialogoMallaTopografica
        dialogo = DialogoMallaTopografica(self.doc, self)
        if dialogo.exec() and dialogo.descripcion:
            self.mensajes.agregar(f"{dialogo.descripcion} (Ctrl+Z para deshacer).")
            QTimer.singleShot(60, self.visor.vista_isometrica)
            QTimer.singleShot(80, self.visor.ajustar)

    def exportar_cad(self) -> None:
        if not self.doc.proyecto.perforaciones():
            QMessageBox.information(self, "Exportar", "El proyecto no tiene taladros para exportar.")
            return
        from app.ui.dialogo_exportar_cad import DialogoExportarCAD
        dialogo = DialogoExportarCAD(self.doc, self)
        if dialogo.exec() and dialogo.ruta:
            self.mensajes.agregar(f"Malla exportada: {dialogo.ruta}")

    def config_dwg(self) -> None:
        from app.ui.dialogo_cad import DialogoConfigDWG
        DialogoConfigDWG(self).exec()

    def _herramienta(self, nombre: str, activa: bool) -> None:
        otra = self.acc_medir if nombre == "consultar" else self.acc_consultar
        if activa:
            otra.blockSignals(True); otra.setChecked(False); otra.blockSignals(False)
            self.mensajes.agregar("Consultar: haz clic en la vista 3D." if nombre == "consultar"
                                  else "Medir: haz clic en dos puntos de la vista 3D.")
        self.visor.set_herramienta(nombre if activa else None)

    def _calidad(self, nivel: str) -> None:
        for acc in self.acciones_calidad:
            acc.setChecked(acc.text().endswith(nivel.lower()))
        self.visor.set_calidad(nivel.lower())

    # ================================================================ biblioteca
    def biblioteca(self) -> None:
        from app.ui.dialogo_biblioteca import DialogoBiblioteca
        dialogo = DialogoBiblioteca(self.doc, self)
        if dialogo.exec() and dialogo.descripcion:
            self.mensajes.agregar(f"{dialogo.descripcion} (Ctrl+Z para deshacer).", "aviso")
            QTimer.singleShot(60, self.visor.vista_frontal)

    # ================================================================ simulación 3D
    def simulador_3d(self, etapa: int = 0, comparar: bool = False) -> None:
        try:
            from app.sim3d.ventana import abrir_simulador
        except Exception as error:  # noqa: BLE001
            QMessageBox.warning(self, "Simulador 3D", f"No se pudo cargar el simulador 3D: {error}")
            return
        ventana = abrir_simulador(self.doc, self, etapa)
        if ventana is not None:
            self._simulador = ventana
            if comparar:
                ventana.chk_comparar.setChecked(True)
            self.mensajes.agregar("Simulador 3D abierto. Las animaciones son ilustrativas; los datos de la malla "
                                  "son los del proyecto.")

    # ================================================================ reportes
    def reporte(self) -> None:
        from app.core.reporte import generar_html
        nombre = (self.doc.ruta.stem if self.doc.ruta else self.doc.proyecto.nombre) + "_reporte.html"
        ruta, _ = QFileDialog.getSaveFileName(self, "Guardar reporte", nombre, "Página web (*.html)")
        if not ruta:
            return
        with open(ruta, "w", encoding="utf-8") as fh:
            fh.write(generar_html(self.doc.proyecto, str(self.doc.ruta or "")))
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl.fromLocalFile(ruta))
        self.mensajes.agregar(f"Reporte guardado: {ruta}")

    # ================================================================ eventos
    def _cambiar_visibilidad_capa(self, capa_id: str, visible: bool) -> None:
        self.visor.set_capa_visible(capa_id, visible)
        capa = self.doc.proyecto.capa(capa_id)
        self.mensajes.agregar(f"Capa «{capa.nombre if capa else capa_id}»: "
                              f"{'visible' if visible else 'oculta'}.")

    def _al_cambiar_seleccion(self, objeto_id, _origen) -> None:
        objeto = self.doc.proyecto.objeto(objeto_id)
        self.etiqueta_seleccion.setText(
            f"Seleccionado: {objeto.nombre} ({objeto.TIPO})" if objeto else "Sin selección")
        self._actualizar_acciones()

    def _acerca_de(self) -> None:
        QMessageBox.about(
            self, f"Acerca de {NOMBRE_APP}",
            f"<b>{NOMBRE_APP}</b> versión {VERSION}<br><br>"
            "Diseño y análisis de voladuras para tajo abierto y minería subterránea.<br>"
            "Python · PySide6 (Qt) · PyVista (VTK).<br><br>"
            "Cálculos de carga documentados en <i>app/calc/carga.py</i> "
            "(fuentes, supuestos y límites).<br>"
            "Los resultados son de referencia: verifícalos y ajústalos con pruebas de campo antes de "
            "usarlos. Se entrega sin garantía.",
        )

    def closeEvent(self, evento) -> None:  # noqa: N802 (nombre exigido por Qt)
        if not self.cerrar_sin_preguntar and not self.confirmar_descartar():
            evento.ignore()
            return
        self.visor.cerrar()
        super().closeEvent(evento)
