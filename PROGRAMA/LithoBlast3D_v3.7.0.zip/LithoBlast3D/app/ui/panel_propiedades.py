"""
Panel derecho: propiedades del objeto seleccionado.
Sin selección, muestra el resumen del disparo (carga total, factores).
"""

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QHeaderView,
    QLabel,
    QSizePolicy,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.documento import Documento
from app.core.modelo import NOMBRES_ESCENARIO, Perforacion, Propiedad
from app.core.resultados import propiedades_completas, propiedades_resumen


class PanelPropiedades(QWidget):
    def __init__(self, documento: Documento, colores: dict, parent=None):
        super().__init__(parent)
        self._doc = documento
        self._c = colores

        self.titulo = QLabel()
        self.titulo.setObjectName("TituloObjeto")
        self.titulo.setWordWrap(True)
        self.subtitulo = QLabel()
        self.subtitulo.setObjectName("Subtitulo")
        self.insignia = QLabel()
        self.insignia.setObjectName("Insignia")
        self.insignia.setWordWrap(True)
        self.ayuda = QLabel("Haz clic en un objeto del visor, del árbol o de la tabla "
                            "para ver sus propiedades.")
        self.ayuda.setObjectName("TextoVacio")
        self.ayuda.setWordWrap(True)

        self.tabla = QTreeWidget()
        self.tabla.setColumnCount(3)
        self.tabla.setHeaderLabels(["Propiedad", "Valor", "Unidad"])
        self.tabla.setRootIsDecorated(False)
        self.tabla.setSelectionMode(QTreeWidget.SelectionMode.NoSelection)
        self.tabla.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        cabecera = self.tabla.header()
        cabecera.setStretchLastSection(False)
        cabecera.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        cabecera.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        cabecera.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)

        encabezado = QWidget()
        encabezado.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        diseno_enc = QVBoxLayout(encabezado)
        diseno_enc.setContentsMargins(12, 10, 12, 8)
        diseno_enc.setSpacing(4)
        for w in (self.titulo, self.subtitulo, self.insignia, self.ayuda):
            diseno_enc.addWidget(w)

        diseno = QVBoxLayout(self)
        diseno.setContentsMargins(0, 0, 0, 0)
        diseno.setSpacing(0)
        diseno.addWidget(encabezado)
        diseno.addWidget(self.tabla, 1)

        self._doc.seleccion.suscribir(lambda *_: self.refrescar())
        self.refrescar()

    def refrescar(self) -> None:
        proyecto = self._doc.proyecto
        objeto = proyecto.objeto(self._doc.seleccion.actual)
        self.tabla.clear()

        if objeto is None:
            self.titulo.setText("Resumen del disparo")
            self.subtitulo.setText(f"{proyecto.nombre} · "
                                   f"{NOMBRES_ESCENARIO.get(proyecto.diseno.escenario, '')}")
            self.insignia.setVisible(proyecto.escenario_demo)
            self.insignia.setText("⚠  Proyecto de ejemplo: datos inventados para mostrar el programa")
            self.ayuda.show()
            filas = propiedades_resumen(proyecto)
        else:
            self.titulo.setText(objeto.nombre)
            self.subtitulo.setText(objeto.TIPO)
            self.ayuda.hide()
            avisos = []
            if objeto.es_demo:
                avisos.append("⚠  Dato de ejemplo: reemplázalo por tus datos")
            if isinstance(objeto, Perforacion):
                explosivo = proyecto.explosivo(objeto.explosivo_id)
                if explosivo is not None and explosivo.referencial:
                    avisos.append("⚠  Densidad genérica: verifica con la ficha técnica del fabricante "
                                  "(Editar → Explosivos)")
            self.insignia.setText("\n".join(avisos))
            self.insignia.setVisible(bool(avisos))
            capa = proyecto.capa(objeto.capa_id)
            filas = [
                Propiedad("General", "Identificador", objeto.id),
                Propiedad("General", "Capa", capa.nombre if capa else objeto.capa_id),
                *propiedades_completas(proyecto, objeto),
            ]
        self._llenar(filas)

    def _llenar(self, filas: list[Propiedad]) -> None:
        grupo_actual = None
        for fila in filas:
            if fila.grupo != grupo_actual:
                grupo_actual = fila.grupo
                self._agregar_grupo(fila.grupo)
            item = QTreeWidgetItem([fila.nombre, fila.valor, fila.unidad])
            item.setTextAlignment(1, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            item.setForeground(0, QColor(self._c["texto_secundario"]))
            item.setForeground(2, QColor(self._c["texto_secundario"]))
            if fila.nombre.startswith("⚠"):
                item.setForeground(0, QColor(self._c["aviso"]))
                item.setForeground(1, QColor(self._c["aviso"]))
                item.setToolTip(1, fila.valor)
            self.tabla.addTopLevelItem(item)

    def _agregar_grupo(self, nombre: str) -> None:
        item = QTreeWidgetItem([nombre.upper()])
        fuente = item.font(0)
        fuente.setBold(True)
        item.setFont(0, fuente)
        item.setForeground(0, QColor(self._c["acento"]))
        item.setFlags(Qt.ItemFlag.ItemIsEnabled)
        self.tabla.addTopLevelItem(item)
        item.setFirstColumnSpanned(True)
