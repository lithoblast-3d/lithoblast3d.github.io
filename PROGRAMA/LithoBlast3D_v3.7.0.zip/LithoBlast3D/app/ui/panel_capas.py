"""Panel izquierdo: árbol del proyecto con capas (visibilidad) y objetos."""

from collections.abc import Callable

from PySide6.QtCore import QModelIndex, Qt
from PySide6.QtWidgets import QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget

from app.core.documento import Documento
from app.ui.iconos import icono_color

ROL_ID = Qt.ItemDataRole.UserRole  # guarda "capa:<id>" u "objeto:<id>"


class PanelCapas(QWidget):
    def __init__(self, documento: Documento, al_cambiar_visibilidad: Callable[[str, bool], None],
                 parent=None):
        super().__init__(parent)
        self._doc = documento
        self._al_cambiar_visibilidad = al_cambiar_visibilidad
        self._items_objeto: dict[str, QTreeWidgetItem] = {}
        self._capas_plegadas: set[str] = set()

        self.arbol = QTreeWidget()
        self.arbol.setHeaderHidden(True)
        self.arbol.setIndentation(16)
        self.arbol.setUniformRowHeights(True)
        self.arbol.setToolTip("Marca o desmarca una capa para mostrarla u ocultarla")
        diseno = QVBoxLayout(self)
        diseno.setContentsMargins(0, 0, 0, 0)
        diseno.addWidget(self.arbol)

        self.arbol.itemChanged.connect(self._al_cambiar_item)
        self.arbol.currentItemChanged.connect(self._al_cambiar_actual)
        self.arbol.itemCollapsed.connect(lambda i: self._recordar_plegado(i, True))
        self.arbol.itemExpanded.connect(lambda i: self._recordar_plegado(i, False))
        self._doc.seleccion.suscribir(self._al_cambiar_seleccion)

        proyecto = self._doc.proyecto
        self._capas_plegadas = {c.id for c in proyecto.capas if len(proyecto.objetos_de_capa(c.id)) > 5}
        self.refrescar()

    def refrescar(self) -> None:
        proyecto = self._doc.proyecto
        self.arbol.blockSignals(True)
        try:
            self.arbol.clear()
            self._items_objeto.clear()
            raiz = QTreeWidgetItem([proyecto.nombre])
            fuente = raiz.font(0)
            fuente.setBold(True)
            raiz.setFont(0, fuente)
            raiz.setFlags(Qt.ItemFlag.ItemIsEnabled)
            self.arbol.addTopLevelItem(raiz)

            for capa in proyecto.capas:
                objetos = proyecto.objetos_de_capa(capa.id)
                item_capa = QTreeWidgetItem([f"{capa.nombre}  ({len(objetos)})"])
                item_capa.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
                                   | Qt.ItemFlag.ItemIsUserCheckable)
                item_capa.setCheckState(0, Qt.CheckState.Checked if capa.visible
                                        else Qt.CheckState.Unchecked)
                item_capa.setIcon(0, icono_color(capa.color, "cuadro"))
                item_capa.setData(0, ROL_ID, f"capa:{capa.id}")
                raiz.addChild(item_capa)
                for objeto in objetos:
                    item = QTreeWidgetItem([objeto.nombre])
                    item.setIcon(0, icono_color(capa.color, "circulo"))
                    item.setData(0, ROL_ID, f"objeto:{objeto.id}")
                    item.setToolTip(0, f"{objeto.TIPO} · {objeto.id}")
                    item.setDisabled(not capa.visible)
                    item_capa.addChild(item)
                    self._items_objeto[objeto.id] = item
                item_capa.setExpanded(capa.id not in self._capas_plegadas)
            raiz.setExpanded(True)
        finally:
            self.arbol.blockSignals(False)
        self._al_cambiar_seleccion(self._doc.seleccion.actual, "")

    @staticmethod
    def _leer_id(item: QTreeWidgetItem | None):
        if item is None:
            return (None, None)
        dato = item.data(0, ROL_ID)
        if not dato or ":" not in str(dato):
            return (None, None)
        tipo, ident = str(dato).split(":", 1)
        return (tipo, ident)

    def _recordar_plegado(self, item: QTreeWidgetItem, plegado: bool) -> None:
        tipo, capa_id = self._leer_id(item)
        if tipo == "capa":
            (self._capas_plegadas.add if plegado else self._capas_plegadas.discard)(capa_id)

    def _al_cambiar_item(self, item: QTreeWidgetItem, _columna: int) -> None:
        tipo, capa_id = self._leer_id(item)
        if tipo != "capa":
            return
        visible = item.checkState(0) == Qt.CheckState.Checked
        capa = self._doc.proyecto.capa(capa_id)
        if capa is None or capa.visible == visible:
            return
        capa.visible = visible
        for k in range(item.childCount()):
            item.child(k).setDisabled(not visible)
        self._al_cambiar_visibilidad(capa_id, visible)

    def _al_cambiar_actual(self, actual: QTreeWidgetItem | None, _anterior) -> None:
        tipo, ident = self._leer_id(actual)
        if tipo == "objeto":
            self._doc.seleccion.seleccionar(ident, origen="capas")

    def _al_cambiar_seleccion(self, objeto_id: str | None, origen: str) -> None:
        if origen == "capas":
            return
        self.arbol.blockSignals(True)
        try:
            item = self._items_objeto.get(objeto_id) if objeto_id else None
            if item is not None:
                if item.parent() is not None:
                    item.parent().setExpanded(True)
                self.arbol.setCurrentItem(item)
                self.arbol.scrollToItem(item)
            else:
                self.arbol.clearSelection()
                self.arbol.setCurrentIndex(QModelIndex())
        finally:
            self.arbol.blockSignals(False)
