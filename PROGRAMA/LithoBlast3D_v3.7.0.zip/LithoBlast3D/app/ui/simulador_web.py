"""Abre la simulación 3D del ciclo (la misma del teléfono) en el navegador, sin internet.

Los archivos están en app/datos/web3d (página, simlabor.js, modelos3d.js y three.js incluido). Se copian a una
carpeta temporal junto con escena.json y se sirven con un servidor local (127.0.0.1) porque los navegadores no
cargan módulos JavaScript desde archivos sueltos (file://)."""

from __future__ import annotations

import functools
import json
import shutil
import tempfile
import threading
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ORIGEN = Path(__file__).resolve().parent.parent / "datos" / "web3d"
_SERVIDOR: dict = {}


class _Servidor(ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):  # el navegador cortó la conexión: no es un error
        pass


class _Silencioso(SimpleHTTPRequestHandler):
    def log_message(self, *a):  # noqa: D401 — sin mensajes en consola
        pass

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()


def preparar(escena: dict) -> Path:
    """Carpeta con la página y la escena (reutiliza la del servidor en marcha)."""
    if not (ORIGEN / "labor.html").exists():
        raise FileNotFoundError(f"Falta la simulación web en {ORIGEN}")
    carpeta = _SERVIDOR.get("carpeta")
    if carpeta is None:
        carpeta = Path(tempfile.mkdtemp(prefix="barreno3d_sim_"))
        shutil.copytree(ORIGEN, carpeta, dirs_exist_ok=True)
        _SERVIDOR["carpeta"] = carpeta
    (carpeta / "escena.json").write_text(json.dumps(escena, ensure_ascii=False), encoding="utf-8")
    return carpeta


def url(escena: dict) -> str:
    carpeta = preparar(escena)
    if "srv" not in _SERVIDOR:
        srv = _Servidor(("127.0.0.1", 0), functools.partial(_Silencioso, directory=str(carpeta)))
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        _SERVIDOR["srv"] = srv
    return f"http://127.0.0.1:{_SERVIDOR['srv'].server_address[1]}/labor.html"


def abrir(escena: dict) -> str:
    u = url(escena)
    webbrowser.open(u)
    return u
