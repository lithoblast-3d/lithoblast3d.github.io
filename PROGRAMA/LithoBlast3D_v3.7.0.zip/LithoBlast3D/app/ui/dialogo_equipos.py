"""Catálogo editable de equipos de perforación y prueba de selección para una sección."""

from __future__ import annotations

from dataclasses import replace

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from app.core import equipos as eq
from app.ui.analisis.base import numero
from app.ui.tema import ajustar_a_pantalla

COLS = [("nombre", "Equipo", str), ("tipo", "Tipo", str), ("brazos", "Brazos", int), ("ancho", "Ancho m", float),
        ("alto", "Alto m", float), ("seccion_min_ancho", "Sección mín.\nancho m", float),
        ("seccion_min_alto", "Sección mín.\nalto m", float), ("cobertura_m2", "Cobertura\nm²", float),
        ("diametro_min_mm", "Ø mín\nmm", float), ("diametro_max_mm", "Ø máx\nmm", float),
        ("long_perforacion_max", "L perf.\nmáx m", float), ("labores", "Labores", list)]


class DialogoEquipos(QDialog):
    def __init__(self, parent=None, ancho: float = 3.5, alto: float = 3.5):
        super().__init__(parent)
        self.setWindowTitle("Equipos de perforación")
        v = QVBoxLayout(self)
        t = QLabel("Equipos de perforación")
        t.setObjectName("TituloGrande")
        v.addWidget(t)
        n = QLabel("Datos de las hojas técnicas de los fabricantes y de la clase S-6 (pasa el cursor sobre el nombre "
                   "para ver la fuente). Si una celda de sección mínima está vacía, se calcula con el ancho/alto del "
                   f"equipo + holguras ({eq.HOLGURA_LATERAL:.2f} m por lado y {eq.HOLGURA_SUPERIOR:.2f} m arriba). "
                   "Todo es editable y se guarda en tu usuario.")
        n.setObjectName("TextoSecundario")
        n.setWordWrap(True)
        v.addWidget(n)
        self.tabla = QTableWidget(0, len(COLS))
        self.tabla.setHorizontalHeaderLabels([c[1] for c in COLS])
        self.tabla.verticalHeader().setVisible(False)
        self.tabla.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        v.addWidget(self.tabla, 1)
        self.equipos = eq.catalogo()
        self._llenar()

        prueba = QHBoxLayout()
        self.p_ancho = numero(0.5, 30, ancho, 2, 0.1, "m")
        self.p_alto = numero(0.5, 30, alto, 2, 0.1, "m")
        self.p_labor = QComboBox()
        for k, txt in eq.LABORES.items():
            self.p_labor.addItem(txt, k)
        for w, txt in ((QLabel("Probar:"), None), (QLabel("ancho"), None), (self.p_ancho, None), (QLabel("alto"), None),
                       (self.p_alto, None), (self.p_labor, None)):
            prueba.addWidget(w)
        b = QPushButton("Elegir equipo")
        b.clicked.connect(self._probar)
        prueba.addWidget(b)
        prueba.addStretch(1)
        v.addLayout(prueba)
        self.resultado = QLabel("")
        self.resultado.setWordWrap(True)
        v.addWidget(self.resultado)
        fila = QHBoxLayout()
        rest = QPushButton("Restaurar valores del catálogo")
        rest.clicked.connect(self._restaurar)
        guardar = QPushButton("Guardar")
        guardar.setObjectName("Primario")
        guardar.clicked.connect(self._guardar)
        cerrar = QPushButton("Cerrar")
        cerrar.clicked.connect(self.reject)
        fila.addWidget(rest)
        fila.addStretch(1)
        fila.addWidget(guardar)
        fila.addWidget(cerrar)
        v.addLayout(fila)
        ajustar_a_pantalla(self, 1250, 640)
        self._probar()

    def _llenar(self):
        self.tabla.setRowCount(0)
        for e in self.equipos:
            r = self.tabla.rowCount()
            self.tabla.insertRow(r)
            for c, (k, _, tipo) in enumerate(COLS):
                val = getattr(e, k)
                txt = ", ".join(val) if tipo is list else ("" if val is None else str(val))
                it = QTableWidgetItem(txt)
                if k == "nombre":
                    it.setToolTip(f"{e.fuente}\n{e.nota}".strip())
                    it.setData(Qt.ItemDataRole.UserRole, e.clave)
                if k == "tipo":
                    it.setFlags(Qt.ItemFlag.ItemIsEnabled)
                self.tabla.setItem(r, c, it)

    def leer(self) -> list[eq.Equipo]:
        res = []
        for r, e in enumerate(self.equipos):
            cambios = {}
            for c, (k, titulo, tipo) in enumerate(COLS):
                if k == "tipo":
                    continue
                txt = self.tabla.item(r, c).text().strip().replace(",", ".") if tipo is not list else \
                    self.tabla.item(r, c).text()
                if tipo is list:
                    cambios[k] = [x.strip() for x in txt.split(",") if x.strip() in eq.LABORES]
                elif tipo is str:
                    cambios[k] = txt or e.nombre
                elif txt == "":
                    cambios[k] = None if k.startswith("seccion") or k == "cobertura_m2" else getattr(e, k)
                else:
                    try:
                        cambios[k] = tipo(float(txt))
                    except ValueError as err:
                        raise ValueError(f"{e.nombre} · {titulo.replace(chr(10), ' ')}: «{txt}» no es un número") from err
            res.append(replace(e, **cambios))
        return res

    def _probar(self):
        try:
            lista = self.leer()
        except ValueError as e:
            self.resultado.setText(f"✖ {e}")
            return
        s = eq.seleccionar(self.p_ancho.value(), self.p_alto.value(), self.p_labor.currentData(), equipos=lista)
        filas = "".join(f"<li>{'✔' if ok else '✖'} {e.nombre}{': ' + m if m else ''}</li>" for e, ok, m in s.evaluados)
        self.resultado.setText(f"<b>→ {s.equipo.nombre}</b> — {s.motivo}<ul>{filas}</ul>")

    def _guardar(self):
        try:
            lista = self.leer()
        except ValueError as e:
            QMessageBox.warning(self, "Equipos", str(e))
            return
        eq.guardar_cambios(lista)
        self.equipos = lista
        self.accept()

    def _restaurar(self):
        self.equipos = [replace(e) for e in eq.CATALOGO]
        self._llenar()
        self._probar()
