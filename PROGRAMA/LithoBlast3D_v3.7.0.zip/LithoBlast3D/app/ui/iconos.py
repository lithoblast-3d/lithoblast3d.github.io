"""Iconos sencillos dibujados por el propio programa (sin archivos externos)."""

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QIcon, QPainter, QPixmap


def icono_color(color: str, forma: str = "cuadro", tamano: int = 14) -> QIcon:
    """Icono de un color: 'cuadro' para capas, 'circulo' para objetos."""
    pixmap = QPixmap(tamano, tamano)
    pixmap.fill(Qt.GlobalColor.transparent)
    pintor = QPainter(pixmap)
    pintor.setRenderHint(QPainter.RenderHint.Antialiasing)
    pintor.setPen(Qt.PenStyle.NoPen)
    pintor.setBrush(QColor(color))
    if forma == "circulo":
        margen = tamano // 4
        pintor.drawEllipse(margen, margen, tamano - 2 * margen, tamano - 2 * margen)
    else:
        pintor.drawRoundedRect(1, 1, tamano - 2, tamano - 2, 3, 3)
    pintor.end()
    return QIcon(pixmap)


def icono_simbolo(simbolo: str, color: str = "#e8ebef", tamano: int = 44, fondo: str | None = None) -> QIcon:
    """Icono a partir de un símbolo (Segoe UI Symbol / Emoji en Windows): sin archivos externos.
    Si se indica «fondo», el símbolo va sobre una pastilla redondeada de ese color."""
    from PySide6.QtCore import QRectF
    from PySide6.QtGui import QFont
    pixmap = QPixmap(tamano, tamano)
    pixmap.fill(Qt.GlobalColor.transparent)
    p = QPainter(pixmap)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
    if fondo:
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(fondo))
        p.drawRoundedRect(QRectF(1, 1, tamano - 2, tamano - 2), tamano * 0.28, tamano * 0.28)
    f = QFont()
    f.setFamilies(["Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji", "Segoe UI"])
    f.setPixelSize(int(tamano * 0.58))
    p.setFont(f)
    p.setPen(QColor(color))
    p.drawText(QRectF(0, 0, tamano, tamano), int(Qt.AlignmentFlag.AlignCenter), simbolo)
    p.end()
    return QIcon(pixmap)
