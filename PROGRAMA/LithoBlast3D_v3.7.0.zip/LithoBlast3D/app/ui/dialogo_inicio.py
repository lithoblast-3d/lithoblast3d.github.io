"""Pantalla de inicio: accesos directos por tipo de labor y el ciclo de minado explicado paso a paso."""

from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app import VERSION
from app.ui.tema import ajustar_a_pantalla

ARCHIVO = Path.home() / ".barreno3d" / "inicio.json"

ESTILO = """
QDialog#Inicio { background: #14171b; }
QWidget#Hero { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1f2a30, stop:1 #15191e);
               border: 1px solid #2f363e; border-radius: 18px; }
QLabel#Etiqueta { color: #2ec4b6; font-size: 11px; letter-spacing: 1px; }
QLabel#Grande { color: #e8ebef; font-size: 26px; font-weight: 700; }
QLabel#Texto { color: #8f99a5; font-size: 13px; }
QLabel#Seccion { color: #e8ebef; font-size: 15px; font-weight: 600; margin-top: 6px; }
QPushButton#Acceso { text-align: left; padding: 14px 16px; border-radius: 14px; background: #1b1f24;
                     border: 1px solid #2f363e; color: #e8ebef; font-size: 14px; }
QPushButton#Acceso:hover { border-color: #2ec4b6; background: #1e252b; }
QLabel#Paso { background: #1b1f24; border: 1px solid #2f363e; border-radius: 12px; padding: 10px 12px; color: #c9d0d7; }
"""

ACCESOS = [
    ("⛰  Frente de avance", "Galería, crucero, rampa · malla por tipo de roca", "frente"),
    ("⬆  Chimenea", "Malla en el techo · stoper desde plataforma", "chimenea"),
    ("▤  Tajeo", "Corte y relleno · perforación en breasting", "tajeo"),
    ("◭  Tajo abierto", "Malla sobre las curvas de nivel (DXF/DWG)", "tajo"),
    ("▶  Simular el ciclo 3D", "Mecanizado (jumbo + scoop) o convencional (jackleg)", "simular"),
    ("🧨  Explosivos Emulnor", "500 · 1000 · 3000 · 5000 desde la ficha técnica", "explosivos"),
    ("🛠  Equipos de perforación", "Jumbo, jackleg y stoper con sus medidas", "equipos"),
    ("📚  Referencias de minas", "Volcan SC-CR y Retamas (ejemplos, no reglas)", "referencias"),
]

CICLO = [
    ("Perforación", "Jumbo en secciones grandes; jackleg en secciones pequeñas; stoper en chimeneas."),
    ("Carguío", "Cebo al fondo, cartuchos con atacador de madera y taco al collar."),
    ("Amarre", "Carmex + conectores + mecha rápida en el orden de salida, o Fanel + cordón detonante."),
    ("Voladura", "Arranque, ayudas, cuadradores, corona y al final los arrastres."),
    ("Ventilación", "Se ingresa solo cuando los gases bajan a niveles seguros."),
    ("Limpieza", "Scoop (LHD) donde entra; si no, pala neumática con carros o winche."),
]


def mostrar_al_iniciar() -> bool:
    try:
        return bool(json.loads(ARCHIVO.read_text(encoding="utf-8")).get("mostrar", True))
    except (OSError, ValueError):
        return True


def _guardar(mostrar: bool) -> None:
    try:
        ARCHIVO.parent.mkdir(parents=True, exist_ok=True)
        ARCHIVO.write_text(json.dumps({"mostrar": mostrar}), encoding="utf-8")
    except OSError:
        pass


class DialogoInicio(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Inicio")
        self.setWindowTitle("LithoBlast3D — Inicio")
        self.setStyleSheet(ESTILO)
        self.eleccion: str | None = None
        v = QVBoxLayout(self)
        v.setContentsMargins(22, 22, 22, 18)
        v.setSpacing(12)
        hero = QWidget(); hero.setObjectName("Hero")
        h = QVBoxLayout(hero); h.setContentsMargins(22, 18, 22, 18)
        e = QLabel(f"PERFORACIÓN Y VOLADURA · v{VERSION}"); e.setObjectName("Etiqueta")
        t = QLabel("Diseña, carga y simula tu voladura"); t.setObjectName("Grande")
        x = QLabel("Mallas por tipo de roca, equipos con medidas reales, productos de ficha técnica y el ciclo "
                   "completo en 3D: perforación, carguío, amarre, voladura y limpieza.")
        x.setObjectName("Texto"); x.setWordWrap(True)
        for w in (e, t, x):
            h.addWidget(w)
        v.addWidget(hero)
        s = QLabel("¿Qué vas a trabajar?"); s.setObjectName("Seccion"); v.addWidget(s)
        g = QGridLayout(); g.setSpacing(10)
        self.botones = {}
        for k, (tit, sub, clave) in enumerate(ACCESOS):
            b = QPushButton(f"{tit}\n{sub}"); b.setObjectName("Acceso"); b.setMinimumHeight(64)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, c=clave: self._elegir(c))
            self.botones[clave] = b
            g.addWidget(b, k // 4, k % 4)
        v.addLayout(g)
        s2 = QLabel("El ciclo de minado"); s2.setObjectName("Seccion"); v.addWidget(s2)
        fila = QHBoxLayout(); fila.setSpacing(8)
        for i, (n, d) in enumerate(CICLO, 1):
            p = QLabel(f"<b style='color:#2ec4b6'>{i}. {n}</b><br><span style='color:#8f99a5'>{d}</span>")
            p.setObjectName("Paso"); p.setWordWrap(True)
            fila.addWidget(p, 1)
        v.addLayout(fila)
        pie = QHBoxLayout()
        self.chk = QCheckBox("Mostrar al iniciar"); self.chk.setChecked(mostrar_al_iniciar())
        self.chk.toggled.connect(_guardar)
        pie.addWidget(self.chk); pie.addStretch(1)
        c = QPushButton("Ir al proyecto"); c.clicked.connect(self.reject); pie.addWidget(c)
        v.addLayout(pie)
        ajustar_a_pantalla(self, 1180, 640)

    def _elegir(self, clave: str) -> None:
        self.eleccion = clave
        self.accept()
