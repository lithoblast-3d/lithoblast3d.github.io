"""Exportar la malla del proyecto a DXF o DWG (para abrirla en AutoCAD / Civil 3D)."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
)

from app.cad import dwg as cad_dwg
from app.cad import exportar as ex
from app.core.modelo import ESCENARIO_TAJO
from app.ui.analisis.base import numero


class DialogoExportarCAD(QDialog):
    def __init__(self, documento, parent=None):
        super().__init__(parent)
        self.doc = documento
        self.ruta: Path | None = None
        self.setWindowTitle("Exportar malla a DXF / DWG")
        v = QVBoxLayout(self)
        v.setSpacing(10)
        t = QLabel("Exportar malla a AutoCAD")
        t.setObjectName("TituloGrande")
        v.addWidget(t)
        pr = documento.proyecto
        n = len(pr.perforaciones())
        s = QLabel(f"{n} taladros del proyecto «{pr.nombre}». Capas: COLLARES, ALIVIOS, TALADROS, CARGA, PIE, "
                   "TXT_ID, TXT_RETARDO, TXT_COTA, SECCION_AREA, LEYENDA y las capas de la topografía importada.")
        s.setObjectName("TextoSecundario")
        s.setWordWrap(True)
        v.addWidget(s)

        g = QGroupBox("Contenido")
        f = QFormLayout(g)
        self.formato = QComboBox()
        self.formato.addItems(["DWG (AutoCAD)", "DXF (AutoCAD, Civil 3D, BricsCAD, QGIS)"])
        self.version = QComboBox()
        self.version.addItems(cad_dwg.VERSIONES_DWG)
        self.version.setCurrentText("ACAD2013")
        self.vista = QComboBox()
        self.vista.addItems(ex.VISTAS)
        if pr.diseno.escenario != ESCENARIO_TAJO:
            self.vista.setCurrentIndex(1)
        self.radio = numero(0, 5, 0, 3, 0.01, "m")
        self.radio.setSpecialValueText("automático")
        self.alto_txt = numero(0, 5, 0, 3, 0.01, "m")
        self.alto_txt.setSpecialValueText("automático")
        f.addRow("Formato", self.formato)
        f.addRow("Versión DWG", self.version)
        f.addRow("Vista", self.vista)
        f.addRow("Radio del símbolo del collar", self.radio)
        f.addRow("Altura de texto", self.alto_txt)
        self.chk = {}
        for clave, texto, val in (("textos_id", "Número de taladro", True), ("textos_retardo", "Retardo", True),
                                  ("textos_cota", "Cota del collar", True), ("textos_longitud", "Longitud", False),
                                  ("contornos", "Sección / área de voladura", True),
                                  ("topografia", "Curvas de nivel y polilíneas importadas", True),
                                  ("leyenda", "Leyenda con el resumen", True)):
            c = QCheckBox(texto)
            c.setChecked(val)
            self.chk[clave] = c
            f.addRow(c)
        v.addWidget(g)
        oda = cad_dwg.buscar_oda()
        self.l_oda = QLabel(f"Conversor DWG: {oda}" if oda else
                            "⚠ Para DWG se necesita ODA File Converter (gratis). Sin él, guarda en DXF: AutoCAD lo "
                            "abre igual.")
        self.l_oda.setObjectName("TextoSecundario" if oda else "Aviso")
        self.l_oda.setWordWrap(True)
        v.addWidget(self.l_oda)
        if not oda:
            self.formato.setCurrentIndex(1)
        self.formato.currentIndexChanged.connect(lambda i: self.version.setEnabled(i == 0))
        self.version.setEnabled(self.formato.currentIndex() == 0)
        self.l_res = QLabel("")
        self.l_res.setWordWrap(True)
        v.addWidget(self.l_res)
        h = QHBoxLayout()
        h.addStretch(1)
        b = QPushButton("Guardar…")
        b.setObjectName("Primario")
        b.clicked.connect(self._guardar)
        c = QPushButton("Cerrar")
        c.clicked.connect(self.reject)
        h.addWidget(b)
        h.addWidget(c)
        v.addLayout(h)

    def opciones(self) -> ex.OpcionesExportar:
        return ex.OpcionesExportar(vista=self.vista.currentText(), radio_simbolo=self.radio.value(),
                                   altura_texto=self.alto_txt.value(),
                                   **{k: c.isChecked() for k, c in self.chk.items()})

    def _guardar(self, *_, ruta: str | None = None):
        dwg = self.formato.currentIndex() == 0
        if ruta is None:
            nombre = (self.doc.proyecto.nombre or "malla").replace(" ", "_") + (".dwg" if dwg else ".dxf")
            filtro = "DWG (*.dwg)" if dwg else "DXF (*.dxf)"
            ruta, _ = QFileDialog.getSaveFileName(self, "Guardar malla", nombre, filtro)
            if not ruta:
                return
        ruta = Path(ruta)
        if ruta.suffix.lower() not in (".dwg", ".dxf"):
            ruta = ruta.with_suffix(".dwg" if dwg else ".dxf")
        try:
            self.ruta = ex.exportar(self.doc.proyecto, ruta, self.opciones(), self.version.currentText())
        except cad_dwg.ErrorDWG as err:
            self.l_res.setObjectName("Error")
            self.l_res.setText(f"✖ {err}")
            return
        except (OSError, ValueError) as err:
            self.l_res.setObjectName("Error")
            self.l_res.setText(f"✖ No se pudo guardar: {err}")
            return
        self.l_res.setObjectName("Subtitulo")
        self.l_res.setText(f"✔ Guardado: {self.ruta}")
        self.accept()
