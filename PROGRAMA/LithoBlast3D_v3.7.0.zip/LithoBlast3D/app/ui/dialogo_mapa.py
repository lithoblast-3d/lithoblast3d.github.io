"""Diálogo de configuración del mapa de vibración (Holmberg–Persson)."""

import copy

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLabel,
    QMessageBox,
    QVBoxLayout,
)

from app.core.modelo import ConfigMapa
from app.ui.dialogos import CampoNumero


class DialogoMapa(QDialog):
    def __init__(self, cfg: ConfigMapa, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Mapa de vibración (Holmberg–Persson)")
        self.setMinimumWidth(480)
        self._cfg = copy.deepcopy(cfg)

        intro = QLabel(
            "Estima la velocidad pico de partícula (PPV) en un plano que corta la voladura: "
            "horizontal en tajo abierto y paralelo al frente en subterráneo. "
            "Los colores indican zonas de daño según los umbrales.")
        intro.setWordWrap(True)
        intro.setObjectName("TextoSecundario")

        self.k = CampoNumero(0.001, 1e6, 1, "", cfg.k, "K")
        self.alfa = CampoNumero(0.01, 5, 3, "", cfg.alfa, "α")
        self.beta = CampoNumero(0.01, 5, 3, "", cfg.beta, "β")
        self.calibradas = QCheckBox("Son constantes calibradas en mi mina (quitar aviso)")
        self.calibradas.setChecked(cfg.constantes_calibradas)
        self.u1 = CampoNumero(0.1, 1e6, 0, "mm/s", cfg.umbrales[0], "Umbral azul → verde")
        self.u2 = CampoNumero(0.1, 1e6, 0, "mm/s", cfg.umbrales[1], "Umbral verde → amarillo")
        self.u3 = CampoNumero(0.1, 1e6, 0, "mm/s", cfg.umbrales[2], "Umbral amarillo → rojo")
        self.modo = QComboBox()
        self.modo.addItem("Un taladro por retardo (máximo de cada taladro)", "maximo")
        self.modo.addItem("Todos a la vez (suma, muy conservador)", "suma")
        self.modo.setCurrentIndex(0 if cfg.modo == "maximo" else 1)
        self.auto = QCheckBox("Automática: a media columna de carga")
        self.auto.setChecked(cfg.profundidad is None)
        self.profundidad = CampoNumero(0, 500, 2, "m", cfg.profundidad or 1.0, "Profundidad del plano")
        self.profundidad.setEnabled(not self.auto.isChecked())
        self.auto.toggled.connect(lambda v: self.profundidad.setEnabled(not v))
        self.resolucion = CampoNumero(40, 400, 0, "celdas", cfg.resolucion, "Resolución")

        f = QFormLayout()
        f.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        f.addRow(QLabel("<b>Constantes del sitio</b>"))
        f.addRow("K:", self.k)
        f.addRow("α (alfa):", self.alfa)
        f.addRow("β (beta):", self.beta)
        f.addRow(self.calibradas)
        f.addRow(QLabel("<b>Colores (criterio de daño)</b>"))
        f.addRow("Azul → verde:", self.u1)
        f.addRow("Verde → amarillo:", self.u2)
        f.addRow("Amarillo → rojo:", self.u3)
        f.addRow(QLabel("<b>Cálculo</b>"))
        f.addRow("Combinación de taladros:", self.modo)
        f.addRow("Plano de corte:", self.auto)
        f.addRow("Profundidad desde el collar:", self.profundidad)
        f.addRow("Resolución:", self.resolucion)

        nota = QLabel(
            "Valores iniciales: K = 700, α = 0.7, β = 1.5 (Lundborg et al., 1978, usados por "
            "Holmberg y Persson) y umbrales 254 / 635 / 2540 mm/s (Bauer y Calder, 1970). "
            "Para decidir con el mapa, calibra K, α y β con mediciones de sismógrafo en tu mina. "
            "Detalles en app/calc/energia.py.")
        nota.setWordWrap(True)
        nota.setObjectName("TextoSecundario")

        botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                                   | QDialogButtonBox.StandardButton.Cancel)
        botones.button(QDialogButtonBox.StandardButton.Ok).setText("Mostrar mapa")
        botones.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        botones.accepted.connect(self._aceptar)
        botones.rejected.connect(self.reject)

        diseno = QVBoxLayout(self)
        diseno.addWidget(intro)
        diseno.addLayout(f)
        diseno.addWidget(nota)
        diseno.addWidget(botones)

    def _aceptar(self) -> None:
        campos = [self.k, self.alfa, self.beta, self.u1, self.u2, self.u3, self.resolucion]
        if not self.auto.isChecked():
            campos.append(self.profundidad)
        errores = [e for e in (c.error() for c in campos) if e]
        if not errores and not self.u1.value() < self.u2.value() < self.u3.value():
            errores.append("Los umbrales deben ir de menor a mayor.")
        if errores:
            QMessageBox.warning(self, "Mapa de vibración", "\n".join(errores))
            return
        self.accept()

    def valor(self) -> ConfigMapa:
        return ConfigMapa(
            activo=True,
            k=self.k.value(), alfa=self.alfa.value(), beta=self.beta.value(),
            umbrales=[self.u1.value(), self.u2.value(), self.u3.value()],
            modo=self.modo.currentData(),
            profundidad=None if self.auto.isChecked() else self.profundidad.value(),
            resolucion=int(round(self.resolucion.value())),
            constantes_calibradas=self.calibradas.isChecked(),
        )
