"""
Malla automática: el usuario escribe pocos datos y el programa calcula toda la malla.

Frente subterráneo: ancho, alto, arco, longitud, diámetros, alivios y explosivo.
Banco (tajo abierto): área, altura de banco, diámetro, roca y explosivo.
"""

from dataclasses import dataclass, replace

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QScrollArea,
    QSplitter,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.calc import carga as calc
from app.core.documento import Documento, ErrorEdicion
from app.core.generador import generar_malla_tajo, nuevo_id_contorno
from app.core.malla_auto import (
    EntradaBanco,
    EntradaFrente,
    FORMAS_SECCION,
    MODELOS_BANCO,
    Roca,
    evaluar_roca,
    disenar_banco,
    disenar_frente,
    frente_a_pozos,
)
from app.core.modelo import ESCENARIO_SUBTERRANEO, ESCENARIO_TAJO, Banco, Contorno, Superficie, num
from app.ui.dialogo_malla import VistaPrevia
from app.ui.dialogos import CampoNumero
from app.ui.tema import COLORES

COLOR_FUNCION = {
    "Alivio": "#7b8591", "Arranque": "#ff8c42", "Ayuda de arranque": "#ffc857",
    "Ayuda": "#3a8dde", "Hastial": "#2bb3a8", "Corona": "#b48cff",
    "Arrastre": "#e4e7eb", "Producción": "#2bb3a8",
}

# (atributo, etiqueta, mín, máx, decimales, unidad)
DATOS_FRENTE = [
    ("ancho", "Ancho de la sección", 1.0, 30, 2, "m"),
    ("alto", "Alto de la sección", 1.0, 30, 2, "m"),
    ("flecha", "Altura del arco / radio de esquinas", 0.0, 15, 2, "m"),
    ("longitud", "Longitud de perforación", 0.5, 10, 2, "m"),
    ("diametro_mm", "Diámetro de perforación", 20, 150, 0, "mm"),
    ("diametro_alivio_mm", "Diámetro del alivio (rimado)", 20, 400, 0, "mm"),
    ("n_alivios", "Número de alivios (normalmente 1)", 1, 6, 0, "taladros"),
]
AVANZADO_FRENTE = [
    ("c_roca", "Constante de roca c", 0.1, 2.0, 2, "kg/m³"),
    ("alfa", "Desviación angular α", 0.0, 0.1, 3, "m/m"),
    ("emboquille", "Error de emboquille β", 0.0, 0.5, 3, "m"),
]
DATOS_BANCO = [
    ("largo", "Largo del área (a lo largo de la cresta)", 1, 2000, 1, "m"),
    ("ancho", "Ancho del área (hacia el banco)", 1, 500, 1, "m"),
    ("altura_banco", "Altura de banco", 1, 50, 2, "m"),
    ("diametro_mm", "Diámetro de perforación", 50, 400, 0, "mm"),
    ("densidad_roca", "Densidad de la roca", 1.0, 5.0, 2, "t/m³"),
]
DATOS_ROCA = [
    ("rmr", "RMR (Bieniawski)", 0, 100, 0, ""),
    ("rqd", "RQD", 0, 100, 0, "%"),
    ("gsi", "GSI (0 = RMR − 5)", 0, 100, 0, ""),
    ("densidad", "Densidad de la roca", 1.0, 5.0, 2, "t/m³"),
]
RELACIONES_BANCO = [
    ("ks", "KS: espaciamiento S = KS·B", 0.5, 3.0, 2, "(2 simult.; 1–1.8 retardo)"),
    ("kt", "KT: taco T = KT·B", 0.3, 2.0, 2, "(0.7–1.0)"),
    ("kj", "KJ: sobreperforación J = KJ·B", 0.0, 1.0, 2, "(0.2–0.4)"),
]
# (modelo, campos numéricos, listas desplegables)
MODELO_CAMPOS = [
    ("Ash", [("kb_manual", "Kb manual (0 = Tabla I)", 0, 60, 1, "")],
     [("tipo_roca", "Tipo de roca", ["Blanda", "Media", "Dura"])]),
    ("Ash modificado", [
        ("kb_estandar", "Kb estándar", 1, 60, 1, ""),
        ("densidad_roca_ref", "Densidad de roca de referencia", 1, 5, 2, "g/cm³"),
        ("densidad_exp_ref", "Densidad de explosivo de referencia", 0.5, 2, 2, "g/cm³"),
        ("vod_ref", "VOD de referencia", 1000, 9000, 0, "m/s"),
    ], []),
    ("Pearse", [
        ("rqd", "RQD", 1, 100, 0, "%"),
        ("std_mpa", "Resistencia a la tracción dinámica", 0.1, 100, 1, "MPa"),
        ("pd_mpa", "Presión de detonación (0 = ρ·VOD²/4)", 0, 50000, 0, "MPa"),
    ], [("calidad_roca", "Calidad de roca (JSF)", ["Competente", "Media", "Suave", "Muy suave"])]),
    ("Langefors", [
        ("c_roca", "Constante de roca c", 0.1, 2.0, 2, "kg/m³"),
        ("emboquille", "Error de emboquille e'", 0, 1, 2, "m"),
        ("desviacion", "Desviación db", 0, 0.2, 3, "m/m"),
    ], [("inclinacion", "Inclinación del taladro (f)", ["Vertical", "Inclinado 3:1", "Inclinado 2:1"])]),
]
UBICACION = [
    ("x0", "Este X", -1e7, 1e7, 2, "m"),
    ("y0", "Norte Y", -1e7, 1e7, 2, "m"),
    ("z0", "Cota", -1e4, 1e4, 2, "m"),
    ("azimut", "Dirección", 0, 360, 1, "°"),
]


def _campos(formulario: QFormLayout, objeto, especificacion, al_cambiar) -> dict[str, CampoNumero]:
    campos = {}
    for attr, etiqueta, mn, mx, dec, unidad in especificacion:
        campo = CampoNumero(mn, mx, dec, unidad, getattr(objeto, attr), etiqueta)
        campo.valueChanged.connect(al_cambiar)
        formulario.addRow(etiqueta + ":", campo)
        campos[attr] = campo
    return campos


def _leer(campos: dict[str, CampoNumero], objeto):
    errores = [e for e in (c.error() for c in campos.values()) if e]
    if errores:
        raise ErrorEdicion("\n".join(errores))
    valores = {}
    for k, c in campos.items():
        v = c.value()
        valores[k] = int(round(v)) if isinstance(getattr(objeto, k), int) else v
    return replace(objeto, **valores)


@dataclass
class _Ubicacion:
    x0: float = 0.0
    y0: float = 0.0
    z0: float = 0.0
    azimut: float = 0.0


class DialogoMallaAutomatica(QDialog):
    def __init__(self, documento: Documento, parent=None):
        super().__init__(parent)
        self.doc = documento
        proyecto = documento.proyecto
        self.setWindowTitle("Malla automática")
        from app.ui.tema import ajustar_a_pantalla
        ajustar_a_pantalla(self, 1180, 760)
        self._resultado = None

        # ---------------- selector de tipo
        self.tipo = QComboBox()
        self.tipo.addItem("Frente subterráneo (arranque paralelo, Yilmaz 2023)", ESCENARIO_SUBTERRANEO)
        self.tipo.addItem("Banco de tajo abierto (Konya, Ash, Pearse, Langefors)", ESCENARIO_TAJO)
        self.tipo.setCurrentIndex(0 if proyecto.diseno.escenario == ESCENARIO_SUBTERRANEO else 1)
        self.tipo.currentIndexChanged.connect(self._cambiar_tipo)

        # ---------------- formulario de frente
        self.form_frente = QWidget()
        f = QFormLayout(self.form_frente)
        f.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.entrada_frente = EntradaFrente(longitud=round(proyecto.diseno.avance / 0.95, 2)
                                            if proyecto.diseno.avance else 3.5)
        self.campos_frente = _campos(f, self.entrada_frente, DATOS_FRENTE, self._actualizar)
        self.forma = QComboBox()
        for forma in FORMAS_SECCION:
            self.forma.addItem(forma, forma)
        self.forma.setToolTip("Baúl: paredes rectas y bóveda en arco (el valor es la altura del arco). "
                              "Esquinas redondeadas: techo plano con esquinas en curva "
                              "(el valor es el radio). 0 = sección rectangular.")
        self.forma.currentIndexChanged.connect(self._actualizar)
        f.insertRow(0, "Forma de la sección:", self.forma)
        self.exp_frente = self._combo_explosivo(preferir_encartuchado=True)
        f.addRow("Explosivo:", self.exp_frente)
        self.exp_contorno = self._combo_explosivo(preferir_encartuchado=True, igual=True)
        f.addRow("Explosivo de contorno:", self.exp_contorno)
        self.atacado = QCheckBox("Cartuchos atacados (llenan el taladro, como en el artículo)")
        self.atacado.setToolTip("Desmarcado: la carga de fondo se calcula con el diámetro real del "
                                "cartucho. Marcado: con el diámetro del taladro (Ec. 8 del artículo).")
        self.atacado.toggled.connect(self._actualizar)
        f.addRow(self.atacado)
        self.boton_avanzado = QToolButton()
        self.boton_avanzado.setText("▸ Constantes del método (opcional)")
        self.boton_avanzado.setCheckable(True)
        self.boton_avanzado.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        f.addRow(self.boton_avanzado)
        self.panel_avanzado = QWidget()
        fa = QFormLayout(self.panel_avanzado)
        fa.setContentsMargins(0, 0, 0, 0)
        fa.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.campos_avanzado = _campos(fa, self.entrada_frente, AVANZADO_FRENTE, self._actualizar)
        self.panel_avanzado.setVisible(False)
        self.boton_avanzado.toggled.connect(self._mostrar_avanzado)
        f.addRow(self.panel_avanzado)

        # ---------------- formulario de banco
        self.form_banco = QWidget()
        b = QFormLayout(self.form_banco)
        b.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.entrada_banco = EntradaBanco(altura_banco=proyecto.diseno.altura_banco,
                                          densidad_roca=proyecto.diseno.densidad_roca)
        self.campos_banco = _campos(b, self.entrada_banco, DATOS_BANCO, self._actualizar)
        self.exp_banco = self._combo_explosivo(preferir_encartuchado=False)
        b.addRow("Explosivo:", self.exp_banco)
        self.salida = QComboBox()
        self.salida.addItem("Con retardos entre taladros", True)
        self.salida.addItem("Instantánea", False)
        self.salida.currentIndexChanged.connect(self._actualizar)
        b.addRow("Salida:", self.salida)
        self.malla = QComboBox()
        self.malla.addItem("Tresbolillo", True)
        self.malla.addItem("Cuadrada / rectangular", False)
        self.malla.currentIndexChanged.connect(self._actualizar)
        b.addRow("Malla:", self.malla)

        self.modelo = QComboBox()
        for m in MODELOS_BANCO:
            self.modelo.addItem(m, m)
        self.modelo.currentIndexChanged.connect(self._cambiar_modelo)
        b.addRow("<b>Modelo de burden:</b>", self.modelo)
        self.paneles_modelo: dict[str, QWidget] = {}
        self.campos_modelo: dict[str, dict[str, CampoNumero]] = {}
        self.combos_modelo: dict[str, dict[str, QComboBox]] = {}
        for modelo, numeros, combos in MODELO_CAMPOS:
            panel = QWidget()
            fm = QFormLayout(panel)
            fm.setContentsMargins(0, 0, 0, 0)
            fm.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
            self.campos_modelo[modelo] = _campos(fm, self.entrada_banco, numeros, self._actualizar)
            self.combos_modelo[modelo] = {}
            for attr, etiqueta, opciones in combos:
                combo = QComboBox()
                for o in opciones:
                    combo.addItem(o, o)
                combo.setCurrentIndex(max(combo.findData(getattr(self.entrada_banco, attr)), 0))
                combo.currentIndexChanged.connect(self._actualizar)
                fm.addRow(etiqueta + ":", combo)
                self.combos_modelo[modelo][attr] = combo
            b.addRow(panel)
            self.paneles_modelo[modelo] = panel
        self.panel_relaciones = QWidget()
        fr = QFormLayout(self.panel_relaciones)
        fr.setContentsMargins(0, 0, 0, 0)
        fr.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.campos_relaciones = _campos(fr, self.entrada_banco, RELACIONES_BANCO, self._actualizar)
        b.addRow(self.panel_relaciones)

        # ---------------- ubicación
        self.form_ubicacion = QWidget()
        u = QFormLayout(self.form_ubicacion)
        u.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        titulo = QLabel("<b>Ubicación</b> (opcional; 0 = origen local)")
        u.addRow(titulo)
        self.ubicacion = _Ubicacion()
        self.campos_ubicacion = _campos(u, self.ubicacion, UBICACION, self._actualizar)
        self.ayuda_ubicacion = QLabel()
        self.ayuda_ubicacion.setObjectName("TextoSecundario")
        self.ayuda_ubicacion.setWordWrap(True)
        u.addRow(self.ayuda_ubicacion)

        n = len(proyecto.perforaciones())
        self.reemplazar = QCheckBox(f"Reemplazar los {n} taladros actuales")
        self.reemplazar.setChecked(n > 0)
        self.reemplazar.setVisible(n > 0)

        izquierda = QWidget()
        iz = QVBoxLayout(izquierda)
        # ---------------- tipo de roca
        self.panel_roca = QWidget()
        fr_roca = QFormLayout(self.panel_roca)
        fr_roca.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.usar_roca = QCheckBox("Diseñar según el tipo de roca")
        self.usar_roca.setChecked(True)
        self.usar_roca.toggled.connect(self._cambiar_roca)
        fr_roca.addRow(QLabel("<b>Tipo de roca</b>"))
        fr_roca.addRow(self.usar_roca)
        self.roca = Roca(densidad=proyecto.diseno.densidad_roca)
        self.campos_roca = _campos(fr_roca, self.roca, DATOS_ROCA, self._actualizar)
        self.dureza = QComboBox()
        for d in ("Auto", "Dura", "Semidura", "Blanda"):
            self.dureza.addItem("Según la clase RMR" if d == "Auto" else d, d)
        self.dureza.currentIndexChanged.connect(self._actualizar)
        fr_roca.addRow("Dureza (tabla EXSA):", self.dureza)
        self.resumen_roca = QLabel()
        self.resumen_roca.setObjectName("Subtitulo")
        self.resumen_roca.setWordWrap(True)
        fr_roca.addRow(self.resumen_roca)
        iz.addWidget(self.panel_roca)

        datos = QLabel("<b>Datos</b>")
        iz.addWidget(datos)
        iz.addWidget(self.form_frente)
        iz.addWidget(self.form_banco)
        iz.addWidget(self.form_ubicacion)
        iz.addWidget(self.reemplazar)
        iz.addStretch(1)
        desplazable = QScrollArea()
        desplazable.setWidget(izquierda)
        desplazable.setWidgetResizable(True)
        desplazable.setMinimumWidth(400)

        # ---------------- resultados
        self.vista = VistaPrevia()
        self.vista.setMinimumSize(360, 300)
        self.resumen = QLabel()
        self.resumen.setWordWrap(True)
        self.avisos = QLabel()
        self.avisos.setObjectName("Insignia")
        self.avisos.setWordWrap(True)
        self.ficha = QTreeWidget()
        self.ficha.setColumnCount(4)
        self.ficha.setHeaderLabels(["Resultado", "Valor", "Unidad", "Fórmula"])
        self.ficha.setRootIsDecorated(False)
        self.ficha.setSelectionMode(QTreeWidget.SelectionMode.NoSelection)
        cab = self.ficha.header()
        cab.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        cab.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        cab.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        cab.setStretchLastSection(True)
        nota = QLabel("Frente: Yilmaz (2023), Sci. Rep. 13:2449. Banco: Konya, Ash, Pearse o Langefors. "
                      "Diseño preliminar: ajústalo con los resultados de campo.")
        nota.setObjectName("TextoSecundario")
        nota.setWordWrap(True)

        derecha = QSplitter(Qt.Orientation.Vertical)
        arriba = QWidget()
        ar = QVBoxLayout(arriba)
        ar.setContentsMargins(0, 0, 0, 0)
        ar.addWidget(self.vista, 1)
        ar.addWidget(self.resumen)
        ar.addWidget(self.avisos)
        derecha.addWidget(arriba)
        abajo = QWidget()
        ab = QVBoxLayout(abajo)
        ab.setContentsMargins(0, 0, 0, 0)
        ab.addWidget(self.ficha, 1)
        ab.addWidget(nota)
        derecha.addWidget(abajo)
        derecha.setSizes([430, 300])

        cuerpo = QSplitter(Qt.Orientation.Horizontal)
        cuerpo.addWidget(desplazable)
        cuerpo.addWidget(derecha)
        cuerpo.setSizes([420, 760])

        self.botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                                        | QDialogButtonBox.StandardButton.Cancel)
        self.botones.button(QDialogButtonBox.StandardButton.Ok).setText("Crear malla")
        self.botones.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        self.botones.accepted.connect(self._aceptar)
        self.botones.rejected.connect(self.reject)

        fila_tipo = QHBoxLayout()
        fila_tipo.addWidget(QLabel("<b>Tipo de labor:</b>"))
        fila_tipo.addWidget(self.tipo)
        fila_tipo.addStretch(1)
        principal = QVBoxLayout(self)
        principal.addLayout(fila_tipo)
        principal.addWidget(cuerpo, 1)
        principal.addWidget(self.botones)
        self._cambiar_tipo()

    # ------------------------------------------------------------------ ayudas
    def _combo_explosivo(self, preferir_encartuchado: bool, igual: bool = False) -> QComboBox:
        combo = QComboBox()
        if igual:
            combo.addItem("— Igual al principal —", None)
        for e in self.doc.proyecto.explosivos:
            combo.addItem(e.nombre, e.id)
        if not igual:
            tipos = [e.tipo for e in self.doc.proyecto.explosivos]
            buscado = "encartuchado" if preferir_encartuchado else "granel"
            if buscado in tipos:
                combo.setCurrentIndex(tipos.index(buscado))
        combo.currentIndexChanged.connect(self._actualizar)
        return combo

    def _mostrar_avanzado(self, visible: bool) -> None:
        self.panel_avanzado.setVisible(visible)
        self.boton_avanzado.setText(("▾" if visible else "▸") + " Constantes del método (opcional)")

    def _cambiar_modelo(self, *_a) -> None:
        modelo = self.modelo.currentData()
        for nombre, panel in self.paneles_modelo.items():
            panel.setVisible(nombre == modelo)
        self.panel_relaciones.setVisible(modelo != "Konya")
        self.salida.setEnabled(modelo == "Konya")
        self.salida.setToolTip("" if modelo == "Konya" else "En este modelo el espaciamiento es KS·B")
        self._actualizar()

    def es_frente(self) -> bool:
        return self.tipo.currentData() == ESCENARIO_SUBTERRANEO

    def _cambiar_tipo(self, *_a) -> None:
        frente = self.es_frente()
        self.form_frente.setVisible(frente)
        self.form_banco.setVisible(not frente)
        if not frente:
            for nombre, panel in self.paneles_modelo.items():
                panel.setVisible(nombre == self.modelo.currentData())
            self.panel_relaciones.setVisible(self.modelo.currentData() != "Konya")
        self.ayuda_ubicacion.setText(
            "Frente: centro del piso de la sección; Dirección = rumbo de avance (0° = Norte)."
            if frente else
            "Banco: primer taladro de la primera fila; Dirección = rumbo de las filas (90° = Este).")
        if not frente and self.campos_ubicacion["azimut"].value() == 0:
            self.campos_ubicacion["azimut"].setValue(90)
        elif frente and self.campos_ubicacion["azimut"].value() == 90:
            self.campos_ubicacion["azimut"].setValue(0)
        self._actualizar()

    def _explosivo(self, combo: QComboBox):
        return self.doc.proyecto.explosivo(combo.currentData())

    # ------------------------------------------------------------------ cálculo
    def _leer_roca(self):
        if not self.usar_roca.isChecked():
            self.resumen_roca.setText("Sin datos de roca: se usa la constante c del formulario.")
            return None
        roca = replace(_leer(self.campos_roca, self.roca), dureza=self.dureza.currentData())
        ev = evaluar_roca(roca)
        self.resumen_roca.setText(
            f"Clase {ev.clase} · {ev.descripcion}  ·  GSI {ev.gsi:.0f}  ·  "
            f"CE {ev.consumo_especifico:.2f} kg/m³  ·  c = {ev.c:.3f}  ·  dureza {ev.dureza.lower()}")
        return roca

    def _cambiar_roca(self, activo: bool) -> None:
        for campo in self.campos_roca.values():
            campo.setEnabled(activo)
        self.dureza.setEnabled(activo)
        self._actualizar()

    def _calcular(self):
        ubic = _leer(self.campos_ubicacion, self.ubicacion)
        roca = self._leer_roca()
        if self.es_frente():
            e = _leer(self.campos_frente, self.entrada_frente)
            e = _leer(self.campos_avanzado, e)
            e = replace(e, atacado=self.atacado.isChecked(), forma=self.forma.currentData(), roca=roca)
            principal = self._explosivo(self.exp_frente)
            contorno = self._explosivo(self.exp_contorno) or principal
            resultado = disenar_frente(e, principal, contorno)
            return ("frente", e, ubic, resultado, principal, contorno)
        e = _leer(self.campos_banco, self.entrada_banco)
        modelo = self.modelo.currentData()
        e = replace(e, con_retardos=bool(self.salida.currentData()),
                    tresbolillo=bool(self.malla.currentData()), modelo=modelo)
        if modelo != "Konya":
            e = _leer(self.campos_relaciones, e)
        if modelo in self.campos_modelo:
            e = _leer(self.campos_modelo[modelo], e)
            e = replace(e, **{k: c.currentData() for k, c in self.combos_modelo[modelo].items()})
        e = replace(e, roca=roca)
        explosivo = self._explosivo(self.exp_banco)
        resultado, param = disenar_banco(e, explosivo)
        return ("banco", e, ubic, (resultado, param), explosivo, None)

    def _totales(self, calculo) -> list[tuple[str, str]]:
        tipo, e, _u, res, principal, contorno = calculo
        rho_r = self.doc.proyecto.diseno.densidad_roca if tipo == "frente" else e.densidad_roca
        if e.roca is not None:
            rho_r = e.roca.densidad
        if tipo == "frente":
            pozos = res.pozos
            kg = 0.0
            for p in pozos:
                if p.alivio:
                    continue
                exp = contorno if p.explosivo == "contorno" else principal
                q = calc.carga_lineal(exp.diametro_de_carga(e.diametro_mm), exp.densidad_gcc)
                lc = max(e.longitud - p.taco, 0.0)
                hb = min(p.carga_fondo or 0.0, lc)
                kg += q * hb + q * p.factor_columna * (lc - hb)  # fondo + columna (Tabla 2)
            area = next(f.valor for f in res.ficha if f.concepto == "Área de la sección")
            volumen = area * 0.95 * e.longitud
            metros = len(pozos) * e.longitud
            cargados = sum(1 for p in pozos if not p.alivio)
        else:
            resultado, param = res
            q = calc.carga_lineal(principal.diametro_de_carga(e.diametro_mm), principal.densidad_gcc)
            n = len(resultado.pozos)
            kg = n * q * max(param.longitud - param.taco, 0)
            volumen = n * param.burden * param.espaciamiento * e.altura_banco
            metros = n * param.longitud
            cargados = n
        toneladas = volumen * rho_r
        return [
            ("Taladros", f"{cargados} cargados" + (f" + {len(res.pozos) - cargados} alivios"
                                                 if tipo == "frente" else "")),
            ("Perforación total", f"{metros:.1f} m"),
            ("Explosivo total", f"{kg:.1f} kg"),
            ("Volumen", f"{volumen:.1f} m³"),
            ("Factor de carga", f"{kg / volumen:.3f} kg/m³"),
            ("Factor de potencia", f"{kg / toneladas:.3f} kg/t (roca {rho_r:g} t/m³)"),
        ]

    def _actualizar(self, *_a) -> None:
        boton = self.botones.button(QDialogButtonBox.StandardButton.Ok)
        try:
            calculo = self._calcular()
        except (ErrorEdicion, calc.ErrorDeDatos) as error:
            self._resultado = None
            self.vista.mensaje = f"⚠ {error}"
            self.vista.update()
            self.ficha.clear()
            self.resumen.setText("")
            self.avisos.hide()
            boton.setEnabled(False)
            return
        self._resultado = calculo
        boton.setEnabled(True)
        tipo, e, _u, res, _p, _c = calculo
        self.vista.mensaje = ""
        if tipo == "frente":
            r = res
            self.vista.ejes = ("Ancho (m)", "Altura (m)")
            self.vista.contorno = r.seccion
            self.vista.filas = [c + [c[0]] for c in r.cuadros]
            self.vista.puntos = [(p.s, p.h, COLOR_FUNCION.get(p.funcion, "#fff"),
                                  6.5 if p.alivio else 4.5) for p in r.pozos]
            presentes = {p.funcion for p in r.pozos}
        else:
            r, _param = res
            self.vista.ejes = ("A lo largo de la cresta (m)", "Hacia el banco (m)")
            self.vista.contorno = []
            self.vista.filas = []
            self.vista.puntos = [(p.s, p.h, COLOR_FUNCION["Producción"], 4.5) for p in r.pozos]
            presentes = {"Producción"}
        self.vista.existentes = []
        self.vista.leyenda = [(f, c) for f, c in COLOR_FUNCION.items() if f in presentes]
        self.vista.update()

        self.ficha.clear()
        grupo = None
        acento = QColor(COLORES["acento"])
        gris = QColor(COLORES["texto_secundario"])
        for fila in r.ficha:
            if fila.zona != grupo:
                grupo = fila.zona
                item = QTreeWidgetItem([grupo.upper()])
                fuente = item.font(0)
                fuente.setBold(True)
                item.setFont(0, fuente)
                item.setForeground(0, acento)
                self.ficha.addTopLevelItem(item)
                item.setFirstColumnSpanned(True)
            valor = fila.valor if isinstance(fila.valor, str) else (
                f"{fila.valor:.0f}" if fila.unidad in ("", "mm") and float(fila.valor).is_integer()
                else num(fila.valor, 3))
            item = QTreeWidgetItem([fila.concepto, valor, fila.unidad, fila.formula])
            item.setTextAlignment(1, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            item.setForeground(2, gris)
            item.setForeground(3, gris)
            self.ficha.addTopLevelItem(item)
        try:
            totales = self._totales(calculo)
            self.resumen.setText("  ·  ".join(f"<b>{k}:</b> {v}" for k, v in totales))
        except (calc.ErrorDeDatos, ZeroDivisionError, StopIteration) as error:
            self.resumen.setText(f"⚠ {error}")
        self.avisos.setText("\n".join(f"⚠ {a}" for a in r.avisos))
        self.avisos.setVisible(bool(r.avisos))

    # ------------------------------------------------------------------ aplicar
    def _aceptar(self) -> None:
        if self._resultado is None:
            return
        tipo, e, ubic, res, principal, contorno = self._resultado
        proyecto = self.doc.proyecto
        eliminar = []
        if self.reemplazar.isChecked():
            eliminar = [q.id for q in proyecto.perforaciones()]
            eliminar += [o.id for o in proyecto.objetos.values() if isinstance(o, Contorno)]
        if tipo == "frente":
            # La topografía y los bancos de tajo no tienen sentido junto a un frente subterráneo
            # (están a otra cota y deforman la vista). Se quitan; Ctrl+Z los recupera.
            eliminar += [o.id for o in proyecto.objetos.values() if isinstance(o, (Superficie, Banco))]
        else:
            eliminar += [o.id for o in proyecto.objetos.values() if isinstance(o, Contorno)]
        eliminar = list(dict.fromkeys(eliminar))
        ocupados = set(proyecto.objetos) - set(eliminar)
        if tipo == "frente":
            pozos, vertices = frente_a_pozos(
                res, e, ocupados, ubic.x0, ubic.y0, ubic.z0, ubic.azimut,
                principal.id if principal else None,
                (contorno or principal).id if (contorno or principal) else None)
            id_c = nuevo_id_contorno(ocupados | {p.id for p in pozos})
            seccion = Contorno(id=id_c, nombre=f"Sección {e.ancho:g} × {e.alto:g} m",
                               capa_id="contornos", vertices=vertices)
            nuevos = [seccion, *pozos]
            diseno = replace(proyecto.diseno, escenario=ESCENARIO_SUBTERRANEO,
                             area_seccion=round(seccion.area(), 2),
                             avance=round(0.95 * e.longitud, 2),
                             densidad_roca=e.roca.densidad if e.roca else proyecto.diseno.densidad_roca)
            descripcion = f"Malla automática de frente ({len(pozos)} taladros)"
        else:
            _r, param = res
            param = replace(param, x0=ubic.x0, y0=ubic.y0, z0=ubic.z0, azimut_filas=ubic.azimut)
            nuevos = generar_malla_tajo(param, ocupados)
            diseno = replace(proyecto.diseno, escenario=ESCENARIO_TAJO, burden=param.burden,
                             espaciamiento=param.espaciamiento, altura_banco=e.altura_banco,
                             densidad_roca=e.densidad_roca)
            descripcion = f"Malla automática de banco ({len(nuevos)} taladros)"
        try:
            self.doc.aplicar_lote(nuevos, eliminar, diseno, descripcion)
        except ErrorEdicion as error:
            self.vista.mensaje = f"⚠ {error}"
            self.vista.update()
            return
        self.descripcion = descripcion
        self.accept()


__all__ = ["DialogoMallaAutomatica"]
