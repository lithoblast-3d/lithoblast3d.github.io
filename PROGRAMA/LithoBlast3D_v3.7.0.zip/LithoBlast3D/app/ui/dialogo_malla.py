"""
Diseñador de malla de perforación con vista previa en vivo.

Tajo abierto: malla por filas (cuadrada / rectangular o tresbolillo).
Subterráneo: sección baúl con alivios, arranque, ayudas, contorno, corona y arrastre.
"""

import math
from dataclasses import fields

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from app.core.documento import Documento, ErrorEdicion
from app.core.generador import (
    ParamFrente,
    ParamMallaTajo,
    generar_frente,
    generar_malla_tajo,
    nuevo_id_contorno,
    posiciones_frente,
    posiciones_tajo,
    seccion_baul,
)
from app.core.modelo import ESCENARIO_TAJO, FUNCIONES_POZO, Contorno
from app.ui.dialogos import CampoNumero
from app.ui.tema import COLORES

COLOR_FUNCION = {
    "Alivio": "#7b8591", "Arranque": "#ff8c42", "Ayuda": "#3a8dde",
    "Contorno": "#2bb3a8", "Corona": "#b48cff", "Arrastre": "#e4e7eb",
}

# (atributo, etiqueta, mínimo, máximo, decimales, unidad)
CAMPOS_TAJO = [
    ("x0", "Este X del primer taladro", -1e7, 1e7, 2, "m"),
    ("y0", "Norte Y del primer taladro", -1e7, 1e7, 2, "m"),
    ("z0", "Cota del collar", -1e4, 1e4, 2, "m"),
    ("filas", "Número de filas", 1, 200, 0, "filas"),
    ("pozos_por_fila", "Taladros por fila", 1, 500, 0, "taladros"),
    ("burden", "Burden (entre filas)", 0.1, 50, 2, "m"),
    ("espaciamiento", "Espaciamiento (en la fila)", 0.1, 50, 2, "m"),
    ("azimut_filas", "Dirección de las filas", 0, 360, 1, "°"),
    ("inclinacion", "Inclinación del taladro", -90, 90, 1, "°"),
    ("azimut_pozo", "Azimut del taladro", 0, 360, 1, "°"),
    ("longitud", "Longitud del taladro", 0.1, 200, 2, "m"),
    ("diametro_mm", "Diámetro", 1, 1000, 0, "mm"),
    ("taco", "Taco", 0, 200, 2, "m"),
]
CAMPOS_FRENTE = [
    ("x0", "Este X (centro del piso)", -1e7, 1e7, 2, "m"),
    ("y0", "Norte Y (centro del piso)", -1e7, 1e7, 2, "m"),
    ("z0", "Cota del piso", -1e4, 1e4, 2, "m"),
    ("azimut_avance", "Dirección de avance", 0, 360, 1, "°"),
    ("ancho", "Ancho de la sección", 0.5, 30, 2, "m"),
    ("altura_hastial", "Altura de hastiales", 0.5, 30, 2, "m"),
    ("flecha", "Flecha del arco", 0, 15, 2, "m"),
    ("altura_arranque", "Altura del arranque", 0.1, 30, 2, "m"),
    ("n_alivios", "Número de alivios", 0, 10, 0, "taladros"),
    ("separacion_alivios", "Separación de alivios", 0.01, 5, 2, "m"),
    ("diametro_alivio_mm", "Diámetro de alivio", 1, 500, 0, "mm"),
    ("separacion_ayudas", "Separación de ayudas", 0.1, 10, 2, "m"),
    ("retiro_ayudas", "Ayudas: distancia al contorno", 0.05, 10, 2, "m"),
    ("separacion_contorno", "Separación en contorno", 0.1, 5, 2, "m"),
    ("retiro_contorno", "Contorno: retiro del collar", 0, 2, 2, "m"),
    ("longitud", "Longitud de perforación", 0.1, 20, 2, "m"),
    ("diametro_mm", "Diámetro", 1, 500, 0, "mm"),
    ("taco", "Taco (arranque y ayudas)", 0, 20, 2, "m"),
    ("taco_contorno", "Taco (contorno y corona)", 0, 20, 2, "m"),
    ("taco_arrastre", "Taco (arrastre)", 0, 20, 2, "m"),
]


class VistaPrevia(QWidget):
    """Dibujo 2D sencillo de la malla: planta (tajo) o cara del frente (subterráneo)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(420, 420)
        self.puntos: list[tuple[float, float, str, float]] = []  # (u, v, color, radio_px)
        self.existentes: list[tuple[float, float]] = []
        self.contorno: list[tuple[float, float]] = []
        self.filas: list[list[tuple[float, float]]] = []
        self.ejes = ("Este X (m)", "Norte Y (m)")
        self.leyenda: list[tuple[str, str]] = []
        self.mensaje = ""

    def paintEvent(self, _evento):  # noqa: N802 (nombre exigido por Qt)
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor(COLORES["visor_fondo_abajo"]))
        texto = QColor(COLORES["texto_secundario"])
        p.setFont(QFont("Segoe UI", 8))
        if self.mensaje:
            p.setPen(QColor(COLORES["aviso"]))
            p.drawText(self.rect().adjusted(16, 16, -16, -16), Qt.TextFlag.TextWordWrap, self.mensaje)
            p.end()
            return
        todos = [(u, v) for u, v, *_ in self.puntos] + self.existentes + self.contorno
        if not todos:
            p.end()
            return
        umin, umax = min(u for u, _ in todos), max(u for u, _ in todos)
        vmin, vmax = min(v for _, v in todos), max(v for _, v in todos)
        ancho_u, alto_v = max(umax - umin, 1e-6), max(vmax - vmin, 1e-6)
        margen = 44
        area = QRectF(margen, 24, self.width() - 2 * margen, self.height() - margen - 34)
        escala = min(area.width() / ancho_u, area.height() / alto_v)
        cu = area.left() + (area.width() - ancho_u * escala) / 2
        cv = area.top() + (area.height() + alto_v * escala) / 2

        def a_pantalla(u, v):
            return QPointF(cu + (u - umin) * escala, cv - (v - vmin) * escala)

        # Escala gráfica
        paso = 10 ** math.floor(math.log10(max(ancho_u, alto_v) / 4 or 1))
        for factor in (1, 2, 5):
            if max(ancho_u, alto_v) / (paso * factor) <= 6:
                paso *= factor
                break
        x0, y0 = area.left(), self.height() - 18
        p.setPen(QPen(texto, 2))
        p.drawLine(QPointF(x0, y0), QPointF(x0 + paso * escala, y0))
        p.drawText(QPointF(x0 + paso * escala + 6, y0 + 4), f"{paso:g} m")
        p.drawText(QPointF(area.left(), 14), f"{self.ejes[0]} →   {self.ejes[1]} ↑")

        if self.contorno:
            p.setPen(QPen(QColor(COLORES["acento_azul"]), 2))
            pts = [a_pantalla(u, v) for u, v in self.contorno] + [a_pantalla(*self.contorno[0])]
            for a, b in zip(pts, pts[1:]):
                p.drawLine(a, b)
        p.setPen(QPen(QColor(COLORES["borde"]), 1, Qt.PenStyle.DashLine))
        for fila in self.filas:
            pts = [a_pantalla(u, v) for u, v in fila]
            for a, b in zip(pts, pts[1:]):
                p.drawLine(a, b)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#4a5058"))
        for u, v in self.existentes:
            p.drawEllipse(a_pantalla(u, v), 3, 3)
        for u, v, color, radio in self.puntos:
            p.setBrush(QColor(color))
            p.drawEllipse(a_pantalla(u, v), radio, radio)

        y = 30
        for nombre, color in self.leyenda:
            p.setBrush(QColor(color))
            p.drawEllipse(QPointF(self.width() - 110, y), 5, 5)
            p.setPen(texto)
            p.drawText(QPointF(self.width() - 98, y + 4), nombre)
            p.setPen(Qt.PenStyle.NoPen)
            y += 18
        p.end()


class DialogoMalla(QDialog):
    CAMBIAR_TIPO = 2  # código de salida: reabrir con el otro tipo de malla

    def __init__(self, documento: Documento, parent=None, es_tajo: bool | None = None):
        super().__init__(parent)
        self.doc = documento
        proyecto = documento.proyecto
        self.es_tajo_proyecto = proyecto.diseno.escenario == ESCENARIO_TAJO
        self.es_tajo = self.es_tajo_proyecto if es_tajo is None else es_tajo
        self.es_tajo_pedido = self.es_tajo
        self.setWindowTitle("Diseñar malla de perforación — "
                            + ("tajo abierto" if self.es_tajo else "frente subterráneo"))
        from app.ui.tema import ajustar_a_pantalla
        ajustar_a_pantalla(self, 1000, 700)

        # Valores iniciales
        d = proyecto.diseno
        pozos = proyecto.perforaciones()
        if self.es_tajo:
            self.param = ParamMallaTajo(burden=d.burden, espaciamiento=d.espaciamiento,
                                        longitud=d.altura_banco)
            if pozos:
                self.param.x0 = min(q.x for q in pozos)
                self.param.y0 = min(q.y for q in pozos)
                self.param.z0 = pozos[0].z
                self.param.diametro_mm = pozos[0].diametro_mm
            especificacion = CAMPOS_TAJO
        else:
            self.param = ParamFrente(longitud=d.avance + 0.3)
            especificacion = CAMPOS_FRENTE

        # Formulario
        self.campos: dict[str, CampoNumero] = {}
        formulario = QFormLayout()
        formulario.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        for attr, etiqueta, mn, mx, dec, unidad in especificacion:
            campo = CampoNumero(mn, mx, dec, unidad, getattr(self.param, attr), etiqueta)
            campo.valueChanged.connect(self._actualizar)
            self.campos[attr] = campo
            formulario.addRow(etiqueta + ":", campo)

        if self.es_tajo:
            self.tipo_malla = QComboBox()
            self.tipo_malla.addItem("Tresbolillo (filas alternadas)", True)
            self.tipo_malla.addItem("Cuadrada / rectangular", False)
            self.tipo_malla.currentIndexChanged.connect(self._actualizar)
            formulario.insertRow(5, "Tipo de malla:", self.tipo_malla)
            self.funcion = QComboBox()
            self.funcion.addItems(FUNCIONES_POZO[:3])
            formulario.addRow("Función:", self.funcion)
        else:
            self.distancias = QLineEdit("; ".join(f"{r:g}" for r in self.param.distancias_arranque))
            self.distancias.setToolTip("Distancia de cada cuadro del arranque al centro, en metros, "
                                       "separadas por punto y coma. Ejemplo: 0.25; 0.55; 0.95")
            self.distancias.textEdited.connect(self._actualizar)
            formulario.insertRow(11, "Cuadros del arranque (m):", self.distancias)

        self.explosivo = QComboBox()
        self.explosivo.addItem("— Sin carga —", None)
        for e in proyecto.explosivos:
            self.explosivo.addItem(e.nombre, e.id)
        if self.explosivo.count() > 1:
            self.explosivo.setCurrentIndex(1)
        formulario.addRow("Explosivo:", self.explosivo)

        n_existentes = len(pozos)
        self.reemplazar = QCheckBox(f"Reemplazar los {n_existentes} taladros actuales"
                                    + ("" if self.es_tajo else " y las secciones"))
        self.reemplazar.setChecked(n_existentes > 0 and (proyecto.escenario_demo
                                                         or self.es_tajo != self.es_tajo_proyecto))
        self.reemplazar.setVisible(n_existentes > 0)
        self.reemplazar.toggled.connect(self._actualizar)
        self.actualizar_diseno = QCheckBox(
            "Usar este burden y espaciamiento en los cálculos" if self.es_tajo
            else "Usar el área de esta sección en los cálculos")
        self.actualizar_diseno.setChecked(True)
        formulario.addRow(self.reemplazar)
        formulario.addRow(self.actualizar_diseno)

        contenedor = QWidget()
        contenedor.setLayout(formulario)
        desplazable = QScrollArea()
        desplazable.setWidget(contenedor)
        desplazable.setWidgetResizable(True)
        desplazable.setMinimumWidth(430)

        self.vista = VistaPrevia()
        self.resumen = QLabel()
        self.resumen.setObjectName("TextoSecundario")
        self.resumen.setWordWrap(True)
        nota = QLabel("El programa solo coloca los taladros con los valores que indiques; "
                      "elegir burden, espaciamiento y distancias lo decides tú según la mina.")
        nota.setObjectName("TextoSecundario")
        nota.setWordWrap(True)
        derecha = QVBoxLayout()
        derecha.addWidget(self.vista, 1)
        derecha.addWidget(self.resumen)
        derecha.addWidget(nota)

        cuerpo = QHBoxLayout()
        cuerpo.addWidget(desplazable)
        cuerpo.addLayout(derecha, 1)

        self.botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                                        | QDialogButtonBox.StandardButton.Cancel)
        self.botones.button(QDialogButtonBox.StandardButton.Ok).setText("Crear malla")
        self.botones.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        self.botones.accepted.connect(self._aceptar)
        self.botones.rejected.connect(self.reject)

        self.selector = QComboBox()
        self.selector.addItem("Tajo abierto (malla por filas)", True)
        self.selector.addItem("Frente subterráneo (sección con arranque)", False)
        self.selector.setCurrentIndex(0 if self.es_tajo else 1)
        self.selector.currentIndexChanged.connect(self._cambiar_tipo)
        fila_tipo = QHBoxLayout()
        etiqueta_tipo = QLabel("<b>Tipo de malla:</b>")
        fila_tipo.addWidget(etiqueta_tipo)
        fila_tipo.addWidget(self.selector)
        if self.es_tajo != self.es_tajo_proyecto:
            cambio = QLabel("⚠ Al crearla, el proyecto pasará a «"
                            + ("Tajo abierto" if self.es_tajo else "Minería subterránea") + "»")
            cambio.setObjectName("TextoSecundario")
            fila_tipo.addWidget(cambio)
        fila_tipo.addStretch(1)

        principal = QVBoxLayout(self)
        principal.addLayout(fila_tipo)
        principal.addLayout(cuerpo, 1)
        principal.addWidget(self.botones)
        self._actualizar()

    # ------------------------------------------------------------------ lectura
    def _leer(self):
        """Lee el formulario; lanza ErrorEdicion con todos los problemas encontrados."""
        errores = [e for e in (c.error() for c in self.campos.values()) if e]
        if errores:
            raise ErrorEdicion("\n".join(errores))
        valores = {k: c.value() for k, c in self.campos.items()}
        enteros = {f.name for f in fields(type(self.param))
                   if isinstance(f.default, int) and not isinstance(f.default, bool)}
        for k in enteros & set(valores):
            valores[k] = int(round(valores[k]))
        if self.es_tajo:
            param = ParamMallaTajo(**valores, tresbolillo=bool(self.tipo_malla.currentData()),
                                   explosivo_id=self.explosivo.currentData(),
                                   funcion=self.funcion.currentText())
            if param.taco > param.longitud:
                raise ErrorEdicion("El taco no puede ser mayor que la longitud del taladro")
        else:
            try:
                distancias = [float(t.strip().replace(",", "."))
                              for t in self.distancias.text().replace(";", " ").split() if t.strip()]
            except ValueError:
                raise ErrorEdicion("Cuadros del arranque: escribe números separados por «;»") from None
            if any(r <= 0 for r in distancias):
                raise ErrorEdicion("Cuadros del arranque: las distancias deben ser mayores que 0")
            param = ParamFrente(**valores, distancias_arranque=distancias,
                                explosivo_id=self.explosivo.currentData())
            if param.altura_arranque >= param.altura_hastial + param.flecha:
                raise ErrorEdicion("El arranque debe estar dentro de la sección")
        return param

    # ------------------------------------------------------------------ vista previa
    def _actualizar(self, *_args) -> None:
        boton = self.botones.button(QDialogButtonBox.StandardButton.Ok)
        try:
            param = self._leer()
        except ErrorEdicion as error:
            self.vista.mensaje = f"⚠ {error}"
            self.vista.update()
            self.resumen.setText("")
            boton.setEnabled(False)
            return
        boton.setEnabled(True)
        self.vista.mensaje = ""
        reemplazar = self.reemplazar.isChecked()
        pozos = self.doc.proyecto.perforaciones()
        if self.es_tajo:
            posiciones = posiciones_tajo(param)
            self.vista.ejes = ("Este X (m)", "Norte Y (m)")
            self.vista.puntos = [(x, y, COLORES["acento"], 4.5) for x, y, _f in posiciones]
            self.vista.filas = [[(x, y) for x, y, f in posiciones if f == n]
                                for n in range(1, param.filas + 1)]
            self.vista.existentes = [] if reemplazar else [(q.x, q.y) for q in pozos]
            self.vista.contorno = []
            self.vista.leyenda = [("Taladro nuevo", COLORES["acento"])] + (
                [] if reemplazar or not pozos else [("Existente", "#4a5058")])
            self.resumen.setText(
                f"{len(posiciones)} taladros nuevos · {param.filas} filas × {param.pozos_por_fila} · "
                f"{param.burden:g} × {param.espaciamiento:g} m · "
                f"{len(posiciones) * param.longitud:.1f} m perforados")
        else:
            posiciones = posiciones_frente(param)
            self.vista.ejes = ("Ancho (m)", "Altura (m)")
            self.vista.puntos = [(s, h, COLOR_FUNCION.get(f, "#ffffff"), 6.5 if alivio else 4.5)
                                 for s, h, f, alivio in posiciones]
            self.vista.filas = []
            self.vista.existentes = []
            self.vista.contorno = seccion_baul(param.ancho, param.altura_hastial, param.flecha)
            presentes = {f for *_x, f, _a in posiciones}
            self.vista.leyenda = [(f, c) for f, c in COLOR_FUNCION.items() if f in presentes]
            area = Contorno(id="_", nombre="_", capa_id="contornos",
                            vertices=[(s, 0.0, h) for s, h in self.vista.contorno]).area()
            conteo = {f: sum(1 for *_x, g, _a in posiciones if g == f) for f in presentes}
            self.resumen.setText(
                f"{len(posiciones)} taladros ({conteo.get('Alivio', 0)} alivios sin carga) · "
                f"sección {area:.2f} m² · " + " · ".join(f"{f}: {n}" for f, n in conteo.items()
                                                         if f != "Alivio"))
        self.vista.update()

    # ------------------------------------------------------------------ aplicar
    def _cambiar_tipo(self, *_args) -> None:
        self.es_tajo_pedido = bool(self.selector.currentData())
        if self.es_tajo_pedido != self.es_tajo:
            self.done(self.CAMBIAR_TIPO)

    def _aceptar(self) -> None:
        try:
            param = self._leer()
        except ErrorEdicion:
            return
        proyecto = self.doc.proyecto
        reemplazar = self.reemplazar.isChecked()
        eliminar = []
        if reemplazar:
            eliminar = [q.id for q in proyecto.perforaciones()]
            if not self.es_tajo:
                eliminar += [o.id for o in proyecto.objetos.values() if isinstance(o, Contorno)]
        ids_ocupados = set(proyecto.objetos) - set(eliminar)
        diseno = None
        if self.es_tajo:
            nuevos = generar_malla_tajo(param, ids_ocupados)
            diseno = _copiar(proyecto.diseno, escenario="tajo")
            if self.actualizar_diseno.isChecked():
                diseno = _copiar(diseno, burden=param.burden, espaciamiento=param.espaciamiento)
        else:
            pozos, contorno = generar_frente(param, ids_ocupados,
                                             nuevo_id_contorno(ids_ocupados))
            nuevos = [contorno, *pozos]
            diseno = _copiar(proyecto.diseno, escenario="subterraneo")
            if self.actualizar_diseno.isChecked():
                diseno = _copiar(diseno, area_seccion=round(contorno.area(), 2))
        try:
            self.doc.aplicar_lote(nuevos, eliminar, diseno,
                                  f"Diseñar malla ({sum(1 for n in nuevos if n.TIPO == 'Perforación')} taladros)")
        except ErrorEdicion as error:
            self.vista.mensaje = f"⚠ {error}"
            self.vista.update()
            return
        self.accept()


def _copiar(diseno, **cambios):
    from dataclasses import replace
    return replace(diseno, **cambios)
