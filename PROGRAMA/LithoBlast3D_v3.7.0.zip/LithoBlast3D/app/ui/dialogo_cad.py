"""Diálogos de Topografía y CAD: importar DXF/DWG, crear TIN, perfil y pendientes."""

from __future__ import annotations

import csv
import math
from pathlib import Path

import numpy as np
from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QHBoxLayout, QHeaderView,
    QLabel, QMessageBox, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from app.cad import dwg as cad_dwg
from app.cad import dxf as cad_dxf
from app.cad import topografia as topo
from app.cad.topografia import _cruz2
from app.core.modelo import Capa, PolilineaCAD, PuntosCAD, SuperficieTIN
from app.ui.dialogos import CampoNumero
from app.ui.tema import COLORES, ajustar_a_pantalla


def _ids_libres(existentes: set, prefijo: str):
    n = 1
    while True:
        ident = f"{prefijo}{n:04d}"
        if ident not in existentes:
            existentes.add(ident)
            yield ident
        n += 1


# ===================================================================== importar
class DialogoImportarCAD(QDialog):
    def __init__(self, documento, parent=None):
        super().__init__(parent)
        self.doc = documento
        self.dibujo: cad_dxf.DibujoCAD | None = None
        self.descripcion = ""
        self.setWindowTitle("Importar DXF / DWG")
        ajustar_a_pantalla(self, 900, 640)
        lay = QVBoxLayout(self)
        fila = QHBoxLayout()
        self.ruta = QLabel("Ningún archivo"); self.ruta.setObjectName("TextoSecundario")
        b = QPushButton("Elegir archivo…"); b.clicked.connect(self._elegir)
        fila.addWidget(b); fila.addWidget(self.ruta, 1)
        lay.addLayout(fila)
        self.info = QLabel(); self.info.setWordWrap(True)
        lay.addWidget(self.info)
        self.tabla = QTableWidget(0, 4)
        self.tabla.setHorizontalHeaderLabels(["Importar", "Capa", "Contenido", "Usar para TIN"])
        lay.addWidget(self.tabla, 1)
        f = QFormLayout()
        self.unidad = QComboBox()
        for cod, (nom, fac) in cad_dxf.UNIDADES_INSUNITS.items():
            if fac:
                self.unidad.addItem(f"{nom}", fac)
        self.unidad.setCurrentIndex(self.unidad.findText("Metros"))
        f.addRow("Unidades del dibujo", self.unidad)
        self.crear_tin = QCheckBox("Crear superficie TIN con las capas marcadas en «Usar para TIN»")
        self.crear_tin.setChecked(True)
        f.addRow(self.crear_tin)
        self.lado = CampoNumero(0, 1e5, 1, "m", 0, "Lado máximo de triángulo (0 = sin límite)")
        self.dens = CampoNumero(0, 1e4, 1, "m", 0, "Densificar curvas cada (0 = no)")
        f.addRow(self.lado.nombre, self.lado)
        f.addRow(self.dens.nombre, self.dens)
        lay.addLayout(f)
        nota = QLabel("Se conservan las coordenadas y la escala del dibujo (convertidas a metros). "
                      "DWG: se convierte con el programa gratuito ODA File Converter.")
        nota.setObjectName("TextoSecundario"); nota.setWordWrap(True)
        lay.addWidget(nota)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self._aceptar); bb.rejected.connect(self.reject)
        self.ok = bb.button(QDialogButtonBox.StandardButton.Ok); self.ok.setEnabled(False)
        lay.addWidget(bb)

    def _elegir(self):
        ruta, _ = QFileDialog.getOpenFileName(self, "Importar dibujo CAD", "",
                                              "Dibujos CAD (*.dxf *.dwg *.DXF *.DWG);;Todos (*)")
        if ruta:
            self.cargar(ruta)

    def cargar(self, ruta: str):
        try:
            if ruta.lower().endswith(".dwg"):
                dxf_tmp = cad_dwg.convertir_dwg_a_dxf(ruta)
                dib = cad_dxf.leer_dxf(dxf_tmp)
                dib.ruta = ruta
            else:
                dib = cad_dxf.leer_dxf(ruta)
        except (cad_dxf.ErrorDXF, cad_dwg.ErrorDWG, OSError) as error:
            QMessageBox.warning(self, "Importar CAD", str(error))
            return
        self.dibujo = dib
        self.ruta.setText(ruta)
        nom, fac = dib.unidad
        if fac:
            i = self.unidad.findData(fac)
            if i >= 0:
                self.unidad.setCurrentIndex(i)
        ext = dib.extension()
        txt = [f"<b>Versión:</b> {dib.version or '—'} · <b>Unidades ($INSUNITS):</b> {nom}"
               + ("" if fac else " → <span style='color:#e0b341'>⚠ elige la unidad abajo</span>"),
               f"<b>Entidades leídas:</b> {len(dib.entidades)}"]
        if ext:
            txt.append(f"<b>Extensión:</b> X {ext[0]:.2f} – {ext[1]:.2f} · Y {ext[2]:.2f} – {ext[3]:.2f} · "
                       f"Z {ext[4]:.2f} – {ext[5]:.2f} (unidades del dibujo)")
            if ext[4] == ext[5]:
                txt.append("<span style='color:#e0b341'>⚠ Todas las cotas son iguales: el dibujo no trae "
                           "elevación (curvas en 2D). No se podrá crear un TIN útil.</span>")
        if dib.ignoradas:
            txt.append("<b>No importadas:</b> " + ", ".join(f"{k} ({v})" for k, v in dib.ignoradas.items()))
        for a in dib.avisos:
            txt.append(f"⚠ {a}")
        self.info.setText("<br>".join(txt))
        capas = dib.capas()
        self.tabla.setRowCount(len(capas))
        for i, (capa, cont) in enumerate(capas.items()):
            chk = QTableWidgetItem(); chk.setCheckState(Qt.CheckState.Checked)
            self.tabla.setItem(i, 0, chk)
            it = QTableWidgetItem(capa); it.setForeground(QColor(dib.color_hex(capa)))
            self.tabla.setItem(i, 1, it)
            self.tabla.setItem(i, 2, QTableWidgetItem(", ".join(f"{k}: {v}" for k, v in cont.items())))
            tin = QTableWidgetItem()
            nombre = capa.lower()
            sugerida = any(p in nombre for p in ("curva", "nivel", "topo", "contour", "cn", "terreno",
                                                    "superficie", "punto"))
            tin.setCheckState(Qt.CheckState.Checked if sugerida else Qt.CheckState.Unchecked)
            self.tabla.setItem(i, 3, tin)
        self.tabla.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.ok.setEnabled(bool(dib.entidades))

    def _marcadas(self, col):
        return {self.tabla.item(i, 1).text() for i in range(self.tabla.rowCount())
                if self.tabla.item(i, col).checkState() == Qt.CheckState.Checked}

    def _aceptar(self):
        if self.dibujo is None:
            return
        import copy
        dib = copy.deepcopy(self.dibujo)  # el original queda intacto si hay que reintentar
        fac = self.unidad.currentData() or 1.0
        dib.escalar(fac)
        importar = self._marcadas(0)
        para_tin = self._marcadas(3) & importar
        proyecto = self.doc.proyecto
        ids = set(proyecto.objetos)
        gen = _ids_libres(ids, "CAD-")
        capas_existentes = {c.nombre: c.id for c in proyecto.capas}
        capas_nuevas, mapa_capa = [], {}
        for k, capa in enumerate(sorted(importar)):
            nombre = f"CAD: {capa}"
            if nombre in capas_existentes:
                mapa_capa[capa] = capas_existentes[nombre]
                continue
            cid = f"cad-{abs(hash((capa, dib.ruta))) % 10**8}"
            while proyecto.capa(cid) is not None or cid in {c.id for c in capas_nuevas}:
                cid += "x"
            capas_nuevas.append(Capa(id=cid, nombre=nombre, color=dib.color_hex(capa)))
            mapa_capa[capa] = cid
        objetos = []
        puntos_por_capa: dict[str, list] = {}
        tri_por_capa: dict[str, tuple[list, list]] = {}
        for e in dib.entidades:
            if e.capa not in importar:
                continue
            if e.tipo == "polilinea" and len(e.puntos) >= 2:
                ident = next(gen)
                objetos.append(PolilineaCAD(id=ident, nombre=f"{e.capa} {ident}", capa_id=mapa_capa[e.capa],
                                            vertices=[tuple(map(float, p)) for p in e.puntos], cerrada=e.cerrada,
                                            capa_cad=e.capa, archivo=dib.ruta))
            elif e.tipo in ("punto", "texto"):
                lst = puntos_por_capa.setdefault(e.capa, [[], []])
                lst[0].extend(e.puntos); lst[1].extend([e.texto] * len(e.puntos))
            elif e.tipo == "triangulos":
                vs, ts = tri_por_capa.setdefault(e.capa, ([], []))
                base = len(vs)
                vs.extend(e.puntos); ts.extend((a + base, b + base, c + base) for a, b, c in e.triangulos)
        for capa, (pts, txts) in puntos_por_capa.items():
            ident = next(gen)
            objetos.append(PuntosCAD(id=ident, nombre=f"Puntos {capa}", capa_id=mapa_capa[capa],
                                     puntos=[tuple(map(float, p)) for p in pts], textos=txts, capa_cad=capa,
                                     archivo=dib.ruta))
        if not any(c.id == "topografia" for c in proyecto.capas):
            capas_nuevas.append(Capa(id="topografia", nombre="Topografía", color="#8c7a64"))
        for capa, (vs, ts) in tri_por_capa.items():
            ident = next(gen)
            objetos.append(SuperficieTIN(id=ident, nombre=f"Superficie CAD {capa}", capa_id="topografia",
                                         vertices=[tuple(map(float, v)) for v in vs], triangulos=ts,
                                         fuente=f"Caras 3D de la capa {capa}"))
        avisos = []
        if self.crear_tin.isChecked() and para_tin:
            pts = []
            paso = self.dens.value()
            for e in dib.entidades:
                if e.capa in para_tin and e.tipo in ("polilinea", "punto", "texto"):
                    pts.extend(topo.densificar(e.puntos, paso) if (e.tipo == "polilinea" and paso > 0)
                               else e.puntos)
            try:
                t = topo.crear_tin(pts, lado_max=self.lado.value() or None)
                ident = next(gen)
                objetos.append(SuperficieTIN(
                    id=ident, nombre=f"TIN {Path(dib.ruta).stem}", capa_id="topografia",
                    vertices=[tuple(map(float, p)) for p in t.puntos], triangulos=[tuple(map(int, x)) for x in t.triangulos],
                    fuente="Delaunay de: " + ", ".join(sorted(para_tin))))
            except topo.ErrorTopografia as error:
                avisos.append(f"TIN no creado: {error}")
        try:
            self.descripcion = f"Importar {Path(dib.ruta).name}: {len(objetos)} objetos en {len(capas_nuevas)} capas"
            self.doc.importar_capas_y_objetos(capas_nuevas, objetos, self.descripcion)
        except Exception as error:  # noqa: BLE001
            QMessageBox.warning(self, "Importar CAD", str(error))
            return
        if avisos:
            QMessageBox.information(self, "Importar CAD", "\n".join(avisos))
        self.accept()


# ===================================================================== TIN desde el proyecto
def tins_del_proyecto(proyecto) -> list[SuperficieTIN]:
    return [o for o in proyecto.objetos.values() if isinstance(o, SuperficieTIN)]


def tin_de_objeto(o: SuperficieTIN) -> topo.TIN:
    return topo.TIN(np.asarray(o.vertices, float), np.asarray(o.triangulos, int))


class DialogoCrearTIN(QDialog):
    """TIN a partir de las polilíneas/puntos CAD visibles del proyecto (por capa)."""

    def __init__(self, documento, parent=None):
        super().__init__(parent)
        self.doc = documento
        self.descripcion = ""
        self.setWindowTitle("Crear superficie TIN")
        lay = QVBoxLayout(self)
        self.capas = {}
        for o in documento.proyecto.objetos.values():
            if isinstance(o, (PolilineaCAD, PuntosCAD)):
                self.capas.setdefault(o.capa_id, []).append(o)
        self.chks = []
        for cid, objs in self.capas.items():
            capa = documento.proyecto.capa(cid)
            c = QCheckBox(f"{capa.nombre if capa else cid} ({len(objs)} objetos)")
            c.setChecked(True); c.setProperty("capa", cid)
            self.chks.append(c); lay.addWidget(c)
        if not self.chks:
            lay.addWidget(QLabel("No hay polilíneas ni puntos CAD. Importa primero un DXF/DWG."))
        f = QFormLayout()
        self.lado = CampoNumero(0, 1e5, 1, "m", 0, "Lado máximo (0 = sin límite)")
        self.dens = CampoNumero(0, 1e4, 1, "m", 0, "Densificar cada (0 = no)")
        f.addRow(self.lado.nombre, self.lado); f.addRow(self.dens.nombre, self.dens)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self._aceptar); bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _aceptar(self):
        pts = []
        for c in self.chks:
            if not c.isChecked():
                continue
            for o in self.capas[c.property("capa")]:
                if isinstance(o, PolilineaCAD):
                    pts.extend(topo.densificar(o.vertices, self.dens.value()) if self.dens.value() > 0 else o.vertices)
                else:
                    pts.extend(o.puntos)
        try:
            t = topo.crear_tin(pts, lado_max=self.lado.value() or None)
        except topo.ErrorTopografia as error:
            QMessageBox.warning(self, "Crear TIN", str(error))
            return
        proyecto = self.doc.proyecto
        gen = _ids_libres(set(proyecto.objetos), "TIN-")
        capas = [] if proyecto.capa("topografia") else [Capa(id="topografia", nombre="Topografía", color="#8c7a64")]
        obj = SuperficieTIN(id=next(gen), nombre="TIN", capa_id="topografia",
                            vertices=[tuple(map(float, p)) for p in t.puntos],
                            triangulos=[tuple(map(int, x)) for x in t.triangulos], fuente="Capas CAD del proyecto")
        self.descripcion = f"TIN creado: {t.n_triangulos} triángulos"
        self.doc.importar_capas_y_objetos(capas, [obj], self.descripcion)
        self.accept()


# ===================================================================== perfil
class GraficoPerfil(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.perfil: topo.Perfil | None = None
        self.setMinimumSize(640, 300)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor(COLORES["visor_fondo_abajo"]))
        pf = self.perfil
        if pf is None or np.all(np.isnan(pf.z)):
            p.setPen(QColor(COLORES["texto_secundario"]))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "El perfil no cruza la superficie")
            return
        m = 50
        w, h = self.width() - 2 * m, self.height() - 2 * m
        d0, d1 = 0.0, float(pf.distancia[-1]) or 1.0
        z = pf.z[~np.isnan(pf.z)]
        z0, z1 = float(z.min()), float(z.max())
        if z1 - z0 < 1e-6:
            z0 -= 1; z1 += 1
        # escala vertical = horizontal si cabe (sin exagerar), si no se indica exageración
        sx = w / (d1 - d0); sz = h / (z1 - z0)
        ex = sz / sx
        def P(d, zz):
            return QPointF(m + (d - d0) * sx, m + h - (zz - z0) * sz)
        p.setPen(QPen(QColor("#2a3037"), 1))
        for k in range(6):
            y = m + h * k / 5
            p.drawLine(QPointF(m, y), QPointF(m + w, y))
        path = QPainterPath(); empezado = False
        for d, zz in zip(pf.distancia, pf.z):
            if np.isnan(zz):
                empezado = False; continue
            if not empezado:
                path.moveTo(P(d, zz)); empezado = True
            else:
                path.lineTo(P(d, zz))
        p.setPen(QPen(QColor(COLORES["acento"]), 2))
        p.drawPath(path)
        p.setPen(QColor(COLORES["texto_secundario"]))
        p.setFont(QFont("Segoe UI", 8))
        for k in range(6):
            zz = z0 + (z1 - z0) * k / 5
            p.drawText(QRectF(0, m + h - h * k / 5 - 8, m - 4, 16), Qt.AlignmentFlag.AlignRight, f"{zz:.1f}")
            dd = d0 + (d1 - d0) * k / 5
            p.drawText(QRectF(m + w * k / 5 - 30, m + h + 4, 60, 16), Qt.AlignmentFlag.AlignCenter, f"{dd:.1f}")
        p.drawText(m, 18, f"Cota (m) vs. distancia (m) · exageración vertical ×{ex:.1f}")


class DialogoPerfil(QDialog):
    def __init__(self, documento, visor=None, parent=None):
        super().__init__(parent)
        self.doc = documento
        self.setWindowTitle("Perfil topográfico")
        ajustar_a_pantalla(self, 900, 560)
        lay = QVBoxLayout(self)
        self.tins = tins_del_proyecto(documento.proyecto)
        f = QFormLayout()
        self.cb = QComboBox()
        for t in self.tins:
            self.cb.addItem(f"{t.nombre} ({len(t.triangulos)} triángulos)", t.id)
        f.addRow("Superficie", self.cb)
        x0 = y0 = x1 = y1 = 0.0
        if visor is not None and visor.ultima_medida:
            (x0, y0, _), (x1, y1, _) = visor.ultima_medida
        elif self.tins:
            v = np.asarray(self.tins[0].vertices)
            x0, y0 = v[:, 0].min(), v[:, 1].min(); x1, y1 = v[:, 0].max(), v[:, 1].max()
        self.x0 = CampoNumero(-1e8, 1e8, 3, "m", x0, "Inicio X"); self.y0 = CampoNumero(-1e8, 1e8, 3, "m", y0, "Inicio Y")
        self.x1 = CampoNumero(-1e8, 1e8, 3, "m", x1, "Fin X"); self.y1 = CampoNumero(-1e8, 1e8, 3, "m", y1, "Fin Y")
        self.paso = CampoNumero(0.01, 1e4, 2, "m", 1.0, "Paso de muestreo")
        fila = QHBoxLayout()
        for c in (self.x0, self.y0, self.x1, self.y1, self.paso):
            caja = QVBoxLayout(); caja.addWidget(QLabel(c.nombre)); caja.addWidget(c); fila.addLayout(caja)
        lay.addLayout(f); lay.addLayout(fila)
        nota = QLabel("Consejo: usa Topografía y CAD → Medir distancia en la vista 3D; el perfil toma esos dos puntos.")
        nota.setObjectName("TextoSecundario"); lay.addWidget(nota)
        self.grafico = GraficoPerfil(); lay.addWidget(self.grafico, 1)
        self.res = QLabel(); lay.addWidget(self.res)
        botones = QHBoxLayout()
        bc = QPushButton("Calcular perfil"); bc.clicked.connect(self.calcular)
        be = QPushButton("Exportar CSV…"); be.clicked.connect(self.exportar)
        botones.addWidget(bc); botones.addWidget(be); botones.addStretch(1)
        cerrar = QPushButton("Cerrar"); cerrar.clicked.connect(self.reject); botones.addWidget(cerrar)
        lay.addLayout(botones)
        self.perfil = None
        if self.tins:
            self.calcular()

    def calcular(self):
        if not self.tins:
            return
        obj = next(t for t in self.tins if t.id == self.cb.currentData())
        try:
            self.perfil = topo.perfil(tin_de_objeto(obj), [(self.x0.value(), self.y0.value()),
                                                           (self.x1.value(), self.y1.value())], self.paso.value())
        except topo.ErrorTopografia as error:
            QMessageBox.warning(self, "Perfil", str(error)); return
        self.grafico.perfil = self.perfil
        self.grafico.update()
        r = self.perfil.resumen()
        if "cota_min" in r:
            self.res.setText(f"Longitud {r['longitud']:.2f} m · con datos {r['con_datos']:.0f} % · cotas "
                             f"{r['cota_min']:.2f} – {r['cota_max']:.2f} m · desnivel {r['desnivel']:.2f} m · "
                             f"pendiente máx. {r['pend_max_pct']:.1f} % ({r['pend_max_grados']:.1f}°)")
        else:
            self.res.setText("El perfil no cruza la superficie.")

    def exportar(self):
        if self.perfil is None:
            return
        ruta, _ = QFileDialog.getSaveFileName(self, "Exportar perfil", "perfil.csv", "CSV (*.csv)")
        if not ruta:
            return
        with open(ruta, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh, delimiter=";")
            w.writerow(["distancia_m", "este_x", "norte_y", "cota_z"])
            for d, x, y, z in zip(self.perfil.distancia, self.perfil.x, self.perfil.y, self.perfil.z):
                w.writerow([f"{d:.3f}", f"{x:.3f}", f"{y:.3f}", "" if math.isnan(z) else f"{z:.3f}"])


class DialogoPendientes(QDialog):
    def __init__(self, documento, parent=None):
        super().__init__(parent)
        self.doc = documento
        self.setWindowTitle("Pendientes, bancos y taludes")
        lay = QVBoxLayout(self)
        self.tins = tins_del_proyecto(documento.proyecto)
        f = QFormLayout()
        self.cb = QComboBox()
        for t in self.tins:
            self.cb.addItem(t.nombre, t.id)
        f.addRow("Superficie", self.cb)
        self.modo = QComboBox(); self.modo.addItem("Colorear por pendiente", "pendiente"); self.modo.addItem("Colorear por cota", "cota")
        f.addRow("Mostrar", self.modo)
        self.bajo = CampoNumero(0, 90, 1, "°", 15, "Plataforma / berma hasta")
        self.alto = CampoNumero(0, 90, 1, "°", 45, "Talud / cara de banco desde")
        f.addRow(self.bajo.nombre, self.bajo); f.addRow(self.alto.nombre, self.alto)
        lay.addLayout(f)
        self.res = QLabel(); self.res.setWordWrap(True); lay.addWidget(self.res)
        nota = QLabel("Clasificación geométrica por pendiente de cada triángulo, con los umbrales que tú eliges. "
                      "No reemplaza el diseño de bancos ni un análisis de estabilidad.")
        nota.setObjectName("TextoSecundario"); nota.setWordWrap(True); lay.addWidget(nota)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self._aceptar); bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.cb.currentIndexChanged.connect(self._calcular)
        self.bajo.valueChanged.connect(self._calcular); self.alto.valueChanged.connect(self._calcular)
        self._calcular()

    def _calcular(self, *_):
        if not self.tins:
            self.res.setText("No hay superficies TIN."); return
        obj = next(t for t in self.tins if t.id == self.cb.currentData())
        t = tin_de_objeto(obj)
        pend = t.pendientes()
        p = t.puntos[t.triangulos][:, :, :2]
        areas = np.abs(_cruz2(p[:, 1] - p[:, 0], p[:, 2] - p[:, 0])) / 2
        cl = topo.clasificar_pendientes(pend, self.bajo.value(), self.alto.value())
        tot = areas.sum() or 1
        self.res.setText(
            f"Área en planta {tot:.1f} m² · pendiente media {np.average(pend, weights=areas):.1f}° · máxima {pend.max():.1f}°<br>"
            f"Plataforma/berma: {100 * areas[cl == 0].sum() / tot:.1f} % · intermedia: {100 * areas[cl == 1].sum() / tot:.1f} % · "
            f"talud/cara: {100 * areas[cl == 2].sum() / tot:.1f} %")

    def _aceptar(self):
        if self.tins:
            self.doc.cambiar_atributos(self.cb.currentData(), "Coloreado de superficie",
                                       colorear=self.modo.currentData(), umbral_bajo=self.bajo.value(),
                                       umbral_alto=self.alto.value())
        self.accept()


class DialogoConfigDWG(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Conversor DWG (ODA File Converter)")
        lay = QVBoxLayout(self)
        actual = cad_dwg.buscar_oda()
        self.lab = QLabel(f"Detectado: {actual}" if actual else
                          "No se encontró ODA File Converter. Descárgalo gratis de opendesign.com (Guest files), "
                          "instálalo y luego indica aquí su ejecutable (ODAFileConverter.exe).")
        self.lab.setWordWrap(True); lay.addWidget(self.lab)
        b = QPushButton("Buscar ejecutable…"); b.clicked.connect(self._buscar); lay.addWidget(b)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close); bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _buscar(self):
        ruta, _ = QFileDialog.getOpenFileName(self, "ODAFileConverter", "", "Programa (*.exe ODAFileConverter);;Todos (*)")
        if ruta:
            cad_dwg.guardar_ruta_oda(ruta)
            self.lab.setText(f"Configurado: {ruta}")
