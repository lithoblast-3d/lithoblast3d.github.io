"""
Biblioteca de mallas del estándar (referencias documentales).

- Lista filtrable de los planos del estándar MIN-SOS-ESO-001 (6 secciones).
- Vistas: Frontal (editable, con el plano original de fondo), Planta, Lateral y 3D.
- Tablas del documento y verificación de la malla contra esas tablas.
- Edición manual: mover (arrastrar), agregar (doble clic; Shift = alivio),
  eliminar (Supr), editar valores en la tabla. Guardar edición / restaurar original.
- "Usar en el proyecto": crea las perforaciones como referencia documental.
"""

from __future__ import annotations

import math

import numpy as np
from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QImage, QPainter, QPainterPath, QPen, QTransform
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout,
    QHeaderView, QInputDialog, QLabel, QListWidget, QListWidgetItem, QMessageBox, QPushButton,
    QSplitter, QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget,
)

from app.biblioteca import estandar as est
from app.ui.tema import COLORES, ajustar_a_pantalla

_LEYENDAS = None
COLOR_ALIVIO = QColor("#f2f2f2")
COLOR_SIN_EXPL = QColor("#8a9099")


def _color_explosivo(plano: est.PlanoRef, nombre: str | None) -> QColor:
    rgb = plano_colores(plano).get(nombre)
    return QColor(*rgb) if rgb else COLOR_SIN_EXPL


def plano_colores(plano) -> dict:
    # colores tomados de la leyenda del mismo plano (cuadros de la tabla de explosivos)
    return getattr(plano, "_colores", None) or {}


# ====================================================================== lienzos 2D
class Lienzo(QWidget):
    """Base: transforma metros <-> píxeles con escala uniforme."""

    cambiado = Signal()
    seleccion = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.plano: est.PlanoRef | None = None
        self.sel: int | None = None
        self.setMinimumSize(320, 320)
        self.setMouseTracking(True)

    def set_plano(self, p):
        self.plano = p
        self.sel = None
        self.update()

    def limites(self):
        return (-1, 1, -0.5, 2)

    def _xf(self):
        x0, x1, y0, y1 = self.limites()
        m = 30
        w, h = self.width() - 2 * m, self.height() - 2 * m
        s = min(w / max(x1 - x0, 1e-6), h / max(y1 - y0, 1e-6))
        ox = m + (w - s * (x1 - x0)) / 2 - s * x0
        oy = m + (h - s * (y1 - y0)) / 2 + s * y1
        return s, ox, oy

    def a_px(self, x, y):
        s, ox, oy = self._xf()
        return QPointF(ox + s * x, oy - s * y)

    def a_m(self, px, py):
        s, ox, oy = self._xf()
        return (px - ox) / s, (oy - py) / s

    def _fondo(self, p: QPainter):
        p.fillRect(self.rect(), QColor(COLORES["visor_fondo_abajo"]))

    def _rejilla(self, p: QPainter, paso=0.5):
        x0, x1, y0, y1 = self.limites()
        p.setPen(QPen(QColor("#2a3037"), 1))
        x = math.floor(x0 / paso) * paso
        while x <= x1:
            a, b = self.a_px(x, y0), self.a_px(x, y1)
            p.drawLine(a, b); x += paso
        y = math.floor(y0 / paso) * paso
        while y <= y1:
            a, b = self.a_px(x0, y), self.a_px(x1, y)
            p.drawLine(a, b); y += paso

    def _sello(self, p: QPainter, texto: str):
        p.setPen(QColor(COLORES["aviso"]))
        p.setFont(QFont("Segoe UI", 8))
        p.drawText(QRectF(8, self.height() - 22, self.width() - 16, 18),
                   Qt.AlignmentFlag.AlignLeft, texto)


class LienzoFrontal(Lienzo):
    """Vista del frente (lo que se ve en el plano). Editable."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.mostrar_imagen = True
        self.mostrar_rotulos = True
        self._img: QImage | None = None
        self._afin = None
        self._arrastre = False
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def set_plano(self, p):
        super().set_plano(p)
        self._img = None
        self._afin = None
        if p is not None and p.imagen.exists():
            self._img = QImage(str(p.imagen))
            self._ajustar_afin()
        self.update()

    def _ajustar_afin(self):
        """Transformación imagen(px) -> metros por mínimos cuadrados con los taladros."""
        orig = est.original(self.plano.pagina)
        pts = [(t.px[0], t.px[1], t.x, t.y) for t in orig.taladros if len(t.px) == 2]
        if len(pts) < 3:
            return
        A = np.array([[a, b, 1.0] for a, b, _, _ in pts])
        bx = np.array([c for _, _, c, _ in pts]); by = np.array([d for _, _, _, d in pts])
        cx, *_ = np.linalg.lstsq(A, bx, rcond=None)
        cy, *_ = np.linalg.lstsq(A, by, rcond=None)
        self._afin = (cx, cy)

    def limites(self):
        if not self.plano:
            return super().limites()
        a, h = self.plano.ancho, self.plano.alto
        return (-a / 2 - 0.3, a / 2 + 0.3, -0.5, h + 0.25)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        self._fondo(p)
        if not self.plano:
            return
        self._rejilla(p)
        pl = self.plano
        if self.mostrar_imagen and self._img is not None and self._afin is not None:
            cx, cy = self._afin
            # imagen (u,v) -> metros (x,y) -> pantalla
            s, ox, oy = self._xf()
            t = QTransform(cx[0] * s, -cy[0] * s, cx[1] * s, -cy[1] * s,
                           ox + cx[2] * s, oy - cy[2] * s)
            p.save()
            p.setTransform(t)
            p.setOpacity(0.35)
            p.drawImage(0, 0, self._img)
            p.restore()
        if pl.contorno:
            path = QPainterPath(self.a_px(*pl.contorno[0]))
            for v in pl.contorno[1:]:
                path.lineTo(self.a_px(*v))
            path.closeSubpath()
            p.setPen(QPen(QColor(COLORES["acento_azul"]), 2))
            p.setBrush(QColor(58, 141, 222, 25))
            p.drawPath(path)
        s, _, _ = self._xf()
        r = max(4.0, 0.025 * s)
        f = QFont("Segoe UI", 8)
        p.setFont(f)
        for i, t in enumerate(pl.taladros):
            c = self.a_px(t.x, t.y)
            if t.tipo == "alivio":
                p.setBrush(COLOR_ALIVIO)
            else:
                p.setBrush(_color_explosivo(pl, t.explosivo))
            pen = QPen(QColor("#ff5fd2") if i == self.sel else QColor("#101214"), 3 if i == self.sel else 1)
            p.setPen(pen)
            p.drawEllipse(c, r, r)
            if t.revisar:
                p.setPen(QPen(QColor(COLORES["aviso"]), 1.5, Qt.PenStyle.DashLine))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(c, r + 4, r + 4)
            if self.mostrar_rotulos and t.tipo == "cargado":
                p.setPen(QColor(COLORES["texto"]))
                txt = f"{t.detonador},{t.cartuchos}" + (f",{t.anfo_kg:g}" if t.anfo_kg is not None else "")
                p.drawText(QRectF(c.x() - 40, c.y() - r - 16, 80, 14), Qt.AlignmentFlag.AlignCenter, txt)
        # cota
        p.setPen(QColor(COLORES["texto_secundario"]))
        p.drawText(8, 16, f"Frente · {pl.ancho:.2f} m × {pl.alto:.2f} m · arrastrar = mover · "
                          "doble clic = agregar (Shift: alivio) · Supr = eliminar")
        self._sello(p, est.ESTADO_DOC if pl.estado == est.ESTADO_DOC else f"{pl.estado}: {pl.validado_por}")

    # --- edición
    def _taladro_en(self, pos):
        if not self.plano:
            return None
        s, _, _ = self._xf()
        r = max(6.0, 0.03 * s)
        best = None
        for i, t in enumerate(self.plano.taladros):
            c = self.a_px(t.x, t.y)
            d = math.hypot(c.x() - pos.x(), c.y() - pos.y())
            if d <= r and (best is None or d < best[0]):
                best = (d, i)
        return best[1] if best else None

    def mousePressEvent(self, e):
        i = self._taladro_en(e.position())
        self.sel = i
        self._arrastre = i is not None
        self.seleccion.emit(-1 if i is None else i)
        self.update()

    def mouseMoveEvent(self, e):
        if self._arrastre and self.sel is not None and e.buttons() & Qt.MouseButton.LeftButton:
            x, y = self.a_m(e.position().x(), e.position().y())
            t = self.plano.taladros[self.sel]
            t.x, t.y = round(x, 3), round(y, 3)
            t.lectura = "posición editada por el usuario"
            self.update()

    def mouseReleaseEvent(self, e):
        if self._arrastre:
            self._arrastre = False
            self.cambiado.emit()

    def mouseDoubleClickEvent(self, e):
        if not self.plano or self._taladro_en(e.position()) is not None:
            return
        x, y = self.a_m(e.position().x(), e.position().y())
        alivio = bool(e.modifiers() & Qt.KeyboardModifier.ShiftModifier)
        expl = None
        if not alivio:
            nombres = [n for n in est.PlanoRef.kg_por_cartucho(self.plano)]
            expl = nombres[0] if nombres else None
        self.plano.taladros.append(est.TaladroRef(
            x=round(x, 3), y=round(y, 3), tipo="alivio" if alivio else "cargado",
            detonador=None if alivio else 0, cartuchos=0, explosivo=expl,
            lectura="agregado por el usuario: completar datos"))
        self.sel = len(self.plano.taladros) - 1
        self.seleccion.emit(self.sel)
        self.cambiado.emit()
        self.update()

    def keyPressEvent(self, e):
        if e.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace) and self.sel is not None:
            del self.plano.taladros[self.sel]
            self.sel = None
            self.seleccion.emit(-1)
            self.cambiado.emit()
            self.update()
        else:
            super().keyPressEvent(e)


class LienzoProyeccion(Lienzo):
    """Planta (eje horizontal del frente vs. avance) o lateral (avance vs. altura)."""

    def __init__(self, modo: str, parent=None):
        super().__init__(parent)
        self.modo = modo  # "planta" o "lateral"

    def limites(self):
        if not self.plano:
            return super().limites()
        L = self.plano.longitud_perforacion()
        if self.modo == "planta":
            a = self.plano.ancho
            return (-0.3 - L - 0.3, 0.6, -a / 2 - 0.3, a / 2 + 0.3)
        h = self.plano.alto
        return (-0.3 - L - 0.3, 0.6, -0.5, h + 0.3)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        self._fondo(p)
        if not self.plano:
            return
        self._rejilla(p)
        pl = self.plano
        L = pl.longitud_perforacion()
        # roca a volar (prisma) y frente
        if self.modo == "planta":
            y0, y1 = -pl.ancho / 2, pl.ancho / 2
        else:
            ys = [v[1] for v in pl.contorno] or [0, pl.alto]
            y0, y1 = min(ys), max(ys)
        p.setPen(QPen(QColor(COLORES["acento_azul"]), 1.5))
        p.setBrush(QColor(140, 122, 100, 40))
        p.drawRect(QRectF(self.a_px(-L, y1), self.a_px(0, y0)))
        p.setPen(QPen(QColor(COLORES["acento"]), 2))
        p.drawLine(self.a_px(0, y0 - 0.2), self.a_px(0, y1 + 0.2))
        orden = sorted(range(len(pl.taladros)), key=lambda i: pl.taladros[i].tipo != "alivio")
        for i in orden:
            t = pl.taladros[i]
            lt = t.longitud or L
            az = math.radians(getattr(t, "azimut_rel", 0.0) or 0.0)
            prof = lt * math.cos(az)
            if self.modo == "planta":  # mirando desde arriba: eje vertical = −x
                v0, v1 = -t.x, -(t.x + lt * math.sin(az))
            else:
                v0 = v1 = t.y
            col = COLOR_ALIVIO if t.tipo == "alivio" else _color_explosivo(pl, t.explosivo)
            p.setPen(QPen(col, 2.5 if t.tipo == "alivio" else 1.6))
            p.drawLine(self.a_px(0, v0), self.a_px(-prof, v1))
        p.setPen(QColor(COLORES["texto_secundario"]))
        p.setFont(QFont("Segoe UI", 8))
        nombre = "Planta (vista superior)" if self.modo == "planta" else "Lateral (corte longitudinal)"
        p.drawText(8, 16, f"{nombre} · longitud de perforación {L:.2f} m "
                          f"({pl.parametros.get('long_perforacion_pies', 6):g} pies, del plano) · "
                          "taladros paralelos (el plano no indica inclinación)")
        a = self.a_px(-L, y0 - 0.15); b = self.a_px(0, y0 - 0.15)
        p.drawLine(a, b)
        p.drawText(QRectF(a.x(), a.y() + 2, b.x() - a.x(), 14), Qt.AlignmentFlag.AlignCenter, f"{L:.2f} m")
        self._sello(p, est.ESTADO_DOC)


# ====================================================================== vista 3D
class Vista3DPlano(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.plotter = None
        try:
            from pyvistaqt import QtInteractor
            self.plotter = QtInteractor(self)
            lay.addWidget(self.plotter.interactor)
            self.plotter.set_background(COLORES["visor_fondo_abajo"], top=COLORES["visor_fondo_arriba"])
        except Exception as error:  # noqa: BLE001
            lay.addWidget(QLabel(f"Vista 3D no disponible: {error}"))

    def mostrar(self, pl: est.PlanoRef | None):
        if self.plotter is None or pl is None:
            return
        import pyvista as pv
        pv_ = self.plotter
        pv_.clear()
        L = pl.longitud_perforacion()
        if pl.contorno:
            pts = np.array([[x, 0.0, y] for x, y in pl.contorno])
            n = len(pts)
            cara = pv.PolyData(pts, faces=np.array([n, *range(n)]))
            try:
                prisma = cara.extrude((0, L, 0), capping=True)
                pv_.add_mesh(prisma, color="#8c7a64", opacity=0.25, show_edges=False)
            except Exception:  # noqa: BLE001
                pass
            pv_.add_mesh(pv.PolyData(pts, lines=np.array([n + 1, *range(n), 0])), color=COLORES["acento_azul"],
                         line_width=3)
        for t in pl.taladros:
            col = "#f2f2f2" if t.tipo == "alivio" else _color_explosivo(pl, t.explosivo).name()
            r = 0.05 if t.tipo == "alivio" else 0.02
            lt = t.longitud or L
            az = math.radians(getattr(t, "azimut_rel", 0.0) or 0.0)
            dirv = (math.sin(az), math.cos(az), 0.0)
            centro = (t.x + dirv[0] * lt / 2, dirv[1] * lt / 2, t.y)
            cil = pv.Cylinder(center=centro, direction=dirv, radius=r, height=lt, resolution=16)
            pv_.add_mesh(cil, color=col)
        pv_.add_text(est.ESTADO_DOC, position="lower_left", font_size=8, color=COLORES["aviso"])
        pv_.add_axes(xlabel="Ancho", ylabel="Avance", zlabel="Alto")
        pv_.view_isometric()
        pv_.reset_camera()

    def cerrar(self):
        if self.plotter is not None:
            try:
                self.plotter.close()
            except Exception:  # noqa: BLE001
                pass


# ====================================================================== diálogo de importación
def colores_leyenda(pagina: int) -> dict:
    """Colores de la leyenda de explosivos de un plano (tomados del PDF)."""
    import json
    global _LEYENDAS
    if _LEYENDAS is None:
        try:
            datos = json.loads(est.ARCHIVO_BIBLIOTECA.read_text(encoding="utf-8"))
            _LEYENDAS = {d["pagina"]: d.get("leyenda_colores", {}) for d in datos}
        except Exception:  # noqa: BLE001
            _LEYENDAS = {}
    return {k: tuple(v) for k, v in _LEYENDAS.get(pagina, {}).items()}


def aplicar_plano_en_proyecto(doc, pl: est.PlanoRef, d_mm: float, da_mm: float, x0: float, y0: float, z0: float,
                              az: float, reemplazar: bool, longitud_m: float | None = None,
                              labor: str = "frente") -> str:
    """Crea en el proyecto los explosivos, la sección y las perforaciones del plano (un solo paso deshacible)."""
    from dataclasses import replace
    from app.core.generador import nuevo_id_contorno
    from app.core.modelo import (ESCENARIO_SUBTERRANEO, TIPO_ENCARTUCHADO, Banco, Contorno, Explosivo, Superficie)
    proyecto = doc.proyecto
    ids = {}
    nuevos_exp = list(proyecto.explosivos)
    for e in est.explosivos_del_plano(pl):
        existente = next((x for x in nuevos_exp if x.nombre.strip().lower() == e["nombre"].lower()), None)
        if existente is None:
            n = len(nuevos_exp) + 1
            while any(x.id == f"EXP-{n:02d}" for x in nuevos_exp):
                n += 1
            existente = Explosivo(id=f"EXP-{n:02d}", nombre=e["nombre"], tipo=TIPO_ENCARTUCHADO,
                                  densidad_gcc=e["densidad_gcc"] or 1.0,
                                  diametro_cartucho_mm=round(e["diametro_mm"], 1), referencial=True)
            nuevos_exp.append(existente)
        ids[e["nombre"]] = existente.id
    for t in pl.cargados():  # explosivos del proyecto usados por mallas calculadas
        if t.explosivo and t.explosivo not in ids:
            ex = next((x for x in nuevos_exp if x.nombre == t.explosivo), None)
            if ex is not None:
                ids[t.explosivo] = ex.id
    if len(nuevos_exp) != len(proyecto.explosivos):
        doc.reemplazar_explosivos(nuevos_exp)
    eliminar = [o.id for o in proyecto.objetos.values() if isinstance(o, (Superficie, Banco))]
    if reemplazar:
        eliminar += [q.id for q in proyecto.perforaciones()]
        eliminar += [o.id for o in proyecto.objetos.values() if isinstance(o, Contorno)]
    eliminar = list(dict.fromkeys(eliminar))
    ocupados = set(proyecto.objetos) - set(eliminar)
    pozos, vertices = est.plano_a_pozos(pl, ocupados, d_mm, da_mm, x0, y0, z0, az, ids, longitud_m, labor)
    id_c = nuevo_id_contorno(ocupados | {p.id for p in pozos})
    seccion = Contorno(id=id_c, nombre=f"Sección {pl.seccion} m ({pl.codigo})", capa_id="contornos",
                       vertices=vertices)
    par = pl.parametros
    diseno = replace(proyecto.diseno, escenario=ESCENARIO_SUBTERRANEO,
                     area_seccion=float((par.get("area_m2") or {}).get("sin_sobrerotura") or seccion.area()),
                     avance=float(par.get("avance_m") or proyecto.diseno.avance),
                     densidad_roca=float(par.get("peso_especifico_t_m3") or proyecto.diseno.densidad_roca))
    if pl.plantilla is not None or getattr(pl, "estado", "") == "Generado":
        descripcion = f"Malla generada: {pl.nombre} — {len(pozos)} taladros (verifícala en campo)"
    else:
        descripcion = (f"Malla de referencia documental: {pl.nombre} — {len(pozos)} taladros "
                       f"(validar antes de usar en campo)")
    doc.aplicar_lote([seccion, *pozos], eliminar, diseno, descripcion)
    return descripcion


class DialogoUsarPlano(QDialog):
    def __init__(self, pl: est.PlanoRef, parent=None, d_mm: float = 38, da_mm: float = 38):
        super().__init__(parent)
        from app.ui.dialogos import CampoNumero
        self.setWindowTitle("Usar plano en el proyecto")
        lay = QVBoxLayout(self)
        aviso = QLabel(
            "⚠ El estándar NO indica el diámetro de perforación ni el de los alivios: "
            "escríbelos según tus brocas.\nLa carga de cada taladro = cartuchos del rótulo × kg por "
            "cartucho de la tabla del plano (o la carga calculada en mallas generadas).")
        aviso.setWordWrap(True)
        aviso.setObjectName("Insignia")
        lay.addWidget(aviso)
        f = QFormLayout()
        self.d = CampoNumero(10, 200, 0, "mm", d_mm, "Ø de perforación")
        self.da = CampoNumero(10, 300, 0, "mm", da_mm, "Ø de los alivios")
        self.x0 = CampoNumero(-1e7, 1e7, 2, "m", 0, "Este X del centro del piso")
        self.y0 = CampoNumero(-1e7, 1e7, 2, "m", 0, "Norte Y")
        self.z0 = CampoNumero(-1e5, 1e5, 2, "m", 0, "Cota del piso")
        self.az = CampoNumero(0, 360, 1, "°", 0, "Azimut de avance")
        for c in (self.d, self.da, self.x0, self.y0, self.z0, self.az):
            f.addRow(c.nombre, c)
        self.reemplazar = QCheckBox("Reemplazar la malla actual del proyecto")
        self.reemplazar.setChecked(True)
        f.addRow(self.reemplazar)
        lay.addLayout(f)
        ex = est.explosivos_del_plano(pl)
        txt = "\n".join(f"• {e['nombre']}: {e['kg_cartucho']:.3f} kg/cartucho (tabla) → " + (
            f"densidad derivada {e['densidad_gcc']:.2f} g/cm³ (referencial)" if e['densidad_gcc'] else
            "densidad no derivable del plano (se registra 1.00 solo como marcador; ingresa la de la ficha)")
            for e in ex)
        lab = QLabel("Explosivos que se registrarán:\n" + (txt or "—"))
        lab.setObjectName("TextoSecundario")
        lay.addWidget(lab)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)


# ====================================================================== diálogo principal
class DialogoBiblioteca(QDialog):
    def __init__(self, documento=None, parent=None):
        super().__init__(parent)
        self.doc = documento
        self.descripcion = ""
        self.setWindowTitle("Biblioteca de mallas — Estándar de voladura en labores de avance de 6 pies")
        ajustar_a_pantalla(self, 1400, 860)
        try:
            self.planos = est.cargar_biblioteca()
        except FileNotFoundError:
            self.planos = []
        for pl in self.planos:
            self._colores_de(pl)
        self.actual: est.PlanoRef | None = None
        self._llenando = False

        raiz = QVBoxLayout(self)
        cab = QLabel(f"<b>Fuente:</b> {est.DOCUMENTO} (Cía. Minera Poderosa). "
                     "Mallas digitalizadas de los planos (imagen) y verificadas contra sus tablas. "
                     "<span style='color:#e0b341'>⚠ Referencias documentales: no son diseños validados "
                     "para condiciones reales.</span>")
        cab.setWordWrap(True)
        raiz.addWidget(cab)
        self.barra_botones = QHBoxLayout()
        raiz.addLayout(self.barra_botones)

        div = QSplitter(Qt.Orientation.Horizontal)
        raiz.addWidget(div, 1)

        # ---- izquierda: filtros + lista
        izq = QWidget(); li = QVBoxLayout(izq); li.setContentsMargins(0, 0, 0, 0)
        self.f_sec = QComboBox(); self.f_sec.addItem("Todas las secciones", None)
        for s in est.SECCIONES:
            self.f_sec.addItem(f"Sección {s} m", s)
        self.f_roca = QComboBox(); self.f_roca.addItem("Toda roca", None)
        for r in est.ROCAS:
            self.f_roca.addItem(f"Roca {r}", r)
        li.addWidget(self.f_sec); li.addWidget(self.f_roca)
        self.lista = QListWidget()
        li.addWidget(self.lista, 1)
        self.cuenta = QLabel(); self.cuenta.setObjectName("TextoSecundario")
        li.addWidget(self.cuenta)
        div.addWidget(izq)

        # ---- centro: pestañas
        centro = QWidget(); lc = QVBoxLayout(centro); lc.setContentsMargins(0, 0, 0, 0)
        self.titulo = QLabel(); self.titulo.setObjectName("TituloObjeto"); self.titulo.setWordWrap(True)
        self.estado = QLabel(); self.estado.setObjectName("Insignia"); self.estado.setWordWrap(True)
        lc.addWidget(self.titulo); lc.addWidget(self.estado)
        self.tabs = QTabWidget()
        self.frontal = LienzoFrontal()
        marco = QWidget(); lm = QVBoxLayout(marco); lm.setContentsMargins(0, 0, 0, 0)
        opciones = QHBoxLayout()
        self.chk_img = QCheckBox("Plano original de fondo"); self.chk_img.setChecked(True)
        self.chk_rot = QCheckBox("Rótulos"); self.chk_rot.setChecked(True)
        opciones.addWidget(self.chk_img); opciones.addWidget(self.chk_rot); opciones.addStretch(1)
        lm.addLayout(opciones); lm.addWidget(self.frontal, 1)
        self.tabs.addTab(marco, "Frontal (editar)")
        self.planta = LienzoProyeccion("planta"); self.tabs.addTab(self.planta, "Planta")
        self.lateral = LienzoProyeccion("lateral"); self.tabs.addTab(self.lateral, "Lateral")
        self.vista3d = Vista3DPlano(); self.tabs.addTab(self.vista3d, "3D")
        self.t_doc = QTableWidget(); self.tabs.addTab(self.t_doc, "Tablas del plano")
        self.t_ver = QTableWidget(); self.tabs.addTab(self.t_ver, "Verificación")
        lc.addWidget(self.tabs, 1)
        div.addWidget(centro)

        # ---- derecha: tabla de taladros + botones
        der = QWidget(); ld = QVBoxLayout(der); ld.setContentsMargins(0, 0, 0, 0)
        ld.addWidget(QLabel("Taladros (doble clic para editar)"))
        self.t_tal = QTableWidget()
        self.t_tal.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        ld.addWidget(self.t_tal, 1)
        self.b_guardar = QPushButton("Guardar edición")
        self.b_restaurar = QPushButton("Restaurar digitalización original")
        self.b_validar = QPushButton("Marcar como verificado…")
        self.b_usar = QPushButton("Usar en el proyecto…")
        self.b_usar.setDefault(True)
        self.b_adaptar = QPushButton("Adaptar a otra sección / cuneta…")
        self.b_usar.setText("✔ Usar en el proyecto…")
        for b in (self.b_usar, self.b_adaptar, self.b_guardar, self.b_restaurar, self.b_validar):
            self.barra_botones.addWidget(b)
        self.barra_botones.addStretch(1)
        div.addWidget(der)
        div.setSizes([260, 760, 420])

        b_cerrar = QPushButton("Cerrar")
        b_cerrar.clicked.connect(self.reject)
        self.barra_botones.addWidget(b_cerrar)

        # señales
        self.f_sec.currentIndexChanged.connect(self._llenar_lista)
        self.f_roca.currentIndexChanged.connect(self._llenar_lista)
        self.lista.currentItemChanged.connect(self._elegir)
        self.chk_img.toggled.connect(self._opciones)
        self.chk_rot.toggled.connect(self._opciones)
        self.frontal.cambiado.connect(self._al_editar)
        self.frontal.seleccion.connect(self._seleccionar_fila)
        self.t_tal.itemChanged.connect(self._celda_editada)
        self.t_tal.itemSelectionChanged.connect(self._fila_elegida)
        self.tabs.currentChanged.connect(self._pestana)
        self.b_guardar.clicked.connect(self._guardar)
        self.b_restaurar.clicked.connect(self._restaurar)
        self.b_validar.clicked.connect(self._validar)
        self.b_usar.clicked.connect(self._usar)
        self.b_adaptar.clicked.connect(self._adaptar)
        self.b_usar.setEnabled(self.doc is not None)
        self._llenar_lista()

    # ------------------------------------------------------------ datos
    def _colores_de(self, pl):
        # La leyenda de colores se guardó en el JSON original
        pl._colores = colores_leyenda(pl.pagina)

    def _llenar_lista(self, *_):
        sec, roca = self.f_sec.currentData(), self.f_roca.currentData()
        filtrados = est.filtrar(self.planos, sec, roca)
        self.lista.clear()
        for pl in filtrados:
            ok, dif, rev = est.resumen_verificacion(pl)
            marca = "✓" if dif == 0 else "⚠"
            extra = " · editado" if pl.editado else ""
            extra += " · VALIDADO" if pl.estado == est.ESTADO_VALIDADO else ""
            it = QListWidgetItem(f"{marca} {pl.seccion} · {pl.roca} · {pl.variante}\n"
                                 f"   pág. {pl.pagina} · {len(pl.taladros)} tal. · revisar {rev}{extra}")
            it.setData(Qt.ItemDataRole.UserRole, pl.pagina)
            self.lista.addItem(it)
        self.cuenta.setText(f"{len(filtrados)} de {len(self.planos)} planos")
        if self.lista.count():
            self.lista.setCurrentRow(0)

    def _plano(self, pagina):
        return next(p for p in self.planos if p.pagina == pagina)

    def _elegir(self, item, _prev=None):
        if item is None:
            return
        self.actual = self._plano(item.data(Qt.ItemDataRole.UserRole))
        self._mostrar()

    def _mostrar(self):
        pl = self.actual
        self.titulo.setText(f"{pl.nombre}  —  {pl.codigo}")
        ok, dif, rev = est.resumen_verificacion(pl)
        txt = (f"{pl.estado}{' (' + pl.validado_por + ')' if pl.validado_por else ''} · "
               f"Verificación contra las tablas del plano: {ok} coinciden, {dif} difieren · "
               f"{rev} taladros con lectura a revisar · Rótulo: {pl.rotulo} · Iniciación {pl.iniciacion} · "
               f"RMR {pl.rmr}")
        self.estado.setText(txt)
        for lz in (self.frontal, self.planta, self.lateral):
            lz.set_plano(pl)
        self._llenar_taladros()
        self._llenar_doc()
        self._llenar_ver()
        if self.tabs.currentWidget() is self.vista3d:
            self.vista3d.mostrar(pl)

    def _pestana(self, _i):
        if self.tabs.currentWidget() is self.vista3d and self.actual:
            self.vista3d.mostrar(self.actual)

    def _opciones(self):
        self.frontal.mostrar_imagen = self.chk_img.isChecked()
        self.frontal.mostrar_rotulos = self.chk_rot.isChecked()
        self.frontal.update()

    COLS = ["X (m)", "Y (m)", "Tipo", "Detonador", "Cartuchos", "Explosivo", "ANFO kg", "Función", "Lectura"]

    def _llenar_taladros(self):
        pl = self.actual
        self._llenando = True
        t = self.t_tal
        t.clear()
        t.setColumnCount(len(self.COLS))
        t.setHorizontalHeaderLabels(self.COLS)
        t.setRowCount(len(pl.taladros))
        fun = est.clasificar(pl)
        for i, ta in enumerate(pl.taladros):
            vals = [f"{ta.x:.3f}", f"{ta.y:.3f}", ta.tipo, "" if ta.detonador is None else str(ta.detonador),
                    str(ta.cartuchos), ta.explosivo or "", "" if ta.anfo_kg is None else f"{ta.anfo_kg:g}",
                    fun[i], ta.lectura]
            for j, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if j >= 7:
                    it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if ta.revisar:
                    it.setForeground(QBrush(QColor(COLORES["aviso"])))
                t.setItem(i, j, it)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self._llenando = False

    def _celda_editada(self, item):
        if self._llenando or not self.actual:
            return
        i, j = item.row(), item.column()
        ta = self.actual.taladros[i]
        v = item.text().strip().replace(",", ".")
        try:
            if j == 0:
                ta.x = float(v)
            elif j == 1:
                ta.y = float(v)
            elif j == 2:
                if v not in ("cargado", "alivio"):
                    raise ValueError("Tipo: escribe cargado o alivio")
                ta.tipo = v
            elif j == 3:
                ta.detonador = int(float(v)) if v else None
            elif j == 4:
                ta.cartuchos = int(float(v or 0))
            elif j == 5:
                nombres = [f["nombre"] for f in self.actual.explosivos_tabla]
                if v and item.text().strip() not in nombres:
                    raise ValueError("Explosivo: usa un nombre de la tabla del plano:\n" + "\n".join(nombres))
                ta.explosivo = item.text().strip() or None
            elif j == 6:
                ta.anfo_kg = float(v) if v else None
        except ValueError as error:
            QMessageBox.warning(self, "Editar taladro", str(error))
            self._llenar_taladros()
            return
        ta.lectura = "editado por el usuario"
        self._al_editar(recargar_tabla=False)

    def _al_editar(self, recargar_tabla=True):
        self.actual.editado = True
        if recargar_tabla:
            self._llenar_taladros()
        self._llenar_ver()
        for lz in (self.frontal, self.planta, self.lateral):
            lz.update()
        ok, dif, rev = est.resumen_verificacion(self.actual)
        self.estado.setText(f"Edición sin guardar · verificación: {ok} coinciden, {dif} difieren · "
                            f"{rev} por revisar")

    def _seleccionar_fila(self, i):
        if i >= 0:
            self.t_tal.selectRow(i)

    def _fila_elegida(self):
        filas = {ix.row() for ix in self.t_tal.selectedIndexes()}
        if len(filas) == 1:
            self.frontal.sel = filas.pop()
            self.frontal.update()

    def _llenar_doc(self):
        pl = self.actual
        filas = []
        if pl.cuenta_detonadores:
            filas.append(("CUENTA DE DETONADORES (N_Det_NE)", "", ""))
            for k, v in sorted(pl.cuenta_detonadores.items()):
                filas.append((f"  Detonador N.º {k}", str(v), "taladros"))
            filas.append(("  Total", str(pl.total_cargados), "taladros"))
        filas.append(("EXPLOSIVOS", "", ""))
        for f in pl.explosivos_tabla:
            filas.append((f"  {f['nombre']}", " · ".join(f"{k}: {v:g}" for k, v in f["valores"].items()), ""))
        if pl.accesorios:
            filas.append(("ACCESORIOS", "", ""))
            for k, v in pl.accesorios.items():
                filas.append((f"  {k}", f"{v:g}" if isinstance(v, (int, float)) else str(v), ""))
        filas.append(("PARÁMETROS", "", ""))
        for k, v in pl.parametros.items():
            if isinstance(v, dict):
                v = f"sin sobrerotura {v['sin_sobrerotura']:g} · con sobrerotura {v['con_sobrerotura']:g}"
            filas.append((f"  {k.replace('_', ' ')}", f"{v:g}" if isinstance(v, (int, float)) else str(v), ""))
        filas.append(("TÍTULO (OCR del plano)", pl.titulo_ocr, ""))
        t = self.t_doc
        t.clear(); t.setColumnCount(3); t.setRowCount(len(filas))
        t.setHorizontalHeaderLabels(["Dato", "Valor (documento)", "Unidad"])
        for i, fila in enumerate(filas):
            for j, v in enumerate(fila):
                it = QTableWidgetItem(v)
                it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                t.setItem(i, j, it)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)

    def _llenar_ver(self):
        filas = est.verificar(self.actual)
        t = self.t_ver
        t.clear(); t.setColumnCount(4); t.setRowCount(len(filas))
        t.setHorizontalHeaderLabels(["Concepto", "Malla digitalizada", "Tabla del plano", "Resultado"])
        for i, f in enumerate(filas):
            res = "—" if f.coincide is None else ("✓ coincide" if f.coincide else "✗ difiere")
            if f.informativo and f.coincide is not None:
                res = "≈ (±5 %)" if f.coincide else "≠ informativo"
            for j, v in enumerate([f.concepto, "—" if f.digitalizado is None else f"{f.digitalizado:g}",
                                   "—" if f.documento is None else f"{f.documento:g}", res]):
                it = QTableWidgetItem(v)
                it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if f.coincide is False and not f.informativo:
                    it.setForeground(QBrush(QColor("#e5322d")))
                t.setItem(i, j, it)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)

    # ------------------------------------------------------------ acciones
    def _guardar(self):
        if not self.actual:
            return
        ruta = est.guardar_edicion(self.actual)
        QMessageBox.information(self, "Biblioteca", f"Edición guardada en:\n{ruta}\n\n"
                                "El estándar original no se modifica.")
        self._refrescar_item()

    def _restaurar(self):
        if not self.actual:
            return
        if QMessageBox.question(self, "Restaurar", "¿Descartar tus ediciones de este plano y volver "
                                "a la digitalización original?") != QMessageBox.StandardButton.Yes:
            return
        est.descartar_edicion(self.actual.pagina)
        nuevo = est.original(self.actual.pagina)
        self._colores_de(nuevo)
        i = self.planos.index(self.actual)
        self.planos[i] = nuevo
        self.actual = nuevo
        self._mostrar()
        self._refrescar_item()

    def _validar(self):
        if not self.actual:
            return
        ok, dif, rev = est.resumen_verificacion(self.actual)
        nombre, aceptar = QInputDialog.getText(
            self, "Validación profesional",
            f"Verificación: {ok} coinciden, {dif} difieren, {rev} taladros por revisar.\n"
            "Marca el plano como verificado en tu mina.\n"
            "Nota (por ejemplo, fecha o labor donde se probó):")
        if not aceptar or not nombre.strip():
            return
        self.actual.estado = est.ESTADO_VALIDADO
        self.actual.validado_por = nombre.strip()
        est.guardar_edicion(self.actual)
        self._mostrar()
        self._refrescar_item()

    def _refrescar_item(self):
        pag = self.actual.pagina if self.actual else None
        self._llenar_lista()
        for i in range(self.lista.count()):
            if self.lista.item(i).data(Qt.ItemDataRole.UserRole) == pag:
                self.lista.setCurrentRow(i)

    def _usar(self):
        if not self.actual or self.doc is None:
            return
        from app.core.documento import ErrorEdicion
        pl = self.actual
        dlg = DialogoUsarPlano(pl, self)
        if not dlg.exec():
            return
        try:
            self.descripcion = aplicar_plano_en_proyecto(self.doc, pl, dlg.d.value(), dlg.da.value(), dlg.x0.value(),
                                                         dlg.y0.value(), dlg.z0.value(), dlg.az.value(),
                                                         dlg.reemplazar.isChecked())
        except ErrorEdicion as error:
            QMessageBox.warning(self, "Usar plano", str(error))
            return
        self.accept()

    def _adaptar(self):
        """Abre la malla automática con este plano como base (otra sección, cuneta, edición)."""
        if not self.actual:
            return
        from app.ui.dialogo_malla_real import DialogoMallaReal
        dlg = DialogoMallaReal(self.doc, self, plantilla=self.actual.pagina)
        if dlg.exec() and dlg.descripcion:
            self.descripcion = dlg.descripcion
            self.accept()

    def done(self, r):
        self.vista3d.cerrar()
        super().done(r)
