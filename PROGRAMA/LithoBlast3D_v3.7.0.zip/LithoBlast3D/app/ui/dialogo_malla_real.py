"""
Malla automática con ARRANQUES y MALLAS REALES del estándar.

Escribe la sección, el tipo de roca y las medidas de los taladros: el programa toma el
plano real más parecido del estándar, copia su arranque y adapta la malla a tu sección
(con cuneta si la pides). La malla se puede editar a mano antes de usarla.
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout, QGroupBox, QHBoxLayout,
    QHeaderView, QLabel, QMessageBox, QPushButton, QSplitter, QTableWidget, QTableWidgetItem, QTabWidget,
    QVBoxLayout, QWidget,
)

from app.biblioteca import estandar as est
from app.biblioteca import generador as gen
from app.ui.dialogo_biblioteca import (DialogoUsarPlano, LienzoFrontal, LienzoProyeccion, Vista3DPlano,
                                       aplicar_plano_en_proyecto, colores_leyenda)
from app.ui.dialogos import CampoNumero
from app.ui.tema import COLORES, ajustar_a_pantalla, con_desplazamiento


class DialogoMallaReal(QDialog):
    COLS = ["X (m)", "Y (m)", "Tipo", "Detonador", "Cartuchos", "Explosivo", "Función", "Origen"]

    def __init__(self, documento, parent=None, plantilla: int | None = None):
        super().__init__(parent)
        self.doc = documento
        self.descripcion = ""
        self.resultado: gen.ResultadoMallaReal | None = None
        self._llenando = False
        self.setWindowTitle("Malla automática — arranques y mallas reales del estándar")
        ajustar_a_pantalla(self, 1450, 880)
        self.planos = est.cargar_biblioteca()
        self.catalogo = gen.catalogo_arranques(self.planos)

        raiz = QVBoxLayout(self)
        cab = QLabel("Escribe tu sección, el tipo de roca y las medidas de los taladros. El programa toma el plano "
                     "REAL más parecido del estándar MIN-SOS-ESO-001, copia su arranque con sus medidas reales y "
                     "adapta hastiales, corona, arrastres y ayudas a tu sección con los mismos espaciamientos. "
                     "")
        cab.setWordWrap(True)
        raiz.addWidget(cab)
        # botones principales ARRIBA (siempre visibles, aunque la pantalla sea pequeña)
        barra = QHBoxLayout()
        self.b_generar = QPushButton("⚙ Generar malla")
        self.b_usar = QPushButton("✔ Usar en el proyecto…")
        self.b_usar.setDefault(True)
        self.b_cerrar = QPushButton("Cerrar")
        barra.addWidget(self.b_generar); barra.addWidget(self.b_usar); barra.addStretch(1); barra.addWidget(self.b_cerrar)
        raiz.addLayout(barra)
        div = QSplitter(Qt.Orientation.Horizontal)
        raiz.addWidget(div, 1)

        # ------------------------------------------------ datos
        izq = QWidget(); li = QVBoxLayout(izq)
        g = QGroupBox("Sección"); f = QFormLayout(g)
        sec0 = self._seccion_inicial()
        self.ancho = CampoNumero(0.8, 8, 2, "m", sec0[0], "Ancho")
        self.alto = CampoNumero(1.2, 8, 2, "m", sec0[1], "Alto")
        f.addRow("Ancho", self.ancho); f.addRow("Alto", self.alto)
        li.addWidget(g)

        g = QGroupBox("Tipo de roca"); f = QFormLayout(g)
        self.modo_roca = QComboBox(); self.modo_roca.addItems(["Elegir calidad", "Escribir RMR"])
        self.roca = QComboBox(); self.roca.addItems(["Buena (RMR 61-80)", "Regular (RMR 41-60)", "Mala (RMR 21-40)"])
        self.roca.setCurrentIndex(1)
        self.rmr = CampoNumero(0, 100, 0, "", 50, "RMR")
        f.addRow("Cómo", self.modo_roca); f.addRow("Calidad", self.roca); f.addRow("RMR", self.rmr)
        nota = QLabel("Rangos de RMR tomados de los títulos de los planos del estándar.")
        nota.setObjectName("TextoSecundario"); nota.setWordWrap(True)
        f.addRow(nota)
        li.addWidget(g)

        g = QGroupBox("Taladros"); f = QFormLayout(g)
        self.d = CampoNumero(20, 120, 0, "mm", 38, "Ø de perforación")
        self.da = CampoNumero(20, 200, 0, "mm", 38, "Ø de alivios")
        self.lp = CampoNumero(2, 20, 1, "pies", 6, "Longitud de perforación")
        for c in (self.d, self.da, self.lp):
            f.addRow(c.nombre, c)
        li.addWidget(g)

        g = QGroupBox("Arranque y variante"); f = QFormLayout(g)
        self.arranque = QComboBox()
        self.arranque.addItem("Automático (el del plano más parecido)", "auto")
        for clave, t in self.catalogo.items():
            self.arranque.addItem(f"{t.nombre} — roca {', '.join(t.rocas)} ({len(t.paginas)} planos)", clave)
        self.variante = QComboBox()
        f.addRow("Arranque", self.arranque); f.addRow("Variante del plano", self.variante)
        self.info_arranque = QLabel(); self.info_arranque.setWordWrap(True)
        self.info_arranque.setObjectName("TextoSecundario")
        f.addRow(self.info_arranque)
        li.addWidget(g)

        g = QGroupBox("Cuneta"); f = QFormLayout(g)
        self.cuneta = QCheckBox("Poner cuneta"); self.cuneta.setChecked(True)
        self.lado = QComboBox(); self.lado.addItems(["izquierda", "derecha"])
        self.c_ancho = CampoNumero(0.15, 1.5, 2, "m", 0.35, "Ancho de cuneta")
        self.c_prof = CampoNumero(0.1, 1.0, 2, "m", 0.30, "Profundidad de cuneta")
        f.addRow(self.cuneta); f.addRow("Lado (mirando al frente)", self.lado)
        f.addRow(self.c_ancho.nombre, self.c_ancho); f.addRow(self.c_prof.nombre, self.c_prof)
        li.addWidget(g)

        li.addStretch(1)
        div.addWidget(con_desplazamiento(izq))

        # ------------------------------------------------ vista y edición
        centro = QWidget(); lc = QVBoxLayout(centro); lc.setContentsMargins(0, 0, 0, 0)
        self.titulo = QLabel(); self.titulo.setObjectName("TituloObjeto"); self.titulo.setWordWrap(True)
        lc.addWidget(self.titulo)
        self.tabs = QTabWidget()
        self.frontal = LienzoFrontal(); self.frontal.mostrar_imagen = False
        self.tabs.addTab(self.frontal, "Frontal (editar)")
        self.planta = LienzoProyeccion("planta"); self.tabs.addTab(self.planta, "Planta")
        self.lateral = LienzoProyeccion("lateral"); self.tabs.addTab(self.lateral, "Lateral")
        self.vista3d = Vista3DPlano(); self.tabs.addTab(self.vista3d, "3D")
        self.t_inf = QTableWidget(); self.tabs.addTab(self.t_inf, "Informe y comprobaciones")
        self.t_tab = QTableWidget(); self.tabs.addTab(self.t_tab, "Tabla de carga")
        lc.addWidget(self.tabs, 1)
        self.avisos = QLabel(); self.avisos.setWordWrap(True); self.avisos.setObjectName("Insignia")
        self.avisos.setVisible(False)
        lc.addWidget(self.avisos)
        div.addWidget(centro)

        der = QWidget(); ld = QVBoxLayout(der); ld.setContentsMargins(0, 0, 0, 0)
        ld.addWidget(QLabel("Taladros (doble clic para editar)"))
        self.t_tal = QTableWidget()
        self.t_tal.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        ld.addWidget(self.t_tal, 1)
        div.addWidget(der)
        div.setSizes([330, 760, 400])

        self.b_cerrar.clicked.connect(self.reject)

        self.b_generar.clicked.connect(self.generar)
        self.b_usar.clicked.connect(self._usar)
        self.modo_roca.currentIndexChanged.connect(self._modo_roca)
        self.roca.currentIndexChanged.connect(self._variantes)
        self.rmr.valueChanged.connect(self._variantes)
        self.arranque.currentIndexChanged.connect(self._info_arranque)
        self.cuneta.toggled.connect(self._cuneta)
        self.frontal.cambiado.connect(self._editado)
        self.frontal.seleccion.connect(lambda i: self.t_tal.selectRow(i) if i >= 0 else None)
        self.t_tal.itemChanged.connect(self._celda)
        self.tabs.currentChanged.connect(self._pestana)
        self._modo_roca()
        self._info_arranque()
        if plantilla is not None:
            p = next((x for x in self.planos if x.pagina == plantilla), None)
            if p is not None:
                self.roca.setCurrentIndex(est.ROCAS.index(p.roca))
                self._variantes()
                i = self.variante.findText(p.variante)
                if i >= 0:
                    self.variante.setCurrentIndex(i)
        self.generar()

    # ------------------------------------------------------------ entradas
    def _seccion_inicial(self):
        from app.core.modelo import Contorno
        cs = [o for o in self.doc.proyecto.objetos.values() if isinstance(o, Contorno)] if self.doc else []
        if cs:
            import math
            v = cs[0].vertices
            zs = [p[2] for p in v]
            xy = [(p[0], p[1]) for p in v]
            ancho = max(math.dist(a, b) for a in xy for b in xy)
            alto = max(zs) - min(zs)
            if 0.8 <= ancho <= 8 and 1.2 <= alto <= 8:
                return round(ancho, 2), round(alto, 2)
        return 2.5, 2.7

    def _roca(self) -> str:
        if self.modo_roca.currentIndex() == 1:
            return gen.roca_desde_rmr(self.rmr.value())
        return est.ROCAS[self.roca.currentIndex()]

    def _modo_roca(self, *_):
        rmr = self.modo_roca.currentIndex() == 1
        self.roca.setEnabled(not rmr)
        self.rmr.setEnabled(rmr)
        self._variantes()

    def _variantes(self, *_):
        actual = self.variante.currentText()
        self.variante.blockSignals(True)
        self.variante.clear()
        self.variante.addItem("Automática", "auto")
        for v in gen.variantes_disponibles(self.planos, self._roca()):
            self.variante.addItem(v, v)
        i = self.variante.findText(actual)
        self.variante.setCurrentIndex(max(i, 0))
        self.variante.blockSignals(False)

    def _info_arranque(self, *_):
        clave = self.arranque.currentData()
        if clave == "auto":
            self.info_arranque.setText("Se usa el arranque del plano del estándar más parecido a tu sección y roca.")
            return
        t = self.catalogo[clave]
        self.info_arranque.setText(f"{t.descripcion}\nMedidas del estándar: alivios a {t.sep_alivios:.3f} m del "
                                   f"centro; 1.er taladro cargado a {t.burden1:.3f} m. Planos: "
                                   + ", ".join(str(p) for p in t.paginas[:8]) + ("…" if len(t.paginas) > 8 else ""))

    def _cuneta(self, v):
        for w in (self.lado, self.c_ancho, self.c_prof):
            w.setEnabled(v)

    def entrada(self) -> gen.EntradaMallaReal:
        return gen.EntradaMallaReal(
            ancho=self.ancho.value(), alto=self.alto.value(), roca=self._roca(), diametro_mm=self.d.value(),
            diametro_alivio_mm=self.da.value(), longitud_pies=self.lp.value(), arranque=self.arranque.currentData(),
            variante=self.variante.currentData() or "auto", cuneta=self.cuneta.isChecked(),
            cuneta_lado=self.lado.currentText(), cuneta_ancho=self.c_ancho.value(),
            cuneta_profundidad=self.c_prof.value())

    # ------------------------------------------------------------ generar
    def generar(self, *_):
        try:
            r = gen.generar(self.entrada(), self.planos)
        except ValueError as error:
            QMessageBox.warning(self, "Malla automática", str(error))
            return
        r.plano._colores = colores_leyenda(r.plantilla.pagina)
        self.resultado = r
        pl = r.plano
        self.titulo.setText(pl.nombre)
        for lz in (self.frontal, self.planta, self.lateral):
            lz.set_plano(pl)
        self.frontal.mostrar_imagen = False
        self._llenar_taladros()
        self._llenar_informe()
        self._llenar_tabla()
        self.avisos.setText("\n".join(f"⚠ {a}" for a in r.avisos))
        self.avisos.setVisible(bool(r.avisos))
        if self.tabs.currentWidget() is self.vista3d:
            self.vista3d.mostrar(pl)

    def _pestana(self, *_):
        if self.tabs.currentWidget() is self.vista3d and self.resultado:
            self.vista3d.mostrar(self.resultado.plano)

    def _llenar_taladros(self):
        pl = self.resultado.plano
        self._llenando = True
        t = self.t_tal
        t.clear(); t.setColumnCount(len(self.COLS)); t.setHorizontalHeaderLabels(self.COLS)
        t.setRowCount(len(pl.taladros))
        fun = est.clasificar(pl)
        for i, ta in enumerate(pl.taladros):
            vals = [f"{ta.x:.3f}", f"{ta.y:.3f}", ta.tipo, "" if ta.detonador is None else str(ta.detonador),
                    str(ta.cartuchos), ta.explosivo or "", fun[i], ta.lectura]
            for j, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if j >= 6:
                    it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                t.setItem(i, j, it)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self._llenando = False

    def _celda(self, item):
        if self._llenando or not self.resultado:
            return
        ta = self.resultado.plano.taladros[item.row()]
        v = item.text().strip().replace(",", ".")
        j = item.column()
        try:
            if j == 0:
                ta.x = float(v)
            elif j == 1:
                ta.y = float(v)
            elif j == 2:
                if v not in ("cargado", "alivio"):
                    raise ValueError("Tipo: escribe cargado o alivio")
                ta.tipo = v
            elif j == 3:
                ta.detonador = int(float(v)) if v else None
            elif j == 4:
                ta.cartuchos = int(float(v or 0))
            elif j == 5:
                nombres = [f["nombre"] for f in self.resultado.plano.explosivos_tabla]
                if item.text().strip() not in nombres:
                    raise ValueError("Usa un explosivo de la tabla del plano:\n" + "\n".join(nombres))
                ta.explosivo = item.text().strip()
        except ValueError as error:
            QMessageBox.warning(self, "Editar taladro", str(error))
            self._llenar_taladros()
            return
        ta.lectura = "editado por el usuario"
        self._editado(recargar=False)

    def _editado(self, recargar=True):
        pl = self.resultado.plano
        # recalcular tablas del plano editado
        nuevo = gen._armar_plano(self.resultado.plantilla, self.entrada(), pl.taladros, pl.contorno)
        pl.explosivos_tabla, pl.cuenta_detonadores = nuevo.explosivos_tabla, nuevo.cuenta_detonadores
        pl.total_cargados = nuevo.total_cargados
        if recargar:
            self._llenar_taladros()
        self._llenar_tabla()
        for lz in (self.frontal, self.planta, self.lateral):
            lz.update()

    def _llenar_informe(self):
        filas = self.resultado.informe
        t = self.t_inf
        t.clear(); t.setColumnCount(4); t.setRowCount(len(filas))
        t.setHorizontalHeaderLabels(["Concepto", "Plano del estándar", "Malla generada", "Nota"])
        for i, f in enumerate(filas):
            for j, v in enumerate((f.concepto, f.plantilla, f.generado, f.nota)):
                it = QTableWidgetItem(v)
                it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if f.aviso:
                    it.setForeground(QBrush(QColor(COLORES["aviso"])))
                t.setItem(i, j, it)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)

    def _llenar_tabla(self):
        pl = self.resultado.plano
        filas = [("Explosivo", "Cartuchos", "Perforaciones", "kg")]
        for f in pl.explosivos_tabla:
            v = f["valores"]
            filas.append((f["nombre"], f"{v.get('Cart', 0):g}", f"{v.get('Perf', 0):g}", f"{v.get('Expl_Kg', 0):g}"))
        filas.append(("", "", "", ""))
        filas.append(("N.º de detonador", "Taladros", "", ""))
        for k, n in sorted(pl.cuenta_detonadores.items()):
            filas.append((str(k), str(n), "", ""))
        t = self.t_tab
        t.clear(); t.setColumnCount(4); t.setRowCount(len(filas) - 1)
        t.setHorizontalHeaderLabels(list(filas[0]))
        for i, fila in enumerate(filas[1:]):
            for j, v in enumerate(fila):
                it = QTableWidgetItem(v)
                it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                t.setItem(i, j, it)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)

    # ------------------------------------------------------------ usar
    def _usar(self):
        if not self.resultado or self.doc is None:
            return
        pl = self.resultado.plano
        dlg = DialogoUsarPlano(pl, self, self.d.value(), self.da.value())
        if not dlg.exec():
            return
        from app.core.documento import ErrorEdicion
        try:
            self.descripcion = aplicar_plano_en_proyecto(self.doc, pl, dlg.d.value(), dlg.da.value(), dlg.x0.value(),
                                                         dlg.y0.value(), dlg.z0.value(), dlg.az.value(),
                                                         dlg.reemplazar.isChecked(),
                                                         longitud_m=self.lp.value() * est.PIE)
        except ErrorEdicion as error:
            QMessageBox.warning(self, "Usar malla", str(error))
            return
        self.accept()

    def done(self, r):
        self.vista3d.cerrar()
        super().done(r)
