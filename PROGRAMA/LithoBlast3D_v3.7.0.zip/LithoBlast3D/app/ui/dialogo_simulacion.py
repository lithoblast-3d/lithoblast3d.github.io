"""
Simulación de la voladura: secuencia de salida animada.

- Asigna la secuencia automática (frente o banco) o usa la que ya tienen los taladros.
- Reproduce la voladura: cada taladro detona en su tiempo y se dibuja la roca que rompe.
- Muestra la carga por retardo y marca los taladros que salen sin una abertura cercana.
"""

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPainterPath, QPen, QPolygonF
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QSlider,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.documento import Documento
from app.core.secuencia import (
    Simulacion,
    preparar_simulacion,
    secuencia_banco,
    secuencia_frente,
)
from app.ui.dialogos import CampoNumero
from app.ui.tema import COLORES

COLOR = {
    "pendiente": "#4a5058",
    "detonando": "#ffe14d",
    "detonado": "#ff6a3d",
    "alivio": "#000000",
    "roca": "#ff6a3d",
    "aviso": "#e0b341",
}
# Milisegundos de voladura que avanzan por cada segundo de animación
VELOCIDADES = [("Muy lenta (50 ms/s)", 50), ("Lenta (150 ms/s)", 150), ("Normal (400 ms/s)", 400),
               ("Rápida (1000 ms/s)", 1000)]


class LienzoVoladura(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(480, 420)
        self.sim: Simulacion | None = None
        self.t = 0.0
        self.mostrar_numeros = True
        self.mensaje = ""

    def paintEvent(self, _evento):  # noqa: N802 (nombre exigido por Qt)
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor(COLORES["visor_fondo_abajo"]))
        sim = self.sim
        if sim is None or not sim.pozos:
            p.setPen(QColor(COLORES["texto_secundario"]))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self.mensaje or "Sin taladros")
            p.end()
            return
        puntos = [(q.x, q.y) for q in sim.pozos] + [v for c in sim.contornos for v in c]
        umin, umax = min(u for u, _ in puntos), max(u for u, _ in puntos)
        vmin, vmax = min(v for _, v in puntos), max(v for _, v in puntos)
        margen_mundo = 0.08 * max(umax - umin, vmax - vmin, 1e-3)
        umin, umax, vmin, vmax = umin - margen_mundo, umax + margen_mundo, vmin - margen_mundo, vmax + margen_mundo
        area = QRectF(20, 40, self.width() - 40, self.height() - 70)
        escala = min(area.width() / (umax - umin), area.height() / (vmax - vmin))
        cu = area.left() + (area.width() - (umax - umin) * escala) / 2
        cv = area.top() + (area.height() + (vmax - vmin) * escala) / 2

        def pt(u, v):
            return QPointF(cu + (u - umin) * escala, cv - (v - vmin) * escala)

        estados = sim.estado(self.t)
        # Roca rota: disco del tamaño del burden efectivo de cada taladro detonado
        roca = QColor(COLOR["roca"])
        roca.setAlpha(55)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(roca)
        if sim.contornos:  # la roca rota no puede salir de la sección excavada
            recorte = QPainterPath()
            recorte.addPolygon(QPolygonF([pt(*v) for v in sim.contornos[0]]))
            p.setClipPath(recorte)
        for q, estado in estados:
            if estado in ("detonado", "detonando") and q.burden_efectivo:
                radio = q.burden_efectivo * escala
                p.drawEllipse(pt(q.x, q.y), radio, radio)
        p.setClipping(False)
        # Contorno de la sección
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QColor(COLORES["acento_azul"]), 2))
        for c in sim.contornos:
            pts = [pt(*v) for v in c] + [pt(*c[0])]
            for a, b in zip(pts, pts[1:]):
                p.drawLine(a, b)
        # Taladros
        radio_px = max(4.0, min(9.0, 0.035 * escala))
        p.setFont(QFont("Segoe UI", 8))
        for q, estado in estados:
            centro = pt(q.x, q.y)
            if estado == "detonando":
                p.setPen(QPen(QColor(COLOR["detonando"]), 2))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(centro, radio_px * 2.6, radio_px * 2.6)
            p.setPen(QPen(QColor(COLOR["aviso"]), 2) if q.sin_cara_libre
                     else QPen(QColor("#111111"), 0.8))
            p.setBrush(QBrush(QColor(COLOR[estado])))
            p.drawEllipse(centro, radio_px * (1.4 if q.alivio else 1.0), radio_px * (1.4 if q.alivio else 1.0))
            if self.mostrar_numeros and not q.alivio and q.retardo:
                p.setPen(QColor(COLOR["aviso"] if q.sin_cara_libre else "#ff8fa3"))
                p.drawText(centro + QPointF(radio_px + 2, -radio_px), str(q.retardo))
        # Encabezado
        p.setPen(QColor(COLORES["texto"]))
        p.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        detonados = sum(1 for _q, e in estados if e in ("detonado", "detonando"))
        kg = sum(q.carga_kg for q, e in estados if e in ("detonado", "detonando"))
        total = sum(1 for q in sim.pozos if not q.alivio)
        p.drawText(QPointF(20, 26), f"t = {self.t:,.0f} ms   ·   {detonados}/{total} taladros   ·   "
                                    f"{kg:,.1f} kg")
        p.end()


class DialogoSimulacion(QDialog):
    def __init__(self, documento: Documento, parent=None):
        super().__init__(parent)
        self.doc = documento
        self.setWindowTitle("Simulación de la voladura")
        from app.ui.tema import ajustar_a_pantalla
        ajustar_a_pantalla(self, 1250, 760)
        self.es_frente = documento.proyecto.diseno.escenario == "subterraneo"

        # ---------------- secuencia
        panel = QWidget()
        f = QFormLayout(panel)
        f.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        titulo = QLabel("<b>Secuencia de salida</b>")
        f.addRow(titulo)
        nota = QLabel("Escribe los tiempos NOMINALES de tus detonadores (catálogo del fabricante).")
        nota.setObjectName("TextoSecundario")
        nota.setWordWrap(True)
        f.addRow(nota)
        if self.es_frente:
            self.intervalo = CampoNumero(1, 10000, 0, "ms", 100, "Tiempo entre números de retardo")
            f.addRow("Tiempo entre retardos:", self.intervalo)
            orden = QLabel("Orden: arranque (cuadro por cuadro) → ayudas hacia afuera → "
                           "hastiales → corona → arrastres.")
        else:
            self.entre_taladros = CampoNumero(0, 2000, 0, "ms", 25, "Retardo entre taladros")
            self.entre_filas = CampoNumero(0, 5000, 0, "ms", 50, "Retardo entre filas")
            self.patron = QComboBox()
            self.patron.addItem("En línea (desde un extremo)", False)
            self.patron.addItem("En V (desde el centro)", True)
            self.invertir = QCheckBox("La cara libre está del otro lado")
            f.addRow("Entre taladros:", self.entre_taladros)
            f.addRow("Entre filas:", self.entre_filas)
            f.addRow("Patrón:", self.patron)
            f.addRow(self.invertir)
            orden = QLabel("Orden: fila por fila desde la cara libre.")
        orden.setObjectName("TextoSecundario")
        orden.setWordWrap(True)
        f.addRow(orden)
        self.boton_asignar = QPushButton("Asignar secuencia automática")
        self.boton_asignar.clicked.connect(self._asignar)
        f.addRow(self.boton_asignar)
        self.numeros = QCheckBox("Mostrar números de retardo")
        self.numeros.setChecked(True)
        self.numeros.toggled.connect(self._mostrar_numeros)
        f.addRow(self.numeros)
        self.avisos = QLabel()
        self.avisos.setObjectName("Insignia")
        self.avisos.setWordWrap(True)
        f.addRow(self.avisos)
        leyenda = QLabel(
            "<span style='color:#9aa3ad'>● pendiente</span>  "
            "<span style='color:#ffe14d'>● detonando</span>  "
            "<span style='color:#ff6a3d'>● detonado</span>  "
            "<span style='color:#e0b341'>◯ sin abertura cercana</span><br>"
            "<span style='color:#9aa3ad'>Zona sombreada: roca que rompe cada taladro hasta la "
            "abertura más cercana (burden efectivo).</span>")
        leyenda.setWordWrap(True)
        f.addRow(leyenda)

        # ---------------- tabla de retardos
        self.tabla = QTableWidget(0, 4)
        self.tabla.setHorizontalHeaderLabels(["N°", "Tiempo\n(ms)", "Taladros", "Carga\n(kg)"])
        self.tabla.verticalHeader().setVisible(False)
        self.tabla.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tabla.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tabla.cellClicked.connect(self._ir_a_retardo)
        izquierda = QWidget()
        iz = QVBoxLayout(izquierda)
        iz.addWidget(panel)
        iz.addWidget(QLabel("<b>Carga por retardo</b> (clic para ir a ese instante)"))
        iz.addWidget(self.tabla, 1)

        # ---------------- lienzo y controles
        self.lienzo = LienzoVoladura()
        self.boton_play = QPushButton("▶ Reproducir")
        self.boton_play.clicked.connect(self._alternar)
        self.reiniciar = QPushButton("⟲ Inicio")
        self.reiniciar.clicked.connect(lambda: self._ir_a(-1))
        self.barra = QSlider(Qt.Orientation.Horizontal)
        self.barra.setRange(0, 1000)
        self.barra.valueChanged.connect(self._desde_barra)
        self.velocidad = QComboBox()
        for texto, valor in VELOCIDADES:
            self.velocidad.addItem(texto, valor)
        self.velocidad.setCurrentIndex(1)
        exportar = QPushButton("Guardar imagen…")
        exportar.clicked.connect(self._exportar)
        controles = QHBoxLayout()
        for w in (self.reiniciar, self.boton_play):
            controles.addWidget(w)
        controles.addWidget(self.barra, 1)
        controles.addWidget(QLabel("Velocidad:"))
        controles.addWidget(self.velocidad)
        controles.addWidget(exportar)
        derecha = QWidget()
        de = QVBoxLayout(derecha)
        de.setContentsMargins(0, 0, 0, 0)
        de.addWidget(self.lienzo, 1)
        de.addLayout(controles)

        division = QSplitter(Qt.Orientation.Horizontal)
        division.addWidget(izquierda)
        division.addWidget(derecha)
        division.setSizes([380, 870])
        principal = QVBoxLayout(self)
        principal.addWidget(division)

        self.reloj = QTimer(self)
        self.reloj.setInterval(33)
        self.reloj.timeout.connect(self._avanzar)
        self._actualizar_simulacion()
        if self.sim.sin_tiempo and not self.sim.retardos:
            # Ningún taladro tiene secuencia: se asigna la automática (Ctrl+Z la deshace)
            self._asignar(automatica=True)
        self._ir_a(-1)

    # ------------------------------------------------------------------ secuencia
    def _asignar(self, automatica: bool = False) -> None:
        proyecto = self.doc.proyecto
        try:
            if self.es_frente:
                valores = secuencia_frente(proyecto, self.intervalo.value())
            else:
                valores = secuencia_banco(proyecto, self.entre_taladros.value(), self.entre_filas.value(),
                                          en_v=bool(self.patron.currentData()),
                                          invertir_cara=self.invertir.isChecked())
        except Exception as error:  # datos del formulario no válidos
            self.avisos.setText(f"⚠ {error}")
            return
        self.doc.asignar_secuencia(valores)
        self._actualizar_simulacion()
        if automatica and self.sim.retardos:
            self.avisos.setText("Se asignó la secuencia automática (puedes cambiar los tiempos y "
                                "volver a asignarla).\n" + self.avisos.text())
            self.avisos.setVisible(True)
        self._ir_a(-1)

    def _actualizar_simulacion(self) -> None:
        self.sim = preparar_simulacion(self.doc.proyecto)
        self.lienzo.sim = self.sim
        self.avisos.setText("\n".join(f"⚠ {a}" if not a.startswith("Carga máxima") else a
                                      for a in self.sim.avisos))
        self.avisos.setVisible(bool(self.sim.avisos))
        self.tabla.setRowCount(len(self.sim.retardos))
        kg_max = max((r[3] for r in self.sim.retardos), default=0)
        for fila, (n, t, cantidad, kg) in enumerate(self.sim.retardos):
            for col, texto in enumerate((str(n), f"{t:,.0f}", str(cantidad), f"{kg:,.1f}")):
                item = QTableWidgetItem(texto)
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                if kg == kg_max and kg_max > 0:
                    item.setForeground(QColor(COLOR["aviso"]))
                self.tabla.setItem(fila, col, item)
        self.boton_play.setEnabled(any(not q.alivio for q in self.sim.pozos))

    # ------------------------------------------------------------------ reproducción
    def _fin(self) -> float:
        return self.sim.duracion * 1.08 + 100

    def _ir_a(self, t: float) -> None:
        self.lienzo.t = t
        self.barra.blockSignals(True)
        self.barra.setValue(int(max(t, 0) / self._fin() * 1000))
        self.barra.blockSignals(False)
        self.lienzo.update()

    def _desde_barra(self, valor: int) -> None:
        self.lienzo.t = valor / 1000 * self._fin()
        self.lienzo.update()

    def _ir_a_retardo(self, fila: int, _col: int) -> None:
        if 0 <= fila < len(self.sim.retardos):
            self.reloj.stop()
            self.boton_play.setText("▶ Reproducir")
            self._ir_a(self.sim.retardos[fila][1] + 1)

    def _alternar(self) -> None:
        if self.reloj.isActive():
            self.reloj.stop()
            self.boton_play.setText("▶ Reproducir")
            return
        if not self.sim.retardos:  # sin secuencia: asignarla antes de reproducir
            self._asignar(automatica=True)
            if not self.sim.retardos:
                return
        if self.lienzo.t >= self._fin():
            self._ir_a(-1)
        self.reloj.start()
        self.boton_play.setText("⏸ Pausa")

    def _avanzar(self) -> None:
        paso = self.velocidad.currentData() * self.reloj.interval() / 1000
        nuevo = self.lienzo.t + paso
        if nuevo >= self._fin():
            nuevo = self._fin()
            self.reloj.stop()
            self.boton_play.setText("▶ Reproducir")
        self._ir_a(nuevo)

    def _mostrar_numeros(self, visible: bool) -> None:
        self.lienzo.mostrar_numeros = visible
        self.lienzo.update()

    def _exportar(self) -> None:
        ruta, _ = QFileDialog.getSaveFileName(self, "Guardar imagen", "simulacion_voladura.png",
                                              "Imagen PNG (*.png)")
        if ruta:
            self.lienzo.grab().save(ruta)

    def closeEvent(self, evento) -> None:  # noqa: N802
        self.reloj.stop()
        super().closeEvent(evento)

