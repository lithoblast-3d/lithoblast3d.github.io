"""Ventanas de diálogo: nuevo proyecto, parámetros de voladura y explosivos."""

import copy

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.documento import ErrorEdicion
from app.core.modelo import (
    ESCENARIO_SUBTERRANEO,
    ESCENARIO_TAJO,
    NOMBRES_ESCENARIO,
    NOMBRES_TIPO_EXPLOSIVO,
    TIPO_ENCARTUCHADO,
    TIPO_GRANEL,
    DisenoVoladura,
    Explosivo,
)


class CampoNumero(QWidget):
    """Cuadro de texto para un número, con su unidad a la derecha.
    Acepta coma o punto decimal. El rango se comprueba al aceptar el diálogo."""

    def __init__(self, minimo: float, maximo: float, decimales: int, unidad: str,
                 valor: float, nombre: str = "", parent=None):
        super().__init__(parent)
        self._min, self._max, self._dec = minimo, maximo, decimales
        self._unidad = unidad
        self.nombre = nombre
        self.edit = QLineEdit()
        self.edit.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.edit.setMinimumWidth(110)
        self.unidad = QLabel(unidad)
        self.unidad.setObjectName("TextoSecundario")
        self.unidad.setMinimumWidth(38)
        fila = QHBoxLayout(self)
        fila.setContentsMargins(0, 0, 0, 0)
        fila.setSpacing(6)
        fila.addWidget(self.edit, 1)
        fila.addWidget(self.unidad)
        self.valueChanged = self.edit.textEdited
        self.setValue(valor)

    def setValue(self, valor: float) -> None:
        self.edit.setText(f"{valor:.{self._dec}f}")

    def value(self) -> float:
        texto = self.edit.text().strip().replace(" ", "").replace(",", ".")
        try:
            return float(texto)
        except ValueError:
            raise ErrorEdicion(f"{self.nombre or 'Campo'}: «{self.edit.text()}» no es un número") from None

    def error(self) -> str | None:
        """Mensaje de error si el valor no es válido; None si está bien."""
        try:
            v = self.value()
        except ErrorEdicion as e:
            return str(e)
        if not self._min <= v <= self._max:
            return f"{self.nombre or 'Campo'}: debe estar entre {self._min:g} y {self._max:g} {self._unidad}"
        return None


def _campo(minimo: float, maximo: float, decimales: int, unidad: str, valor: float,
           nombre: str = "") -> CampoNumero:
    return CampoNumero(minimo, maximo, decimales, unidad, valor, nombre)


class FormularioDiseno(QWidget):
    """Campos de diseño de voladura; muestra solo los que aplican al escenario."""

    def __init__(self, diseno: DisenoVoladura, area_contorno: float | None = None, parent=None):
        super().__init__(parent)
        self._area_contorno = area_contorno
        self.escenario = QComboBox()
        for clave in (ESCENARIO_TAJO, ESCENARIO_SUBTERRANEO):
            self.escenario.addItem(NOMBRES_ESCENARIO[clave], clave)
        self.escenario.setCurrentIndex(0 if diseno.escenario == ESCENARIO_TAJO else 1)

        self.densidad_roca = _campo(0.5, 6.0, 2, "t/m³", diseno.densidad_roca, "Densidad de la roca")
        self.burden = _campo(0.1, 50, 2, "m", diseno.burden, "Burden")
        self.espaciamiento = _campo(0.1, 50, 2, "m", diseno.espaciamiento, "Espaciamiento")
        self.altura_banco = _campo(0.5, 100, 2, "m", diseno.altura_banco, "Altura de banco")
        self.area_seccion = _campo(0.5, 500, 2, "m²", diseno.area_seccion, "Área de la sección")
        self.avance = _campo(0.1, 20, 2, "m", diseno.avance, "Avance")
        self.boton_area = QPushButton("Usar área del contorno dibujado")
        self.boton_area.setVisible(area_contorno is not None)
        if area_contorno is not None:
            self.boton_area.clicked.connect(lambda: self.area_seccion.setValue(area_contorno))

        self.formulario = QFormLayout(self)
        self.formulario.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.formulario.addRow("Escenario:", self.escenario)
        self.formulario.addRow("Densidad de la roca:", self.densidad_roca)
        self._filas_tajo = [("Burden:", self.burden), ("Espaciamiento:", self.espaciamiento),
                            ("Altura de banco:", self.altura_banco)]
        self._filas_sub = [("Área de la sección:", self.area_seccion), ("", self.boton_area),
                           ("Avance por disparo:", self.avance)]
        for etiqueta, campo in self._filas_tajo + self._filas_sub:
            self.formulario.addRow(etiqueta, campo)
        self.escenario.currentIndexChanged.connect(self._mostrar_campos)
        self._mostrar_campos()

    def _mostrar_campos(self) -> None:
        tajo = self.escenario.currentData() == ESCENARIO_TAJO
        for _e, campo in self._filas_tajo:
            self.formulario.setRowVisible(campo, tajo)
        for _e, campo in self._filas_sub:
            visible = not tajo and (campo is not self.boton_area or self._area_contorno is not None)
            self.formulario.setRowVisible(campo, visible)

    def errores(self) -> list[str]:
        """Errores de los campos visibles del escenario elegido."""
        tajo = self.escenario.currentData() == ESCENARIO_TAJO
        campos = [self.densidad_roca] + ([self.burden, self.espaciamiento, self.altura_banco]
                                         if tajo else [self.area_seccion, self.avance])
        return [e for e in (c.error() for c in campos) if e]

    def valor(self) -> DisenoVoladura:
        return DisenoVoladura(
            escenario=self.escenario.currentData(),
            densidad_roca=self.densidad_roca.value(),
            burden=self.burden.value(),
            espaciamiento=self.espaciamiento.value(),
            altura_banco=self.altura_banco.value(),
            area_seccion=self.area_seccion.value(),
            avance=self.avance.value(),
        )


class DialogoDiseno(QDialog):
    def __init__(self, diseno: DisenoVoladura, area_contorno: float | None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Parámetros de voladura")
        self.formulario = FormularioDiseno(diseno, area_contorno)
        nota = QLabel("Estos valores se usan para el volumen, el tonelaje y los factores "
                      "de carga y de potencia.")
        nota.setObjectName("TextoSecundario")
        nota.setWordWrap(True)
        botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                                   | QDialogButtonBox.StandardButton.Cancel)
        botones.button(QDialogButtonBox.StandardButton.Ok).setText("Aplicar")
        botones.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        botones.accepted.connect(self._aceptar)
        botones.rejected.connect(self.reject)
        diseno = QVBoxLayout(self)
        diseno.addWidget(nota)
        diseno.addWidget(self.formulario)
        diseno.addWidget(botones)

    def _aceptar(self) -> None:
        errores = self.formulario.errores()
        if errores:
            QMessageBox.warning(self, "Parámetros de voladura", "\n".join(errores))
            return
        self.accept()


class DialogoNuevoProyecto(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Nuevo proyecto")
        self.setMinimumWidth(420)
        self.nombre = QLineEdit("Mi voladura")
        self.formulario = FormularioDiseno(DisenoVoladura())
        nota = QLabel("Se crea un proyecto vacío. Luego agrega taladros en la tabla o impórtalos "
                      "desde un archivo CSV (Archivo → Importar taladros CSV).")
        nota.setObjectName("TextoSecundario")
        nota.setWordWrap(True)
        botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                                   | QDialogButtonBox.StandardButton.Cancel)
        botones.button(QDialogButtonBox.StandardButton.Ok).setText("Crear")
        botones.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        botones.accepted.connect(self._aceptar)
        botones.rejected.connect(self.reject)
        fila = QFormLayout()
        fila.addRow("Nombre del proyecto:", self.nombre)
        diseno = QVBoxLayout(self)
        diseno.addLayout(fila)
        diseno.addWidget(self.formulario)
        diseno.addWidget(nota)
        diseno.addWidget(botones)

    def _aceptar(self) -> None:
        if not self.nombre.text().strip():
            QMessageBox.warning(self, "Nuevo proyecto", "Escribe un nombre para el proyecto.")
            return
        errores = self.formulario.errores()
        if errores:
            QMessageBox.warning(self, "Nuevo proyecto", "\n".join(errores))
            return
        self.accept()


class DialogoExplosivos(QDialog):
    """Tabla para registrar los explosivos con los datos de su ficha técnica."""

    COLS = ["Nombre", "Tipo", "Densidad\n(g/cm³)", "Ø cartucho\n(mm)", "RWS / PRP\n(ANFO = 1)",
            "AWS\n(Dynamex M = 1)", "VOD\n(m/s)", "Origen del dato"]

    def __init__(self, explosivos: list[Explosivo], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Explosivos")
        self.resize(760, 380)
        self._explosivos = copy.deepcopy(explosivos)

        nota = QLabel("Registra los explosivos con los datos de la ficha técnica del fabricante. "
                      "Los valores marcados «⚠ Genérico» son solo referenciales. "
                      "El Ø de cartucho se usa solo en explosivos encartuchados. "
                      "RWS = potencia relativa en peso respecto al ANFO; AWS = potencia absoluta en peso "
                      "(Dynamex M = 1). Ambas las usa la malla automática.")
        nota.setWordWrap(True)
        nota.setObjectName("TextoSecundario")

        self.tabla = QTableWidget(0, len(self.COLS))
        self.tabla.setHorizontalHeaderLabels(self.COLS)
        self.tabla.verticalHeader().setVisible(False)
        self.tabla.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabla.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for k in range(1, len(self.COLS)):
            self.tabla.horizontalHeader().setSectionResizeMode(k, QHeaderView.ResizeMode.ResizeToContents)

        agregar = QPushButton("+ Agregar explosivo")
        catalogo = QPushButton("+ Desde ficha técnica (Emulnor FAMESA)…")
        quitar = QPushButton("Quitar seleccionado")
        agregar.clicked.connect(self._agregar)
        catalogo.clicked.connect(self._desde_catalogo)
        quitar.clicked.connect(self._quitar)
        fila_botones = QHBoxLayout()
        fila_botones.addWidget(agregar)
        fila_botones.addWidget(catalogo)
        fila_botones.addWidget(quitar)
        fila_botones.addStretch(1)

        botones = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                                   | QDialogButtonBox.StandardButton.Cancel)
        botones.button(QDialogButtonBox.StandardButton.Ok).setText("Guardar cambios")
        botones.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        botones.accepted.connect(self._aceptar)
        botones.rejected.connect(self.reject)

        diseno = QVBoxLayout(self)
        diseno.addWidget(nota)
        diseno.addWidget(self.tabla, 1)
        diseno.addLayout(fila_botones)
        diseno.addWidget(botones)
        for e in self._explosivos:
            self._fila(e)

    def _fila(self, e: Explosivo) -> None:
        fila = self.tabla.rowCount()
        self.tabla.insertRow(fila)
        nombre = QTableWidgetItem(e.nombre)
        nombre.setData(Qt.ItemDataRole.UserRole, e.id)
        nombre.setData(Qt.ItemDataRole.UserRole + 1, e.kg_cartucho)
        nombre.setData(Qt.ItemDataRole.UserRole + 2, e.fuente)
        self.tabla.setItem(fila, 0, nombre)
        tipo = QComboBox()
        for clave in (TIPO_GRANEL, TIPO_ENCARTUCHADO):
            tipo.addItem(NOMBRES_TIPO_EXPLOSIVO[clave], clave)
        tipo.setCurrentIndex(0 if e.tipo == TIPO_GRANEL else 1)
        self.tabla.setCellWidget(fila, 1, tipo)
        self.tabla.setCellWidget(fila, 2, _campo(0.01, 3.0, 3, "g/cm³", e.densidad_gcc, "Densidad"))
        self.tabla.setCellWidget(fila, 3, _campo(0.0, 500, 1, "mm", e.diametro_cartucho_mm, "Ø cartucho"))
        self.tabla.setCellWidget(fila, 4, _campo(0.1, 3.0, 2, "", e.prp, "RWS"))
        self.tabla.setCellWidget(fila, 5, _campo(0.1, 3.0, 2, "", e.aws, "AWS"))
        self.tabla.setCellWidget(fila, 6, _campo(0, 10000, 0, "", e.vod_ms, "VOD"))
        origen = QTableWidgetItem("⚠ Genérico" if e.referencial else (e.fuente or "Usuario"))
        if e.fuente:
            origen.setToolTip(e.fuente + (f" · {e.kg_cartucho:.4f} kg/cartucho" if e.kg_cartucho else ""))
        origen.setFlags(Qt.ItemFlag.ItemIsEnabled)
        origen.setData(Qt.ItemDataRole.UserRole, e.referencial)
        self.tabla.setItem(fila, 7, origen)
        # Si el usuario cambia un dato, deja de ser genérico
        for w in (tipo, self.tabla.cellWidget(fila, 2), self.tabla.cellWidget(fila, 3),
                  self.tabla.cellWidget(fila, 4), self.tabla.cellWidget(fila, 5),
                  self.tabla.cellWidget(fila, 6)):
            senal = w.currentIndexChanged if isinstance(w, QComboBox) else w.valueChanged
            senal.connect(lambda *_a, it=origen: self._marcar_usuario(it))

    def _marcar_usuario(self, item: QTableWidgetItem) -> None:
        item.setText("Usuario")
        item.setData(Qt.ItemDataRole.UserRole, False)
        fila = item.row()
        if fila >= 0 and self.tabla.item(fila, 0) is not None:  # datos cambiados: ya no es la ficha
            self.tabla.item(fila, 0).setData(Qt.ItemDataRole.UserRole + 1, 0.0)
            self.tabla.item(fila, 0).setData(Qt.ItemDataRole.UserRole + 2, "")

    def _desde_catalogo(self) -> None:
        from app.biblioteca import productos as prod
        dlg = QDialog(self)
        dlg.setWindowTitle("Explosivo desde la ficha técnica")
        prod_c, pres_c = QComboBox(), QComboBox()
        prod_c.addItems(list(prod.productos()))
        info = QLabel()
        info.setWordWrap(True)
        info.setObjectName("TextoSecundario")

        def llenar(*_):
            pres_c.clear()
            for p in prod.presentaciones(prod_c.currentText()):
                pres_c.addItem(f'{p["diametro_texto"]} x {p["largo_pulg"]:g}"  ·  {p["kg_cartucho"]:.3f} kg/cart. '
                               f'({p["piezas_caja"]} por caja de {p["kg_caja"]:g} kg)', (p["diametro_pulg"], p["largo_pulg"]))
            d = prod.productos()[prod_c.currentText()]
            info.setText(f"{d['uso']}. Densidad {d['densidad']} g/cm³ · VOD {d['vod_conf']} m/s confinada / "
                         f"{d['vod_libre']} m/s sin confinar · presión de detonación {d['presion_kbar']} kbar · "
                         f"energía {d['energia_kcal']} kcal/kg · RWS {d['rws']} % · RBS {d['rbs']} % (ANFO = 100).\n"
                         f"Fuente: {prod.datos()['fuente']}")
        prod_c.currentIndexChanged.connect(llenar)
        llenar()
        f = QFormLayout()
        f.addRow("Producto", prod_c)
        f.addRow("Presentación", pres_c)
        v = QVBoxLayout(dlg)
        v.addLayout(f)
        v.addWidget(info)
        b = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        b.accepted.connect(dlg.accept)
        b.rejected.connect(dlg.reject)
        v.addWidget(b)
        if not dlg.exec() or pres_c.currentData() is None:
            return
        usados = {self.tabla.item(r, 0).data(Qt.ItemDataRole.UserRole) for r in range(self.tabla.rowCount())}
        n = 1
        while f"EXP-{n:02d}" in usados:
            n += 1
        dp, lp = pres_c.currentData()
        self._fila(prod.explosivo_de(prod_c.currentText(), dp, lp, f"EXP-{n:02d}"))

    def _agregar(self) -> None:
        usados = {self.tabla.item(f, 0).data(Qt.ItemDataRole.UserRole) for f in range(self.tabla.rowCount())}
        n = 1
        while f"EXP-{n:02d}" in usados:
            n += 1
        self._fila(Explosivo(id=f"EXP-{n:02d}", nombre="Nuevo explosivo", densidad_gcc=1.0))
        self.tabla.editItem(self.tabla.item(self.tabla.rowCount() - 1, 0))

    def _quitar(self) -> None:
        fila = self.tabla.currentRow()
        if fila >= 0:
            self.tabla.removeRow(fila)

    def explosivos(self) -> list[Explosivo]:
        lista = []
        for f in range(self.tabla.rowCount()):
            nombre = self.tabla.item(f, 0)
            origen = self.tabla.item(f, 7)
            lista.append(Explosivo(
                id=nombre.data(Qt.ItemDataRole.UserRole),
                nombre=nombre.text().strip(),
                tipo=self.tabla.cellWidget(f, 1).currentData(),
                densidad_gcc=self.tabla.cellWidget(f, 2).value(),
                diametro_cartucho_mm=self.tabla.cellWidget(f, 3).value(),
                prp=self.tabla.cellWidget(f, 4).value(),
                aws=self.tabla.cellWidget(f, 5).value(),
                vod_ms=self.tabla.cellWidget(f, 6).value(),
                referencial=bool(origen.data(Qt.ItemDataRole.UserRole)) and origen.text() != "Usuario",
                kg_cartucho=float(nombre.data(Qt.ItemDataRole.UserRole + 1) or 0.0),
                fuente=str(nombre.data(Qt.ItemDataRole.UserRole + 2) or ""),
            ))
        return lista

    def _aceptar(self) -> None:
        for f in range(self.tabla.rowCount()):
            for col in (2, 3, 4, 5, 6):
                error = self.tabla.cellWidget(f, col).error()
                if error:
                    nombre = self.tabla.item(f, 0).text()
                    QMessageBox.warning(self, "Explosivos", f"{nombre} → {error}")
                    return
        for e in self.explosivos():
            if e.tipo == TIPO_ENCARTUCHADO and e.diametro_cartucho_mm <= 0:
                QMessageBox.warning(self, "Explosivos",
                                    f"«{e.nombre}» es encartuchado: indica el diámetro del cartucho.")
                return
            if not e.nombre:
                QMessageBox.warning(self, "Explosivos", "Todos los explosivos necesitan un nombre.")
                return
        self.accept()


__all__ = ["DialogoDiseno", "DialogoExplosivos", "DialogoNuevoProyecto", "ErrorEdicion"]
