"""Tema visual oscuro (gris carbón con acentos turquesa y azul)."""

from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import QApplication

COLORES = {
    "fondo": "#14171b",
    "panel": "#1b1f24",
    "panel_alto": "#242a31",
    "borde": "#2f363e",
    "texto": "#e8ebef",
    "texto_secundario": "#8f99a5",
    "acento": "#2ec4b6",  # turquesa
    "acento_oscuro": "#1a6e67",
    "acento_azul": "#3d8fe0",
    "aviso": "#e6b84a",  # amarillo = advertencia (siempre con símbolo ⚠)
    "error": "#e5534b",
    "visor_fondo_abajo": "#111418",
    "visor_fondo_arriba": "#262d35",
}

_HOJA_ESTILO = """
* { font-family: "Segoe UI", "Inter", "Roboto", sans-serif; font-size: 10pt; }
QWidget { color: @texto; }
QMainWindow, QDialog { background: @fondo; }
QMainWindow::separator { background: @fondo; width: 4px; height: 4px; }
QMainWindow::separator:hover { background: @acento; }
QSplitter::handle { background: @fondo; }
QSplitter::handle:hover { background: @acento_oscuro; }

QMenuBar { background: @panel; border-bottom: 1px solid @borde; padding: 3px 6px; }
QMenuBar::item { padding: 6px 12px; border-radius: 6px; background: transparent; }
QMenuBar::item:selected { background: @panel_alto; color: #ffffff; }
QMenu { background: @panel; border: 1px solid @borde; border-radius: 8px; padding: 6px; }
QMenu::item { padding: 7px 30px 7px 22px; border-radius: 6px; }
QMenu::item:selected { background: @acento_oscuro; color: #ffffff; }
QMenu::separator { height: 1px; background: @borde; margin: 5px 10px; }

QToolBar { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #1d2228, stop:1 @panel);
           border: none; border-bottom: 1px solid @borde; spacing: 2px; padding: 6px 10px; }
QToolBar::separator { background: @borde; width: 1px; margin: 8px 8px; }
QToolButton { background: transparent; border: 1px solid transparent; border-radius: 10px;
              padding: 5px 8px; color: @texto; font-size: 8.5pt; }
QToolButton:hover { background: @panel_alto; border-color: #3a434d; }
QToolButton:pressed, QToolButton:checked { background: @acento_oscuro; border-color: @acento; }
QToolBar#barra_vistas QToolButton { font-size: 9pt; padding: 5px 12px; }

QDockWidget { color: @texto_secundario; font-weight: 600; }
QDockWidget::title { background: @panel; padding: 10px 14px; border-bottom: 2px solid @acento_oscuro; text-align: left; }

QTreeWidget, QPlainTextEdit, QListWidget { background: @panel; border: none; outline: 0;
                              selection-background-color: @acento_oscuro; border-radius: 8px; }
QTreeWidget::item, QListWidget::item { padding: 5px 4px; border-radius: 6px; }
QTreeWidget::item:hover, QListWidget::item:hover { background: @panel_alto; }
QTreeWidget::item:selected, QListWidget::item:selected { background: @acento_oscuro; color: #ffffff; }
QTreeWidget::item:disabled { color: #5d6670; }
QHeaderView::section { background: @panel_alto; color: @texto_secundario; border: none;
                       border-bottom: 1px solid @borde; padding: 6px 8px; font-weight: 600; }

QLabel#TituloGrande { font-size: 16pt; font-weight: 700; color: #ffffff; padding: 2px 4px; }
QLabel#TituloObjeto { font-size: 13pt; font-weight: 600; color: @texto; }
QLabel#TituloTarjeta { font-size: 11.5pt; font-weight: 700; color: #ffffff; }
QLabel#Etiqueta { color: @acento; font-size: 8pt; font-weight: 700; letter-spacing: 1px; }
QLabel#Subtitulo { color: @acento; font-weight: 600; }
QLabel#TextoVacio { color: @texto_secundario; padding: 16px 4px; }
QLabel#Insignia, QLabel#Aviso { background: #2f2a1c; color: @aviso; border: 1px solid #5c4d24;
                  border-radius: 8px; padding: 6px 10px; }
QLabel#Error { background: #33201f; color: @error; border: 1px solid #6b2c28; border-radius: 8px; padding: 6px 10px; }
QLabel#Chip { background: @panel_alto; color: @texto_secundario; border: 1px solid @borde;
              border-radius: 10px; padding: 2px 10px; }
QLabel#Kpi { font-size: 17pt; font-weight: 700; color: #ffffff; }
QLabel#KpiTitulo { color: @texto_secundario; font-size: 8.5pt; }
QLabel#TextoSecundario { color: @texto_secundario; }

QFrame#Tarjeta { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #1f252b, stop:1 @panel);
                 border: 1px solid @borde; border-radius: 16px; }
QFrame#Tarjeta:hover { border-color: @acento; background: #1e242a; }

QGroupBox { background: @panel; border: 1px solid @borde; border-radius: 14px; margin-top: 16px;
            padding: 14px 10px 10px 10px; font-weight: 600; }
QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left; left: 12px; padding: 0 6px;
                   color: @acento; background: @fondo; border-radius: 4px; }

QTabWidget::pane { border: none; }
QTabBar { background: transparent; }
QTabBar::tab { background: transparent; color: @texto_secundario; padding: 8px 18px; margin-right: 2px;
               border: none; border-bottom: 2px solid transparent; }
QTabBar::tab:selected { color: #ffffff; border-bottom: 2px solid @acento; }
QTabBar::tab:hover { color: @texto; background: @panel; border-top-left-radius: 6px; border-top-right-radius: 6px; }

QTableWidget { background: @panel; alternate-background-color: #20252b; border: none; border-radius: 8px;
               gridline-color: @borde; selection-background-color: @acento_oscuro; outline: 0; }
QTableWidget::item { padding: 3px 8px; }
QTableWidget::item:selected { background: @acento_oscuro; color: #ffffff; }
QTableCornerButton::section { background: @panel_alto; border: none; }

QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox { background: #101317; border: 1px solid @borde;
               border-radius: 9px; padding: 6px 10px; selection-background-color: @acento_oscuro; }
QSpinBox:focus, QDoubleSpinBox:focus { border-color: @acento; }
QLineEdit:hover, QComboBox:hover { border-color: #46505b; }
QLineEdit:focus, QComboBox:focus { border-color: @acento; }
QLineEdit { min-height: 20px; }
QLineEdit:disabled, QComboBox:disabled { color: #5d6670; background: @panel; }
QTableWidget QLineEdit { border-radius: 0; padding: 1px 4px; }
QTableWidget QComboBox { border-radius: 0; border: none; background: transparent; padding: 1px 6px; }
QComboBox::drop-down { border: none; width: 22px; }
QComboBox QAbstractItemView { background: @panel; border: 1px solid @borde; border-radius: 6px;
               selection-background-color: @acento_oscuro; padding: 4px; }
QCheckBox { spacing: 8px; }
QCheckBox::indicator { width: 16px; height: 16px; border-radius: 4px; border: 1px solid #4a535e; background: #101317; }
QCheckBox::indicator:checked { background: @acento; border-color: @acento; }
QToolBar#BarraTabla { padding: 3px 6px; }
QDialog QLabel { color: @texto; }
QDialog QLabel#TextoSecundario { color: @texto_secundario; }

QStatusBar { background: @panel; color: @texto_secundario; border-top: 1px solid @borde; }
QStatusBar QLabel { padding: 0 8px; }
QProgressBar { background: @panel_alto; border: none; border-radius: 5px; height: 10px; text-align: center; color: transparent; }
QProgressBar::chunk { background: @acento; border-radius: 5px; }
QSlider::groove:horizontal { height: 4px; background: @borde; border-radius: 2px; }
QSlider::handle:horizontal { background: @acento; width: 14px; height: 14px; margin: -6px 0; border-radius: 7px; }

QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: #3a424c; border-radius: 4px; min-height: 28px; }
QScrollBar::handle:vertical:hover { background: @texto_secundario; }
QScrollBar:horizontal { background: transparent; height: 10px; margin: 2px; }
QScrollBar::handle:horizontal { background: #3a424c; border-radius: 4px; min-width: 28px; }
QScrollBar::add-line, QScrollBar::sub-line { width: 0; height: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }

QToolTip { background: @panel_alto; color: @texto; border: 1px solid @borde; padding: 6px; border-radius: 6px; }
QMessageBox { background: @fondo; }
QPushButton { background: @panel_alto; border: 1px solid @borde; border-radius: 10px; padding: 8px 18px; font-weight: 600; }
QPushButton:hover { border-color: @acento; background: #2a3139; }
QPushButton:pressed { background: @acento_oscuro; }
QPushButton:checked { background: @acento_oscuro; border-color: @acento; }
QPushButton:disabled { color: #5d6670; }
QPushButton#Primario, QPushButton:default { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #36d1c2, stop:1 @acento);
                                            color: #0b1514; border: 1px solid @acento; }
QPushButton#Primario:hover, QPushButton:default:hover { background: #46dccd; }
QPushButton#Primario:pressed { background: @acento_oscuro; color: #ffffff; }
"""


def _hoja_estilo() -> str:
    hoja = _HOJA_ESTILO
    # Reemplaza las claves más largas primero (p. ej. @acento_oscuro antes que @acento)
    for clave in sorted(COLORES, key=len, reverse=True):
        hoja = hoja.replace("@" + clave, COLORES[clave])
    return hoja


def aplicar_tema_oscuro(app: QApplication) -> None:
    app.setStyle("Fusion")
    paleta = QPalette()
    rol = QPalette.ColorRole
    paleta.setColor(rol.Window, QColor(COLORES["fondo"]))
    paleta.setColor(rol.WindowText, QColor(COLORES["texto"]))
    paleta.setColor(rol.Base, QColor(COLORES["panel"]))
    paleta.setColor(rol.AlternateBase, QColor(COLORES["panel_alto"]))
    paleta.setColor(rol.Text, QColor(COLORES["texto"]))
    paleta.setColor(rol.Button, QColor(COLORES["panel_alto"]))
    paleta.setColor(rol.ButtonText, QColor(COLORES["texto"]))
    paleta.setColor(rol.Highlight, QColor(COLORES["acento_oscuro"]))
    paleta.setColor(rol.HighlightedText, QColor("#ffffff"))
    paleta.setColor(rol.ToolTipBase, QColor(COLORES["panel_alto"]))
    paleta.setColor(rol.ToolTipText, QColor(COLORES["texto"]))
    paleta.setColor(rol.PlaceholderText, QColor(COLORES["texto_secundario"]))
    paleta.setColor(QPalette.ColorGroup.Disabled, rol.Text, QColor("#5d6670"))
    paleta.setColor(QPalette.ColorGroup.Disabled, rol.WindowText, QColor("#5d6670"))
    app.setPalette(paleta)
    app.setStyleSheet(_hoja_estilo())


def ajustar_a_pantalla(ventana, ancho: int, alto: int) -> None:
    """Tamaño deseado, sin pasar del área disponible de la pantalla (deja ver los botones)."""
    from PySide6.QtWidgets import QApplication
    try:
        pantalla = ventana.screen() or QApplication.primaryScreen()
        g = pantalla.availableGeometry()
        ancho = min(ancho, g.width() - 30)
        alto = min(alto, g.height() - 70)
        ventana.resize(ancho, alto)
        ventana.move(g.x() + (g.width() - ancho) // 2, g.y() + max(0, (g.height() - alto) // 2 - 10))
    except Exception:  # noqa: BLE001
        ventana.resize(ancho, alto)


def con_desplazamiento(widget):
    """Envuelve un panel en un área con barra de desplazamiento vertical."""
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QFrame, QScrollArea
    area = QScrollArea()
    area.setWidget(widget)
    area.setWidgetResizable(True)
    area.setFrameShape(QFrame.Shape.NoFrame)
    area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    return area
