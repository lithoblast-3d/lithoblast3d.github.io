"""Diseño de la malla de perforación sobre las curvas de nivel (TIN importado de DWG/DXF)."""

from __future__ import annotations

from dataclasses import replace

import numpy as np
from matplotlib.tri import Triangulation
from PySide6.QtWidgets import QLabel, QMessageBox

from app.cad import malla_topografica as mt
from app.core.ejemplos import explosivos_referenciales
from app.core.generador import _generador_ids, nuevo_id_contorno
from app.core.modelo import ESCENARIO_TAJO, Contorno, Perforacion, PolilineaCAD
from app.ui.analisis.base import DialogoAnalisis, FilaKpi, Tabla, grupo, lista, numero
from app.ui.dialogo_cad import tin_de_objeto, tins_del_proyecto
from app.ui.graficos import Grafico

AREA_RECT = "Rectángulo (centro, largo, ancho)"


class DialogoMallaTopografica(DialogoAnalisis):
    def __init__(self, documento, parent=None):
        super().__init__("Malla sobre la topografía", "Diseña la malla de perforación del banco sobre las curvas de "
                         "nivel: cada collar toma la cota del terreno y cada taladro llega a la cota de piso.",
                         parent, 1420, 880)
        self.doc = documento
        self.descripcion = ""
        self.resultado: mt.ResultadoMallaTopo | None = None
        pr = documento.proyecto
        self.tins = tins_del_proyecto(pr)
        self.cerradas = [o for o in pr.objetos.values() if isinstance(o, PolilineaCAD) and o.cerrada
                         and len(o.vertices) >= 3]
        self.btn_calcular.setText("▶  Vista previa")
        self.btn_crear = self.boton("✔ Crear en el proyecto", self._crear, primario=True)

        # --- superficie y área
        self.c_tin = lista([f"{t.nombre} ({len(t.triangulos)} triángulos)" for t in self.tins])
        self.c_area = lista([AREA_RECT] + [f"{o.capa_cad or 'CAD'} · {o.nombre} ({mt.area_poligono(o.vertices):.0f} m²)"
                                           for o in self.cerradas])
        cx, cy, zmin, zmax = 0.0, 0.0, 0.0, 10.0
        if self.tins:
            v = np.asarray(self.tins[0].vertices, float)
            cx, cy = float(v[:, 0].mean()), float(v[:, 1].mean())
            zmin, zmax = float(v[:, 2].min()), float(v[:, 2].max())
        self.cx = numero(-1e7, 1e7, round(cx, 1), 2, 1, "m")
        self.cy = numero(-1e7, 1e7, round(cy, 1), 2, 1, "m")
        self.largo = numero(2, 2000, 40, 1, 1, "m")
        self.ancho = numero(2, 2000, 20, 1, 1, "m")
        self.az_largo = numero(0, 360, 90, 1, 5, "°")
        self.form.addWidget(grupo("Superficie y área de voladura", [
            ("Superficie TIN", self.c_tin), ("Área", self.c_area), ("Centro Este (X)", self.cx),
            ("Centro Norte (Y)", self.cy), ("Largo", self.largo), ("Ancho", self.ancho),
            ("Azimut del largo", self.az_largo)]))

        # --- malla
        d = pr.diseno
        self.b = numero(0.5, 20, d.burden, 2, 0.1, "m")
        self.s = numero(0.5, 25, d.espaciamiento, 2, 0.1, "m")
        self.patron = lista(mt.PATRONES)
        self.az_sal = numero(0, 360, 0, 1, 5, "°")
        self.btn_az = self.boton("Detectar salida por la pendiente", self._detectar)
        self.margen = numero(0, 20, 1.0, 2, 0.1, "m")
        self.form.addWidget(grupo("Malla", [("Burden B", self.b), ("Espaciamiento S", self.s), ("Patrón", self.patron),
                                            ("Azimut de salida (cara libre)", self.az_sal),
                                            ("Margen al borde del área", self.margen)]))
        # --- banco
        self.modo = lista(mt.MODOS_PISO)
        self.piso = numero(-1000, 9000, round(zmin + 0.0, 2), 2, 0.5, "m")
        self.h = numero(1, 40, d.altura_banco, 2, 0.5, "m")
        self.j = numero(0, 5, round(0.3 * d.burden, 2), 2, 0.1, "m")
        self.incl = numero(45, 90, 90, 1, 1, "°")
        self.form.addWidget(grupo("Banco", [("Fondo de los taladros", self.modo), ("Cota de piso", self.piso),
                                            ("Altura de banco", self.h), ("Sobreperforación J", self.j),
                                            ("Inclinación (90° = vertical)", self.incl)]))
        # --- carga
        self.exps = list(pr.explosivos) or explosivos_referenciales()
        self.genericos = not pr.explosivos
        self.c_exp = lista([e.nombre for e in self.exps])
        self.dia = numero(25, 400, 165 if not pr.perforaciones() else pr.perforaciones()[0].diametro_mm, 0, 1, "mm")
        self.taco = numero(0, 15, round(0.7 * d.burden, 2), 2, 0.1, "m")
        self.form.addWidget(grupo("Perforación y carga", [("Diámetro", self.dia), ("Explosivo", self.c_exp),
                                                          ("Taco", self.taco)]))
        if self.genericos:
            n = QLabel("⚠ El proyecto no tiene explosivos: se usan genéricos y se agregan al crear la malla.")
            n.setObjectName("Aviso"); n.setWordWrap(True)
            self.form.addWidget(n)
        # --- secuencia
        self.sec = lista(mt.SECUENCIAS)
        self.ms_t = numero(0, 500, 25, 0, 1, "ms")
        self.ms_f = numero(0, 1000, 67, 0, 1, "ms")
        self.form.addWidget(grupo("Secuencia de salida", [("Tipo", self.sec), ("Entre taladros", self.ms_t),
                                                          ("Entre filas", self.ms_f)]))
        self.reemplazar = lista(["Reemplazar los taladros del proyecto", "Agregar a los existentes"])
        self.form.addWidget(grupo("Al crear", [("", self.reemplazar)]))
        self.form.addStretch(1)

        # --- resultados
        self.kpi = FilaKpi(["Taladros", "Perforación", "Explosivo", "Volumen", "Factor de carga"])
        self.zona.addWidget(self.kpi)
        tabs = self.pestanas()
        self.g = Grafico(alto_min=420)
        tabs.addTab(self.g, "Planta con curvas de nivel")
        self.tabla = Tabla(["Fila", "N.º", "Este X", "Norte Y", "Cota collar", "Altura banco", "Longitud", "kg",
                            "Retardo", "ms"], solo_lectura=True)
        tabs.addTab(self.tabla, "Taladros")
        if not self.tins:
            self.avisar("El proyecto no tiene superficie TIN. Importa el DWG/DXF del profesor con "
                        "Topografía y CAD → Importar DXF / DWG (marca la capa de curvas en «Usar para TIN»).",
                        error=True)
            self.btn_crear.setEnabled(False)
            return
        if self.cerradas:
            self.c_area.setCurrentIndex(1)
        self._detectar()
        for w in (self.cx, self.cy, self.largo, self.ancho, self.az_largo, self.b, self.s, self.az_sal, self.margen,
                  self.piso, self.h, self.j, self.incl, self.dia, self.taco, self.ms_t, self.ms_f):
            w.valueChanged.connect(self._calcular_seguro)
        for w in (self.c_tin, self.c_area, self.patron, self.modo, self.c_exp, self.sec):
            w.currentIndexChanged.connect(self._calcular_seguro)
        self._calcular_seguro()

    # ------------------------------------------------------------------
    def tin(self):
        return tin_de_objeto(self.tins[self.c_tin.currentIndex()])

    def poligono(self):
        i = self.c_area.currentIndex()
        rect = i == 0
        for w in (self.cx, self.cy, self.largo, self.ancho, self.az_largo):
            w.setEnabled(rect)
        if rect:
            return mt.rectangulo(self.cx.value(), self.cy.value(), self.largo.value(), self.ancho.value(),
                                 self.az_largo.value())
        return [(v[0], v[1]) for v in self.cerradas[i - 1].vertices]

    def _detectar(self, *_):
        try:
            az = mt.azimut_pendiente(self.tin(), self.poligono())
        except (ValueError, IndexError):
            az = None
        if az is None:
            self.avisar("No se pudo deducir la cara libre (terreno plano en el área): indica el azimut de salida.")
            return
        self.az_sal.blockSignals(True)
        self.az_sal.setValue(round(az / 5) * 5 % 360)
        self.az_sal.blockSignals(False)
        self._calcular_seguro()

    def explosivo(self):
        return self.exps[self.c_exp.currentIndex()]

    def entrada(self) -> mt.EntradaMallaTopo:
        e = self.explosivo()
        return mt.EntradaMallaTopo(
            poligono=self.poligono(), burden=self.b.value(), espaciamiento=self.s.value(),
            patron=self.patron.currentText(), azimut_salida=self.az_sal.value(), margen=self.margen.value(),
            modo_piso=self.modo.currentText(), cota_piso=self.piso.value(), altura_banco=self.h.value(),
            sobreperforacion=self.j.value(), taco=self.taco.value(), inclinacion=self.incl.value(),
            diametro_mm=self.dia.value(), densidad_explosivo=e.densidad_gcc,
            diametro_carga_mm=e.diametro_de_carga(self.dia.value()), explosivo_id=e.id,
            secuencia=self.sec.currentText(), ms_taladros=self.ms_t.value(), ms_filas=self.ms_f.value())

    def calcular(self) -> None:
        self.piso.setEnabled(self.modo.currentIndex() == 0)
        self.h.setEnabled(self.modo.currentIndex() == 1)
        e = self.entrada()
        tin = self.tin()
        r = mt.generar(e, tin)
        self.resultado, self.ent = r, e
        fc = r.kg / r.volumen_m3 if r.volumen_m3 else 0
        self.kpi["Taladros"].poner(str(len(r.taladros)), f"{r.filas} filas")
        self.kpi["Perforación"].poner(f"{r.metros:,.0f} m", f"L media {r.metros / len(r.taladros):.1f} m")
        self.kpi["Explosivo"].poner(f"{r.kg:,.0f} kg", self.explosivo().nombre[:28])
        self.kpi["Volumen"].poner(f"{r.volumen_m3:,.0f} m³", f"área {r.area_m2:,.0f} m²")
        self.kpi["Factor de carga"].poner(f"{fc:.3f} kg/m³")
        if r.avisos:
            self.avisar(" ".join(r.avisos))
        self.tabla.poner_filas([[t.fila, t.orden, t.x, t.y, t.z, t.altura, t.longitud, t.carga_kg, t.retardo,
                                 t.tiempo_ms if t.tiempo_ms is not None else ""] for t in r.taladros])
        self._dibujar(tin, e, r)

    def _dibujar(self, tin, e, r):
        pol = np.asarray(e.poligono, float)
        m = max(e.burden * 4, 10)
        x0, x1 = pol[:, 0].min() - m, pol[:, 0].max() + m
        y0, y1 = pol[:, 1].min() - m, pol[:, 1].max() + m
        P, T = tin.puntos, tin.triangulos
        cen = P[T].mean(axis=1)
        mm = 2 * m  # se toma más terreno que el visible para que el borde no se vea dentado
        sel = (cen[:, 0] > x0 - mm) & (cen[:, 0] < x1 + mm) & (cen[:, 1] > y0 - mm) & (cen[:, 1] < y1 + mm)
        ax = self.g.limpiar()
        if sel.sum() > 0:
            tri = Triangulation(P[:, 0], P[:, 1], T[sel])
            z = P[:, 2]
            zl = z[np.unique(T[sel])]
            paso = _paso_curvas(float(zl.max() - zl.min()))
            niveles = np.arange(np.floor(zl.min() / paso) * paso, zl.max() + paso, paso)
            if len(niveles) > 1:
                cf = ax.tricontourf(tri, z, levels=niveles, cmap="gist_earth", alpha=0.55)
                cs = ax.tricontour(tri, z, levels=niveles, colors="#cfd6dd", linewidths=0.5)
                ax.clabel(cs, cs.levels[::max(len(cs.levels) // 8, 1)], fontsize=7, fmt="%.0f")
                cb = self.g.figura.colorbar(cf, ax=ax, fraction=0.035, pad=0.02)
                cb.set_label("Cota (m)")
        c = np.vstack([pol, pol[:1]])
        ax.plot(c[:, 0], c[:, 1], color="#2ec4b6", lw=1.8, label="Área de voladura")
        xs = [t.x for t in r.taladros]; ys = [t.y for t in r.taladros]
        col = [t.tiempo_ms or 0 for t in r.taladros]
        sc = ax.scatter(xs, ys, c=col, cmap="plasma", s=34, edgecolors="#ffffff", linewidths=0.6, zorder=5)
        if len(r.taladros) <= 160:
            for t in r.taladros:
                ax.annotate(str(t.retardo) if t.retardo else "", (t.x, t.y), textcoords="offset points",
                            xytext=(4, 4), fontsize=6.5, color="#ffffff")
        # flecha de salida
        a = np.radians(e.azimut_salida)
        cx, cy = pol.mean(axis=0)
        L = max(e.burden * 2.5, 5)
        ax.annotate("", (cx + L * np.sin(a), cy + L * np.cos(a)), (cx, cy),
                    arrowprops=dict(arrowstyle="-|>", color="#e6b84a", lw=2))
        ax.text(cx + L * 1.1 * np.sin(a), cy + L * 1.1 * np.cos(a), "salida", color="#e6b84a", fontsize=8.5)
        if e.secuencia != mt.SECUENCIAS[2]:
            cb2 = self.g.figura.colorbar(sc, ax=ax, orientation="horizontal", fraction=0.04, pad=0.09, aspect=40)
            cb2.set_label("Tiempo (ms)")
        ax.set_xlim(x0, x1); ax.set_ylim(y0, y1)
        ax.set_aspect("equal")
        ax.set_xlabel("Este (m)"); ax.set_ylabel("Norte (m)")
        ax.ticklabel_format(useOffset=False, style="plain")
        ax.set_title("Planta: curvas de nivel, área y taladros (número = retardo)")
        ax.grid(False)
        self.g.actualizar()

    # ------------------------------------------------------------------
    def _crear(self):
        self._calcular_seguro()
        r = self.resultado
        if r is None or not r.taladros:
            return
        pr = self.doc.proyecto
        if self.genericos and not pr.explosivos:
            self.doc.reemplazar_explosivos(list(self.exps))
        e = self.ent
        eliminar = [p.id for p in pr.perforaciones()] if self.reemplazar.currentIndex() == 0 else []
        ocupados = set(pr.objetos) - set(eliminar)
        nuevo = _generador_ids(ocupados)
        pozos = []
        for t in r.taladros:
            i = nuevo()
            pozos.append(Perforacion(
                id=i, nombre=i, capa_id="perforaciones", x=t.x, y=t.y, z=t.z, azimut=e.azimut_salida,
                inclinacion=e.inclinacion, longitud=t.longitud, diametro_mm=e.diametro_mm, explosivo_id=e.explosivo_id,
                taco=e.taco, funcion="Primera fila" if t.fila == 1 else "Producción", retardo=t.retardo,
                tiempo_ms=t.tiempo_ms, origen="Malla sobre topografía"))
        id_c = nuevo_id_contorno(ocupados | {p.id for p in pozos}, "AREA-")
        area = Contorno(id=id_c, nombre=f"Área de voladura ({r.area_m2:.0f} m²)", capa_id="contornos",
                        vertices=mt.poligono_sobre_terreno(self.tin(), e.poligono, max(e.espaciamiento / 4, 0.5)))
        alturas = [t.altura for t in r.taladros]
        dis = replace(pr.diseno, escenario=ESCENARIO_TAJO, burden=e.burden, espaciamiento=e.espaciamiento,
                      altura_banco=round(float(np.mean(alturas)), 2))
        self.descripcion = (f"Malla sobre topografía: {len(pozos)} taladros, {r.metros:.0f} m, {r.kg:.0f} kg "
                            f"(B {e.burden:g} × S {e.espaciamiento:g} m)")
        try:
            self.doc.aplicar_lote([area, *pozos], eliminar, dis, self.descripcion)
        except ValueError as err:
            QMessageBox.warning(self, "Malla sobre la topografía", str(err))
            return
        self.accept()


def _paso_curvas(rango: float) -> float:
    for p in (0.5, 1, 2, 5, 10, 20, 50):
        if rango / p <= 25:
            return p
    return 100.0
