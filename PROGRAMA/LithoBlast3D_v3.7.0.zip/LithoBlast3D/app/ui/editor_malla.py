"""Editor de una malla (PlanoRef): vistas frontal (editable), planta, lateral y 3D + tabla de taladros."""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QBrush, QColor, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (
    QAbstractItemView, QHeaderView, QLabel, QMessageBox, QSplitter, QTableWidget, QTableWidgetItem, QTabWidget,
    QVBoxLayout, QWidget,
)

from app.biblioteca import estandar as est
from app.ui.dialogo_biblioteca import LienzoFrontal, LienzoProyeccion, Vista3DPlano
from app.ui.tema import COLORES

COLORES_FUNCION = {"Alivio": "#f2f2f2", "Arranque": "#ffd23f", "Ayuda": "#ff8c1a", "Hastial": "#2bb3a8",
                   "Contorno": "#2bb3a8", "Corona": "#3a8dde", "Arrastre": "#b06cff"}


class MiniMalla(QWidget):
    """Vista previa pequeña de una malla (para las tarjetas de opciones)."""

    def __init__(self, plano: est.PlanoRef | None, parent=None):
        super().__init__(parent)
        self.plano = plano
        self.setMinimumSize(220, 190)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor("#12161a"))
        pl = self.plano
        if pl is None or not pl.contorno:
            p.setPen(QColor(COLORES["texto_secundario"]))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "Sin vista previa")
            return
        xs = [v[0] for v in pl.contorno]; ys = [v[1] for v in pl.contorno]
        x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        m = 10
        s = min((self.width() - 2 * m) / max(x1 - x0, 1e-6), (self.height() - 2 * m) / max(y1 - y0, 1e-6))
        ox = m + (self.width() - 2 * m - s * (x1 - x0)) / 2 - s * x0
        oy = self.height() - m - (self.height() - 2 * m - s * (y1 - y0)) / 2 + s * y0

        def P(x, y):
            from PySide6.QtCore import QPointF
            return QPointF(ox + s * x, oy - s * y)
        path = QPainterPath(P(*pl.contorno[0]))
        for v in pl.contorno[1:]:
            path.lineTo(P(*v))
        path.closeSubpath()
        p.setPen(QPen(QColor(COLORES["acento_azul"]), 1.6))
        p.setBrush(QColor(58, 141, 222, 22))
        p.drawPath(path)
        r = max(2.2, 0.022 * s)
        fun = est.clasificar(pl)
        for t, f in zip(pl.taladros, fun):
            f = t.funcion or f
            p.setPen(QPen(QColor("#0b0d0f"), 0.6))
            p.setBrush(QColor(COLORES_FUNCION.get(f, "#ff8c1a")))
            p.drawEllipse(P(t.x, t.y), r * (1.5 if t.tipo == "alivio" else 1.0), r * (1.5 if t.tipo == "alivio" else 1.0))


class EditorMalla(QWidget):
    COLS = ["X (m)", "Y (m)", "Tipo", "Retardo", "Cartuchos", "kg", "Explosivo", "Función", "Nota"]
    cambiado = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.plano: est.PlanoRef | None = None
        self._llenando = False
        lay = QVBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
        self.titulo = QLabel(); self.titulo.setObjectName("TituloObjeto"); self.titulo.setWordWrap(True)
        lay.addWidget(self.titulo)
        div = QSplitter(Qt.Orientation.Horizontal)
        lay.addWidget(div, 1)
        self.tabs = QTabWidget()
        self.frontal = LienzoFrontal(); self.frontal.mostrar_imagen = False
        self.tabs.addTab(self.frontal, "Frontal (editar)")
        self.planta = LienzoProyeccion("planta"); self.tabs.addTab(self.planta, "Planta")
        self.lateral = LienzoProyeccion("lateral"); self.tabs.addTab(self.lateral, "Lateral")
        self.vista3d = Vista3DPlano(); self.tabs.addTab(self.vista3d, "3D")
        div.addWidget(self.tabs)
        self.tabla = QTableWidget()
        self.tabla.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabla.setAlternatingRowColors(True)
        div.addWidget(self.tabla)
        div.setSizes([700, 460])
        self.frontal.cambiado.connect(self._editado_lienzo)
        self.frontal.seleccion.connect(lambda i: self.tabla.selectRow(i) if i >= 0 else None)
        self.tabla.itemChanged.connect(self._celda)
        self.tabs.currentChanged.connect(self._pestana)

    def set_plano(self, pl: est.PlanoRef):
        self.plano = pl
        self.titulo.setText(pl.nombre)
        for lz in (self.frontal, self.planta, self.lateral):
            lz.set_plano(pl)
        self.frontal.mostrar_imagen = False
        self._llenar()
        if self.tabs.currentWidget() is self.vista3d:
            self.vista3d.mostrar(pl)

    def _pestana(self, *_):
        if self.tabs.currentWidget() is self.vista3d and self.plano:
            self.vista3d.mostrar(self.plano)

    def _llenar(self):
        pl = self.plano
        self._llenando = True
        t = self.tabla
        t.clear(); t.setColumnCount(len(self.COLS)); t.setHorizontalHeaderLabels(self.COLS)
        t.setRowCount(len(pl.taladros))
        fun = est.clasificar(pl)
        for i, ta in enumerate(pl.taladros):
            kg = ta.kg if ta.kg is not None else None
            vals = [f"{ta.x:.3f}", f"{ta.y:.3f}", ta.tipo, "" if ta.detonador is None else str(ta.detonador),
                    str(ta.cartuchos), "" if kg is None else f"{kg:.2f}", ta.explosivo or "", ta.funcion or fun[i],
                    ta.lectura]
            for j, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if j >= 7:
                    it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
                t.setItem(i, j, it)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self._llenando = False

    def _celda(self, item):
        if self._llenando or not self.plano:
            return
        ta = self.plano.taladros[item.row()]
        v = item.text().strip().replace(",", ".")
        j = item.column()
        try:
            if j == 0:
                ta.x = float(v)
            elif j == 1:
                ta.y = float(v)
            elif j == 2:
                if v not in ("cargado", "alivio"):
                    raise ValueError("Tipo: escribe cargado o alivio")
                ta.tipo = v
                ta.funcion = "Alivio" if v == "alivio" else (ta.funcion if ta.funcion != "Alivio" else "Ayuda")
            elif j == 3:
                ta.detonador = int(float(v)) if v else None
            elif j == 4:
                nuevo = int(float(v or 0))
                if ta.kg is not None and ta.cartuchos:
                    ta.kg = ta.kg * nuevo / ta.cartuchos
                ta.cartuchos = nuevo
            elif j == 5:
                ta.kg = float(v) if v else None
            elif j == 6:
                ta.explosivo = item.text().strip() or None
        except ValueError as error:
            QMessageBox.warning(self, "Editar taladro", str(error))
            self._llenar()
            return
        ta.lectura = "editado"
        self._recalcular()

    def _editado_lienzo(self):
        self._llenar()
        self._recalcular()

    def _recalcular(self):
        from app.biblioteca.opciones import _a_plano  # noqa: F401  (tablas se recalculan al usar)
        for lz in (self.frontal, self.planta, self.lateral):
            lz.update()
        self.cambiado.emit()

    def cerrar(self):
        self.vista3d.cerrar()
