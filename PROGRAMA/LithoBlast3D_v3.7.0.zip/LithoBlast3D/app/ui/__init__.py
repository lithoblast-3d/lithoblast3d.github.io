"""Interfaz gráfica: ventana principal, paneles y tema."""
