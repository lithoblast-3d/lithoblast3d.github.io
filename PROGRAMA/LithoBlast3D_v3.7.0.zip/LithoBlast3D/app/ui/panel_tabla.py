"""
Panel inferior: tabla editable de perforaciones.

- Doble clic en una celda blanca para editar; Enter para confirmar.
- Las columnas grises son resultados calculados (no editables).
- La selección de fila se sincroniza con el visor, el árbol y las propiedades.
"""

from collections.abc import Callable

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QHeaderView,
    QLabel,
    QTableWidget,
    QTableWidgetItem,
    QToolBar,
    QVBoxLayout,
    QWidget,
)

from app.core.documento import Documento, ErrorEdicion
from app.core.modelo import ESCENARIO_TAJO, FUNCIONES_POZO, num
from app.core.resultados import carga_de_pozo

# (clave, título, tipo, decimales). Tipos: "id", "num", "funcion", "explosivo", "calc"
COLUMNAS = [
    ("id", "ID", "id", 0),
    ("funcion", "Función", "funcion", 0),
    ("x", "Este X\n(m)", "num", 2),
    ("y", "Norte Y\n(m)", "num", 2),
    ("z", "Cota Z\n(m)", "num", 2),
    ("azimut", "Azimut\n(°)", "num", 1),
    ("inclinacion", "Inclinación\n(°)", "num", 1),
    ("longitud", "Longitud\n(m)", "num", 2),
    ("diametro_mm", "Diámetro\n(mm)", "num", 0),
    ("explosivo_id", "Explosivo", "explosivo", 0),
    ("taco", "Taco\n(m)", "num", 2),
    ("retardo", "Retardo\n(N°)", "num", 0),
    ("tiempo_ms", "Tiempo\n(ms)", "num", 0),
    ("carga_lineal", "Carga lineal\n(kg/m)", "calc", 3),
    ("carga", "Carga\n(kg)", "calc", 2),
    ("factor_carga", "F. carga taladro\n(kg/m³)", "calc", 3),
]
ROL_POZO = Qt.ItemDataRole.UserRole


def _a_numero(texto: str) -> float:
    texto = texto.strip().replace(" ", "").replace(",", ".")
    try:
        return float(texto)
    except ValueError:
        raise ErrorEdicion(f"«{texto}» no es un número válido") from None


class PanelTabla(QWidget):
    def __init__(self, documento: Documento, colores: dict, acciones: list[QAction],
                 al_mensaje: Callable[[str, str], None], parent=None):
        super().__init__(parent)
        self._doc = documento
        self._c = colores
        self._al_mensaje = al_mensaje
        self._ids_fila: list[str] = []

        barra = QToolBar()
        barra.setObjectName("BarraTabla")
        barra.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        for accion in acciones:
            if accion is None:
                barra.addSeparator()
            else:
                barra.addAction(accion)
        self.contador = QLabel()
        self.contador.setObjectName("TextoSecundario")
        barra.addSeparator()
        barra.addWidget(self.contador)

        self.tabla = QTableWidget(0, len(COLUMNAS))
        self.tabla.setHorizontalHeaderLabels([c[1] for c in COLUMNAS])
        self.tabla.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tabla.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tabla.setEditTriggers(QAbstractItemView.EditTrigger.DoubleClicked
                                   | QAbstractItemView.EditTrigger.EditKeyPressed
                                   | QAbstractItemView.EditTrigger.AnyKeyPressed)
        self.tabla.verticalHeader().setVisible(False)
        self.tabla.verticalHeader().setDefaultSectionSize(26)
        self.tabla.setAlternatingRowColors(True)
        self.tabla.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.tabla.horizontalHeader().setStretchLastSection(True)

        diseno = QVBoxLayout(self)
        diseno.setContentsMargins(0, 0, 0, 0)
        diseno.setSpacing(0)
        diseno.addWidget(barra)
        diseno.addWidget(self.tabla, 1)

        self.tabla.cellChanged.connect(self._al_editar_celda)
        self.tabla.currentCellChanged.connect(self._al_cambiar_celda_actual)
        self._doc.seleccion.suscribir(self._al_cambiar_seleccion)
        self.refrescar()

    # ------------------------------------------------------------------ llenado
    def refrescar(self) -> None:
        proyecto = self._doc.proyecto
        pozos = proyecto.perforaciones()
        es_tajo = proyecto.diseno.escenario == ESCENARIO_TAJO
        self._ids_fila = [p.id for p in pozos]
        gris = QColor(self._c["texto_secundario"])

        self.tabla.blockSignals(True)
        try:
            self.tabla.setRowCount(len(pozos))
            for fila, pozo in enumerate(pozos):
                cp = carga_de_pozo(proyecto, pozo)
                calculados = {
                    "carga_lineal": cp.carga_lineal,
                    "carga": cp.carga if cp.cargado else 0.0,
                    "factor_carga": cp.factor_carga,
                }
                for col, (clave, _titulo, tipo, dec) in enumerate(COLUMNAS):
                    if tipo == "funcion":
                        self._poner_combo(fila, col, pozo.id, "funcion",
                                          [(f, f) for f in FUNCIONES_POZO], pozo.funcion)
                        continue
                    if tipo == "explosivo":
                        opciones = [("— Sin carga —", None)] + [(e.nombre, e.id) for e in proyecto.explosivos]
                        self._poner_combo(fila, col, pozo.id, "explosivo_id", opciones, pozo.explosivo_id)
                        continue
                    if tipo == "id":
                        item = QTableWidgetItem(pozo.id)
                        item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
                    elif tipo == "num":
                        item = QTableWidgetItem(num(getattr(pozo, clave), dec))
                        item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                    else:  # calculado
                        item = QTableWidgetItem(num(calculados[clave], dec))
                        item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                        item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
                        item.setForeground(gris)
                        item.setToolTip("Calculado (ver app/calc/carga.py)")
                    item.setData(ROL_POZO, pozo.id)
                    self.tabla.setItem(fila, col, item)
            self.tabla.setColumnHidden(len(COLUMNAS) - 1, not es_tajo)
        finally:
            self.tabla.blockSignals(False)
        cargados = sum(1 for p in pozos if carga_de_pozo(proyecto, p).cargado)
        self.contador.setText(f"  {len(pozos)} taladros · {cargados} cargados  ")
        self._al_cambiar_seleccion(self._doc.seleccion.actual, "")

    def _poner_combo(self, fila, col, pozo_id, campo, opciones, actual) -> None:
        combo = QComboBox()
        combo.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        for texto, valor in opciones:
            combo.addItem(texto, valor)
        indice = next((i for i, (_t, v) in enumerate(opciones) if v == actual), -1)
        if indice < 0 and actual is not None:
            combo.addItem(str(actual), actual)
            indice = combo.count() - 1
        combo.setCurrentIndex(max(indice, 0))
        combo.currentIndexChanged.connect(
            lambda _i, c=combo, pid=pozo_id, f=campo: self._aplicar(pid, {f: c.currentData()}))
        self.tabla.setCellWidget(fila, col, combo)

    # ------------------------------------------------------------------ edición
    def _aplicar(self, pozo_id: str, cambios: dict) -> None:
        try:
            self._doc.actualizar_pozo(pozo_id, **cambios)
        except ErrorEdicion as error:
            self._al_mensaje(f"{pozo_id}: {error}", "aviso")
            self.refrescar()

    def _al_editar_celda(self, fila: int, col: int) -> None:
        clave, _t, tipo, _d = COLUMNAS[col]
        if tipo != "num" or fila >= len(self._ids_fila):
            return
        item = self.tabla.item(fila, col)
        try:
            valor = _a_numero(item.text())
        except ErrorEdicion as error:
            self._al_mensaje(f"{self._ids_fila[fila]}: {error}", "aviso")
            self.refrescar()
            return
        if clave == "retardo":
            valor = int(round(valor))
        self._aplicar(self._ids_fila[fila], {clave: valor})

    # ------------------------------------------------------------------ selección
    def _al_cambiar_celda_actual(self, fila: int, _col: int, fila_anterior: int, _c: int) -> None:
        if fila == fila_anterior or not 0 <= fila < len(self._ids_fila):
            return
        self._doc.seleccion.seleccionar(self._ids_fila[fila], origen="tabla")

    def _al_cambiar_seleccion(self, objeto_id: str | None, origen: str) -> None:
        if origen == "tabla":
            return
        self.tabla.blockSignals(True)
        try:
            if objeto_id in self._ids_fila:
                fila = self._ids_fila.index(objeto_id)
                self.tabla.setCurrentCell(fila, 0)
                self.tabla.selectRow(fila)
                self.tabla.scrollToItem(self.tabla.item(fila, 0))
            else:
                self.tabla.clearSelection()
                self.tabla.setCurrentCell(-1, -1)
        finally:
            self.tabla.blockSignals(False)
