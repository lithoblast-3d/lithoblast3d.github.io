"""
Importación de DWG mediante conversión a DXF.

El formato DWG es cerrado y no existe un lector libre confiable en Python.
Procedimiento compatible (gratuito): «ODA File Converter» de la Open Design
Alliance (https://www.opendesign.com/guestfiles/oda_file_converter).
LithoBlast3D lo ejecuta en segundo plano: DWG -> DXF ASCII (en una carpeta temporal)
y luego lee ese DXF con app/cad/dxf.py.

Limitaciones: requiere instalar ODA File Converter (Windows/Linux/macOS);
los objetos propios de Civil 3D (superficies AECC, alineamientos) no se exportan
como geometría: en Civil 3D usa «Exportar a AutoCAD» o extrae la superficie a
caras 3D/polilíneas antes de guardar.
"""

from __future__ import annotations

import glob
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

CONFIG = Path.home() / ".barreno3d" / "config.json"


class ErrorDWG(Exception):
    pass


def _config() -> dict:
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def guardar_ruta_oda(ruta: str) -> None:
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    datos = _config()
    datos["oda_file_converter"] = ruta
    CONFIG.write_text(json.dumps(datos, indent=1), encoding="utf-8")


def buscar_oda() -> str | None:
    """Ruta del ejecutable de ODA File Converter (configurada o en ubicaciones habituales)."""
    ruta = _config().get("oda_file_converter")
    if ruta and Path(ruta).exists():
        return ruta
    candidatos = []
    for base in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                 os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")):
        candidatos += glob.glob(os.path.join(base, "ODA", "ODAFileConverter*", "ODAFileConverter.exe"))
    candidatos += ["/usr/bin/ODAFileConverter", "/usr/local/bin/ODAFileConverter",
                   "/Applications/ODAFileConverter.app/Contents/MacOS/ODAFileConverter"]
    for c in sorted(candidatos, reverse=True):
        if Path(c).exists():
            return c
    return shutil.which("ODAFileConverter")


def convertir_dwg_a_dxf(ruta_dwg: str | Path, ejecutable: str | None = None, version: str = "ACAD2013",
                        tiempo_max: int = 180) -> Path:
    """Convierte un DWG en DXF ASCII y devuelve la ruta del DXF (carpeta temporal)."""
    ruta_dwg = Path(ruta_dwg)
    exe = ejecutable or buscar_oda()
    if not exe:
        raise ErrorDWG(
            "Para abrir archivos DWG instala el programa gratuito «ODA File Converter» "
            "(opendesign.com → Guest files) y, si no se detecta solo, indica su ubicación en "
            "Topografía y CAD → Configurar conversor DWG. Alternativa: en AutoCAD/Civil 3D usa "
            "Guardar como → DXF.")
    entrada = Path(tempfile.mkdtemp(prefix="b3d_dwg_in_"))
    salida = Path(tempfile.mkdtemp(prefix="b3d_dwg_out_"))
    shutil.copy2(ruta_dwg, entrada / ruta_dwg.name)
    # Sintaxis: ODAFileConverter <in> <out> <versión> <DXF|DWG> <recursivo 0/1> <auditar 0/1> [filtro]
    cmd = [exe, str(entrada), str(salida), version, "DXF", "0", "1", "*.DWG"]
    try:
        subprocess.run(cmd, check=False, timeout=tiempo_max, capture_output=True)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise ErrorDWG(f"No se pudo ejecutar ODA File Converter: {error}") from error
    dxfs = list(salida.glob("*.dxf")) + list(salida.glob("*.DXF"))
    if not dxfs:
        raise ErrorDWG("ODA File Converter no generó el DXF (¿el DWG está dañado o protegido?).")
    return dxfs[0]


VERSIONES_DWG = ["ACAD2018", "ACAD2013", "ACAD2010", "ACAD2007", "ACAD2004", "ACAD2000"]


def convertir_dxf_a_dwg(ruta_dxf: str | Path, ruta_dwg: str | Path, ejecutable: str | None = None,
                        version: str = "ACAD2013", tiempo_max: int = 180) -> Path:
    """Convierte un DXF en DWG (con ODA File Converter) y lo deja en «ruta_dwg»."""
    ruta_dxf, ruta_dwg = Path(ruta_dxf), Path(ruta_dwg)
    exe = ejecutable or buscar_oda()
    if not exe:
        raise ErrorDWG(
            "Para guardar en DWG instala el programa gratuito «ODA File Converter» (opendesign.com → Guest "
            "files) y, si no se detecta solo, indica su ubicación en Topografía y CAD → Configurar conversor DWG. "
            "Mientras tanto puedes guardar en DXF: AutoCAD lo abre igual y puedes «Guardar como» DWG allí.")
    entrada = Path(tempfile.mkdtemp(prefix="b3d_dxf_in_"))
    salida = Path(tempfile.mkdtemp(prefix="b3d_dwg_out_"))
    nombre = ruta_dwg.stem + ".dxf"
    shutil.copy2(ruta_dxf, entrada / nombre)
    cmd = [exe, str(entrada), str(salida), version, "DWG", "0", "1", "*.DXF"]
    try:
        subprocess.run(cmd, check=False, timeout=tiempo_max, capture_output=True)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise ErrorDWG(f"No se pudo ejecutar ODA File Converter: {error}") from error
    dwgs = list(salida.glob("*.dwg")) + list(salida.glob("*.DWG"))
    if not dwgs:
        raise ErrorDWG("ODA File Converter no generó el DWG. Guarda en DXF y ábrelo en AutoCAD.")
    ruta_dwg.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(dwgs[0]), str(ruta_dwg))
    return ruta_dwg
