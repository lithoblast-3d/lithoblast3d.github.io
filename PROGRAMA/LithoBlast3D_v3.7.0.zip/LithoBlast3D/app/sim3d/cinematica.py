"""
Cinemática del equipo de perforación (modelo GENÉRICO, parámetros editables).

Jumbo electrohidráulico simplificado:
  pivote del brazo (en el chasis) -> brazo telescópico (giro horizontal + elevación)
  -> viga de avance (feed) paralela al taladro -> perforadora que se desliza -> barra y broca.
La viga se mantiene paralela a la dirección del taladro (paralelismo hidráulico); su
extremo delantero (centralizador) queda a «separacion_frente» de la boca del taladro.

Restricciones geométricas que se comprueban (no se asume que todo es alcanzable):
- ancho y alto de la sección frente a las dimensiones del equipo (con holgura);
- largo del brazo entre mínimo y máximo; giro y elevación dentro de sus límites;
- la viga de avance debe caber dentro de la sección (sin chocar con el contorno);
- longitud de perforación ≤ carrera de la viga.
Si el jumbo no cabe, se usa una perforadora manual con barra de avance (tipo «jackleg»).

Los valores por defecto NO corresponden a un modelo comercial: son genéricos y se
pueden editar. La velocidad de penetración es ilustrativa (define la duración de la
animación), no un rendimiento real.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field, replace

import numpy as np

from app.sim3d.datos import FrenteSim, distancia_a_poligono, punto_en_poligono


@dataclass
class EspecEquipo:
    nombre: str = "Jumbo genérico (parámetros editables)"
    ancho: float = 1.30  # m, chasis
    alto: float = 2.00  # m, techo de protección
    largo: float = 8.5  # m
    holgura: float = 0.20  # m a cada lado
    brazos: int = 2  # 1 o 2 (se reduce a 1 si la sección es angosta)
    altura_pivote: float = 1.20  # m sobre el piso
    separacion_pivotes: float = 0.70  # m entre pivotes (2 brazos)
    distancia_pivote_frente: float = 4.2  # m del pivote al frente al perforar
    brazo_min: float = 1.8  # m
    brazo_max: float = 4.8  # m
    giro_max: float = 45.0  # ° a cada lado
    elev_min: float = -30.0  # °
    elev_max: float = 55.0  # °
    largo_viga: float = 3.2  # m
    carrera: float = 2.6  # m (longitud perforable con una barra)
    separacion_frente: float = 0.05  # m (centralizador apoyado)
    penetracion_ilustrativa: float = 2.0  # m/min (solo para la duración de la animación)
    cambio_taladro_s: float = 20.0  # s de reposicionamiento (ilustrativo)


@dataclass
class PoseBrazo:
    pivote: np.ndarray
    punta: np.ndarray  # punto donde el brazo sujeta la viga
    viga_inicio: np.ndarray  # extremo trasero de la viga
    viga_fin: np.ndarray  # extremo delantero (centralizador)
    giro: float  # °
    elevacion: float  # °
    largo_brazo: float
    alcanzable: bool
    motivo: str = ""


@dataclass
class PlanPerforacion:
    modo: str  # "jumbo" o "manual"
    brazos: int
    asignacion: list[list[int]]  # índices de taladros por brazo, en orden
    poses: dict[int, PoseBrazo] = field(default_factory=dict)
    inalcanzables: list[int] = field(default_factory=list)
    avisos: list[str] = field(default_factory=list)
    duraciones: dict[int, float] = field(default_factory=dict)  # s (ilustrativo) por taladro
    equipo: str = ""  # nombre del equipo (catálogo app/core/equipos.py)
    motivo: str = ""  # por qué se eligió


def pivotes(espec: EspecEquipo, brazos: int) -> list[np.ndarray]:
    y = -espec.distancia_pivote_frente
    z = espec.altura_pivote
    if brazos == 1:
        return [np.array([0.0, y, z])]
    s = espec.separacion_pivotes / 2
    return [np.array([-s, y, z]), np.array([s, y, z])]


def pose_para(espec: EspecEquipo, pivote: np.ndarray, collar: np.ndarray, direccion: np.ndarray,
              seccion=None) -> PoseBrazo:
    """Posición del brazo para que la viga quede alineada con el taladro (cinemática inversa)."""
    d = direccion / (np.linalg.norm(direccion) or 1.0)
    viga_fin = collar - d * espec.separacion_frente
    viga_inicio = viga_fin - d * espec.largo_viga
    punta = viga_fin - d * (espec.largo_viga * 0.55)  # el brazo toma la viga cerca del centro
    v = punta - pivote
    largo = float(np.linalg.norm(v))
    giro = math.degrees(math.atan2(v[0], v[1]))
    elev = math.degrees(math.atan2(v[2], math.hypot(v[0], v[1])))
    motivos = []
    if largo < espec.brazo_min - 1e-9:
        motivos.append(f"brazo muy corto ({largo:.2f} < {espec.brazo_min:.2f} m)")
    if largo > espec.brazo_max + 1e-9:
        motivos.append(f"fuera de alcance ({largo:.2f} > {espec.brazo_max:.2f} m)")
    if abs(giro) > espec.giro_max:
        motivos.append(f"giro {giro:.0f}° > ±{espec.giro_max:.0f}°")
    if not espec.elev_min <= elev <= espec.elev_max:
        motivos.append(f"elevación {elev:.0f}° fuera de [{espec.elev_min:.0f}, {espec.elev_max:.0f}]°")
    if seccion is not None:
        for t in np.linspace(0, 1, 7):
            q = viga_inicio + (viga_fin - viga_inicio) * t
            if not punto_en_poligono(q[0], q[2], seccion) and distancia_a_poligono(q[0], q[2], seccion) > 0.06:
                motivos.append("la viga choca con el contorno de la sección")
                break
    return PoseBrazo(pivote=pivote, punta=punta, viga_inicio=viga_inicio, viga_fin=viga_fin, giro=giro,
                     elevacion=elev, largo_brazo=largo, alcanzable=not motivos, motivo="; ".join(motivos))


def cabe_jumbo(espec: EspecEquipo, frente: FrenteSim) -> tuple[bool, str]:
    ancho_libre = frente.ancho - 2 * espec.holgura
    if ancho_libre < espec.ancho:
        return False, (f"La sección ({frente.ancho:.2f} m de ancho) no deja paso al jumbo "
                       f"({espec.ancho:.2f} m + {espec.holgura:.2f} m de holgura por lado).")
    if frente.alto - espec.holgura < espec.alto:
        return False, (f"La sección ({frente.alto:.2f} m de alto) es más baja que el jumbo "
                       f"({espec.alto:.2f} m + holgura).")
    return True, ""


def espec_de_equipo(eq) -> EspecEquipo:
    """Parámetros de cinemática a partir de un equipo del catálogo (app/core/equipos.py)."""
    base = EspecEquipo()
    if eq is None or eq.tipo != "jumbo":
        return base
    a_min, h_min = eq.seccion_minima()
    return replace(base, nombre=eq.nombre, ancho=eq.ancho or base.ancho, alto=eq.alto or base.alto,
                   largo=eq.largo or base.largo, brazos=eq.brazos,
                   holgura=max(min((a_min - (eq.ancho or base.ancho)) / 2, 0.6), 0.1),
                   carrera=eq.long_perforacion_max or base.carrera,
                   largo_viga=max(base.largo_viga, (eq.long_perforacion_max or base.carrera) + 0.6))


def seleccion_para(frente: FrenteSim):
    """Equipo del catálogo para este frente (o None si el catálogo no está disponible)."""
    try:
        from app.core.equipos import seleccionar
    except ImportError:
        return None
    dm = sorted(t.diametro_mm for t in frente.taladros if not t.alivio) or [None]
    return seleccionar(frente.ancho, frente.alto, "frente", longitud=frente.longitud_perforacion(),
                       diametro=dm[len(dm) // 2])


def planificar(frente: FrenteSim, espec: EspecEquipo | None = None, seleccion=None) -> PlanPerforacion:
    espec = espec or EspecEquipo()
    n = len(frente.taladros)
    ok, motivo = cabe_jumbo(espec, frente)
    if seleccion is not None and seleccion.equipo.tipo != "jumbo":
        ok, motivo = False, f"Equipo: {seleccion.equipo.nombre} — {seleccion.motivo}."
    # orden de perforación: primero alivios y arranque (centro), luego hacia afuera
    al = [t for t in frente.taladros if t.alivio]
    if al:
        cx = sum(t.x for t in al) / len(al); cz = sum(t.z for t in al) / len(al)
    else:
        cx, cz = 0.0, frente.alto / 2
    orden = sorted(range(n), key=lambda i: (not frente.taladros[i].alivio,
                                            math.hypot(frente.taladros[i].x - cx, frente.taladros[i].z - cz)))
    durac = {}
    for i, t in enumerate(frente.taladros):
        durac[i] = espec.cambio_taladro_s + 60.0 * t.longitud / max(espec.penetracion_ilustrativa, 0.05)
    if not ok:
        plan = PlanPerforacion(modo="manual", brazos=1, asignacion=[orden], duraciones=durac,
                               avisos=[motivo + ("" if seleccion is not None else
                                                 " Se simula una perforadora manual con barra de avance.")],
                               equipo=seleccion.equipo.nombre if seleccion is not None else "Jackleg",
                               motivo=seleccion.motivo if seleccion is not None else motivo)
        return plan
    brazos = espec.brazos if frente.ancho >= 3.0 else 1
    piv = pivotes(espec, brazos)
    plan = PlanPerforacion(modo="jumbo", brazos=brazos, asignacion=[[] for _ in range(brazos)], duraciones=durac,
                           equipo=espec.nombre, motivo=seleccion.motivo if seleccion is not None else "")
    for i in orden:
        t = frente.taladros[i]
        if t.longitud > espec.carrera + 1e-9:
            plan.avisos.append(f"{t.id}: longitud {t.longitud:.2f} m mayor que la carrera de la viga "
                               f"({espec.carrera:.2f} m); requiere barras de extensión.")
        candidatos = []
        for b in range(brazos):
            pose = pose_para(espec, piv[b], t.collar(), t.direccion, frente.seccion)
            lado_ok = brazos == 1 or (b == 0) == (t.x < 0) or abs(t.x) < 0.05
            candidatos.append((not pose.alcanzable, not lado_ok, len(plan.asignacion[b]), b, pose))
        candidatos.sort(key=lambda c: c[:4])
        _, _, _, b, pose = candidatos[0]
        plan.asignacion[b].append(i)
        plan.poses[i] = pose
        if not pose.alcanzable:
            plan.inalcanzables.append(i)
    if plan.inalcanzables:
        ejemplos = ", ".join(f"{frente.taladros[i].id} ({plan.poses[i].motivo})" for i in plan.inalcanzables[:4])
        plan.avisos.append(f"{len(plan.inalcanzables)} taladros fuera de las restricciones del equipo: {ejemplos}"
                           + ("…" if len(plan.inalcanzables) > 4 else ""))
    return plan


def interpolar_pose(a: PoseBrazo, b: PoseBrazo, s: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Transición suave (punta, viga_inicio, viga_fin) entre dos poses, s en [0, 1]."""
    s = s * s * (3 - 2 * s)
    return (a.punta + (b.punta - a.punta) * s, a.viga_inicio + (b.viga_inicio - a.viga_inicio) * s,
            a.viga_fin + (b.viga_fin - a.viga_fin) * s)


def pose_reposo(espec: EspecEquipo, pivote: np.ndarray) -> PoseBrazo:
    """Brazo recogido, viga horizontal hacia adelante."""
    d = np.array([0.0, 1.0, 0.0])
    punta = pivote + np.array([0.0, espec.brazo_min, 0.1])
    viga_fin = punta + d * espec.largo_viga * 0.55
    return PoseBrazo(pivote=pivote, punta=punta, viga_inicio=viga_fin - d * espec.largo_viga, viga_fin=viga_fin,
                     giro=0.0, elevacion=0.0, largo_brazo=espec.brazo_min, alcanzable=True)
