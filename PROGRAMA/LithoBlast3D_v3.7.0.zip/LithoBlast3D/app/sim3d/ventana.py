"""
Simulador 3D de Perforación Minera — ventana interactiva (PyVista + Qt).

Etapas (ver app/sim3d/ciclo.py), cada una reproducible sola o en cadena, con
iniciar / pausar / continuar / reiniciar, cámara lenta y velocidad.
Cámaras: superior, frontal, lateral, isométrica, libre, operador y cinematográfica.
Calidad gráfica: baja / media / alta (bloques, partículas, sombras, suavizado).

Qué es dato y qué es efecto (se muestra en pantalla):
- Datos del proyecto: sección, posición y longitud de taladros, carga, retardos/orden.
- Ilustrativo/cinematográfico: movimiento del equipo, polvo, destello, vibración de
  cámara, bloques y su trayectoria. No son predicciones de fragmentación, proyección ni
  vibraciones (no hay modelo calibrado).
"""

from __future__ import annotations

import math
import os
import time

os.environ.setdefault("QT_API", "pyside6")

import numpy as np  # noqa: E402
import pyvista as pv  # noqa: E402
from PySide6.QtCore import Qt, QTimer  # noqa: E402
from PySide6.QtWidgets import (  # noqa: E402
    QButtonGroup, QCheckBox, QComboBox, QDialog, QGridLayout, QGroupBox, QHBoxLayout, QLabel, QListWidget,
    QMessageBox, QProgressBar, QPushButton, QSlider, QSplitter, QVBoxLayout, QWidget,
)
from pyvistaqt import QtInteractor  # noqa: E402
from vtkmodules.vtkRenderingCore import vtkCellPicker  # noqa: E402

from app.sim3d import ciclo, fisica, fragmentos, modelos  # noqa: E402
from app.sim3d.audio import Sonidos  # noqa: E402
from app.sim3d.cinematica import (EspecEquipo, espec_de_equipo, interpolar_pose, pivotes, planificar,  # noqa: E402
                                  pose_reposo, seleccion_para)
from app.sim3d.datos import ErrorSimulacion, casco_convexo, frente_desde_proyecto  # noqa: E402
from app.ui.tema import COLORES  # noqa: E402

ESTILOS = ["Presentación (vista en corte)", "Realista (galería cerrada)"]
COLORES_MINERAL = {"Cian (resaltado)": "#22c7e8", "Roca (textura)": None, "Ocre": "#c98b2b",
                   "Verde (cobre)": "#3fae6a"}
AMARILLO = "#e8b923"
AZUL_TITULO = "#1e9fe0"
POST_VOLADURA = ("fragmentacion", "resultado", "limpieza", "desatado", "sostenimiento")

CALIDADES = {
    "Baja": {"fragmentos": 40, "particulas": 300, "sombras": False, "aa": None, "textura": 128},
    "Media": {"fragmentos": 90, "particulas": 900, "sombras": False, "aa": "fxaa", "textura": 256},
    "Alta": {"fragmentos": 150, "particulas": 1800, "sombras": True, "aa": "ssaa", "textura": 512},
}
CAMARAS = ["Corte lateral", "Superior", "Frontal", "Lateral", "Isométrica", "Libre", "Operador", "Cinematográfica"]
AVISO = ("Datos del proyecto: sección, taladros, cargas y retardos. Movimiento del equipo, polvo, destello, "
         "vibración de cámara y bloques: ILUSTRATIVO (sin modelo calibrado; no predice fragmentación, "
         "proyección ni vibraciones).")


def _suave(s):
    s = min(max(s, 0.0), 1.0)
    return s * s * (3 - 2 * s)


def _hex(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) / 255 for i in (0, 2, 4))


class VentanaSimulador(QDialog):
    def __init__(self, documento, parent=None, etapa_inicial: int | None = None):
        super().__init__(parent)
        self.setWindowTitle("Simulador 3D de Perforación Minera")
        from app.ui.tema import ajustar_a_pantalla
        ajustar_a_pantalla(self, 1500, 900)
        self.doc = documento
        self.frente = frente_desde_proyecto(documento.proyecto)  # puede lanzar ErrorSimulacion
        self.seleccion = seleccion_para(self.frente)  # catálogo de equipos (app/core/equipos.py)
        self.espec = espec_de_equipo(self.seleccion.equipo if self.seleccion else None)
        self.plan = planificar(self.frente, self.espec, self.seleccion)
        self.reloj = ciclo.Reloj(self._etapas_ajustadas())
        self.calidad = "Media"
        self.modo_camara = "Cinematográfica"
        self.sonidos = Sonidos()
        self.rng = np.random.default_rng(11)
        self._t_real = None
        self._sacudida = 0.0
        self._herramienta = None
        self._medida = []
        self._actores_medida = []
        self._ultima_etapa_preparada = None
        self._fisica_lista = False
        self._construir_ui()
        self._construir_escena()
        self._llenar_info()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(33)
        self._preparar_etapa(0)
        self._dibujar(0, 0.0)
        self._camara("Cinematográfica")
        if etapa_inicial is not None:
            self.lista.setCurrentRow(etapa_inicial)

    # ================================================================= etapas
    def _etapas_ajustadas(self):
        from dataclasses import replace
        por_brazo = max((len(a) for a in self.plan.asignacion), default=1)
        dur_perf = float(np.clip(2.0 + 1.6 * por_brazo, 10, 120))
        n_carg = sum(1 for t in self.frente.taladros if not t.alivio)
        dur_carg = float(np.clip(4 + 0.35 * n_carg, 8, 40))
        etapas = []
        for e in ciclo.ETAPAS:
            if e.clave == "perforacion":
                e = replace(e, duracion=dur_perf)
            elif e.clave == "carguio":
                e = replace(e, duracion=dur_carg)
            etapas.append(e)
        # agenda de perforación (segundos de animación dentro de la etapa)
        self.agenda = []
        for b, lista in enumerate(self.plan.asignacion):
            if not lista:
                self.agenda.append([]); continue
            pesos = np.array([self.plan.duraciones[i] for i in lista], float)
            pesos = pesos / pesos.sum() * (dur_perf - 1.0)
            t0 = 0.5
            filas = []
            for i, w in zip(lista, pesos):
                filas.append((i, t0, t0 + w))
                t0 += w
            self.agenda.append(filas)
        return etapas

    # ================================================================= interfaz
    def _construir_ui(self):
        raiz = QHBoxLayout(self)
        div = QSplitter(Qt.Orientation.Horizontal)
        raiz.addWidget(div)
        izq = QWidget(); li = QVBoxLayout(izq)

        g = QGroupBox("Etapas"); lg = QVBoxLayout(g)
        self.lista = QListWidget()
        for e in self.reloj.etapas:
            self.lista.addItem(f"{e.nombre}  ({e.duracion:.0f} s)")
        self.lista.setCurrentRow(0)
        lg.addWidget(self.lista)
        self.cadena = QCheckBox("Reproducir en cadena (todas las etapas)"); self.cadena.setChecked(True)
        lg.addWidget(self.cadena)
        botones = QGridLayout()
        self.b_iniciar = QPushButton("▶ Iniciar"); self.b_pausar = QPushButton("⏸ Pausar")
        self.b_continuar = QPushButton("⏵ Continuar"); self.b_reiniciar = QPushButton("⟲ Reiniciar")
        self.b_etapa = QPushButton("▶ Solo esta etapa")
        for k, b in enumerate((self.b_iniciar, self.b_pausar, self.b_continuar, self.b_reiniciar)):
            botones.addWidget(b, k // 2, k % 2)
        botones.addWidget(self.b_etapa, 2, 0, 1, 2)
        lg.addLayout(botones)
        self.lenta = QCheckBox("Cámara lenta (×0.25)")
        lg.addWidget(self.lenta)
        fila = QHBoxLayout(); fila.addWidget(QLabel("Velocidad"))
        self.vel = QSlider(Qt.Orientation.Horizontal); self.vel.setRange(1, 80); self.vel.setValue(10)
        self.lab_vel = QLabel("1.0×")
        fila.addWidget(self.vel, 1); fila.addWidget(self.lab_vel)
        lg.addLayout(fila)
        li.addWidget(g)

        g = QGroupBox("Cámara"); lg = QGridLayout(g)
        self.grupo_cam = QButtonGroup(self)
        for k, nombre in enumerate(CAMARAS):
            b = QPushButton(nombre); b.setCheckable(True)
            if nombre == "Cinematográfica":
                b.setChecked(True)
            b.setProperty("camara", nombre)
            self.grupo_cam.addButton(b)
            lg.addWidget(b, k // 2, k % 2)
            b.clicked.connect(lambda _=False, n=nombre: self._camara(n))
        li.addWidget(g)

        g = QGroupBox("Visualización"); lg = QGridLayout(g)
        self.cb_calidad = QComboBox(); self.cb_calidad.addItems(list(CALIDADES)); self.cb_calidad.setCurrentText("Media")
        lg.addWidget(QLabel("Calidad gráfica"), 0, 0); lg.addWidget(self.cb_calidad, 0, 1)
        self.cb_estilo = QComboBox(); self.cb_estilo.addItems(ESTILOS)
        self.cb_mineral = QComboBox(); self.cb_mineral.addItems(list(COLORES_MINERAL))
        lg.addWidget(QLabel("Estilo"), 6, 0); lg.addWidget(self.cb_estilo, 6, 1)
        lg.addWidget(QLabel("Material volado"), 7, 0); lg.addWidget(self.cb_mineral, 7, 1)
        self.chk_rejilla = QCheckBox("Cuadrícula"); self.chk_rotulos = QCheckBox("Rótulos de taladros")
        self.chk_polvo = QCheckBox("Partículas / polvo"); self.chk_polvo.setChecked(True)
        self.chk_sonido = QCheckBox("Sonido"); self.chk_sonido.setChecked(self.sonidos.ok)
        self.chk_sonido.setEnabled(self.sonidos.ok)
        self.chk_comparar = QCheckBox("Comparar antes / después")
        for k, w in enumerate((self.chk_rejilla, self.chk_rotulos, self.chk_polvo, self.chk_sonido, self.chk_comparar)):
            lg.addWidget(w, 1 + k // 2, k % 2)
        self.b_medir = QPushButton("📏 Medir"); self.b_medir.setCheckable(True)
        self.b_selec = QPushButton("🔍 Seleccionar"); self.b_selec.setCheckable(True); self.b_selec.setChecked(True)
        lg.addWidget(self.b_selec, 4, 0); lg.addWidget(self.b_medir, 4, 1)
        self.b_equipo = QPushButton("⚙ Parámetros del equipo…")
        lg.addWidget(self.b_equipo, 5, 0, 1, 2)
        li.addWidget(g)
        li.addStretch(1)
        from app.ui.tema import con_desplazamiento
        div.addWidget(con_desplazamiento(izq))

        centro = QWidget(); lc = QVBoxLayout(centro); lc.setContentsMargins(0, 0, 0, 0)
        self.plotter = QtInteractor(centro)
        lc.addWidget(self.plotter.interactor, 1)
        self.progreso = QProgressBar(); self.progreso.setRange(0, 1000)
        lc.addWidget(self.progreso)
        self.estado = QLabel(); self.estado.setWordWrap(True)
        lc.addWidget(self.estado)
        div.addWidget(centro)

        der = QWidget(); ld = QVBoxLayout(der)
        self.info = QLabel(); self.info.setWordWrap(True); self.info.setTextFormat(Qt.TextFormat.RichText)
        self.info.setAlignment(Qt.AlignmentFlag.AlignTop)
        ld.addWidget(self.info, 1)
        self.propiedades = QLabel("Haz clic en un taladro para ver sus datos."); self.propiedades.setWordWrap(True)
        self.propiedades.setTextFormat(Qt.TextFormat.RichText)
        ld.addWidget(self.propiedades)
        aviso = QLabel("⚠ " + AVISO); aviso.setWordWrap(True); aviso.setObjectName("Insignia")
        ld.addWidget(aviso)
        div.addWidget(der)
        div.setSizes([300, 900, 320])

        self.b_iniciar.clicked.connect(self._iniciar)
        self.b_etapa.clicked.connect(self._solo_etapa)
        self.b_pausar.clicked.connect(self._pausar)
        self.b_continuar.clicked.connect(self._continuar)
        self.b_reiniciar.clicked.connect(self._reiniciar)
        self.lenta.toggled.connect(lambda v: setattr(self.reloj, "camara_lenta", v))
        self.vel.valueChanged.connect(self._velocidad)
        self.cb_calidad.currentTextChanged.connect(self._cambiar_calidad)
        self.cb_estilo.currentTextChanged.connect(lambda _t: self._cambiar_calidad(self.calidad))
        self.cb_mineral.currentTextChanged.connect(lambda _t: self._preparar_etapa(self.reloj.indice, forzar=True))
        self.chk_rejilla.toggled.connect(self._rejilla)
        self.chk_rotulos.toggled.connect(self._rotulos)
        self.chk_sonido.toggled.connect(lambda v: self.sonidos.set_silencio(not v))
        self.chk_comparar.toggled.connect(self._comparar)
        self.lista.currentRowChanged.connect(self._ver_etapa)
        self.b_equipo.clicked.connect(self._editar_equipo)
        self.b_medir.toggled.connect(lambda v: self._set_herramienta("medir" if v else None))
        self.b_selec.toggled.connect(lambda v: self._set_herramienta(None if v else self._herramienta))

        self._picker = vtkCellPicker()
        self._picker.SetTolerance(0.005)
        iren = self.plotter.iren.interactor
        iren.AddObserver("LeftButtonPressEvent", self._al_presionar, 10.0)
        iren.AddObserver("LeftButtonReleaseEvent", self._al_soltar, 10.0)
        self._pos_presion = None

    # ================================================================= escena
    def _construir_escena(self):
        pl = self.plotter
        pl.clear()
        q = CALIDADES[self.calidad]
        self.corte = self.cb_estilo.currentText().startswith("Presentación")
        if self.corte:
            pl.set_background("#000000", top="#202224")
        else:
            pl.set_background("#0d0f11", top="#1c2127")
        try:
            pl.remove_all_lights()
        except Exception:  # noqa: BLE001
            pass
        f = self.frente
        sec = f.seccion
        self.avance = max(0.3, min(f.avance, f.longitud_perforacion()))
        self.tex = modelos.textura_roca(q["textura"])
        self.tex_oscura = modelos.textura_roca(q["textura"], semilla=9, tono=(92, 84, 76))
        # luces: ambiente tenue + foco cenital + luces del equipo + destello
        self.luz_amb = pv.Light(light_type="headlight", intensity=0.55 if self.corte else 0.35)
        pl.add_light(self.luz_amb)
        if self.corte:
            self.luz_clave = pv.Light(position=(9, -10, 9), focal_point=(0, -3, 0), positional=False, intensity=0.75,
                                      color="#ffffff")
            pl.add_light(self.luz_clave)
        self.luz_techo = pv.Light(position=(0, -6, f.alto * 0.95), focal_point=(0, 0, f.alto * 0.4),
                                  positional=True, cone_angle=70, intensity=0.55, color="#ffe9c8")
        pl.add_light(self.luz_techo)
        self.luces_equipo = [pv.Light(position=(0, -10, 1.2), focal_point=(0, 0, 1.2), positional=True,
                                      cone_angle=35, intensity=0.0, color="#fff4dc") for _ in range(2)]
        for lz in self.luces_equipo:
            pl.add_light(lz)
        self.luz_destello = pv.Light(position=(0, -0.5, f.alto / 2), positional=True, intensity=0.0,
                                     color="#ffb04a", cone_angle=89)
        pl.add_light(self.luz_destello)

        # labor y roca
        self.tex_shot = modelos.textura_shotcrete(q["textura"])
        if self.corte:
            # vista en corte: piso claro, pared izquierda con concreto lanzado y pernos, sin techo ni pared derecha
            self.a_piso = pl.add_mesh(modelos.piso_exterior(sec, -26.0, self.avance + 6.0), color="#d8d5ce",
                                      ambient=0.35, pickable=True, name="piso")
            self.a_labor = pl.add_mesh(modelos.labor_tramo(sec, -26.0, 0.0, corte=True, piso=False),
                                       texture=self.tex_shot, ambient=0.35, diffuse=0.75, pickable=True, name="labor")
            self.a_tramo = pl.add_mesh(modelos.labor_tramo(sec, 0.0, self.avance, corte=True, piso=False),
                                       texture=self.tex, ambient=0.3, pickable=True, name="tramo")
            self.a_shot = pl.add_mesh(modelos.labor_tramo(sec, 0.0, self.avance, corte=True, piso=False,
                                                          desplazar=0.03), texture=self.tex_shot, ambient=0.35,
                                      opacity=0.0, pickable=False, name="shot")
            self.a_roca_post = pl.add_mesh(modelos.roca_frontal(sec, self.avance, 7.0), texture=self.tex_oscura,
                                           ambient=0.2, pickable=True, name="roca_post")
        else:
            self.a_piso = None
            self.a_labor = pl.add_mesh(modelos.labor(sec, 24.0, self.avance), texture=self.tex, smooth_shading=True,
                                       ambient=0.15, diffuse=0.85, specular=0.05, pickable=True, name="labor")
            self.a_tramo = None
            self.a_shot = pl.add_mesh(modelos.labor_tramo(sec, 0.0, self.avance, desplazar=0.03, piso=False),
                                      texture=self.tex_shot, ambient=0.25, opacity=0.0, pickable=False, name="shot")
            self.a_roca_post = pl.add_mesh(modelos.roca_frontal(sec, self.avance), texture=self.tex_oscura,
                                           ambient=0.15, pickable=True, name="roca_post")
        # ducto de ventilación
        self.a_ducto = pl.add_mesh(modelos.ducto_ventilacion(sec, -24.0, -3.0), color=AMARILLO, specular=0.4,
                                   smooth_shading=True, pickable=False, name="ducto")
        # pernos del tramo nuevo (patrón en rombos, ilustrativo)
        self.pos_pernos = self._posiciones_pernos(sec)
        p_m = modelos.perno()
        self.a_pernos = []
        for k, (p, nrm) in enumerate(self.pos_pernos):
            a = pl.add_mesh(p_m, color="#4a4d52", specular=0.5, pickable=False, name=f"perno{k}")
            a.user_matrix = modelos.matriz(p, nrm)
            self.a_pernos.append(a)
        # bloques fracturables (cubren el volumen a volar)
        cargados = [i for i, t in enumerate(f.taladros) if not t.alivio]
        pts = np.array([[f.taladros[i].x, f.taladros[i].z] for i in cargados]) if cargados else np.zeros((0, 2))
        convexa = casco_convexo(sec)
        frs = fragmentos.generar(convexa, self.avance, pts, q["fragmentos"])
        self.frags = frs
        self.a_frags = []
        for k, fr in enumerate(frs):
            malla = modelos.fragmento_malla(fr.vertices)
            a = pl.add_mesh(malla, texture=self.tex, smooth_shading=False, ambient=0.18, pickable=False,
                            name=f"frag{k}")
            self.a_frags.append(a)
        orden = f.orden_salida()
        self.salida_frag = np.array([orden[cargados[fr.taladro]] if cargados else 0.0 for fr in frs])
        radios = np.array([max(0.05, (3 * fr.volumen / (4 * math.pi)) ** (1 / 3)) for fr in frs])
        masas = np.array([fr.volumen * f.densidad_roca * 1000 for fr in frs])
        xs = [p[0] for p in sec]
        self.mundo = fisica.MundoFisico([fr.centro for fr in frs], radios, masas,
                                        medio_ancho=(max(xs) - min(xs)) / 2, alto=f.alto, y_frente_final=self.avance)
        self.mundo_inicial = (radios, masas)
        al = [t for t in f.taladros if t.alivio]
        if al:
            self.centro_arranque = np.array([np.mean([t.x for t in al]), self.avance / 2, np.mean([t.z for t in al])])
        else:
            self.centro_arranque = np.array([0.0, self.avance / 2, f.alto / 2])

        # marcas de los taladros en el frente (pintura) y bocas perforadas
        self.a_marcas, self.a_bocas, self.a_tubos = [], [], []
        for i, t in enumerate(f.taladros):
            r = max(t.diametro_mm / 2000, 0.02)
            m = pv.Disc(center=(t.x, -0.004, t.z), inner=0, outer=r * 2.6, normal=(0, -1, 0), c_res=20)
            a = pl.add_mesh(m, color=t.color_explosivo if not t.alivio else "#f2f2f2", lighting=False,
                            pickable=True, name=f"marca{i}")
            self.a_marcas.append(a)
            b = pv.Disc(center=(t.x, -0.006, t.z), inner=0, outer=r, normal=(0, -1, 0), c_res=20)
            ab = pl.add_mesh(b, color="#050505", lighting=False, pickable=True, name=f"boca{i}")
            self.a_bocas.append(ab)
            tubo = pv.Cylinder(center=t.collar() + t.direccion * t.longitud / 2, direction=t.direccion,
                               radius=r, height=t.longitud, resolution=16)
            at = pl.add_mesh(tubo, color="#f4f4f4" if self.corte else "#1a1a1a", opacity=0.9, pickable=True,
                             lighting=not self.corte, name=f"tubo{i}")
            self.a_tubos.append(at)
        self._mapa_actor = {}
        for lista in (self.a_marcas, self.a_bocas, self.a_tubos):
            for i, a in enumerate(lista):
                self._mapa_actor[a.GetAddressAsString("vtkObject")] = i
        # cartuchos para el carguío (por taladro cargado)
        self.a_cart = {}
        for i, t in enumerate(f.taladros):
            if t.alivio or t.longitud_carga <= 0:
                continue
            n = t.cartuchos if t.cartuchos > 0 else max(1, round(t.longitud_carga / 0.2))
            n = min(n, 14)
            largo = min(t.longitud_carga, t.longitud) / n
            r = max(t.diametro_mm / 2000 * 0.8, 0.015)
            lst = []
            for k in range(n):
                c = modelos.cartucho(largo * 0.92, r)
                inicio = t.collar() + t.direccion * (t.longitud - (k + 1) * largo)
                a = pl.add_mesh(c, color=t.color_explosivo, pickable=False, name=f"cart{i}_{k}")
                a.user_matrix = modelos.matriz(inicio, t.direccion)
                lst.append(a)
            self.a_cart[i] = lst
        # equipo
        self._construir_equipo()
        self._construir_vehiculo()
        # polvo
        n = q["particulas"]
        self.pol_x = np.zeros((n, 3)); self.pol_v = np.zeros((n, 3)); self.pol_vida = np.zeros(n)
        self.pol_malla = pv.PolyData(np.full((n, 3), -999.0))
        self.a_polvo = pl.add_mesh(self.pol_malla, color="#a89c8c", point_size=14 if self.calidad != "Baja" else 9,
                                   render_points_as_spheres=False, opacity=0.18, lighting=False, pickable=False,
                                   name="polvo")
        # destello
        self.a_destello = pl.add_mesh(pv.Sphere(radius=1.0, center=(0, 0, 0)),
                                      color="#ffcf7a", opacity=0.0, lighting=False, pickable=False, name="destello")
        # contorno original (comparación)
        s3 = np.array([[x, -0.01, z] for x, z in sec])
        n3 = len(s3)
        self.a_contorno0 = pl.add_mesh(pv.PolyData(s3, lines=np.array([n3 + 1, *range(n3), 0])),
                                       color=COLORES["acento"], line_width=3, pickable=False, name="cont0")
        s4 = s3.copy(); s4[:, 1] = self.avance - 0.01
        self.a_contorno1 = pl.add_mesh(pv.PolyData(s4, lines=np.array([n3 + 1, *range(n3), 0])),
                                       color="#ff5fd2", line_width=3, pickable=False, name="cont1")
        prisma = modelos.roca_frontal(sec, 0.0, self.avance)
        self.a_fantasma = pl.add_mesh(prisma, style="wireframe", color="#9aa3ad", opacity=0.35, pickable=False,
                                      name="fantasma")
        self.a_contorno1.SetVisibility(False); self.a_fantasma.SetVisibility(False)
        self.a_rotulos = None
        self.a_titulo = None
        self.a_subtitulo = None
        self._aplicar_calidad()
        if self.chk_rejilla.isChecked():
            self._rejilla(True)

    # ----------------------------------------------------------------- piezas del ciclo post-voladura
    def _posiciones_pernos(self, sec):
        """Pernos en rombos (1.2 m) sobre paredes y techo del tramo nuevo. Patrón ILUSTRATIVO,
        no es un diseño de sostenimiento."""
        secc, usar = modelos._segmentos_seccion(sec, self.corte, piso=False)
        centro = np.array([0.0, secc[:, 1].mean()])
        paso = 1.2
        filas = [y for y in np.arange(0.35, max(self.avance - 0.15, 0.36), paso)] or [self.avance / 2]
        # recorrido continuo por el contorno (longitud de arco acumulada)
        tramos = []
        s_acum = 0.0
        for i, j in usar:
            a, b = secc[i], secc[j]
            L = float(np.linalg.norm(b - a))
            if L > 1e-6:
                tramos.append((s_acum, L, a, b))
            s_acum += L
        res = []
        for fila, y in enumerate(filas):
            s_pos = 0.4 + (paso / 2 if fila % 2 else 0.0)
            while s_pos < s_acum - 0.2:
                for s0, L, a, b in tramos:
                    if s0 <= s_pos < s0 + L:
                        q = a + (b - a) * ((s_pos - s0) / L)
                        if q[1] > 0.6:  # no en el piso ni al pie de la pared
                            nrm = q - centro
                            nrm = nrm / (np.linalg.norm(nrm) or 1)
                            res.append((np.array([q[0] - nrm[0] * 0.035, y, q[1] - nrm[1] * 0.035]),
                                        np.array([nrm[0], 0.0, nrm[1]])))
                        break
                s_pos += paso
        res.sort(key=lambda r: (r[0][1], -r[0][2]))
        return res

    def _construir_vehiculo(self):
        pl = self.plotter
        v = modelos.PiezasVehiculo()
        self.veh = v
        self.a_veh = []
        for malla, color, kw in [(v.trasero, AMARILLO, {}), (v.motor, "#2f3338", {}), (v.delantero, AMARILLO, {}),
                                 (v.articulacion, "#2b2e33", {}), (v.cabina, "#2f3439", {}), (v.techo, AMARILLO, {}),
                                 (v.vidrio, "#7fb8d9", {"opacity": 0.35})] + \
                [(r, "#141414", {}) for r in v.ruedas] + [(ll, "#9aa0a6", {}) for ll in v.llantas] + \
                [(lz, "#fffbe6", {"lighting": False}) for lz in v.luces]:
            self.a_veh.append(pl.add_mesh(malla, color=color, smooth_shading=True, specular=0.3, pickable=False, **kw))
        self.a_herr = {
            "cuchara": pl.add_mesh(v.cuchara, color=AMARILLO, specular=0.3, pickable=False),
            "carga": pl.add_mesh(v.carga, color="#22c7e8", pickable=False),
            "seg1": pl.add_mesh(v.segmento, color=AMARILLO, pickable=False),
            "seg2": pl.add_mesh(v.segmento, color="#c99c18", pickable=False),
            "cesta": pl.add_mesh(v.cesta, color=AMARILLO, pickable=False),
            "persona": pl.add_mesh(v.persona, color="#ff8c1a", pickable=False),
            "martillo": pl.add_mesh(v.martillo, color="#d0d3d6", specular=0.6, pickable=False),
            "boquilla": pl.add_mesh(v.boquilla, color="#d0d3d6", pickable=False),
            "viga_perno": pl.add_mesh(v.viga_perno, color="#4a4f55", pickable=False),
            "tanque": pl.add_mesh(v.tanque, color="#b9bcc0", specular=0.5, pickable=False),
        }
        self._rol_vehiculo(None)

    HERRAMIENTAS = {"lhd": ("cuchara",), "carguio": ("seg1", "seg2", "cesta", "persona", "tanque"),
                    "desatado": ("seg1", "seg2", "martillo"), "shotcrete": ("seg1", "seg2", "boquilla", "tanque"),
                    "pernos": ("seg1", "seg2", "viga_perno")}

    def _rol_vehiculo(self, rol):
        self.rol = rol
        for a in self.a_veh:
            a.SetVisibility(bool(rol is not None))
        visibles = self.HERRAMIENTAS.get(rol, ())
        for k, a in self.a_herr.items():
            a.SetVisibility(bool(k in visibles))

    def _poner_vehiculo(self, y_frente, objetivo=None, angulo_cuchara=0.0, con_carga=False):
        """Coloca el vehículo con su frente en y_frente; mueve brazo/cuchara hacia «objetivo»."""
        L = self.veh.largo
        y0 = y_frente - L * 0.85
        M = np.eye(4); M[:3, 3] = (0.0, y0, 0.0)
        for a in self.a_veh:
            a.user_matrix = M
        h = self.a_herr
        if self.rol == "lhd":
            ang = math.radians(angulo_cuchara)
            piv = np.array([0.0, y0 + L * 0.85, 0.35])
            Mc = modelos.matriz(piv, (0.0, math.cos(ang), math.sin(ang)))
            h["cuchara"].user_matrix = Mc
            h["carga"].user_matrix = Mc
            h["carga"].SetVisibility(bool(con_carga))
            return
        if "tanque" in self.HERRAMIENTAS.get(self.rol, ()):
            h["tanque"].user_matrix = M
        if objetivo is None:
            return
        B = np.array([0.0, y0 + L * 0.8, 1.6])
        T = np.asarray(objetivo, float)
        E = B + (T - B) * 0.45 + np.array([0.0, 0.0, 0.6])
        h["seg1"].user_matrix = modelos.matriz(B, E - B, (1, float(np.linalg.norm(E - B)), 1))
        d = T - E
        Ld = float(np.linalg.norm(d)) or 1.0
        du = d / Ld
        if self.rol == "carguio":
            h["seg2"].user_matrix = modelos.matriz(E, d, (1, Ld, 1))
            h["cesta"].user_matrix = modelos.matriz(T)
            h["persona"].user_matrix = modelos.matriz(T + np.array([0.0, 0.1, 0.08]))
        else:
            largo_herr = {"desatado": 0.75, "shotcrete": 0.5, "pernos": 1.0}[self.rol]
            base_h = T - du * largo_herr
            h["seg2"].user_matrix = modelos.matriz(E, base_h - E, (1, float(np.linalg.norm(base_h - E)) or 0.05, 1))
            clave = {"desatado": "martillo", "shotcrete": "boquilla", "pernos": "viga_perno"}[self.rol]
            esc = (1, largo_herr, 1) if self.rol == "pernos" else (1, 1, 1)
            h[clave].user_matrix = modelos.matriz(base_h, du, esc)

    def _emitir(self, origen, n, v_media, dispersion=0.4, vida=(1.0, 3.0)):
        if not self.chk_polvo.isChecked():
            return
        libres = np.nonzero(self.pol_vida <= 0)[0][:max(1, int(n))]
        if len(libres) == 0:
            return
        self.pol_x[libres] = np.asarray(origen, float) + self.rng.normal(0, 0.05, (len(libres), 3))
        self.pol_v[libres] = np.asarray(v_media, float) + self.rng.normal(0, dispersion, (len(libres), 3))
        self.pol_vida[libres] = self.rng.uniform(vida[0], vida[1], len(libres))

    def _textura_bloques(self, mineral: bool):
        color = COLORES_MINERAL.get(self.cb_mineral.currentText())
        for a in self.a_frags:
            try:
                if mineral and color:
                    a.texture = None
                    a.prop.color = _hex(color)
                else:
                    a.texture = self.tex
                    a.prop.color = (1.0, 1.0, 1.0)
            except Exception:  # noqa: BLE001
                pass

    def _titulos(self, clave):
        pl = self.plotter
        for nombre in ("a_titulo", "a_subtitulo"):
            act = getattr(self, nombre, None)
            if act is not None:
                try:
                    pl.remove_actor(act, render=False)
                except Exception:  # noqa: BLE001
                    pass
        etapa = next(e for e in self.reloj.etapas if e.clave == clave)
        self.a_titulo = pl.add_text(ciclo.TITULOS.get(clave, etapa.nombre), position="lower_right", font_size=16,
                                    color=AZUL_TITULO, name="titulo")
        self.a_subtitulo = pl.add_text(etapa.descripcion + ("" if etapa.validado else "  (ilustrativo)"),
                                       position="lower_left", font_size=9, color="#ffffff", shadow=True,
                                       name="subtitulo")

    def _construir_equipo(self):
        pl = self.plotter
        e = self.espec
        self.a_equipo, self.a_brazos, self.a_manual = [], [], None
        if self.plan.modo == "jumbo":
            p = modelos.PiezasJumbo(e)
            self.piezas = p
            amarillo = "#e8b923"
            for malla, color, kw in [(p.chasis, amarillo, {}), (p.motor, "#3b3f45", {}), (p.cabina, "#2f3439", {}),
                                     (p.techo, amarillo, {}), (p.postes, "#2a2d31", {}),
                                     (p.vidrio, "#7fb8d9", {"opacity": 0.35})] + \
                    [(r, "#151515", {}) for r in p.ruedas] + [(ll, "#9aa0a6", {}) for ll in p.llantas] + \
                    [(lz, "#fffbe6", {"lighting": False}) for lz in p.luces] + [(g, "#5b6066", {}) for g in p.gatos]:
                a = pl.add_mesh(malla, color=color, smooth_shading=True, specular=0.3, pickable=False, **kw)
                self.a_equipo.append(a)
            self.piv = pivotes(e, self.plan.brazos)
            for b in range(self.plan.brazos):
                partes = {
                    "torreta": pl.add_mesh(p.torreta, color="#3b3f45", pickable=False),
                    "brazo": pl.add_mesh(p.brazo, color=amarillo, smooth_shading=True, pickable=False),
                    "tel": pl.add_mesh(p.brazo_tel, color="#c99c18", pickable=False),
                    "viga": pl.add_mesh(p.viga, color="#4a4f55", specular=0.4, pickable=False),
                    "perf": pl.add_mesh(p.perforadora, color="#d0d3d6", specular=0.6, pickable=False),
                    "barra": pl.add_mesh(p.barra, color="#8a8f96", specular=0.8, pickable=False),
                    "broca": pl.add_mesh(p.broca, color="#c0c4c8", specular=0.9, pickable=False),
                    "cent": pl.add_mesh(p.centralizador, color="#2b2e33", pickable=False),
                }
                self.a_brazos.append(partes)
        else:
            m = modelos.PiezasManual()
            self.piezas_m = m
            self.a_manual = {
                "cuerpo": pl.add_mesh(m.cuerpo, color="#c9ccd0", specular=0.6, pickable=False),
                "emp": pl.add_mesh(m.empunadura, color="#222222", pickable=False),
                "pata": pl.add_mesh(m.pata, color="#d8a21c", pickable=False),
                "barra": pl.add_mesh(m.barra, color="#8a8f96", specular=0.8, pickable=False),
                "broca": pl.add_mesh(m.broca, color="#c0c4c8", pickable=False),
            }
            try:  # operador de la perforadora manual (escala humana)
                ropa, casco, piernas = modelos.operador()
                self.a_manual["op_ropa"] = pl.add_mesh(ropa, color="#e8752a", pickable=False)
                self.a_manual["op_casco"] = pl.add_mesh(casco, color="#f2f2f2", specular=0.4, pickable=False)
                self.a_manual["op_piernas"] = pl.add_mesh(piernas, color="#1d1f22", pickable=False)
            except Exception:  # noqa: BLE001 — sin operador si la versión de PyVista no tiene alguna forma
                pass

    def _aplicar_calidad(self):
        q = CALIDADES[self.calidad]
        pl = self.plotter
        for fn in (pl.disable_shadows, pl.disable_anti_aliasing):
            try:
                fn()
            except Exception:  # noqa: BLE001
                pass
        try:
            if q["aa"]:
                pl.enable_anti_aliasing(q["aa"])
            if q["sombras"]:
                pl.enable_shadows()
        except Exception:  # noqa: BLE001
            pass

    def _cambiar_calidad(self, texto):
        self.calidad = texto
        indice, t = self.reloj.indice, self.reloj.t
        en_marcha = self.reloj.en_marcha
        self.reloj.pausar()
        cam = self.plotter.camera_position
        self._construir_escena()
        self._ultima_etapa_preparada = None
        self._fisica_lista = False
        self._preparar_etapa(indice)
        self._dibujar(indice, t)
        self.plotter.camera_position = cam
        if en_marcha:
            self.reloj.continuar()

    # ================================================================= información
    def _llenar_info(self):
        f = self.frente
        car = [t for t in f.taladros if not t.alivio]
        kg = sum(t.carga_kg for t in car)
        plan = self.plan
        perforacion_ilustr = sum(plan.duraciones.values()) / 60 / max(plan.brazos, 1)
        avisos = "".join(f"<li>{a}</li>" for a in (f.avisos + plan.avisos)[:8])
        self.info.setText(
            f"<b>{f.nombre}</b><br>Origen de la malla: <b>{f.origen}</b><br>"
            f"Sección: {f.ancho:.2f} m × {f.alto:.2f} m · avance de diseño {f.avance:.2f} m<br>"
            f"Taladros: {len(f.taladros)} ({len(car)} cargados, {len(f.taladros) - len(car)} alivios)<br>"
            f"Longitud de perforación: {f.longitud_perforacion():.2f} m<br>"
            f"Explosivo total (del proyecto): {kg:.1f} kg<br>"
            f"Salida: {'tiempos (ms) del proyecto' if f.escala_tiempo_real() else 'ORDEN de retardos (sin escala de tiempo real)'}<br><br>"
            f"<b>Equipo:</b> {'jumbo de ' + str(plan.brazos) + ' brazo(s)' if plan.modo == 'jumbo' else 'perforadora manual con barra de avance'}"
            f" — {plan.equipo or self.espec.nombre}<br>"
            + (f"<i>Por qué:</i> {plan.motivo}<br>" if plan.motivo else "") +
            f"Tiempo de perforación ilustrativo: {perforacion_ilustr:.0f} min "
            f"(penetración supuesta {self.espec.penetracion_ilustrativa:g} m/min, editable en el código; no es un rendimiento)<br>"
            + (f"<b>Restricciones:</b><ul>{avisos}</ul>" if avisos else "Todas las posiciones son alcanzables con el modelo de equipo."))

    # ================================================================= control
    def _iniciar(self):
        self._preparar_etapa(0, forzar=True)
        self.reloj.iniciar(0, cadena=self.cadena.isChecked())
        self.lista.blockSignals(True); self.lista.setCurrentRow(0); self.lista.blockSignals(False)
        self._t_real = time.perf_counter()

    def _solo_etapa(self):
        i = max(0, self.lista.currentRow())
        self._preparar_etapa(i, forzar=True)
        self.reloj.iniciar(i, cadena=False)
        self._t_real = time.perf_counter()

    def _pausar(self):
        self.reloj.pausar()
        self.sonidos.detener()

    def _continuar(self):
        self.reloj.continuar()
        self._t_real = time.perf_counter()

    def _reiniciar(self):
        self.reloj.reiniciar()
        self.sonidos.detener()
        self._preparar_etapa(0, forzar=True)
        self._dibujar(0, 0.0)
        self.lista.blockSignals(True); self.lista.setCurrentRow(0); self.lista.blockSignals(False)
        self.plotter.render()

    def _velocidad(self, v):
        self.reloj.set_velocidad(v / 10)
        self.lab_vel.setText(f"{v / 10:.1f}×")

    def _ver_etapa(self, i):
        if i < 0 or self.reloj.en_marcha:
            return
        self.reloj.ir_a(i)
        self._preparar_etapa(i, forzar=True)
        self._dibujar(i, 0.0)
        self.plotter.render()

    # ================================================================= bucle
    def _tick(self):
        ahora = time.perf_counter()
        dt = 0.0 if self._t_real is None else min(ahora - self._t_real, 0.1)
        self._t_real = ahora
        if self.reloj.en_marcha:
            antes = self.reloj.indice
            eventos = self.reloj.avanzar(dt)
            for ev, i in eventos:
                if ev == "inicio_etapa":
                    self._preparar_etapa(i)
                    self.lista.blockSignals(True); self.lista.setCurrentRow(i); self.lista.blockSignals(False)
                elif ev == "fin":
                    self.sonidos.detener("motor"); self.sonidos.detener("percusion")
            if self.reloj.indice != antes and not eventos:
                self._preparar_etapa(self.reloj.indice)
            self._dibujar(self.reloj.indice, self.reloj.t, dt * self.reloj.factor)
        e = self.reloj.etapa
        self.progreso.setValue(int(self.reloj.progreso_total * 1000))
        estado = "▶" if self.reloj.en_marcha else ("■ fin" if self.reloj.terminado else "⏸")
        self.estado.setText(f"{estado}  {e.nombre} — {e.descripcion}  ·  {self.reloj.t:.1f}/{e.duracion:.0f} s  ·  "
                            f"velocidad {self.reloj.factor:.2f}×" + ("  ·  [dato del proyecto]" if e.validado
                                                                     else "  ·  [ilustrativo]"))
        if self.reloj.en_marcha or self._sacudida > 0:
            self.plotter.render()

    # ================================================================= estados por etapa
    def _preparar_etapa(self, i, forzar=False):
        if not forzar and self._ultima_etapa_preparada == i:
            return
        self._ultima_etapa_preparada = i
        clave = self.reloj.etapas[i].clave
        n = len(self.frente.taladros)
        perforado = clave in ("retiro", "carguio", "secuencia", "detonacion", "fragmentacion", "resultado")
        marcas = clave in ("malla", "ingreso", "perforacion", "retiro", "secuencia")
        for k in range(n):
            self.a_marcas[k].SetVisibility(bool(marcas))
            self.a_bocas[k].SetVisibility(bool(perforado and clave not in ("fragmentacion", "resultado")))
            self.a_tubos[k].SetVisibility(bool(clave == "carguio"))
            self.a_marcas[k].prop.color = _hex(self.frente.taladros[k].color_explosivo if not self.frente.taladros[k].alivio
                                               else "#f2f2f2")
        for lst in self.a_cart.values():
            for a in lst:
                a.SetVisibility(False)
        corte = clave == "carguio"
        if clave not in POST_VOLADURA:
            self._reset_fisica()
        antes_voladura = clave in ("perforacion", "retiro", "secuencia")
        for a in self.a_frags:
            a.prop.opacity = 0.16 if corte else (0.6 if self.corte and antes_voladura else 1.0)
            a.SetVisibility(bool(clave not in ("desatado", "sostenimiento")))
        self._textura_bloques(clave in ("detonacion",) + POST_VOLADURA)
        if self.corte:
            for k in range(n):
                self.a_tubos[k].SetVisibility(bool(clave == "carguio" or (perforado and clave in ("retiro", "secuencia"))))
        if self.a_tramo is not None:
            self.a_tramo.SetVisibility(bool(clave in POST_VOLADURA))
        self.a_shot.prop.opacity = 0.0
        self.a_shot.SetVisibility(bool(clave == "sostenimiento"))
        for a in self.a_pernos:
            a.SetVisibility(False)
        self._rol_vehiculo({"carguio": "carguio", "limpieza": "lhd", "desatado": "desatado",
                            "sostenimiento": "shotcrete"}.get(clave))
        self._nube_emitida = False
        self.a_polvo.prop.color = _hex("#f2f2f2" if clave == "resultado" else "#a89c8c")
        equipo_visible = clave in ("ingreso", "perforacion", "retiro")
        for a in self.a_equipo:
            a.SetVisibility(bool(equipo_visible))
        for partes in self.a_brazos:
            for a in partes.values():
                a.SetVisibility(bool(equipo_visible))
        if self.a_manual:
            for a in self.a_manual.values():
                a.SetVisibility(bool(clave == "perforacion"))
        for lz in self.luces_equipo:
            lz.intensity = 0.9 if equipo_visible else 0.0
        self.a_destello.prop.opacity = 0.0
        self.luz_destello.intensity = 0.0
        self.a_contorno1.SetVisibility(bool(clave == "resultado"))
        self._comparar(self.chk_comparar.isChecked())
        if clave in ("escenario", "malla", "ingreso", "perforacion", "retiro", "carguio", "secuencia"):
            self.pol_vida[:] = 0
        if clave in ("resultado", "limpieza") and not self.mundo.activo.any():
            self._simular_fragmentacion_rapida()
        self._titulos(clave)
        if clave == "fragmentacion":
            self._reset_fisica()
        self._rotulos(self.chk_rotulos.isChecked() or clave in ("malla", "secuencia"))
        self.sonidos.detener()
        if equipo_visible or self.rol is not None:
            self.sonidos.reproducir("motor", 0.45)

    def _reset_fisica(self):
        r, m = self.mundo_inicial
        xs = [p[0] for p in self.frente.seccion]
        self.mundo = fisica.MundoFisico([fr.centro for fr in self.frags], r, m, medio_ancho=(max(xs) - min(xs)) / 2,
                                        alto=self.frente.alto, y_frente_final=self.avance)
        self._fisica_lista = False
        ident = np.eye(4)
        for a in self.a_frags:
            a.user_matrix = ident

    def _simular_fragmentacion_rapida(self):
        """Para reproducir la etapa 10 sola: calcula la etapa 9 sin dibujar."""
        self._reset_fisica()
        dur = next(e.duracion for e in self.reloj.etapas if e.clave == "fragmentacion")
        t = 0.0
        while t < dur:
            self._liberar_hasta(t / dur)
            self.mundo.paso(1 / 30)
            t += 1 / 30
        self._fisica_lista = True
        T = self.mundo.matrices()
        for a, M in zip(self.a_frags, T):
            a.user_matrix = M

    def _liberar_hasta(self, frac_etapa):
        """Libera los bloques cuyo instante de salida (0–1) ya pasó (salidas en el primer 35 % de la etapa)."""
        lim = frac_etapa / 0.35
        nuevos = np.nonzero(~self.mundo.activo & (self.salida_frag <= lim))[0]
        if len(nuevos):
            v, w = fisica.velocidades_iniciales(self.mundo.x[nuevos], self.centro_arranque, self.rng)
            self.mundo.liberar(nuevos, v, w)
        return nuevos

    # ================================================================= dibujo por etapa
    def _dibujar(self, i, t, dt_sim=0.0):
        clave = self.reloj.etapas[i].clave
        dur = self.reloj.etapas[i].duracion
        s = t / dur if dur else 1.0
        f = self.frente
        e = self.espec
        if clave in ("ingreso", "perforacion", "retiro"):
            if clave == "ingreso":
                desp = -18.0 * (1 - _suave(s / 0.85))
            elif clave == "retiro":
                desp = -18.0 * _suave(s)
            else:
                desp = 0.0
            self._colocar_equipo(desp, clave, t)
        if clave == "malla":
            for k, a in enumerate(self.a_marcas):
                a.SetVisibility(bool(k < int(len(self.a_marcas) * min(1, s * 1.3)) + 1))
        if clave == "carguio":
            cargados = [k for k in self.a_cart]
            n = len(cargados)
            for j, k in enumerate(cargados):
                p = np.clip(s * n * 1.15 - j, 0, 1)
                lst = self.a_cart[k]
                vis = int(round(p * len(lst)))
                for m, a in enumerate(lst):
                    a.SetVisibility(bool(m < vis))
            self.sonidos.reproducir("carguio", 0.25)
        if clave == "secuencia":
            orden = f.orden_salida()
            for k, a in enumerate(self.a_marcas):
                tk = f.taladros[k]
                if tk.alivio:
                    continue
                activo = orden[k] <= s * 1.1
                a.prop.color = _hex("#ff3b1f") if activo else _hex("#3a3f45")
        if clave == "detonacion":
            env = math.exp(-((s - 0.12) ** 2) / 0.004) if s < 0.6 else 0.0
            self.luz_destello.intensity = 6.0 * env
            self.a_destello.prop.opacity = 0.75 * env
            self.a_destello.user_matrix = modelos.matriz(self.centro_arranque * [1, 0, 1] + [0, -0.2, 0],
                                                         escala=(0.3 + 2.5 * s,) * 3)
            if s > 0.1 and self._sacudida <= 0 and t < dur * 0.2:
                self._sacudida = 1.0
                self.sonidos.reproducir("explosion", 0.9)
                self._emitir_polvo(self.centro_arranque * [1, 0, 1], 0.35, fuerza=4.0)
        if clave in ("fragmentacion", "resultado"):
            if clave == "fragmentacion":
                nuevos = self._liberar_hasta(s)
                if len(nuevos):
                    for c in self.mundo.x[nuevos][:6]:
                        self._emitir_polvo(c * [1, 0, 1] + [0, -0.1, 0], 0.03, fuerza=3.0)
                if dt_sim > 0:
                    self.mundo.paso(min(dt_sim, 0.05))
                if s >= 0.999:
                    self._fisica_lista = True
            elif dt_sim > 0:
                self.mundo.paso(min(dt_sim, 0.05))
            T = self.mundo.matrices()
            for a, M in zip(self.a_frags, T):
                a.user_matrix = M
            if clave == "resultado":
                self.a_polvo.prop.opacity = 0.18 * max(0.0, 1 - s)
        if clave == "perforacion" and self.corte:
            for k in range(len(self.a_tubos)):
                self.a_tubos[k].SetVisibility(bool(self.a_bocas[k].GetVisibility()))
        if clave == "carguio":
            self._dibujar_carguio(s)
        elif clave == "resultado":
            self._dibujar_ventilacion(s, dt_sim)
        elif clave == "limpieza":
            self._dibujar_limpieza(s, t)
        elif clave == "desatado":
            self._dibujar_desatado(s, t)
        elif clave == "sostenimiento":
            self._dibujar_sostenimiento(s, t)
        self._actualizar_polvo(dt_sim, clave)
        self._camara_auto(clave, s, t)

    # ----------------------------------------------------------------- etapas del ciclo (ilustrativas)
    def _dibujar_carguio(self, s):
        cargados = list(self.a_cart)
        if not cargados:
            self._poner_vehiculo(-1.4)
            return
        n = len(cargados)
        j = min(int(s * n * 1.15), n - 1)
        tk = self.frente.taladros[cargados[j]]
        self._poner_vehiculo(-1.4, objetivo=np.array([tk.x, -0.75, max(tk.z - 1.05, 0.25)]))

    def _dibujar_ventilacion(self, s, dt):
        f = self.frente
        if not self._nube_emitida and self.chk_polvo.isChecked():
            self._nube_emitida = True
            n = len(self.pol_vida)
            for _ in range(6):
                self._emitir((0.0, -0.8, f.alto * 0.6), n // 6, (0.0, -0.3, 0.05), dispersion=0.8, vida=(4, 9))
        # el aire fresco empuja la nube hacia atrás por la labor
        if dt > 0:
            vivos = self.pol_vida > 0
            self.pol_v[vivos, 1] -= 1.2 * dt

    def _dibujar_limpieza(self, s, t):
        ciclos = 4
        c = min(int(s * ciclos), ciclos - 1)
        u = s * ciclos - c
        orden = np.argsort(self.mundo.x[:, 1])  # el scoop entra desde atrás: carga primero lo más cercano a él
        n = len(orden)
        lote = int(math.ceil(n / ciclos))
        retirados = c * lote + (lote if u > 0.42 else 0)
        for k, idx in enumerate(orden):
            self.a_frags[idx].SetVisibility(bool(k >= retirados))
        restantes = orden[min(retirados, n):]
        frente_pila = float(self.mundo.x[restantes, 1].min()) if len(restantes) else self.avance
        y_carga = frente_pila - 0.2
        y_lejos = -17.0
        if u < 0.35:
            y = y_lejos + (y_carga - y_lejos) * _suave(u / 0.35)
            ang, carga = -8.0, False
        elif u < 0.5:
            y = y_carga
            ang = -8.0 + 30.0 * _suave((u - 0.35) / 0.15)
            carga = u > 0.42
            if 0.36 < u < 0.42:
                self._emitir((0.0, y_carga + 0.5, 0.3), 6, (0.0, -0.3, 0.5), 0.4, (1, 2.5))
        else:
            y = y_carga + (y_lejos - y_carga) * _suave((u - 0.5) / 0.5)
            ang, carga = 22.0, True
        self._poner_vehiculo(y, angulo_cuchara=ang, con_carga=carga)

    def _puntos_tramo(self):
        return [p for p, _ in self.pos_pernos] or [np.array([-self.frente.ancho / 2 + 0.1, self.avance / 2,
                                                             self.frente.alto * 0.8])]

    def _dibujar_desatado(self, s, t):
        pts = self._puntos_tramo()
        k = min(int(s * len(pts)), len(pts) - 1)
        p = pts[k]
        golpe = 0.06 * math.sin(t * 25)
        objetivo = p + np.array([0.0, 0.0, -0.05 + golpe]) - np.array([np.sign(p[0]) * 0.05, 0.0, 0.0])
        self._poner_vehiculo(-0.8, objetivo=objetivo)
        if int(t * 10) % 3 == 0:
            self._emitir(p, 3, (0.0, -0.2, -2.5), 0.3, (0.5, 1.2))
        self.sonidos.reproducir("percusion", 0.4)

    def _dibujar_sostenimiento(self, s, t):
        pts = self._puntos_tramo()
        if s < 0.5:
            if self.rol != "shotcrete":
                self._rol_vehiculo("shotcrete")
            u = s / 0.5
            self.a_shot.prop.opacity = min(1.0, u * 1.1)
            k = int(u * len(pts) * 2) % len(pts)
            p = pts[k]
            centro = np.array([0.0, p[1], self.frente.alto * 0.5])
            boquilla = p + (centro - p) / (np.linalg.norm(centro - p) or 1) * 0.9
            self._poner_vehiculo(-0.8, objetivo=boquilla)
            self._emitir(boquilla, 8, (p - boquilla) * 3.0, 0.35, (0.2, 0.5))
            self.sonidos.detener("percusion")
        else:
            if self.rol != "pernos":
                self._rol_vehiculo("pernos")
            self.a_shot.prop.opacity = 1.0
            u = (s - 0.5) / 0.5
            n = len(self.a_pernos)
            hechos = min(n, int(u * n * 1.05))
            for k, a in enumerate(self.a_pernos):
                a.SetVisibility(bool(k < hechos))
            if n:
                p, nrm = self.pos_pernos[min(hechos, n - 1)]
                self._poner_vehiculo(-0.8, objetivo=p - nrm * 0.05)
            self.sonidos.reproducir("percusion", 0.35)

    # ----------------------------------------------------------------- equipo
    def _colocar_equipo(self, desp, clave, t):
        e = self.espec
        if self.plan.modo == "manual":
            self._colocar_manual(clave, t)
            return
        L = e.largo
        y_chasis = -e.distancia_pivote_frente - L * 0.78 + desp
        M = np.eye(4); M[:3, 3] = (0, y_chasis, 0)
        for a in self.a_equipo:
            a.user_matrix = M
        for k, lz in enumerate(self.luces_equipo):
            x = (-0.4 if k == 0 else 0.4)
            lz.position = (x, y_chasis + L * 0.8, 1.0)
            lz.focal_point = (x * 0.5, 0.0, 1.2)
        for b, partes in enumerate(self.a_brazos):
            piv = self.piv[b] + np.array([0, desp, 0])
            reposo = pose_reposo(e, piv)
            punta, vi, vf = reposo.punta, reposo.viga_inicio, reposo.viga_fin
            avance_broca, giro_broca, perforando = 0.0, 0.0, False
            if clave == "perforacion" and self.agenda[b]:
                prev = pose_reposo(e, self.piv[b])
                for (k, t0, t1) in self.agenda[b]:
                    pose = self.plan.poses[k]
                    if t < t0:
                        punta, vi, vf = prev.punta, prev.viga_inicio, prev.viga_fin
                        break
                    if t <= t1:
                        u = (t - t0) / (t1 - t0)
                        if u < 0.3:
                            punta, vi, vf = interpolar_pose(prev, pose, u / 0.3)
                        else:
                            punta, vi, vf = pose.punta, pose.viga_inicio, pose.viga_fin
                            if u < 0.9:
                                avance_broca = (u - 0.3) / 0.6
                                perforando = True
                                giro_broca = t * 40.0
                                self.a_bocas[k].SetVisibility(bool(avance_broca > 0.05))
                            else:
                                avance_broca = 1 - (u - 0.9) / 0.1
                                self.a_bocas[k].SetVisibility(True)
                        break
                    self.a_bocas[k].SetVisibility(True)
                    prev = pose
                else:
                    punta, vi, vf = prev.punta, prev.viga_inicio, prev.viga_fin
            self._poner_brazo(partes, piv, punta, vi, vf, avance_broca, giro_broca, perforando)
        if clave == "perforacion" and any(self._perforando_alguno(t)):
            self.sonidos.reproducir("percusion", 0.55)
            # polvo en la boca
            for b in range(len(self.a_brazos)):
                for (k, t0, t1) in self.agenda[b]:
                    if t0 + 0.3 * (t1 - t0) <= t <= t0 + 0.9 * (t1 - t0):
                        tk = self.frente.taladros[k]
                        self._emitir_polvo(np.array([tk.x, -0.05, tk.z]), 0.004, fuerza=0.6)
        else:
            self.sonidos.detener("percusion")

    def _perforando_alguno(self, t):
        for b in range(len(self.agenda)):
            yield any(t0 + 0.3 * (t1 - t0) <= t <= t0 + 0.9 * (t1 - t0) for (_, t0, t1) in self.agenda[b])

    def _poner_brazo(self, partes, piv, punta, vi, vf, avance_broca, giro, perforando):
        e = self.espec
        d = vf - vi
        Lv = float(np.linalg.norm(d)) or 1.0
        du = d / Lv
        partes["torreta"].user_matrix = modelos.matriz(piv)
        v = punta - piv
        Lb = float(np.linalg.norm(v)) or 1.0
        Lfijo = min(Lb, e.brazo_min * 0.85)
        partes["brazo"].user_matrix = modelos.matriz(piv, v, (1, Lfijo, 1))
        partes["tel"].user_matrix = modelos.matriz(piv + v / Lb * Lfijo * 0.95, v, (1, max(Lb - Lfijo * 0.95, 0.05), 1))
        partes["viga"].user_matrix = modelos.matriz(vi, du, (1, Lv, 1))
        partes["cent"].user_matrix = modelos.matriz(vf, du)
        carrera = min(e.carrera, Lv - 0.6)
        pos_perf = vi + du * (0.3 + avance_broca * carrera)
        partes["perf"].user_matrix = modelos.matriz(pos_perf, du)
        frente_perf = pos_perf + du * 0.25
        punta_barra = vf + du * (avance_broca * carrera + e.separacion_frente) if avance_broca > 0 else vf
        Lbarra = float(np.linalg.norm(punta_barra - frente_perf)) or 0.05
        partes["barra"].user_matrix = modelos.matriz(frente_perf, du, (1, Lbarra, 1))
        partes["broca"].user_matrix = modelos.matriz(punta_barra, du) @ modelos.rot_y(math.radians(giro))

    def _colocar_manual(self, clave, t):
        m = self.a_manual
        if clave != "perforacion":
            return
        orden = self.plan.asignacion[0]
        dur = self.reloj.etapa.duracion - 1.0
        n = len(orden)
        if n == 0:
            return
        paso = dur / n
        j = min(int(max(t - 0.5, 0) / paso), n - 1)
        u = (max(t - 0.5, 0) - j * paso) / paso
        k = orden[j]
        tk = self.frente.taladros[k]
        for kk in orden[:j]:
            self.a_bocas[kk].SetVisibility(True)
        du = tk.direccion
        avance = np.clip((u - 0.2) / 0.7, 0, 1) * tk.longitud
        self.a_bocas[k].SetVisibility(bool(avance > 0.05))
        cuerpo = tk.collar() - du * (1.0 + 0.6 * (1 - avance / max(tk.longitud, 0.01))) + du * avance * 0.0
        cuerpo = tk.collar() - du * 1.2 + du * avance * 0.9
        m["cuerpo"].user_matrix = modelos.matriz(cuerpo, du)
        m["emp"].user_matrix = modelos.matriz(cuerpo, du)
        pie = np.array([cuerpo[0] - 0.2, cuerpo[1] - 1.0, 0.0])
        m["pata"].user_matrix = modelos.matriz(pie, cuerpo - pie, (1, float(np.linalg.norm(cuerpo - pie)), 1))
        punta = tk.collar() + du * avance
        m["barra"].user_matrix = modelos.matriz(cuerpo, du, (1, float(np.linalg.norm(punta - cuerpo)), 1))
        m["broca"].user_matrix = modelos.matriz(punta, du) @ modelos.rot_y(t * 40)
        # operador al costado de la máquina, de pie en el piso; se agacha si la labor es baja
        xs = [q[0] for q in self.frente.seccion]
        lado = -1.0 if cuerpo[0] > (min(xs) + max(xs)) / 2 + 0.2 * self.frente.ancho else 1.0
        xo = float(np.clip(cuerpo[0] + lado * 0.5, min(xs) + 0.25, max(xs) - 0.25))
        k = min(1.0, (self.frente.alto - 0.08) / 1.72)
        pos_op = modelos.matriz((xo, cuerpo[1] - 0.55, 0.0), None, (1, 1, k))
        for c in ("op_ropa", "op_casco", "op_piernas"):
            if c in m:
                m[c].user_matrix = pos_op
        if 0.2 < u < 0.9:
            self.sonidos.reproducir("percusion", 0.5)
            self._emitir_polvo(np.array([tk.x, -0.05, tk.z]), 0.004, fuerza=0.5)

    # ----------------------------------------------------------------- polvo
    def _emitir_polvo(self, origen, fraccion, fuerza=1.0):
        if not self.chk_polvo.isChecked():
            return
        n = len(self.pol_vida)
        k = max(1, int(n * fraccion))
        libres = np.nonzero(self.pol_vida <= 0)[0][:k]
        if len(libres) == 0:
            return
        self.pol_x[libres] = origen + self.rng.normal(0, 0.15, (len(libres), 3))
        v = self.rng.normal(0, 1, (len(libres), 3)) * fuerza
        v[:, 1] = -np.abs(v[:, 1]) - fuerza * 0.8
        self.pol_v[libres] = v
        self.pol_vida[libres] = self.rng.uniform(3, 9, len(libres))

    def _actualizar_polvo(self, dt, clave):
        vivos = self.pol_vida > 0
        if dt > 0 and vivos.any():
            self.pol_v[vivos] *= (1 - 0.9 * dt)
            self.pol_v[vivos, 2] += 0.05 * dt  # el polvo fino flota
            self.pol_x[vivos] += self.pol_v[vivos] * dt
            self.pol_vida[vivos] -= dt
        P = np.where((self.pol_vida > 0)[:, None], self.pol_x, -999.0)
        self.pol_malla.points = P
        self.a_polvo.SetVisibility(bool(self.chk_polvo.isChecked()))
        if clave not in ("resultado",):
            self.a_polvo.prop.opacity = 0.2

    # ================================================================= cámaras
    def _camara(self, nombre):
        self.modo_camara = nombre
        f = self.frente
        c = np.array([0.0, 0.0, f.alto / 2])
        pl = self.plotter
        if nombre == "Corte lateral":
            pl.camera_position = self._pos_corte(0.0)
        elif nombre == "Superior":
            pl.camera_position = [(0, -6, 18), (0, -6, 0), (0, 1, 0)]
        elif nombre == "Frontal":
            pl.camera_position = [(0, -7, f.alto / 2), tuple(c), (0, 0, 1)]
        elif nombre == "Lateral":
            pl.camera_position = [(10, -4, f.alto / 2), (0, -4, f.alto / 2), (0, 0, 1)]
        elif nombre == "Isométrica":
            pl.camera_position = [(7, -12, 6), (0, -3, f.alto / 3), (0, 0, 1)]
        elif nombre == "Operador":
            self._camara_operador()
        elif nombre == "Libre":
            pass
        pl.reset_camera_clipping_range()
        pl.render()

    def _pos_corte(self, fase: float, foco_y: float = -2.0):
        f = self.frente
        return [(f.ancho / 2 + 7.5 + 1.2 * math.sin(fase), -10.0 + 1.5 * math.cos(fase * 0.7), f.alto + 5.0),
                (-f.ancho / 4, foco_y, f.alto * 0.3), (0, 0, 1)]

    def _camara_operador(self):
        e = self.espec
        y = -e.distancia_pivote_frente - e.largo * 0.78 + e.largo * 0.5
        self.plotter.camera_position = [(-e.ancho * 0.2, y, 1.75), (0, 0, self.frente.alto * 0.55), (0, 0, 1)]

    def _camara_auto(self, clave, s, t):
        pl = self.plotter
        f = self.frente
        if self.modo_camara == "Cinematográfica" and self.corte:
            foco = {"limpieza": -4.0, "fragmentacion": -3.0, "resultado": -3.5, "ingreso": -3.0}.get(clave, -1.0)
            pl.camera_position = self._pos_corte(t * 0.05, foco)
        elif self.modo_camara == "Cinematográfica":
            if clave == "escenario":
                pos = (4.0 - 6 * s, -16 + 8 * s, 2.0 + 1.5 * s); foco = (0, 0, f.alto / 2)
            elif clave in ("malla", "secuencia"):
                pos = (0.6 * math.sin(t * 0.3), -4.5, f.alto * 0.55); foco = (0, 0, f.alto / 2)
            elif clave == "ingreso":
                pos = (3.0, -14 + 6 * s, 2.6); foco = (0, -6 + 4 * s, 1.2)
            elif clave == "perforacion":
                a = t * 0.08
                pos = (3.2 * math.cos(a) + 0.5, -5.5 + 1.5 * math.sin(a), 2.4); foco = (0, -0.5, f.alto * 0.5)
            elif clave == "retiro":
                pos = (2.5, -8, 2.2); foco = (0, -6 * s, 1.2)
            elif clave == "carguio":
                a = 0.6 + 0.4 * math.sin(t * 0.2)
                pos = (5.5 * math.sin(a), -5.5 * math.cos(a), f.alto * 0.9); foco = (0, self.avance / 2, f.alto / 2)
            elif clave == "detonacion":
                pos = (1.2, -9, f.alto * 0.6); foco = (0, 0, f.alto / 2)
            elif clave == "fragmentacion":
                pos = (3.5, -11 + 2 * s, 2.6); foco = (0, -3, 0.8)
            else:
                a = t * 0.15
                pos = (6 * math.sin(a), -9 + 2 * math.cos(a), 3.2); foco = (0, -3, 0.8)
            pl.camera_position = [pos, foco, (0, 0, 1)]
        elif self.modo_camara == "Operador" and clave in ("ingreso", "perforacion", "retiro"):
            e = self.espec
            desp = 0.0
            if clave == "ingreso":
                desp = -18.0 * (1 - _suave(s / 0.85))
            elif clave == "retiro":
                desp = -18.0 * _suave(s)
            y = -e.distancia_pivote_frente - e.largo * 0.78 + e.largo * 0.5 + desp
            pl.camera_position = [(-e.ancho * 0.2, y, 1.75), (0, 0, f.alto * 0.55), (0, 0, 1)]
        if self._sacudida > 0:
            cam = pl.camera
            dx = self.rng.normal(0, 0.06 * self._sacudida, 3)
            cam.position = tuple(np.array(cam.position) + dx)
            self._sacudida = max(0.0, self._sacudida - 0.04)
        pl.reset_camera_clipping_range()

    # ================================================================= opciones
    def _rejilla(self, v):
        if v:
            self.plotter.show_grid(color=COLORES["texto_secundario"], xtitle="X (m)", ytitle="Avance Y (m)",
                                   ztitle="Altura Z (m)", font_size=9)
        else:
            self.plotter.remove_bounds_axes()
        self.plotter.render()

    def _rotulos(self, v):
        if self.a_rotulos is not None:
            self.plotter.remove_actor(self.a_rotulos, render=False)
            self.a_rotulos = None
        if v:
            f = self.frente
            pts = np.array([[t.x, -0.02, t.z + 0.07] for t in f.taladros])
            txt = [("" if t.alivio else f"{t.retardo}") for t in f.taladros]
            self.a_rotulos = self.plotter.add_point_labels(pts, txt, font_size=11, text_color="#ffffff",
                                                           shape_opacity=0.0, show_points=False,
                                                           always_visible=False, name="rotulos")

    def _comparar(self, v):
        self.a_fantasma.SetVisibility(bool(v))
        self.a_contorno1.SetVisibility(bool(v) or self.reloj.etapa.clave == "resultado")
        self.plotter.render()

    # ================================================================= selección y medición
    def _set_herramienta(self, h):
        self._herramienta = h
        if h == "medir":
            self.b_selec.blockSignals(True); self.b_selec.setChecked(False); self.b_selec.blockSignals(False)
        else:
            self.b_medir.blockSignals(True); self.b_medir.setChecked(False); self.b_medir.blockSignals(False)
            self.b_selec.blockSignals(True); self.b_selec.setChecked(True); self.b_selec.blockSignals(False)
        for a in self._actores_medida:
            self.plotter.remove_actor(a, render=False)
        self._actores_medida, self._medida = [], []
        self.plotter.render()

    def _al_presionar(self, iren, _ev):
        self._pos_presion = iren.GetEventPosition()

    def _al_soltar(self, iren, _ev):
        if self._pos_presion is None:
            return
        x, y = iren.GetEventPosition()
        px, py = self._pos_presion
        self._pos_presion = None
        if abs(x - px) > 4 or abs(y - py) > 4:
            return
        if not self._picker.Pick(x, y, 0, self.plotter.renderer):
            return
        actor = self._picker.GetActor()
        p = np.array(self._picker.GetPickPosition())
        if self._herramienta == "medir":
            self._medida.append(p)
            self._actores_medida.append(self.plotter.add_mesh(pv.Sphere(radius=0.04, center=p), color="#ff5fd2",
                                                              pickable=False))
            if len(self._medida) == 2:
                a, b = self._medida
                d = b - a
                self._actores_medida.append(self.plotter.add_mesh(pv.Line(a, b), color="#ff5fd2", line_width=3,
                                                                  pickable=False))
                self.propiedades.setText(f"<b>Medición</b><br>Distancia 3D: {np.linalg.norm(d):.3f} m<br>"
                                         f"Horizontal: {math.hypot(d[0], d[1]):.3f} m · vertical: {d[2]:+.3f} m")
                self._medida = []
            else:
                self.propiedades.setText(f"Punto 1: X {p[0]:.3f} · Y {p[1]:.3f} · Z {p[2]:.3f} m. Elige el segundo.")
            self.plotter.render()
            return
        k = self._mapa_actor.get(actor.GetAddressAsString("vtkObject")) if actor is not None else None
        if k is None:
            self.propiedades.setText(f"Punto: X {p[0]:.3f} · Y (avance) {p[1]:.3f} · Z (altura) {p[2]:.3f} m")
            return
        t = self.frente.taladros[k]
        self.propiedades.setText(
            f"<b>Taladro {t.id}</b> · {t.funcion}<br>Posición en el frente: X {t.x:.3f} m · Z {t.z:.3f} m<br>"
            f"Longitud {t.longitud:.2f} m · Ø {t.diametro_mm:.0f} mm<br>"
            + ("Alivio (sin carga)" if t.alivio else
               f"Explosivo: {t.explosivo} · carga {t.carga_kg:.2f} kg"
               + (f" ({t.cartuchos} cartuchos)" if t.cartuchos else "") + f"<br>Retardo / orden: {t.retardo}"
               + (f" · {t.tiempo_ms:.0f} ms" if t.tiempo_ms is not None else ""))
            + (f"<br>Brazo: {self.plan.poses[k].giro:.0f}° giro, {self.plan.poses[k].elevacion:.0f}° elevación, "
               f"{self.plan.poses[k].largo_brazo:.2f} m" + ("" if self.plan.poses[k].alcanzable else
                                                           f"<br>⚠ {self.plan.poses[k].motivo}")
               if k in self.plan.poses else ""))

    # ================================================================= equipo
    CAMPOS_EQUIPO = [("ancho", "Ancho del chasis", "m"), ("alto", "Alto (techo de protección)", "m"),
                     ("holgura", "Holgura lateral mínima", "m"), ("brazos", "Brazos (1 o 2)", ""),
                     ("altura_pivote", "Altura del pivote del brazo", "m"),
                     ("distancia_pivote_frente", "Distancia pivote–frente", "m"),
                     ("brazo_min", "Largo mínimo del brazo", "m"), ("brazo_max", "Largo máximo del brazo", "m"),
                     ("giro_max", "Giro máximo (±)", "°"), ("elev_min", "Elevación mínima", "°"),
                     ("elev_max", "Elevación máxima", "°"), ("largo_viga", "Largo de la viga de avance", "m"),
                     ("carrera", "Carrera (longitud perforable)", "m"),
                     ("penetracion_ilustrativa", "Penetración (ilustrativa)", "m/min")]

    def _editar_equipo(self):
        from dataclasses import replace
        from PySide6.QtWidgets import QDialogButtonBox, QFormLayout
        from app.ui.dialogos import CampoNumero
        dlg = QDialog(self)
        dlg.setWindowTitle("Parámetros del equipo (modelo genérico)")
        form = QFormLayout(dlg)
        campos = {}
        for clave, nombre, unidad in self.CAMPOS_EQUIPO:
            c = CampoNumero(-90 if "elev" in clave else 0, 100, 0 if clave == "brazos" else 2, unidad,
                            float(getattr(self.espec, clave)), nombre)
            campos[clave] = c
            form.addRow(nombre, c)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject)
        form.addRow(bb)
        if not dlg.exec():
            return
        cambios = {k: (int(round(c.value())) if k == "brazos" else c.value()) for k, c in campos.items()}
        cambios["brazos"] = 2 if cambios["brazos"] >= 2 else 1
        self.espec = replace(self.espec, **cambios)
        self.plan = planificar(self.frente, self.espec, self.seleccion)
        self.reloj = ciclo.Reloj(self._etapas_ajustadas())
        self.lista.clear()
        for e in self.reloj.etapas:
            self.lista.addItem(f"{e.nombre}  ({e.duracion:.0f} s)")
        self._cambiar_calidad(self.calidad)
        self._llenar_info()

    # ================================================================= cierre
    def done(self, r):
        self.timer.stop()
        self.sonidos.detener()
        try:
            self.plotter.close()
        except Exception:  # noqa: BLE001
            pass
        super().done(r)


def abrir_simulador(documento, parent=None, etapa: int | None = None):
    try:
        v = VentanaSimulador(documento, parent, etapa)
    except ErrorSimulacion as error:
        QMessageBox.information(parent, "Simulador 3D", str(error))
        return None
    v.show()
    return v
