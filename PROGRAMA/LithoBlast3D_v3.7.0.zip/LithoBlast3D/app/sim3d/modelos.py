"""
Modelos 3D procedurales (PyVista): labor, textura de roca, jumbo y perforadora manual.

Todo se construye con primitivas y numpy; no se usan modelos ni texturas de terceros.
Cada pieza móvil es una malla propia en coordenadas LOCALES de la pieza, que la
ventana coloca con matrices 4×4 (user_matrix) en cada cuadro.
"""

from __future__ import annotations

import math

import numpy as np
import pyvista as pv

from app.sim3d.cinematica import EspecEquipo


# ----------------------------------------------------------------- textura de roca
def textura_roca(n: int = 256, semilla: int = 3, tono=(118, 108, 96)) -> pv.Texture:
    """Ruido fractal (suma de octavas) en tonos de roca; sin imágenes externas."""
    rng = np.random.default_rng(semilla)
    img = np.zeros((n, n))
    amp = 1.0
    for oct_ in range(5):
        k = 2 ** (oct_ + 2)
        base = rng.random((k + 1, k + 1))
        xs = np.linspace(0, k, n, endpoint=False)
        i = xs.astype(int); f = xs - i
        f = f * f * (3 - 2 * f)
        a = base[i][:, i]; b = base[i + 1][:, i]; c = base[i][:, i + 1]; d = base[i + 1][:, i + 1]
        fy, fx = f[:, None], f[None, :]
        img += amp * (a * (1 - fy) * (1 - fx) + b * fy * (1 - fx) + c * (1 - fy) * fx + d * fy * fx)
        amp *= 0.5
    img = (img - img.min()) / (np.ptp(img) or 1)
    vetas = 0.5 + 0.5 * np.sin(np.linspace(0, 18 * np.pi, n)[None, :] + img * 6)
    lum = 0.55 + 0.45 * img * (0.8 + 0.2 * vetas)
    rgb = np.clip(np.stack([lum * tono[0], lum * tono[1], lum * tono[2]], axis=2) * 1.25, 0, 255).astype(np.uint8)
    return pv.Texture(rgb)


def _uv_cilindrico(m: pv.PolyData, escala: float = 0.5) -> pv.PolyData:
    p = m.points
    ang = np.arctan2(p[:, 0], p[:, 2] - p[:, 2].mean())
    m.active_texture_coordinates = np.c_[p[:, 1] * escala, ang * 1.5 * escala].astype(np.float32)
    return m


def _uv_plano(m: pv.PolyData, ejes=(0, 2), escala: float = 0.5) -> pv.PolyData:
    p = m.points
    m.active_texture_coordinates = np.c_[p[:, ejes[0]] * escala, p[:, ejes[1]] * escala].astype(np.float32)
    return m


# ----------------------------------------------------------------- labor
def labor(seccion, largo_atras: float = 22.0, largo_adelante: float = 0.0) -> pv.PolyData:
    """Paredes, techo y piso de la galería (superficie interior) de Y = -largo_atras a Y = adelante."""
    sec = np.asarray(seccion, float)
    n = len(sec)
    y0, y1 = -largo_atras, largo_adelante
    pts = np.vstack([np.c_[sec[:, 0], np.full(n, y0), sec[:, 1]], np.c_[sec[:, 0], np.full(n, y1), sec[:, 1]]])
    caras = []
    for i in range(n):
        j = (i + 1) % n
        caras += [4, i, j, n + j, n + i]
    m = pv.PolyData(pts, faces=np.array(caras)).triangulate().subdivide(1)
    return _uv_cilindrico(m, 0.35)


def roca_frontal(seccion, avance: float, profundidad_extra: float = 2.5) -> pv.PolyData:
    """Bloque de roca más allá del avance (lo que queda después de la voladura)."""
    sec = np.asarray(seccion, float)
    n = len(sec)
    pts = np.c_[sec[:, 0], np.full(n, avance), sec[:, 1]]
    cara = pv.PolyData(pts, faces=np.array([n, *range(n)])).triangulate()
    try:
        prisma = cara.extrude((0, profundidad_extra, 0), capping=True)
    except TypeError:
        prisma = cara.extrude((0, profundidad_extra, 0))
    return _uv_plano(prisma.triangulate(), (0, 2), 0.6)


def cara_frente(seccion, y: float = 0.0) -> pv.PolyData:
    sec = np.asarray(seccion, float)
    n = len(sec)
    pts = np.c_[sec[:, 0], np.full(n, y), sec[:, 1]]
    return _uv_plano(pv.PolyData(pts, faces=np.array([n, *range(n)])).triangulate().subdivide(2), (0, 2), 0.6)


def fragmento_malla(vertices: np.ndarray) -> pv.PolyData:
    nube = pv.PolyData(np.asarray(vertices, float))
    try:
        vol = nube.delaunay_3d()
        try:
            sup = vol.extract_surface(algorithm="dataset_surface")
        except TypeError:  # versiones de PyVista sin el parámetro
            sup = vol.extract_surface()
        m = sup.triangulate()
    except Exception:  # noqa: BLE001
        m = nube.outline()
    try:
        m = m.compute_normals(auto_orient_normals=True, split_vertices=True)
    except Exception:  # noqa: BLE001
        pass
    return _uv_plano(m, (0, 2), 0.8)


# ----------------------------------------------------------------- jumbo
def matriz(origen=(0, 0, 0), eje_y=None, escala=(1, 1, 1)) -> np.ndarray:
    """Matriz 4×4 que lleva el eje +Y local a «eje_y» (y escala local) y traslada a «origen»."""
    M = np.eye(4)
    if eje_y is not None:
        y = np.asarray(eje_y, float)
        L = np.linalg.norm(y)
        y = y / L if L > 0 else np.array([0, 1.0, 0])
        ref = np.array([0, 0, 1.0]) if abs(y[2]) < 0.95 else np.array([1.0, 0, 0])
        x = np.cross(y, ref); x /= np.linalg.norm(x)
        z = np.cross(x, y)
        M[:3, 0], M[:3, 1], M[:3, 2] = x, y, z
    M[:3, :3] = M[:3, :3] @ np.diag(escala)
    M[:3, 3] = origen
    return M


def rot_y(ang) -> np.ndarray:
    c, s = math.cos(ang), math.sin(ang)
    R = np.eye(4)
    R[0, 0], R[0, 2], R[2, 0], R[2, 2] = c, s, -s, c
    return R


class PiezasJumbo:
    """Mallas del jumbo en coordenadas del CHASIS (origen: centro del eje trasero en el piso,
    frente del equipo hacia +Y). Las piezas de los brazos se colocan en coordenadas de la labor."""

    def __init__(self, e: EspecEquipo):
        self.e = e
        a, h, L = e.ancho, e.alto, e.largo
        self.chasis = pv.Box(bounds=(-a / 2, a / 2, 0.0, L * 0.78, 0.35, 1.05))
        self.motor = pv.Box(bounds=(-a / 2 + 0.05, a / 2 - 0.05, 0.05, L * 0.25, 1.05, 1.45))
        self.cabina = pv.Box(bounds=(-a / 2, a * 0.15, L * 0.38, L * 0.58, 1.05, h - 0.1))
        self.techo = pv.Box(bounds=(-a / 2 - 0.05, a / 2 + 0.05, L * 0.36, L * 0.62, h - 0.12, h))
        postes = []
        for x in (-a / 2, a / 2 - 0.08):
            for y in (L * 0.37, L * 0.60):
                postes.append(pv.Box(bounds=(x, x + 0.08, y, y + 0.08, 1.05, h - 0.1)))
        self.postes = postes[0].merge(postes[1:])
        self.vidrio = pv.Box(bounds=(-a / 2 + 0.02, a * 0.13, L * 0.575, L * 0.585, 1.25, h - 0.2))
        ruedas = []
        for y in (L * 0.12, L * 0.62):
            for x in (-a / 2 - 0.05, a / 2 + 0.05):
                ruedas.append(pv.Cylinder(center=(x, y, 0.42), direction=(1, 0, 0), radius=0.42, height=0.28,
                                          resolution=28))
        self.ruedas = ruedas
        self.llantas = [pv.Cylinder(center=r.center, direction=(1, 0, 0), radius=0.2, height=0.30, resolution=16)
                        for r in ruedas]
        self.luces = [pv.Cylinder(center=(x, L * 0.78 + 0.03, 1.0), direction=(0, 1, 0), radius=0.08, height=0.06)
                      for x in (-a / 2 + 0.15, a / 2 - 0.15)] + \
                     [pv.Cylinder(center=(x, L * 0.62, h + 0.05), direction=(0, 1, 0), radius=0.06, height=0.08)
                      for x in (-a / 2 + 0.1, a / 2 - 0.1)]
        self.gatos = [pv.Box(bounds=(x - 0.07, x + 0.07, L * 0.74, L * 0.76, 0.0, 0.5)) for x in (-a / 2, a / 2)]
        # piezas de brazo (unidad de largo en +Y, luego se escalan)
        self.torreta = pv.Cylinder(center=(0, 0, 0), direction=(0, 0, 1), radius=0.16, height=0.35, resolution=20)
        self.brazo = pv.Box(bounds=(-0.09, 0.09, 0.0, 1.0, -0.09, 0.09))
        self.brazo_tel = pv.Box(bounds=(-0.065, 0.065, 0.0, 1.0, -0.065, 0.065))
        self.viga = pv.Box(bounds=(-0.07, 0.07, 0.0, 1.0, -0.05, 0.05))
        self.perforadora = pv.Box(bounds=(-0.11, 0.11, -0.25, 0.25, -0.02, 0.18))
        self.barra = pv.Cylinder(center=(0, 0.5, 0), direction=(0, 1, 0), radius=0.016, height=1.0, resolution=10)
        broca = pv.Cylinder(center=(0, 0.04, 0), direction=(0, 1, 0), radius=0.022, height=0.08, resolution=8)
        botones = [pv.Sphere(radius=0.007, center=(0.015 * math.cos(k), 0.085, 0.015 * math.sin(k)))
                   for k in np.linspace(0, 2 * np.pi, 7)[:-1]]
        self.broca = broca.merge(botones)
        self.centralizador = pv.Box(bounds=(-0.09, 0.09, -0.05, 0.0, -0.07, 0.09))
        self.manguera = None

    def puntos_pivote(self) -> float:
        return self.e.largo * 0.78


class PiezasManual:
    """Perforadora manual con barra de avance (tipo jackleg), genérica."""

    def __init__(self):
        self.cuerpo = pv.Box(bounds=(-0.08, 0.08, -0.55, 0.0, -0.08, 0.08))
        self.empunadura = pv.Cylinder(center=(0, -0.62, 0.05), direction=(1, 0, 0), radius=0.025, height=0.35)
        self.pata = pv.Cylinder(center=(0, 0.5, 0), direction=(0, 1, 0), radius=0.035, height=1.0, resolution=12)
        self.barra = pv.Cylinder(center=(0, 0.5, 0), direction=(0, 1, 0), radius=0.012, height=1.0, resolution=8)
        self.broca = pv.Cylinder(center=(0, 0.03, 0), direction=(0, 1, 0), radius=0.019, height=0.06, resolution=8)


def operador() -> tuple[pv.PolyData, pv.PolyData, pv.PolyData]:
    """Operador (1.72 m) de pie sobre z = 0 mirando hacia +y: (ropa, casco y lámpara, piernas y botas).
    Proporciones humanas promedio; sirve para ver la escala de la labor y del equipo manual."""
    ropa = pv.Cylinder(center=(0, 0, 1.15), direction=(0, 0, 1), radius=0.17, height=0.62, resolution=14)
    for s in (-1, 1):
        ropa = ropa.merge(pv.Cylinder(center=(s * 0.2, 0.12, 1.25), direction=(0, 1, -0.6), radius=0.05, height=0.55, resolution=8))
    cinta = pv.Cylinder(center=(0, 0, 1.05), direction=(0, 0, 1), radius=0.173, height=0.05, resolution=14)
    casco = pv.Sphere(radius=0.135, center=(0, 0, 1.6), theta_resolution=14, phi_resolution=8, end_phi=90)
    casco = casco.merge(pv.Sphere(radius=0.03, center=(0, 0.12, 1.66))).merge(cinta)
    piernas = pv.Sphere(radius=0.11, center=(0, 0, 1.58))
    for s in (-1, 1):
        piernas = piernas.merge(pv.Cylinder(center=(s * 0.1, 0, 0.41), direction=(0, 0, 1), radius=0.075, height=0.82, resolution=10))
        piernas = piernas.merge(pv.Box(bounds=(s * 0.1 - 0.06, s * 0.1 + 0.06, -0.06, 0.16, 0, 0.1)))
    return ropa.triangulate(), casco.triangulate(), piernas.triangulate()


def cartucho(largo: float, radio: float) -> pv.PolyData:
    return pv.Cylinder(center=(0, largo / 2, 0), direction=(0, 1, 0), radius=radio, height=largo, resolution=14)


def esferas_puntos(n: int) -> pv.PolyData:
    return pv.PolyData(np.zeros((max(n, 1), 3)))


# ================================================================= estilo «presentación» (vista en corte)
def textura_shotcrete(n: int = 256, semilla: int = 5) -> pv.Texture:
    """Concreto lanzado gris claro con placas de pernos en patrón de rombos (tresbolillo).
    Un mosaico de la textura = 2.4 m × 2.4 m con 2 placas (esquina y centro)."""
    rng = np.random.default_rng(semilla)
    base = rng.random((n // 8 + 1, n // 8 + 1))
    xs = np.linspace(0, n // 8, n, endpoint=False)
    i = xs.astype(int); f = xs - i
    a, b, c, d = base[i][:, i], base[i + 1][:, i], base[i][:, i + 1], base[i + 1][:, i + 1]
    fy, fx = f[:, None], f[None, :]
    ruido = a * (1 - fy) * (1 - fx) + b * fy * (1 - fx) + c * (1 - fy) * fx + d * fy * fx
    fino = rng.random((n, n)) * 0.08
    lum = 0.78 + 0.12 * ruido + fino
    img = np.stack([lum * 228, lum * 226, lum * 220], axis=2)
    lado = max(3, n // 40)
    for (cy, cx) in ((0, 0), (n // 2, n // 2)):
        for dy in range(-lado, lado + 1):
            for dx in range(-lado, lado + 1):
                if abs(dx) + abs(dy) <= lado:  # rombo
                    img[(cy + dy) % n, (cx + dx) % n] = (70, 72, 76)
    t = pv.Texture(np.clip(img, 0, 255).astype(np.uint8))
    try:
        t.repeat = True
    except Exception:  # noqa: BLE001
        pass
    return t


def _segmentos_seccion(seccion, corte: bool, piso: bool = True):
    """Tramos del contorno que se dibujan: en corte solo piso y pared izquierda (x < 0)."""
    sec = np.asarray(seccion, float)
    n = len(sec)
    alto = sec[:, 1].max()
    usar = []
    for i in range(n):
        j = (i + 1) % n
        (x1, z1), (x2, z2) = sec[i], sec[j]
        xm, zm = (x1 + x2) / 2, (z1 + z2) / 2
        es_piso = max(z1, z2) < 0.05 * alto
        if es_piso and not piso:
            continue
        if not corte or es_piso or (xm < -0.05 and zm < 0.98 * alto):
            usar.append((i, j))
    return sec, usar


def labor_tramo(seccion, y0: float, y1: float, corte: bool = False, desplazar: float = 0.0,
                escala_uv: float = 1 / 2.4, piso: bool = True) -> pv.PolyData:
    """Superficie interior de la labor entre y0 e y1. «desplazar» la mueve hacia el centro
    (capa de concreto lanzado sobre la roca). UV en metros/escala_uv (textura repetida)."""
    sec, usar = _segmentos_seccion(seccion, corte, piso)
    centro = np.array([0.0, sec[:, 1].mean()])
    pts, caras, uv = [], [], []
    s_acum = 0.0
    for i, j in usar:
        a, b = sec[i].copy(), sec[j].copy()
        if desplazar:
            for p in (a, b):
                v = centro - p
                p += v / (np.linalg.norm(v) or 1) * desplazar
        L = float(np.linalg.norm(b - a))
        k = len(pts)
        pts += [(a[0], y0, a[1]), (b[0], y0, b[1]), (b[0], y1, b[1]), (a[0], y1, a[1])]
        uv += [(y0 * escala_uv, s_acum * escala_uv), (y0 * escala_uv, (s_acum + L) * escala_uv),
               (y1 * escala_uv, (s_acum + L) * escala_uv), (y1 * escala_uv, s_acum * escala_uv)]
        caras += [4, k, k + 1, k + 2, k + 3]
        s_acum += L
    m = pv.PolyData(np.array(pts, float), faces=np.array(caras))
    m.active_texture_coordinates = np.array(uv, np.float32)
    return m


def piso_exterior(seccion, y0: float, y1: float, ancho_extra: float = 3.0) -> pv.PolyData:
    """Piso claro que sobresale del corte (como en las animaciones de presentación)."""
    xs = [p[0] for p in seccion]
    x0, x1 = min(xs), max(xs) + ancho_extra
    return pv.Plane(center=((x0 + x1) / 2, (y0 + y1) / 2, -0.01), direction=(0, 0, 1),
                    i_size=x1 - x0, j_size=y1 - y0)


def ducto_ventilacion(seccion, y0: float, y1: float, radio: float = 0.35) -> pv.PolyData:
    xs = [p[0] for p in seccion]
    zs = [p[1] for p in seccion]
    x = min(xs) + radio + 0.1
    z = max(zs) * 0.78
    return pv.Cylinder(center=(x, (y0 + y1) / 2, z), direction=(0, 1, 0), radius=radio, height=y1 - y0,
                       resolution=28)


def perno(largo: float = 0.12, lado_placa: float = 0.15) -> pv.PolyData:
    """Cabeza de perno con su placa (lo visible en la pared), eje local +Y hacia la pared."""
    placa = pv.Box(bounds=(-lado_placa / 2, lado_placa / 2, -0.01, 0.0, -lado_placa / 2, lado_placa / 2))
    tuerca = pv.Cylinder(center=(0, -0.03, 0), direction=(0, 1, 0), radius=0.025, height=0.05, resolution=6)
    return placa.merge(tuerca)


class PiezasVehiculo:
    """Vehículo utilitario genérico (chasis articulado, cabina, ruedas) para scoop, camión de
    carguío, desatadora y lanzadora de concreto. Coordenadas del chasis: frente hacia +Y."""

    def __init__(self, largo=7.0, ancho=1.6, alto_cabina=2.0, rueda=0.55):
        L, a = largo, ancho
        self.largo = L
        self.trasero = pv.Box(bounds=(-a / 2, a / 2, 0.0, L * 0.45, 0.45, 1.25))
        self.motor = pv.Box(bounds=(-a / 2 + 0.08, a / 2 - 0.08, 0.05, L * 0.3, 1.25, 1.6))
        self.delantero = pv.Box(bounds=(-a / 2 + 0.1, a / 2 - 0.1, L * 0.5, L * 0.85, 0.45, 1.1))
        self.articulacion = pv.Cylinder(center=(0, L * 0.475, 0.8), direction=(0, 0, 1), radius=0.18, height=0.5)
        self.cabina = pv.Box(bounds=(a / 2 - 0.75, a / 2, L * 0.33, L * 0.47, 1.25, alto_cabina))
        self.techo = pv.Box(bounds=(a / 2 - 0.8, a / 2 + 0.05, L * 0.31, L * 0.49, alto_cabina, alto_cabina + 0.08))
        self.vidrio = pv.Box(bounds=(a / 2 - 0.72, a / 2 - 0.04, L * 0.469, L * 0.472, 1.45, alto_cabina - 0.1))
        self.ruedas = [pv.Cylinder(center=(x, y, rueda), direction=(1, 0, 0), radius=rueda, height=0.38,
                                   resolution=30) for y in (L * 0.15, L * 0.68) for x in (-a / 2 - 0.12, a / 2 + 0.12)]
        self.llantas = [pv.Cylinder(center=r.center, direction=(1, 0, 0), radius=rueda * 0.5, height=0.40,
                                    resolution=16) for r in self.ruedas]
        self.luces = [pv.Cylinder(center=(x, L * 0.86, 1.0), direction=(0, 1, 0), radius=0.07, height=0.05)
                      for x in (-a / 2 + 0.2, a / 2 - 0.2)]
        # cuchara de scoop (eje de giro en y = L*0.85, z = 0.6); local: abre hacia +Y
        fondo = pv.Box(bounds=(-a / 2 - 0.1, a / 2 + 0.1, 0.0, 1.1, -0.05, 0.03))
        trasera = pv.Box(bounds=(-a / 2 - 0.1, a / 2 + 0.1, -0.05, 0.03, -0.05, 0.85))
        lados = [pv.Box(bounds=(x, x + 0.06, -0.05, 1.1, -0.05, 0.6)) for x in (-a / 2 - 0.16, a / 2 + 0.1)]
        self.cuchara = fondo.merge([trasera] + lados)
        self.carga = pv.Box(bounds=(-a / 2, a / 2, 0.05, 0.95, 0.0, 0.55))
        # brazo genérico (segmento unidad en +Y)
        self.segmento = pv.Box(bounds=(-0.08, 0.08, 0.0, 1.0, -0.08, 0.08))
        self.cesta = pv.Box(bounds=(-0.45, 0.45, -0.35, 0.35, 0.0, 0.08)).merge(
            [pv.Box(bounds=(-0.45, 0.45, -0.35, -0.31, 0.0, 1.0)), pv.Box(bounds=(-0.45, 0.45, 0.31, 0.35, 0.0, 1.0)),
             pv.Box(bounds=(-0.45, -0.41, -0.35, 0.35, 0.0, 1.0)), pv.Box(bounds=(0.41, 0.45, -0.35, 0.35, 0.0, 1.0))])
        self.martillo = pv.Box(bounds=(-0.08, 0.08, 0.0, 0.45, -0.08, 0.08)).merge(
            pv.Cylinder(center=(0, 0.6, 0), direction=(0, 1, 0), radius=0.03, height=0.3))
        self.boquilla = pv.Cylinder(center=(0, 0.2, 0), direction=(0, 1, 0), radius=0.05, height=0.4).merge(
            pv.Cylinder(center=(0, 0.45, 0), direction=(0, 1, 0), radius=0.08, height=0.1))
        self.viga_perno = pv.Box(bounds=(-0.06, 0.06, 0.0, 1.0, -0.05, 0.05))
        self.tanque = pv.Cylinder(center=(0, L * 0.18, 1.7), direction=(0, 0, 1), radius=0.45, height=0.7)
        self.persona = pv.Cylinder(center=(0, 0, 0.55), direction=(0, 0, 1), radius=0.12, height=0.9).merge(
            pv.Sphere(radius=0.12, center=(0, 0, 1.15)))
