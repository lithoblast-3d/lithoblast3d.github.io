"""
Sonidos SINTETIZADOS (no son grabaciones): motor diésel, percusión de la perforadora,
carguío (suave) y detonación. Se generan con numpy como WAV en una carpeta temporal
y se reproducen con QtMultimedia (QSoundEffect). Si QtMultimedia no está disponible,
la simulación continúa en silencio.
"""

from __future__ import annotations

import tempfile
import wave
from pathlib import Path

import numpy as np

FS = 22050


def _guardar(nombre: str, senal: np.ndarray, carpeta: Path) -> Path:
    s = np.clip(senal, -1, 1)
    datos = (s * 32000).astype(np.int16)
    ruta = carpeta / f"{nombre}.wav"
    with wave.open(str(ruta), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(FS)
        w.writeframes(datos.tobytes())
    return ruta


def _ruido(n, rng):
    return rng.uniform(-1, 1, n)


def motor(seg=2.0, rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng(1)
    t = np.arange(int(FS * seg)) / FS
    f0 = 38.0  # Hz (ralentí); periodo entero en 2 s para un bucle limpio
    s = 0.45 * np.sin(2 * np.pi * f0 * t) + 0.25 * np.sin(2 * np.pi * 2 * f0 * t) + 0.12 * np.sin(2 * np.pi * 3 * f0 * t)
    golpes = (np.sin(2 * np.pi * f0 * 2 * t) > 0.92).astype(float)
    ruido = np.convolve(_ruido(len(t), rng), np.ones(30) / 30, mode="same")
    return 0.55 * (s * (0.8 + 0.2 * golpes) + 0.35 * ruido)


def percusion(seg=1.0, rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng(2)
    n = int(FS * seg)
    t = np.arange(n) / FS
    out = np.zeros(n)
    frec = 50.0  # golpes por segundo (ilustrativo)
    periodo = int(FS / frec)
    golpe = np.exp(-np.arange(periodo) / (FS * 0.004)) * _ruido(periodo, rng)
    golpe += 0.6 * np.exp(-np.arange(periodo) / (FS * 0.006)) * np.sin(2 * np.pi * 900 * np.arange(periodo) / FS)
    for k in range(0, n - periodo, periodo):
        out[k:k + periodo] += golpe
    zumbido = 0.25 * np.sin(2 * np.pi * 120 * t) + 0.15 * np.convolve(_ruido(n, rng), np.ones(8) / 8, mode="same")
    return 0.5 * out + 0.35 * zumbido


def explosion(seg=4.0, rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng(3)
    n = int(FS * seg)
    t = np.arange(n) / FS
    env = np.exp(-t / 0.7) * (1 - np.exp(-t / 0.004))
    grave = np.sin(2 * np.pi * (45 * np.exp(-t / 1.5) + 18) * t)
    ruido = np.convolve(_ruido(n, rng), np.ones(40) / 40, mode="same") * 4
    retumbo = np.exp(-t / 2.0) * np.convolve(_ruido(n, rng), np.ones(200) / 200, mode="same") * 10
    return np.tanh(1.6 * (env * (0.9 * grave + 0.8 * ruido) + 0.5 * retumbo))


def carguio(seg=1.5, rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng(4)
    n = int(FS * seg)
    s = np.convolve(_ruido(n, rng), np.ones(60) / 60, mode="same") * 2.5
    return 0.25 * s


def generar_todos(carpeta: Path | None = None) -> dict[str, Path]:
    carpeta = Path(carpeta or tempfile.mkdtemp(prefix="b3d_audio_"))
    return {"motor": _guardar("motor", motor(), carpeta), "percusion": _guardar("percusion", percusion(), carpeta),
            "explosion": _guardar("explosion", explosion(), carpeta), "carguio": _guardar("carguio", carguio(), carpeta)}


class Sonidos:
    """Reproductor tolerante a fallos (sin QtMultimedia = silencio)."""

    def __init__(self):
        self.ok = False
        self.efectos = {}
        self.volumen = 0.7
        self.silencio = False
        try:
            from PySide6.QtCore import QUrl
            from PySide6.QtMultimedia import QSoundEffect
            rutas = generar_todos()
            for k, r in rutas.items():
                e = QSoundEffect()
                e.setSource(QUrl.fromLocalFile(str(r)))
                e.setLoopCount(QSoundEffect.Loop.Infinite.value if k in ("motor", "percusion") else 1)
                e.setVolume(self.volumen)
                self.efectos[k] = e
            self.ok = True
        except Exception:  # noqa: BLE001
            self.ok = False

    def reproducir(self, nombre: str, volumen: float | None = None) -> None:
        if not self.ok or self.silencio or nombre not in self.efectos:
            return
        e = self.efectos[nombre]
        e.setVolume(self.volumen if volumen is None else volumen)
        if not e.isPlaying():
            e.play()

    def detener(self, nombre: str | None = None) -> None:
        if not self.ok:
            return
        for k, e in self.efectos.items():
            if nombre is None or k == nombre:
                e.stop()

    def set_silencio(self, s: bool) -> None:
        self.silencio = s
        if s:
            self.detener()
