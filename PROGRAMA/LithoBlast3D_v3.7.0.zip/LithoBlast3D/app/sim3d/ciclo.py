"""
Ciclo de la simulación completa: 13 etapas (ciclo de minado) reproducibles por separado o en cadena.

Reloj de simulación independiente del reloj real: velocidad (0.1×–8×), cámara lenta,
pausa, continuar, reiniciar y salto a una etapa. Sin interfaz (se prueba aparte).
Las duraciones son de PRESENTACIÓN (segundos de animación), no tiempos de operación.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Etapa:
    clave: str
    nombre: str
    duracion: float  # s de animación (a velocidad 1×)
    descripcion: str
    validado: bool = False  # True solo si la etapa muestra datos del proyecto


ETAPAS = [
    Etapa("escenario", "1. Labor y sección", 6.0, "Galería, sección del frente y topografía de la labor."),
    Etapa("malla", "2. Malla de perforación", 6.0,
          "Marcado de los taladros en el frente según la malla del proyecto.", True),
    Etapa("ingreso", "3. Ingreso y posicionamiento del equipo", 8.0,
          "El equipo avanza hasta el frente y se estaciona; se comprueban sus restricciones geométricas."),
    Etapa("perforacion", "4. Perforación", 30.0,
          "Los brazos se orientan a cada taladro, la broca gira y avanza hasta la longitud de la malla."),
    Etapa("retiro", "5. Retiro del equipo", 6.0, "El equipo retrocede a una zona segura."),
    Etapa("carguio", "6. Carguío (ilustrativo)", 14.0,
          "Vista en corte: taladros vacíos → cargados según la malla. Sin procedimiento operativo."),
    Etapa("secuencia", "7. Secuencia de salida", 8.0,
          "Colores por retardo / orden de salida del proyecto.", True),
    Etapa("detonacion", "8. Detonación", 5.0,
          "Destello, onda y vibración de cámara (efecto visual)."),
    Etapa("fragmentacion", "9. Fragmentación y proyección", 14.0,
          "Bloques con física simplificada: gravedad, colisiones y acumulación (cinematográfico)."),
    Etapa("resultado", "10. Ventilación y resultado", 10.0,
          "Ducto de ventilación: el humo y el polvo se evacúan; comparación antes / después."),
    Etapa("limpieza", "11. Limpieza (carga con scoop)", 18.0,
          "El scoop (LHD) carga el material volado y lo retira de la labor."),
    Etapa("desatado", "12. Desatado", 8.0, "Retiro de rocas sueltas del techo y las paredes nuevas."),
    Etapa("sostenimiento", "13. Sostenimiento", 16.0,
          "Concreto lanzado (shotcrete) y colocación de pernos en el tramo nuevo (patrón ilustrativo)."),
]

TITULOS = {"escenario": "LABOR", "malla": "MALLA DE PERFORACIÓN", "ingreso": "POSICIONAMIENTO",
           "perforacion": "PERFORACIÓN", "retiro": "RETIRO DEL EQUIPO", "carguio": "CARGUÍO",
           "secuencia": "SECUENCIA DE SALIDA", "detonacion": "VOLADURA", "fragmentacion": "VOLADURA",
           "resultado": "VENTILACIÓN", "limpieza": "LIMPIEZA (SCOOP)", "desatado": "DESATADO",
           "sostenimiento": "SOSTENIMIENTO"}

CLAVES = [e.clave for e in ETAPAS]


class Reloj:
    """Tiempo de simulación por etapas.

    modo_cadena=True: al terminar una etapa sigue la siguiente.
    modo_cadena=False: se detiene al final de la etapa actual.
    """

    VEL_MIN, VEL_MAX = 0.1, 8.0
    FACTOR_LENTA = 0.25

    def __init__(self, etapas=ETAPAS):
        self.etapas = list(etapas)
        self.indice = 0
        self.t = 0.0  # s dentro de la etapa
        self.velocidad = 1.0
        self.camara_lenta = False
        self.en_marcha = False
        self.modo_cadena = True
        self.terminado = False

    # ---------------------------------------------------------------- consulta
    @property
    def etapa(self) -> Etapa:
        return self.etapas[self.indice]

    @property
    def progreso_etapa(self) -> float:
        return min(1.0, self.t / self.etapa.duracion) if self.etapa.duracion > 0 else 1.0

    @property
    def progreso_total(self) -> float:
        total = sum(e.duracion for e in self.etapas)
        hecho = sum(e.duracion for e in self.etapas[:self.indice]) + min(self.t, self.etapa.duracion)
        return hecho / total if total else 1.0

    @property
    def factor(self) -> float:
        return self.velocidad * (self.FACTOR_LENTA if self.camara_lenta else 1.0)

    # ---------------------------------------------------------------- control
    def iniciar(self, indice: int | None = None, cadena: bool | None = None) -> None:
        if indice is not None:
            self.ir_a(indice)
        if cadena is not None:
            self.modo_cadena = cadena
        self.en_marcha = True
        self.terminado = False

    def pausar(self) -> None:
        self.en_marcha = False

    def continuar(self) -> None:
        if not self.terminado:
            self.en_marcha = True

    def reiniciar(self) -> None:
        self.indice = 0
        self.t = 0.0
        self.en_marcha = False
        self.terminado = False

    def ir_a(self, indice: int) -> None:
        if not 0 <= indice < len(self.etapas):
            raise IndexError("Etapa inexistente")
        self.indice = indice
        self.t = 0.0
        self.terminado = False

    def set_velocidad(self, v: float) -> None:
        self.velocidad = max(self.VEL_MIN, min(self.VEL_MAX, float(v)))

    def avanzar(self, dt_real: float) -> list[tuple[str, int]]:
        """Avanza el reloj; devuelve eventos [("fin_etapa", i), ("inicio_etapa", j), ("fin", i)]."""
        eventos = []
        if not self.en_marcha or self.terminado:
            return eventos
        self.t += max(0.0, dt_real) * self.factor
        while self.t >= self.etapa.duracion:
            eventos.append(("fin_etapa", self.indice))
            sobra = self.t - self.etapa.duracion
            if self.modo_cadena and self.indice < len(self.etapas) - 1:
                self.indice += 1
                self.t = sobra
                eventos.append(("inicio_etapa", self.indice))
            else:
                self.t = self.etapa.duracion
                self.en_marcha = False
                self.terminado = True
                eventos.append(("fin", self.indice))
                break
        return eventos
