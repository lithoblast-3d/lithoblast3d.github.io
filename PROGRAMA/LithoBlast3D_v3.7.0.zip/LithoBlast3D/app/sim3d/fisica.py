"""
Física simplificada de cuerpos rígidos para los bloques (efecto CINEMATOGRÁFICO).

- Cada bloque: posición, velocidad, orientación (matriz 3×3), velocidad angular,
  radio envolvente y masa (densidad × volumen de su celda).
- Gravedad 9.81 m/s²; integración semi-implícita de Euler con subpasos.
- Colisiones: piso (Z = 0, con «hundimiento» en la pila), paredes laterales y techo
  de la labor (sección), el frente nuevo (no vuelven a entrar a la roca) y entre
  bloques (esferas envolventes, impulso con restitución y fricción).
- Reposo: un bloque lento sobre apoyo se «duerme» para formar la pila.

Las velocidades iniciales son un RECURSO VISUAL (dirección hacia la labor y hacia la
cara libre); NO son una predicción de proyección ni de alcance de la voladura.
"""

from __future__ import annotations

import numpy as np

G = np.array([0.0, 0.0, -9.81])


def _rot(axis_ang: np.ndarray) -> np.ndarray:
    """Matrices de rotación (n,3,3) a partir de vectores eje·ángulo (n,3) (Rodrigues)."""
    th = np.linalg.norm(axis_ang, axis=1)
    k = np.where(th[:, None] > 1e-12, axis_ang / np.maximum(th[:, None], 1e-12), 0.0)
    K = np.zeros((len(k), 3, 3))
    K[:, 0, 1], K[:, 0, 2] = -k[:, 2], k[:, 1]
    K[:, 1, 0], K[:, 1, 2] = k[:, 2], -k[:, 0]
    K[:, 2, 0], K[:, 2, 1] = -k[:, 1], k[:, 0]
    s, c = np.sin(th)[:, None, None], np.cos(th)[:, None, None]
    return np.eye(3)[None] + s * K + (1 - c) * (K @ K)


class MundoFisico:
    def __init__(self, centros, radios, masas, medio_ancho: float, alto: float, y_frente_final: float,
                 restitucion: float = 0.25, friccion: float = 0.55):
        self.n = len(centros)
        self.c0 = np.asarray(centros, float).copy()  # centro inicial (para matriz de transformación)
        self.x = self.c0.copy()
        self.v = np.zeros((self.n, 3))
        self.w = np.zeros((self.n, 3))
        self.R = np.repeat(np.eye(3)[None], self.n, axis=0)
        self.r = np.asarray(radios, float)
        self.m = np.maximum(np.asarray(masas, float), 1e-3)
        self.activo = np.zeros(self.n, bool)  # liberado por la detonación
        self.dormido = np.zeros(self.n, bool)
        self.medio_ancho = medio_ancho
        self.alto = alto
        self.y_frente = y_frente_final  # cara nueva tras el disparo (los bloques no entran en Y > y_frente)
        self.e = restitucion
        self.mu = friccion

    def liberar(self, idx, velocidades, giros) -> None:
        idx = np.asarray(idx, int)
        self.activo[idx] = True
        self.dormido[idx] = False
        self.v[idx] = velocidades
        self.w[idx] = giros

    def matrices(self) -> np.ndarray:
        """Transformaciones 4×4 (n,4,4): rotación alrededor del centro inicial + traslación."""
        T = np.repeat(np.eye(4)[None], self.n, axis=0)
        T[:, :3, :3] = self.R
        T[:, :3, 3] = self.x - np.einsum("nij,nj->ni", self.R, self.c0)
        return T

    def paso(self, dt: float, subpasos: int = 3) -> None:
        if dt <= 0:
            return
        h = dt / subpasos
        for _ in range(subpasos):
            m = self.activo & ~self.dormido
            if not m.any():
                return
            self.v[m] += G * h
            self.x[m] += self.v[m] * h
            self.R[m] = _rot(self.w[m] * h) @ self.R[m]
            self._limites(m)
            self._choques(h)
            self._limites(self.activo)
            self._dormir(m)

    def _limites(self, m) -> None:
        r = self.r
        # piso
        bajo = m & (self.x[:, 2] - r < 0)
        if bajo.any():
            self.x[bajo, 2] = r[bajo]
            vz = self.v[bajo, 2]
            self.v[bajo, 2] = np.where(vz < 0, -vz * self.e, vz)
            self.v[bajo, :2] *= (1 - self.mu * 0.15)
            self.w[bajo] *= 0.85
        # techo
        alto = m & (self.x[:, 2] + r > self.alto)
        if alto.any():
            self.x[alto, 2] = self.alto - r[alto]
            self.v[alto, 2] = -np.abs(self.v[alto, 2]) * self.e
        # paredes
        for signo in (-1, 1):
            fuera = m & (signo * self.x[:, 0] + r > self.medio_ancho)
            if fuera.any():
                self.x[fuera, 0] = signo * (self.medio_ancho - r[fuera])
                self.v[fuera, 0] = -signo * np.abs(self.v[fuera, 0]) * self.e
        # el frente nuevo
        dentro = m & (self.x[:, 1] + r > self.y_frente)
        if dentro.any():
            self.x[dentro, 1] = self.y_frente - r[dentro]
            self.v[dentro, 1] = -np.abs(self.v[dentro, 1]) * self.e

    def _choques(self, h) -> None:
        act = np.nonzero(self.activo)[0]
        if len(act) < 2:
            return
        X = self.x[act]
        d = X[:, None, :] - X[None, :, :]
        dist = np.linalg.norm(d, axis=2)
        rr = self.r[act][:, None] + self.r[act][None, :]
        i, j = np.nonzero(np.triu(dist < rr * 0.9, 1))
        if len(i) == 0:
            return
        a, b = act[i], act[j]
        n = d[i, j] / np.maximum(dist[i, j][:, None], 1e-9)
        pen = (rr[i, j] * 0.9 - dist[i, j])
        ma, mb = self.m[a], self.m[b]
        inv = 1 / ma + 1 / mb
        # separación posicional (proporcional a la masa inversa)
        corr = (pen / inv)[:, None] * n
        np.add.at(self.x, a, corr / ma[:, None] * 0.8)
        np.add.at(self.x, b, -corr / mb[:, None] * 0.8)
        vrel = self.v[a] - self.v[b]
        vn = np.einsum("ij,ij->i", vrel, n)
        acerc = vn < 0
        if acerc.any():
            jimp = (-(1 + self.e) * vn[acerc] / inv[acerc])[:, None] * n[acerc]
            aa, bb = a[acerc], b[acerc]
            np.add.at(self.v, aa, jimp / ma[acerc][:, None])
            np.add.at(self.v, bb, -jimp / mb[acerc][:, None])
            # fricción tangencial simple
            vt = vrel[acerc] - vn[acerc][:, None] * n[acerc]
            np.add.at(self.v, aa, -vt * self.mu * 0.25)
            np.add.at(self.v, bb, vt * self.mu * 0.25)
        # despertar al recibir golpes fuertes
        fuertes = np.abs(vn) > 0.6
        self.dormido[a[fuertes]] = False
        self.dormido[b[fuertes]] = False

    def _dormir(self, m) -> None:
        lento = np.linalg.norm(self.v, axis=1) < 0.12
        apoyado = self.x[:, 2] - self.r < 0.02 + 0.6 * self.r
        z = m & lento & apoyado
        self.v[z] = 0
        self.w[z] = 0
        self.dormido[z] = True

    def energia_cinetica(self) -> float:
        a = self.activo & ~self.dormido
        return float(0.5 * np.sum(self.m[a] * np.sum(self.v[a] ** 2, axis=1)))


def velocidades_iniciales(centros: np.ndarray, centro_cara_libre: np.ndarray, rng, escala: float = 1.0):
    """Velocidades VISUALES: hacia la labor (−Y) y alejándose del centro del arranque."""
    c = np.asarray(centros, float)
    radial = c - centro_cara_libre
    radial[:, 1] = 0
    nr = np.linalg.norm(radial, axis=1, keepdims=True)
    radial = np.where(nr > 1e-6, radial / np.maximum(nr, 1e-6), 0)
    v = np.zeros_like(c)
    v[:, 1] = -(6.0 + rng.random(len(c)) * 6.0) * escala
    v += -radial * (0.5 + rng.random((len(c), 1)) * 1.5) * escala  # convergen hacia la abertura del arranque
    v[:, 2] += (rng.random(len(c)) * 2.0) * escala
    w = rng.normal(0, 4.0, (len(c), 3)) * escala
    return v, w
