"""
Geometría fracturable del bloque a volar (efecto VISUAL, no predicción).

El volumen a volar = sección del frente (casco convexo en X–Z) × avance (Y de 0 a L).
Se divide en celdas de Voronoi convexas: cada celda es la intersección de semiespacios
(caras del volumen + planos bisectores con las semillas vecinas). Los vértices se
obtienen resolviendo intersecciones de 3 planos (numpy) y se conservan los que cumplen
todos los semiespacios. Las celdas cubren el volumen sin huecos, por eso el frente se
ve entero antes de la voladura y se separa en bloques al detonar.

Las semillas se concentran cerca de los taladros cargados (más energía = bloques más
pequeños, solo como recurso visual). Los tamaños de bloque NO son una predicción de
fragmentación: para eso se requiere un modelo calibrado (p. ej. Kuz-Ram con datos de
campo), que este módulo no implementa.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass

import numpy as np


@dataclass
class Fragmento:
    vertices: np.ndarray  # (n, 3) en coordenadas locales del simulador
    centro: np.ndarray  # centroide aproximado (media de vértices)
    volumen: float
    taladro: int  # índice del taladro más cercano (define su instante de salida)


def _planos_volumen(seccion_convexa, largo: float):
    """Semiespacios n·x <= d del prisma (sección convexa antihoraria en X–Z)."""
    planos = []
    pts = list(seccion_convexa)
    for (x1, z1), (x2, z2) in zip(pts, pts[1:] + pts[:1]):
        # normal exterior en X–Z para polígono antihorario: (dz, -dx)
        dx, dz = x2 - x1, z2 - z1
        n = np.array([dz, 0.0, -dx])
        n /= np.linalg.norm(n) or 1
        planos.append((n, float(n @ np.array([x1, 0.0, z1]))))
    planos.append((np.array([0.0, -1.0, 0.0]), 0.0))  # y >= 0
    planos.append((np.array([0.0, 1.0, 0.0]), float(largo)))  # y <= L
    return planos


def _celda(semilla, otras, base, tol=1e-7):
    planos = list(base)
    for o in otras:
        n = o - semilla
        L = np.linalg.norm(n)
        if L < 1e-9:
            continue
        n = n / L
        planos.append((n, float(n @ (semilla + o) / 2)))
    N = np.array([p[0] for p in planos]); D = np.array([p[1] for p in planos])
    combos = _combinaciones(len(planos))
    A = N[combos]  # (m, 3, 3)
    det = np.linalg.det(A)
    ok = np.abs(det) > 1e-10
    A, B = A[ok], D[combos[ok]]
    X = np.linalg.solve(A, B[..., None])[..., 0]
    dentro = np.all(X @ N.T <= D + 1e-6, axis=1)
    verts = X[dentro]
    if len(verts) < 4:
        return None
    v = np.unique(np.round(verts, 6), axis=0)
    return v if len(v) >= 4 else None


_CACHE_COMB: dict[int, np.ndarray] = {}


def _combinaciones(n: int) -> np.ndarray:
    if n not in _CACHE_COMB:
        _CACHE_COMB[n] = np.array(list(itertools.combinations(range(n), 3)), dtype=np.int32)
    return _CACHE_COMB[n]


def simplificar_poligono(sec, max_vertices: int = 16):
    """Reduce el número de vértices de un polígono convexo conservando su forma general."""
    sec = list(sec)
    if len(sec) <= max_vertices:
        return sec
    idx = np.linspace(0, len(sec), max_vertices, endpoint=False).astype(int)
    return [sec[i] for i in idx]


def _volumen_casco(v: np.ndarray) -> float:
    """Volumen del casco convexo (tetraedros desde el centroide sobre caras del casco)."""
    try:
        from scipy.spatial import ConvexHull
        return float(ConvexHull(v).volume)
    except Exception:  # noqa: BLE001
        ext = v.max(0) - v.min(0)
        return float(np.prod(ext) * 0.5)


def generar(seccion_convexa, largo: float, puntos_taladros: np.ndarray, n_fragmentos: int = 90,
            semilla_azar: int = 7, vecinos: int = 36) -> list[Fragmento]:
    rng = np.random.default_rng(semilla_azar)
    sec = np.asarray(simplificar_poligono(seccion_convexa), float)
    xmin, zmin = sec.min(0); xmax, zmax = sec.max(0)

    def dentro(x, z):
        n = len(sec)
        for i in range(n):
            (x1, z1), (x2, z2) = sec[i], sec[(i + 1) % n]
            if (x2 - x1) * (z - z1) - (z2 - z1) * (x - x1) < 0:
                return False
        return True

    semillas = []
    intentos = 0
    pt = np.asarray(puntos_taladros, float) if len(puntos_taladros) else np.zeros((0, 2))
    while len(semillas) < n_fragmentos and intentos < n_fragmentos * 60:
        intentos += 1
        if len(pt) and rng.random() < 0.55:
            b = pt[rng.integers(len(pt))]
            x, z = b[0] + rng.normal(0, 0.25), b[1] + rng.normal(0, 0.25)
        else:
            x, z = rng.uniform(xmin, xmax), rng.uniform(zmin, zmax)
        if dentro(x, z):
            semillas.append((x, rng.uniform(0.02, largo - 0.02), z))
    S = np.array(semillas)
    base = _planos_volumen([tuple(p) for p in sec], largo)
    frags = []
    for i, s in enumerate(S):
        d = np.linalg.norm(S - s, axis=1)
        idx = np.argsort(d)[1:vecinos + 1]
        v = _celda(s, S[idx], base)
        if v is None:
            continue
        c = v.mean(0)
        if len(pt):
            k = int(np.argmin(np.hypot(pt[:, 0] - c[0], pt[:, 1] - c[2])))
        else:
            k = 0
        frags.append(Fragmento(vertices=v, centro=c, volumen=_volumen_casco(v), taladro=k))
    return frags
