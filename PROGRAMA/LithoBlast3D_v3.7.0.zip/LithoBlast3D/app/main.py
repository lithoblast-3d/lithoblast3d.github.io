"""Crea la aplicación Qt, aplica el tema y administra qué proyecto está abierto."""

import sys

from PySide6.QtCore import QTimer
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox

from app import NOMBRE_APP, VERSION
from app.core import archivos
from app.core.documento import Documento
from app.core.ejemplos import (
    crear_ejemplo_subterraneo,
    crear_ejemplo_tajo,
    crear_proyecto_vacio,
    explosivos_referenciales,
)
from app.ui.dialogos import DialogoNuevoProyecto
from app.ui.tema import aplicar_tema_oscuro
from app.ui.ventana_principal import FILTRO_PROYECTO, VentanaPrincipal


class Controlador:
    """Abre documentos reemplazando la ventana actual."""

    def __init__(self):
        self.ventana: VentanaPrincipal | None = None

    def mostrar(self, documento: Documento) -> None:
        anterior = self.ventana
        self.ventana = VentanaPrincipal(documento, self)
        self.ventana.show()
        if anterior is not None:
            anterior.cerrar_sin_preguntar = True
            anterior.close()

    def nuevo(self, ventana: VentanaPrincipal) -> None:
        if not ventana.confirmar_descartar():
            return
        dialogo = DialogoNuevoProyecto(ventana)
        if dialogo.exec():
            proyecto = crear_proyecto_vacio(dialogo.nombre.text().strip(), dialogo.formulario.valor())
            proyecto.explosivos = explosivos_referenciales()
            self.mostrar(Documento(proyecto))

    def abrir(self, ventana: VentanaPrincipal) -> None:
        if not ventana.confirmar_descartar():
            return
        ruta, _ = QFileDialog.getOpenFileName(ventana, "Abrir proyecto", "", FILTRO_PROYECTO)
        if not ruta:
            return
        try:
            proyecto = archivos.abrir_proyecto(ruta)
        except (OSError, ValueError) as error:
            QMessageBox.critical(ventana, "Abrir proyecto", f"No se pudo abrir:\n{error}")
            return
        self.mostrar(Documento(proyecto, ruta))

    def ejemplo(self, ventana: VentanaPrincipal, tipo: str) -> None:
        if not ventana.confirmar_descartar():
            return
        proyecto = crear_ejemplo_tajo() if tipo == "tajo" else crear_ejemplo_subterraneo()
        self.mostrar(Documento(proyecto))


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName(NOMBRE_APP)
    app.setApplicationVersion(VERSION)
    app.setFont(QFont("Segoe UI", 10))
    aplicar_tema_oscuro(app)

    controlador = Controlador()
    if len(sys.argv) > 1 and sys.argv[1].lower().endswith(archivos.EXTENSION):
        controlador.mostrar(Documento(archivos.abrir_proyecto(sys.argv[1]), sys.argv[1]))
    else:
        controlador.mostrar(Documento(crear_ejemplo_tajo()))
    from app.ui.dialogo_inicio import mostrar_al_iniciar
    if mostrar_al_iniciar() and controlador.ventana is not None:
        QTimer.singleShot(350, controlador.ventana.pantalla_inicio)
    return app.exec()
