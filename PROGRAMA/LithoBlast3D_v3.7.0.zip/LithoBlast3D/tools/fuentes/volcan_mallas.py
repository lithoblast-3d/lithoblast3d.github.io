"""Extrae las mallas del compilado «Diseños de malla en labores de avance — Mina SC-CR (Volcan), 2022».

El PDF tiene los dibujos en vectores: cada taladro es un círculo (≈3.5 pt; rimados ≈6.8 pt), el color de
relleno indica el explosivo (rojo = Emulnor 3000, verde = Emulnor 1000; según la leyenda de cada ficha) y el
número junto al círculo es el retardo (Fanel LP). La sección exterior (línea negra) mide lo que dice el título.
Uso: python tools/fuentes/volcan_mallas.py DISEÑOS.pdf  → app/datos/referencias_volcan_sccr2022.json
"""
import json
import math
import re
import sys
from pathlib import Path

import pdfplumber

# Datos de las tablas de cada ficha (son imágenes en el PDF; transcritos de la columna de mayor longitud).
TABLAS = {
    2: dict(L=3.9, cargados=38, rimados=4, alivios=0, broca=51, rimadora=102, cart={"Emulnor 3000 1 1/4\"x12\"": 370, "Emulnor 1000 1 1/4\"x12\"": 84}, kg=119.4, cordon=40, fanel=38, carmex=2, avance=3.80, eficiencia=0.97, densidad=3.40, fa=31.4, fc=2.07, fp=0.61, fe=7.8),
    3: dict(L=3.9, cargados=34, rimados=4, alivios=4, broca=51, rimadora=102, cart={"Emulnor 3000 1 1/4\"x12\"": 297, "Emulnor 1000 1 1/4\"x12\"": 84}, kg=100.0, cordon=40, fanel=34, carmex=2, avance=3.80, eficiencia=0.97, densidad=3.40, fa=26.3, fc=1.73, fp=0.51, fe=6.5),
    4: dict(L=3.9, cargados=29, rimados=4, alivios=4, broca=51, rimadora=102, cart={"Emulnor 3000 1 1/4\"x12\"": 243, "Emulnor 1000 1 1/8\"x12\"": 75}, kg=80.8, cordon=40, fanel=29, carmex=2, avance=3.80, eficiencia=0.97, densidad=3.40, fa=21.3, fc=1.40, fp=0.41, fe=5.2),
    5: dict(L=3.0, cargados=19, rimados=4, alivios=4, broca=51, rimadora=102, cart={"Emulnor 1000 1 1/4\"x12\"": 135, "Emulnor 1000 1 1/8\"x12\"": 36}, kg=41.5, cordon=12, fanel=19, carmex=2, avance=2.90, eficiencia=0.97, densidad=3.40, fa=14.3, fc=0.94, fp=0.28, fe=3.1),
    6: dict(L=3.9, cargados=19, rimados=0, alivios=4, broca=51, rimadora=None, cart={"Emulnor 3000 1 1/4\"x12\"": 139, "Emulnor 1000 1 1/4\"x12\"": 66}, kg=53.5, cordon=40, fanel=19, carmex=2, avance=3.80, eficiencia=0.97, densidad=3.40, fa=14.1, fc=0.93, fp=0.33, fe=3.4),
    7: dict(L=3.9, cargados=16, rimados=0, alivios=0, broca=51, rimadora=None, cart={"Emulnor 1000 1 1/4\"x12\"": 112, "Emulnor 1000 1 1/8\"x12\"": 60}, kg=41.0, cordon=40, fanel=16, carmex=2, avance=3.80, eficiencia=0.97, densidad=3.40, fa=10.8, fc=0.71, fp=0.25, fe=2.3),
    8: dict(L=3.9, cargados=40, rimados=4, alivios=4, broca=45, rimadora=102, cart={"Emulnor 3000 1 1/2\"x12\"": 90, "Emulnor 3000 1 1/4\"x12\"": 292, "Emulnor 1000 1 1/4\"x12\"": 90}, kg=137.1, cordon=40, fanel=40, carmex=2, avance=3.80, eficiencia=0.97, densidad=2.70, fa=36.1, fc=2.37, fp=0.88, fe=8.9),
    9: dict(L=3.9, cargados=36, rimados=4, alivios=4, broca=45, rimadora=102, cart={"Emulnor 3000 1 1/2\"x12\"": 86, "Emulnor 3000 1 1/4\"x12\"": 244, "Emulnor 1000 1 1/4\"x12\"": 90}, kg=122.5, cordon=40, fanel=36, carmex=2, avance=3.80, eficiencia=0.97, densidad=2.70, fa=32.2, fc=2.12, fp=0.79, fe=7.9),
    10: dict(L=3.9, cargados=40, rimados=4, alivios=4, broca=45, rimadora=102, cart={"Emulnor 3000 1 1/2\"x12\"": 90, "Emulnor 3000 1 1/4\"x12\"": 292, "Emulnor 1000 1 1/4\"x12\"": 90}, kg=137.1, cordon=40, fanel=40, carmex=2, avance=3.80, eficiencia=0.97, densidad=2.70, fa=36.1, fc=2.37, fp=0.88, fe=8.9),
    11: dict(L=3.9, cargados=36, rimados=4, alivios=4, broca=45, rimadora=102, cart={"Emulnor 3000 1 1/2\"x12\"": 86, "Emulnor 3000 1 1/4\"x12\"": 244, "Emulnor 1000 1 1/4\"x12\"": 90}, kg=122.5, cordon=40, fanel=36, carmex=2, avance=3.80, eficiencia=0.97, densidad=2.70, fa=32.2, fc=2.12, fp=0.79, fe=7.9),
    12: dict(L=3.9, cargados=50, rimados=4, alivios=4, broca=45, rimadora=102, cart={"Emulnor 3000 1 1/2\"x12\"": 98, "Emulnor 3000 1 1/4\"x12\"": 384, "Emulnor 1000 1 1/4\"x12\"": 96}, kg=166.8, cordon=45, fanel=50, carmex=2, avance=3.80, eficiencia=0.97, densidad=2.70, fa=43.9, fc=2.17, fp=0.80, fe=8.2),
    13: dict(L=3.9, cargados=46, rimados=4, alivios=4, broca=45, rimadora=102, cart={"Emulnor 3000 1 1/2\"x12\"": 94, "Emulnor 3000 1 1/4\"x12\"": 336, "Emulnor 1000 1 1/4\"x12\"": 96}, kg=152.1, cordon=45, fanel=46, carmex=2, avance=3.80, eficiencia=0.97, densidad=2.70, fa=40.0, fc=1.98, fp=0.73, fe=7.4),
    14: dict(L=3.9, cargados=42, rimados=4, alivios=4, broca=45, rimadora=102, cart={"Emulnor 3000 1 1/2\"x12\"": 90, "Emulnor 3000 1 1/4\"x12\"": 296, "Emulnor 1000 1 1/4\"x12\"": 96}, kg=139.7, cordon=45, fanel=42, carmex=2, avance=3.80, eficiencia=0.97, densidad=2.70, fa=36.8, fc=1.82, fp=0.67, fe=6.8),
}


def color(c):
    c = c.get("non_stroking_color")
    if not isinstance(c, (tuple, list)) or len(c) < 3:
        return None
    r, g, b = c[:3]
    if r > 0.8 and g < 0.3 and b < 0.3:
        return "rojo"
    if g > 0.7 and r < 0.4 and b < 0.4:
        return "verde"
    if r > 0.8 and g > 0.8 and b < 0.3:
        return "amarillo"
    return None


def pagina(p, num):
    texto = p.extract_text() or ""
    m = re.search(r"Malla\s+([\d.]+)\s*m\.?\s*x\s*([\d.]+)\s*m", texto)
    A, H = float(m.group(1)), float(m.group(2))
    mr = re.search(r"Tipo de roca\s+([IVX]+\s?[AB]?)\s*\(RMR\s*(\d+)\s*-\s*(\d+)\)", texto)
    clase, r0, r1 = mr.group(1).replace(" ", ""), int(mr.group(2)), int(mr.group(3))
    codigo = next((w for w in ("SN-IIIB", "SN-IVA", "SN-IVB", "SN-V", "BR-IVA", "BR-IVB") if w in texto),
                  "RP/BP/XC" if "RP/BP/XC" in texto else "")
    zona_y = 400
    # sección exterior: objetos negros grandes (líneas y curvas) del dibujo
    negro = lambda o: o.get("stroking_color") in ((0.0, 0.0, 0.0), (0,), [0], 0) or str(o.get("stroking_color")) == "(0.0, 0.0, 0.0)"
    objs = [o for o in list(p.lines) + list(p.curves) if o["bottom"] < zona_y and o["top"] > 20 and negro(o)
            and (o["width"] > 15 or o["height"] > 15) and o["x0"] > 100 and o["x1"] < 520]
    xl = min(o["x0"] for o in objs); xr = max(o["x1"] for o in objs)
    corona = min(o["top"] for o in objs); piso = max(o["bottom"] for o in objs)
    kx0 = (xr - xl) / A
    if abs((piso - corona) / H - kx0) / kx0 > 0.03:  # el dibujo incluye la cuneta bajo el piso
        piso = corona + H * kx0
    puntos = [pt for o in objs for pt in o["pts"]]
    y_hombro = min(y for x, y in puntos if abs(x - xl) < 1.0 and y > corona + 5)
    en_piso = [x for x, y in puntos if abs(y - piso) < 1.5]
    piso_real = max(y for _, y in puntos)
    xpl, xpr = (min(en_piso), max(en_piso)) if en_piso else (xl, xr)
    kx = (xr - xl) / A
    ky = (piso - corona) / H
    top = [(x, y) for x, y in puntos if abs(y - corona) < 0.5]
    cx0, cx1 = min(x for x, _ in top), max(x for x, _ in top)
    mx = (xl + xr) / 2
    a2m = lambda x, y: (round((x - mx) / kx, 3), round((piso - y) / ky, 3))
    contorno = [a2m(xpl, piso), a2m(xpr, piso), a2m(xr, y_hombro)]
    for t in [i / 8 for i in range(1, 8)]:  # arco hombro derecho → corona
        ang = t * math.pi / 2
        contorno.append(a2m(cx1 + (xr - cx1) * math.cos(ang), y_hombro - (y_hombro - corona) * math.sin(ang)))
    contorno += [a2m(cx1, corona), a2m(cx0, corona)]
    for t in [i / 8 for i in range(1, 8)]:  # corona → hombro izquierdo
        ang = math.pi / 2 + t * math.pi / 2
        contorno.append(a2m(cx0 + (cx0 - xl) * math.cos(ang), y_hombro - (y_hombro - corona) * math.sin(ang)))
    contorno.append(a2m(xl, y_hombro))
    # círculos de taladros
    circ = [c for c in p.curves if c["bottom"] < zona_y and abs(c["width"] - c["height"]) < 0.6
            and 2.5 < c["width"] < 9 and c["x0"] > xl - 15 and not c.get("fill")]
    rellenos = [c for c in p.curves if c["bottom"] < zona_y and c.get("fill") and color(c)]
    palabras = [w for w in p.extract_words() if w["bottom"] < zona_y and re.fullmatch(r"\d{1,2}", w["text"])
                and xl - 25 < w["x0"] < xr + 25]
    taladros = []
    vistos = []
    for c in sorted(circ, key=lambda c: -c["width"]):
        cx, cy = (c["x0"] + c["x1"]) / 2, (c["top"] + c["bottom"]) / 2
        if any(math.hypot(cx - a, cy - b) < 2.0 for a, b, _ in vistos):
            continue  # círculo interior de un rimado
        rimado = c["width"] > 5.5
        vistos.append((cx, cy, rimado))
    for cx, cy, rimado in vistos:
        cols = [color(f) for f in rellenos if f["x0"] - 0.5 <= cx <= f["x1"] + 0.5 and f["top"] - 1.9 <= cy <= f["bottom"] + 1.9]
        col = max(set(cols), key=cols.count) if cols else None
        x, y = a2m(cx, cy)
        ret = None
        if col:
            cand = [(math.hypot((w["x0"] + w["x1"]) / 2 - cx, (w["top"] + w["bottom"]) / 2 - cy), int(w["text"])) for w in palabras]
            cand = [c for c in cand if c[0] < 22]
            ret = min(cand)[1] if cand else None
        taladros.append(dict(x=x, y=y, tipo="rimado" if rimado else ("cargado" if col else "alivio"),
                             explosivo={"rojo": "Emulnor 3000", "verde": "Emulnor 1000", "amarillo": "Emulnor 5000"}.get(col),
                             retardo=ret))
    return dict(pagina=num + 1, codigo=codigo, ancho=A, alto=H, clase=clase, rmr=[r0, r1], contorno=contorno,
                taladros=taladros, escala_pt_m=[round(kx, 2), round(ky, 2)])


def main(ruta):
    pdf = pdfplumber.open(ruta)
    salida = []
    for i in range(1, len(pdf.pages)):
        d = pagina(pdf.pages[i], i)
        d["tabla"] = TABLAS.get(i + 1, {})
        salida.append(d)
        car = sum(t["tipo"] == "cargado" for t in d["taladros"])
        rim = sum(t["tipo"] == "rimado" for t in d["taladros"])
        ali = sum(t["tipo"] == "alivio" for t in d["taladros"])
        tb = d["tabla"]
        print(f"p{i + 1} {d['codigo']:8s} {d['ancho']}x{d['alto']} {d['clase']:5s} cargados {car}/{tb.get('cargados')} "
              f"rimados {rim}/{tb.get('rimados')} alivios {ali}/{tb.get('alivios')} sin retardo "
              f"{sum(t['tipo'] == 'cargado' and t['retardo'] is None for t in d['taladros'])}  escala {d['escala_pt_m']}")
    datos = {"fuente": "Cía. Minera Volcan — Mina SC-CR: «Diseños de malla en labores de avance, Perforación & "
                       "Voladura» (compilado 2022)",
             "aviso": "Diseños de UNA mina específica (roca, explosivos y equipos propios). Son ejemplos de referencia, "
                      "no reglas generales.",
             "disenos": salida}
    out = Path(__file__).resolve().parents[2] / "app" / "datos" / "referencias_volcan_sccr2022.json"
    out.write_text(json.dumps(datos, ensure_ascii=False, indent=1), encoding="utf-8")
    print("→", out)


if __name__ == "__main__":
    main(sys.argv[1])
