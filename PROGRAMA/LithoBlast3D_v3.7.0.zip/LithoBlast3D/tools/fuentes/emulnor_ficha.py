"""Genera app/datos/productos_famesa.json a partir del texto de la ficha técnica FT-040-PE/ES Rev. 12 (FAMESA).
Uso: pdftotext -layout FT-EMULNOR.pdf ficha.txt ; python tools/fuentes/emulnor_ficha.py ficha.txt"""
import json
import re
import sys
from pathlib import Path

FRAC = {"⅛": 0.125, "¼": 0.25, "½": 0.5, "¾": 0.75}
PROPS = {  # tabla «Características técnicas» (valores nominales de la ficha)
    "500": dict(densidad=0.90, densidad_tol=0.15, vod_conf=4400, vod_libre=3500, presion_kbar=44, energia_kcal=628,
                gases_l=952, rws=70, rbs=77, uso="Rocas muy suaves"),
    "1000": dict(densidad=1.13, densidad_tol=0.10, vod_conf=5800, vod_libre=4500, presion_kbar=95, energia_kcal=785,
                 gases_l=920, rws=87, rbs=120, uso="Rocas suaves a intermedias"),
    "3000": dict(densidad=1.14, densidad_tol=0.10, vod_conf=5700, vod_libre=4400, presion_kbar=93, energia_kcal=920,
                 gases_l=880, rws=102, rbs=142, uso="Rocas intermedias a duras"),
    "5000": dict(densidad=1.16, densidad_tol=0.10, vod_conf=5500, vod_libre=4200, presion_kbar=88, energia_kcal=1010,
                 gases_l=870, rws=112, rbs=159, uso="Rocas muy duras"),
}


def pulgadas(t: str) -> float:
    t = t.strip().replace('"', "").replace("”", "")
    if "/" in t and " " not in t:
        a, b = t.split("/")
        return float(a) / float(b)
    total = 0.0
    for parte in t.split():
        total += FRAC.get(parte, None) or (float(parte) if parte.replace(".", "").isdigit() else 0.0)
        for ch, v in FRAC.items():
            if parte.endswith(ch) and parte != ch:
                total += v - 0.0
    return total


def main(ruta):
    txt = Path(ruta).read_text(encoding="utf-8")
    pres = []
    pat = re.compile(r"EMULNOR (\d+) (.+?)\s*[\"”]?\s*x\s*(\d+)[\"”]\s*(\(T\))?\s+Cart[oó]n\s+(\d+)\s+([\d,\.]+)")
    for m in pat.finditer(txt):
        tipo, dia, largo, t, piezas, peso = m.groups()
        d = dia.replace("”", "").replace('"', "").strip()
        num = 0.0
        for parte in d.split():
            if parte in FRAC:
                num += FRAC[parte]
            elif "/" in parte:
                a, b = parte.split("/"); num += float(a) / float(b)
            else:
                num += float(parte)
        peso = float(peso.replace(",", "."))
        pres.append(dict(tipo=tipo, diametro_pulg=num, diametro_texto=d + '"', largo_pulg=float(largo),
                         tubular=bool(t), piezas_caja=int(piezas), kg_caja=peso,
                         kg_cartucho=round(peso / int(piezas), 4)))
    datos = {"fuente": "FAMESA Explosivos S.A.C. — Ficha técnica EMULNOR FT-040-PE/ES Rev. 12 (17/10/2024)",
             "nota": "Valores nominales a 20 °C y 1 atm. VOD confinada en tubo de fierro de 1½\"; sin confinar "
                     "como cartucho de 1\". Potencias relativas referidas al ANFO = 100.",
             "productos": {f"EMULNOR {k}": v for k, v in PROPS.items()}, "presentaciones": pres}
    salida = Path(__file__).resolve().parents[2] / "app" / "datos" / "productos_famesa.json"
    salida.write_text(json.dumps(datos, ensure_ascii=False, indent=1), encoding="utf-8")
    print(len(pres), "presentaciones →", salida)


if __name__ == "__main__":
    main(sys.argv[1])
