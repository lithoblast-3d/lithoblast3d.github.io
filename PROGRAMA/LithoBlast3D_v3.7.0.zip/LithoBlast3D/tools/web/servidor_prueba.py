"""SOLO PRUEBAS en la PC: sirve web/ y responde las llamadas del motor con Python normal (sin Pyodide).
Uso: python tools/web/servidor_prueba.py  y abre http://127.0.0.1:8765/app/index.html?prueba
(copia antes tools/web/motor_prueba.js a web/app/ y en la consola: window.B3D_MOTOR="motor_prueba.js")."""
from pathlib import Path
RAIZ_P = Path(__file__).resolve().parents[2]
import sys, json, http.server, socketserver, threading, os
sys.path[:0]=[str(RAIZ_P), str(RAIZ_P / 'movil')]
import movil
RAIZ=str(RAIZ_P / 'web')
class H(http.server.SimpleHTTPRequestHandler):
    def __init__(s,*a,**k): super().__init__(*a,directory=RAIZ,**k)
    def log_message(s,*a): pass
    def do_POST(s):
        n=int(s.headers['Content-Length']); d=json.loads(s.rfile.read(n))
        r=getattr(movil,d['fn'])(d['arg'] or '{}').encode()
        s.send_response(200); s.send_header('Content-Type','application/json'); s.end_headers(); s.wfile.write(r)
socketserver.ThreadingTCPServer.allow_reuse_address=True
srv=socketserver.ThreadingTCPServer(('127.0.0.1',8765),H)
srv.serve_forever()
