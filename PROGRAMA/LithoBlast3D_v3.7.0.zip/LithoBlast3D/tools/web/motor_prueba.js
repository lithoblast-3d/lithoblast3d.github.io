/* SOLO PRUEBAS: reemplaza a motor.js enviando las llamadas a un servidor Python local. */
onmessage = async (ev) => {
  const { id, fn, arg } = ev.data;
  const r = await fetch("/__py", { method: "POST", body: JSON.stringify({ fn, arg }) });
  postMessage({ id, resultado: await r.text() });
};
