"""Empaqueta el motor de cálculo (los mismos módulos del programa) para la app móvil: web/app/nucleo.zip.

Ejecutar desde la carpeta del proyecto cada vez que cambie el cálculo:
    python tools/web/construir_movil.py
"""
import shutil
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]
SALIDA = RAIZ / "web" / "app" / "nucleo.zip"
MODULOS = [
    "app/__init__.py",
    "app/biblioteca/__init__.py", "app/biblioteca/estandar.py", "app/biblioteca/generador.py",
    "app/biblioteca/opciones.py", "app/biblioteca/referencias.py", "app/biblioteca/productos.py",
    "app/cad/__init__.py", "app/cad/dxf.py", "app/cad/exportar.py", "app/cad/malla_topografica.py",
    "app/cad/topografia.py",
    "app/calc/*.py",
    "app/core/__init__.py", "app/core/ejemplos.py", "app/core/generador.py", "app/core/malla_auto.py",
    "app/core/modelo.py", "app/core/resultados.py", "app/core/equipos.py",
    "app/sim3d/datos.py",
    "app/datos/biblioteca_estandar_6p.json", "app/datos/productos_famesa.json",
    "app/datos/referencias_volcan_sccr2022.json",
]


def construir() -> Path:
    archivos = []
    for patron in MODULOS:
        archivos += sorted(RAIZ.glob(patron))
    with zipfile.ZipFile(SALIDA, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in archivos:
            z.write(f, f.relative_to(RAIZ).as_posix())
        z.write(RAIZ / "movil" / "movil.py", "movil.py")
    return SALIDA


def copiar_simulacion_escritorio() -> Path:
    """La simulación del ciclo de Windows usa los mismos archivos que el teléfono."""
    destino = RAIZ / "app" / "datos" / "web3d"
    destino.mkdir(parents=True, exist_ok=True)
    for f in ("simlabor.js", "modelos3d.js", "sonido.js"):
        shutil.copy2(RAIZ / "web" / "app" / f, destino / f)
    shutil.copy2(RAIZ / "web" / "escritorio" / "labor.html", destino / "labor.html")
    return destino


if __name__ == "__main__":
    print(copiar_simulacion_escritorio())
    s = construir()
    print(f"{s} ({s.stat().st_size / 1024:.0f} KB)")
