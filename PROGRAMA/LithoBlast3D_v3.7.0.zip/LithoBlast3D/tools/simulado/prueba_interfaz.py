"""
Prueba de humo de la interfaz con módulos falsos (sin pantalla ni PySide6/pyvista reales).

Ejecutar desde la carpeta del proyecto:  python tools/simulado/prueba_interfaz.py
"""

import os
import sys
import tempfile
import time
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import falsos  # noqa: E402

falsos.instalar()

import numpy as np  # noqa: E402

from app.core.documento import Documento  # noqa: E402
from app.core.ejemplos import crear_proyecto_vacio  # noqa: E402
from app.core.modelo import ESCENARIO_SUBTERRANEO, Perforacion, PolilineaCAD, SuperficieTIN  # noqa: E402

os.environ["HOME"] = tempfile.mkdtemp()  # ediciones de la biblioteca en carpeta temporal
from app.biblioteca import estandar  # noqa: E402

estandar.ARCHIVO_USUARIO = Path(os.environ["HOME"]) / ".barreno3d" / "biblioteca_usuario.json"


def paso(nombre):
    print(f"· {nombre}")


def proyecto_sub():
    from app.core.modelo import DisenoVoladura
    return Documento(crear_proyecto_vacio("Prueba", DisenoVoladura(escenario=ESCENARIO_SUBTERRANEO)))


# ----------------------------------------------------------------- biblioteca
paso("Biblioteca: abrir, filtrar, elegir, editar, verificar, guardar, validar, restaurar")
from app.ui.dialogo_biblioteca import DialogoBiblioteca  # noqa: E402

doc = proyecto_sub()
dlg = DialogoBiblioteca(doc)
assert len(dlg.planos) == 54, len(dlg.planos)
dlg.f_sec.setCurrentIndex(2)  # 2.50 x 2.50
assert dlg.lista.count() == 12, dlg.lista.count()
dlg.f_sec.setCurrentIndex(0)
dlg.lista.setCurrentRow(0)
assert dlg.actual is not None and dlg.actual.pagina == 4
n0 = len(dlg.actual.taladros)
# editar una celda (cartuchos del primer taladro cargado)
i = next(k for k, t in enumerate(dlg.actual.taladros) if t.tipo == "cargado")
it = dlg.t_tal.item(i, 4)
it.setText(str(dlg.actual.taladros[i].cartuchos + 1))
dlg._celda_editada(it)
ok, dif, rev = estandar.resumen_verificacion(dlg.actual)
assert dif >= 1, "la edición debe detectarse en la verificación"
dlg._guardar()
assert estandar.ARCHIVO_USUARIO.exists()
dlg._validar()
assert dlg.actual.estado == estandar.ESTADO_VALIDADO
dlg._restaurar()
assert dlg.actual.estado == estandar.ESTADO_DOC and estandar.resumen_verificacion(dlg.actual)[1] == 0
# vistas
dlg.tabs.currentChanged.emit(3)
dlg.vista3d.mostrar(dlg.actual)
# usar en el proyecto
from app.ui import dialogo_biblioteca as db  # noqa: E402

dlg._usar()
pozos = doc.proyecto.perforaciones()
assert len(pozos) == n0, (len(pozos), n0)
assert all(p.origen for p in pozos)
cargados = [p for p in pozos if p.explosivo_id]
from app.core.resultados import resumen_voladura  # noqa: E402

r = resumen_voladura(doc.proyecto)
tabla_kg = next(f for f in dlg.actual.explosivos_tabla if f["nombre"].startswith("Total"))["valores"]["Expl_Kg"]
print(f"   carga total del proyecto {r.carga_total:.2f} kg vs. tabla del plano {tabla_kg} kg")
assert abs(r.carga_total - tabla_kg) < 0.15, "la carga debe coincidir con la tabla del plano"
assert doc.puede_deshacer()

# ----------------------------------------------------------------- malla automática con mallas reales
paso("Malla automática real: sección 2.80 x 3.10, roca por RMR, cuneta derecha, editar y usar")
from app.ui.dialogo_malla_real import DialogoMallaReal  # noqa: E402

docr = proyecto_sub()
dr = DialogoMallaReal(docr)
dr.ancho.setValue(2.8); dr.alto.setValue(3.1)
dr.modo_roca.setCurrentIndex(1); dr.rmr.setValue(35)
dr.lado.setCurrentIndex(1)
dr.generar()
pl = dr.resultado.plano
assert pl.roca == "Mala" and pl.alivios(), pl.roca
assert any(t.y < -0.05 and t.x > 0 for t in pl.taladros), "taladro de cuneta a la derecha"
n_antes = len(pl.taladros)
it = dr.t_tal.item(0, 4); it.setText("9"); dr._celda(it)
dr.arranque.setCurrentIndex(dr.arranque.findData("cruz5")); dr.generar()
assert len(dr.resultado.plano.alivios()) == 5
dr._usar()
assert len(docr.proyecto.perforaciones()) == len(dr.resultado.plano.taladros)
print(f"   {n_antes} taladros (triángulo) → {len(dr.resultado.plano.taladros)} con cruz; avisos: {len(dr.resultado.avisos)}")
d5 = DialogoBiblioteca(proyecto_sub()); d5.lista.setCurrentRow(3); d5._adaptar()

# ----------------------------------------------------------------- simulador 3D con la malla de la biblioteca
paso("Simulador 3D: construir, reproducir las 13 etapas en cadena, cámaras, calidad, solo una etapa")
from app.sim3d.ventana import VentanaSimulador  # noqa: E402

v = VentanaSimulador(doc)
print(f"   equipo: {v.plan.modo}, brazos {v.plan.brazos}; bloques {len(v.frags)}; avisos: {v.plan.avisos[:1]}")
v._iniciar()
pasos = 0
reloj_real = 0.0
while not v.reloj.terminado and pasos < 20000:
    v._t_real = time.perf_counter() - 0.05
    v._tick()
    pasos += 1
assert v.reloj.terminado and v.reloj.indice == 12, (v.reloj.indice, pasos)
assert v.a_shot.prop.opacity == 1.0
print(f"   pernos colocados: {sum(a.GetVisibility() for a in v.a_pernos)}/{len(v.a_pernos)}")
assert all(not a.GetVisibility() for a in v.a_frags), "tras la limpieza no quedan bloques"
print(f"   {pasos} cuadros; bloques activos {int(v.mundo.activo.sum())}/{v.mundo.n}; dormidos {int(v.mundo.dormido.sum())}")
assert v.mundo.activo.all()
assert (v.mundo.x[:, 2] >= -1e-6).all(), "ningún bloque bajo el piso"
for nombre in ["Superior", "Frontal", "Lateral", "Isométrica", "Libre", "Operador", "Cinematográfica"]:
    v._camara(nombre)
v.cb_calidad.setCurrentText("Baja")
v._cambiar_calidad("Alta")
v.lista.setCurrentRow(5)
v._solo_etapa()
for _ in range(400):
    v._t_real = time.perf_counter() - 0.05
    v._tick()
assert v.reloj.terminado and v.reloj.indice == 5
v.reloj.ir_a(9); v._preparar_etapa(9, forzar=True)  # etapa 10 sola: física precalculada
assert v.mundo.activo.all()
v._pausar(); v._continuar(); v._reiniciar()
v.chk_comparar.setChecked(True)
v._set_herramienta("medir"); v._set_herramienta(None)
v.cb_estilo.setCurrentIndex(1)  # realista
v._cambiar_calidad("Media")
v.reloj.iniciar(10, cadena=True)
for _ in range(3000):
    v._t_real = time.perf_counter() - 0.05
    v._tick()
assert v.reloj.terminado
v.done(0)

# ----------------------------------------------------------------- sección pequeña: perforadora manual
paso("Simulador con sección 1.20 x 1.80 (no cabe el jumbo → perforadora manual)")
doc2 = proyecto_sub()
d2 = DialogoBiblioteca(doc2)
d2.lista.setCurrentRow(0)
d2._usar()
v2 = VentanaSimulador(doc2)
assert v2.plan.modo == "manual", v2.plan.modo
assert {"op_ropa", "op_casco", "op_piernas"} <= set(v2.a_manual), "operador de la jackleg"
v2.reloj.iniciar(3, cadena=False)
for _ in range(1500):
    v2._t_real = time.perf_counter() - 0.05
    v2._tick()
v2.done(0)

# ----------------------------------------------------------------- jumbo de 2 brazos (sección 3.00 x 3.00)
paso("Simulador con sección 3.00 x 3.00 (jumbo de 2 brazos) y edición de parámetros del equipo")
doc4 = proyecto_sub()
d4 = DialogoBiblioteca(doc4)
d4.f_sec.setCurrentIndex(5)
d4.lista.setCurrentRow(0)
assert d4.actual.seccion == "3.00 x 3.00"
d4._usar()
v4 = VentanaSimulador(doc4)
assert v4.plan.modo == "jumbo", (v4.plan.modo, v4.plan.brazos)  # 3.0 × 3.4 m: jumbo del catálogo
assert "Boomer" in v4.plan.equipo or "DD311" in v4.plan.equipo, v4.plan.equipo
print(f"   equipo {v4.plan.equipo} ({v4.plan.brazos} brazo/s); inalcanzables {len(v4.plan.inalcanzables)}; "
      f"agenda {[len(a) for a in v4.agenda]}")
v4._iniciar()
n = 0
while not v4.reloj.terminado and n < 30000:
    v4._t_real = time.perf_counter() - 0.05
    v4._tick(); n += 1
assert v4.reloj.terminado
v4._editar_equipo()
v4.done(0)

# ----------------------------------------------------------------- CAD
paso("Importar DXF (curvas de nivel con elevación) → capas, polilíneas y TIN; perfil y pendientes")
from app.cad.dxf import escribir_dxf  # noqa: E402

carpeta = Path(tempfile.mkdtemp())
curvas = []
for k, z in enumerate(range(3000, 3060, 10)):
    r_ = 80 - k * 10
    pts = [(500000 + r_ * np.cos(a), 8000000 + r_ * np.sin(a), float(z)) for a in np.linspace(0, 2 * np.pi, 40)]
    curvas.append(("CURVAS_NIVEL", pts))
curvas.append(("CRESTAS", [(500000, 8000000, 3060.0), (500050, 8000010, 3055.0)]))
ruta_dxf = carpeta / "topo.dxf"
escribir_dxf(ruta_dxf, curvas)
from app.ui.dialogo_cad import DialogoImportarCAD, DialogoPendientes, DialogoPerfil  # noqa: E402

from app.core.modelo import DisenoVoladura
doc3 = Documento(crear_proyecto_vacio("CAD", DisenoVoladura()))
di = DialogoImportarCAD(doc3)
di.cargar(str(ruta_dxf))
assert di.tabla.rowCount() == 2
di._aceptar()
tins = [o for o in doc3.proyecto.objetos.values() if isinstance(o, SuperficieTIN)]
polis = [o for o in doc3.proyecto.objetos.values() if isinstance(o, PolilineaCAD)]
assert len(polis) == 7 and len(tins) == 1, (len(polis), len(tins))
assert any(c.nombre == "CAD: CURVAS_NIVEL" for c in doc3.proyecto.capas)
x0 = polis[0].vertices[0][0]
assert abs(x0 - 500080) < 1e-6, "se conservan las coordenadas"
dp = DialogoPerfil(doc3)
assert dp.perfil is not None and dp.perfil.resumen()["con_datos"] > 50
dpe = DialogoPendientes(doc3)
dpe._aceptar()
assert tins[0].colorear == "pendiente"
doc3.deshacer(); doc3.deshacer()
assert not [o for o in doc3.proyecto.objetos.values() if isinstance(o, PolilineaCAD)]

# ----------------------------------------------------------------- ventana principal
paso("Ventana principal: construir y ejecutar las acciones nuevas")
from app.ui.ventana_principal import VentanaPrincipal  # noqa: E402


class Ctrl:
    def nuevo(self, *a): pass
    abrir = ejemplo = nuevo


vp = VentanaPrincipal(doc, Ctrl())
for nombre in ("acc_importar_cad", "acc_tin", "acc_perfil", "acc_pendientes", "acc_consultar", "acc_medir",
               "acc_config_dwg", "acc_biblioteca", "acc_rejilla", "acc_sim_completa", "acc_sim_jumbo",
               "acc_sim_perf", "acc_sim_carguio", "acc_sim_voladura", "acc_sim_frag", "acc_sim_comparar",
               "acc_reporte"):
    assert hasattr(vp, nombre), nombre
vp.simulador_3d(8)
vp._herramienta("medir", True)
vp._calidad("Alta")
doc3.rehacer(); doc3.rehacer()
vp3 = VentanaPrincipal(doc3, Ctrl())
vp3.visor.set_herramienta("consultar")
vp3.visor._usar_herramienta(10, 10)
vp3.visor.set_cuadricula(False)
vp3.visor.set_calidad("alta")
vp3.reporte
from app.core.reporte import generar_html  # noqa: E402
assert "Topografía y CAD" in generar_html(doc3.proyecto)

html = generar_html(doc.proyecto)
assert "REFERENCIA DOCUMENTAL" in html and "<table>" in html

# ----------------------------------------------------------------- v3: tema, malla automática por tipo de arranque
paso("Tema moderno: hoja de estilo completa (sin @claves sin reemplazar)")
from app.ui import tema  # noqa: E402

hoja = tema._hoja_estilo()
assert "@" not in hoja, [l for l in hoja.splitlines() if "@" in l][:3]
for nombre in ("Tarjeta", "Primario", "TituloGrande", "TituloTarjeta", "Etiqueta", "Aviso", "Error", "Kpi"):
    assert "#" + nombre in hoja, nombre
assert hoja.count("{") == hoja.count("}")

paso("Malla automática: generar 7 tipos de arranque, elegir, editar y usar en el proyecto")
from app.ui.dialogo_opciones_malla import DialogoOpcionesMalla  # noqa: E402

docm = proyecto_sub()
dm = DialogoOpcionesMalla(docm)
assert len(dm.opciones) == 8, len(dm.opciones)  # 7 arranques + referencia Volcan
validas = [o for o in dm.opciones if o.plano is not None and not o.error]
assert len(validas) >= 6, [(o.nombre, o.error) for o in dm.opciones]
nombres = " ".join(o.nombre for o in dm.opciones)
for clave in ("Holmberg", "Ash", "quemado", "V"):
    assert clave in nombres, clave
op = next(o for o in validas if "Ash" in o.nombre)
dm._elegir(op)
assert dm.elegida is op
dm._usar()
pozos = docm.proyecto.perforaciones()
assert len(pozos) == len(op.plano.taladros), (len(pozos), len(op.plano.taladros))
assert any(p.explosivo_id is None for p in pozos), "hay alivios sin carga"
docm.deshacer()
assert not docm.proyecto.perforaciones()
docm.rehacer()

paso("Análisis: centro y las siete herramientas con el proyecto de la malla anterior")
from app.ui.analisis import HERRAMIENTAS, DialogoCentroAnalisis, abrir  # noqa: E402

DialogoCentroAnalisis(docm)
dialogos = {}
for clave, *_ in HERRAMIENTAS:
    t0 = time.time()
    d = abrir(clave, docm)
    err = d.mensaje.text() if d.mensaje.isVisible() else ""
    assert "✖" not in err, (clave, err)
    dialogos[clave] = d
    print(f"    {clave:14s} {time.time() - t0:5.2f} s  {err[:70]}")

fr_d = dialogos["fragmentacion"]
x50_a = fr_d.res.x50_mm
fr_d.k.setValue(fr_d.k.value() * 1.5)
assert fr_d.res.x50_mm < x50_a, "más factor de carga → fragmentos más finos"
assert fr_d.t_esc.rowCount() == 1
fr_d._agregar_actual()
assert fr_d.t_esc.rowCount() == 2 and fr_d.t_res_esc.rowCount() == 2
for x, pct in ((10, 8), (25, 18), (50, 33), (100, 55), (200, 78), (400, 94)):
    fr_d.t_med.agregar_fila([float(x), float(pct)])
fr_d._ajustar()
assert "R²" in fr_d.l_aj.text() and fr_d.btn_calibrar.isEnabled() is not False
fr_d._usar_calibrado()
assert fr_d.a_manual.isChecked()

dd = dialogos["danio"]
cob = dd.kpi["Cobertura de la sección"].valor.text()
assert cob.endswith("%"), cob
dd.modo.setCurrentIndex(1)
cob2 = dd.kpi["Cobertura de la sección"].valor.text()
assert float(cob2.split()[0]) >= float(cob.split()[0]), (cob, cob2)

dc = dialogos["cimbra"]
assert dc.t_tabla.rowCount() == 6
dc.rmr.setValue(20)
u1 = float(dc.kpi["Utilización"].valor.text().split()[0])
dc.rmr.setValue(70)
u2 = float(dc.kpi["Utilización"].valor.text().split()[0])
assert u2 < u1, (u1, u2)

dn_d = dialogos["dinamica"]
ruta_reg = Path(tempfile.mkdtemp()) / "registro.csv"
t = np.arange(0, 2, 0.01)
ruta_reg.write_text("\n".join(f"{a:.3f},{0.2 * np.sin(2 * np.pi * 2 * a):.5f}" for a in t))
dn_d.registro = (0.01, np.array([0.2 * np.sin(2 * np.pi * 2 * a) for a in t]) * 9.81, "registro.csv")
dn_d.fuente.setCurrentIndex(1)
assert "g" in dn_d.kpi["Sa máx. espectro"].valor.text()
assert "0.500" in dn_d.kpi["Sa máx. espectro"].nota.text() or True

dco = dialogos["costos"]
assert dco.t_res.rowCount() == len(dco.leer()[0]) + 1
assert dco.kpi["Costo por disparo"].valor.text().startswith("US$")
dco.t_ta.item(0, 1).setText("6")
dco._calcular_seguro()

dmz = dialogos["macizo"]
assert dmz.kpi["RMR89"].valor.text().isdigit()

db = dialogos["burden"]
b0 = docm.proyecto.diseno.burden
db._usar()
assert docm.proyecto.diseno.burden == round(db.mediana, 2) != b0
docm.deshacer()
assert docm.proyecto.diseno.burden == b0

vpa = VentanaPrincipal(docm, Ctrl())
assert len(vpa.acciones_analisis) == 7 and hasattr(vpa, "acc_centro_analisis")
vpa.analisis("macizo")
vpa.malla_opciones()

# ----------------------------------------------------------------- v3.1: malla sobre topografía y DWG
paso("Malla sobre la topografía (TIN del DXF importado), crear, exportar DXF y DWG (conversor simulado)")
from app.cad import dwg as cad_dwg  # noqa: E402
from app.cad import dxf as cad_dxf  # noqa: E402
from app.ui.dialogo_exportar_cad import DialogoExportarCAD  # noqa: E402
from app.ui.dialogo_malla_topo import DialogoMallaTopografica  # noqa: E402

doc5 = Documento(crear_proyecto_vacio("Banco topo", DisenoVoladura()))
di5 = DialogoImportarCAD(doc5)
di5.cargar(str(ruta_dxf))
di5._aceptar()
dmt = DialogoMallaTopografica(doc5)
assert dmt.resultado is not None, dmt.mensaje.text()
dmt.piso.setValue(3030.0)
dmt.b.setValue(3.0); dmt.s.setValue(3.5)
r5 = dmt.resultado
assert len(r5.taladros) >= 10, len(r5.taladros)
assert all(t.z > 3030 and abs(t.longitud - (t.z - 3030 + dmt.j.value())) < 0.02 for t in r5.taladros)
assert len({t.retardo for t in r5.taladros}) > 3
dmt.sec.setCurrentIndex(1)
dmt._crear()
pz5 = doc5.proyecto.perforaciones()
assert len(pz5) == len(dmt.resultado.taladros) and doc5.proyecto.explosivos
print(f"   {len(pz5)} taladros, {dmt.resultado.metros:.0f} m, {dmt.resultado.kg:.0f} kg, salida {dmt.az_sal.value():.0f}°")

# conversor ODA simulado: copia y cambia la extensión (DXF<->DWG)
oda = carpeta / "ODAFileConverter"
oda.write_text("#!/bin/sh\nfor f in \"$1\"/*; do b=$(basename \"$f\"); n=${b%.*}; "
               "if [ \"$4\" = DWG ]; then cp \"$f\" \"$2/$n.dwg\"; else cp \"$f\" \"$2/$n.dxf\"; fi; done\n")
oda.chmod(0o755)
cad_dwg.guardar_ruta_oda(str(oda))
de = DialogoExportarCAD(doc5)
de.formato.setCurrentIndex(1)
de._guardar(ruta=str(carpeta / "malla.dxf"))
assert de.ruta and de.ruta.exists(), de.l_res.text()
dib = cad_dxf.leer_dxf(de.ruta)
capas = {e.capa for e in dib.entidades}
assert {"COLLARES", "TALADROS", "CARGA", "TXT_ID", "SECCION_AREA", "CURVAS_NIVEL"} <= capas, capas
de.formato.setCurrentIndex(0)
de._guardar(ruta=str(carpeta / "malla.dwg"))
assert de.ruta.suffix == ".dwg" and de.ruta.exists(), de.l_res.text()
dxf_de_dwg = cad_dwg.convertir_dwg_a_dxf(de.ruta)
assert len(cad_dxf.leer_dxf(dxf_de_dwg).entidades) == len(dib.entidades)
de2 = DialogoExportarCAD(docm)  # frente subterráneo: vista 2D del frente
assert de2.vista.currentIndex() == 1
de2.formato.setCurrentIndex(1)
de2._guardar(ruta=str(carpeta / "frente.dxf"))
assert de2.ruta.exists()
vp5 = VentanaPrincipal(doc5, Ctrl())
assert hasattr(vp5, "acc_malla_topo") and hasattr(vp5, "acc_exportar_cad")

# ----------------------------------------------------------------- v3.4: labores, equipos, referencias, productos
paso("Labores (chimenea, tajeo), equipos del catálogo, referencias de minas y explosivos FAMESA")
from app.ui.dialogo_equipos import DialogoEquipos  # noqa: E402
from app.ui.dialogo_referencias import DialogoReferencias  # noqa: E402
from app.ui.dialogos import DialogoExplosivos  # noqa: E402

dr = DialogoReferencias()
dr._mostrar(4)
assert "RMR" in dr.html_actual and "Factor de carga" in dr.html_actual
de = DialogoEquipos(None, 1.5, 1.5)
assert "Jackleg" in de.resultado.text(), de.resultado.text()
de.p_ancho.setValue(3.8); de.p_alto.setValue(4.0); de._probar()
assert "Boomer" in de.resultado.text() or "DD311" in de.resultado.text()
dx = DialogoExplosivos([])
dx._fila(__import__("app.biblioteca.productos", fromlist=["x"]).explosivo_de("EMULNOR 3000", 1.25, 12, "EXP-01"))
e0 = dx.explosivos()[0]
assert e0.kg_cartucho == 0.266 and "FAMESA" in e0.fuente, e0
for labor, a, h in (("chimenea", 1.5, 1.5), ("tajeo", 1.8, 1.0), ("frente", 1.5, 1.5), ("frente", 3.8, 4.0)):
    dl = DialogoOpcionesMalla(proyecto_sub())
    dl.labor.setCurrentIndex(list(__import__("app.core.equipos", fromlist=["x"]).LABORES).index(labor))
    dl.ancho.setValue(a); dl.alto.setValue(h)
    dl.generar()
    ok = [o for o in dl.opciones if o.plano is not None and not o.error]
    assert ok, [(o.nombre, o.error) for o in dl.opciones]
    eq_ = ok[0].equipo.equipo
    print(f"   {labor:9s} {a}×{h}: {len(ok)} mallas · equipo {eq_.nombre} · {ok[0].comparacion[:1]}")
    if labor == "chimenea":
        assert eq_.tipo == "stoper"
        dl._elegir(ok[0]); dl._usar()
        pz = dl.doc.proyecto.perforaciones()
        assert pz and all(p.inclinacion == -90 for p in pz), "chimenea: taladros hacia arriba"
    if labor == "frente" and a < 2:
        assert eq_.tipo == "jackleg"
    if labor == "frente" and a > 3:
        assert eq_.tipo == "jumbo" and any(o.clave == "ref_volcan" for o in ok)

# ----------------------------------------------------------------- v3.5: inicio, scoop, escena del ciclo
paso("Pantalla de inicio, escena del ciclo 3D (mecanizado / convencional) y área de banco sobre el terreno")
from app.ui.dialogo_inicio import DialogoInicio  # noqa: E402
from app.biblioteca.escena_labor import escena  # noqa: E402
di = DialogoInicio()
assert len(di.botones) == 8
di._elegir("chimenea"); assert di.eleccion == "chimenea"
dl = DialogoOpcionesMalla(proyecto_sub())
dl.ancho.setValue(3.5); dl.alto.setValue(3.5); dl.generar()
ok = [o for o in dl.opciones if o.plano is not None and not o.error]
dl._elegir(ok[0])
es = escena(ok[0], dl.datos())
assert es["metodos"]["mecanizado"]["equipo"]["tipo"] == "jumbo" and es["metodos"]["convencional"]["equipo"]["tipo"] == "jackleg"
assert es["metodos"]["mecanizado"]["scoop"] is not None and len(es["taladros"]) == len(ok[0].plano.taladros)
from app.ui import simulador_web  # noqa: E402
u = simulador_web.url(es)
import urllib.request  # noqa: E402
assert b"crearLabor" in urllib.request.urlopen(u).read()
assert urllib.request.urlopen(u.replace("labor.html", "escena.json")).read().startswith(b"{")
print("   simulación del ciclo servida en", u)
print("\nPRUEBA DE INTERFAZ (simulada): OK")
