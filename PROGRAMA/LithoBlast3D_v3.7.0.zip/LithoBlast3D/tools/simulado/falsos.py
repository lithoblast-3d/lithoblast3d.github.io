"""
Módulos FALSOS de PySide6 / pyvista / pyvistaqt / vtk para ejecutar la interfaz sin pantalla.

Solo sirven para pruebas de humo en un entorno sin estas bibliotecas: verifican que el
código de las ventanas se ejecuta (nombres, flujo, cálculos con numpy). No dibujan nada.
NO se usan en el programa real.
"""

from __future__ import annotations

import sys
import types

import numpy as np


# ======================================================================= Qt falso
class _Enum:
    def __init__(self, nombre="enum", valor=0):
        self._n, self.value = nombre, valor

    def __getattr__(self, k):
        if k.startswith("__"):
            raise AttributeError(k)
        return _Enum(f"{self._n}.{k}", hash(k) % 1000)

    def __or__(self, o): return self
    __ror__ = __and__ = __rand__ = __or__

    def __invert__(self): return self

    def __eq__(self, o): return isinstance(o, _Enum) and o._n == self._n

    def __hash__(self): return hash(self._n)

    def __bool__(self): return True

    def __int__(self): return self.value

    def __add__(self, o): return _Enum(f"{self._n}+{o}", self.value + int(o))


class _Senal:
    def __init__(self, *a, **k):
        self._f = []

    def connect(self, f):
        self._f.append(f)

    def disconnect(self, *a):
        self._f.clear()

    def emit(self, *a):
        # Como PySide6: si el «slot» acepta menos argumentos, se le pasan los primeros.
        import inspect
        for f in list(self._f):
            try:
                sig = inspect.signature(f)
                if not any(p.kind == p.VAR_POSITIONAL for p in sig.parameters.values()):
                    n = sum(1 for p in sig.parameters.values() if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD))
                    f(*a[:n])
                    continue
            except (TypeError, ValueError):
                pass
            f(*a)

    def __call__(self, *a, **k):
        return Widget()


class _Meta(type):
    def __getattr__(cls, k):
        if k.startswith("__"):
            raise AttributeError(k)
        return _Enum(f"{cls.__name__}.{k}")


class Widget(metaclass=_Meta):
    """Widget genérico con estado mínimo; cualquier método desconocido es un no-op."""

    def __init__(self, *a, **k):
        d = self.__dict__
        d.setdefault("_checked", False); d.setdefault("_text", a[0] if a and isinstance(a[0], str) else "")
        d.setdefault("_items", []); d.setdefault("_idx", 0); d.setdefault("_val", 0); d.setdefault("_vis", True)
        d.setdefault("_props", {}); d.setdefault("_auto", {})

    def __getattr__(self, k):
        if k.startswith("__"):
            raise AttributeError(k)
        auto = self.__dict__.setdefault("_auto", {})
        if k not in auto:
            auto[k] = _Senal()
        return auto[k]

    # estado
    def setChecked(self, v):
        cambio = bool(v) != self._checked
        self._checked = bool(v)
        if cambio:
            self.toggled.emit(self._checked)

    def isChecked(self): return self._checked

    def setCheckable(self, v): pass

    def setText(self, *a): self._text = a[-1]

    def text(self, *a): return self._text

    def setValue(self, v):
        self._val = v
        self.valueChanged.emit(v)

    def value(self): return self._val

    def addItem(self, t, data=None):
        self._items.append((t, data))

    def addItems(self, ts):
        for t in ts:
            self.addItem(t)

    def count(self): return len(self._items)

    def clear(self): self._items = []

    def currentText(self): return self._items[self._idx][0] if self._items else ""

    def currentData(self): return self._items[self._idx][1] if self._items else None

    def setCurrentIndex(self, i):
        cambio = i != self._idx
        self._idx = i
        self.currentIndexChanged.emit(i)
        if cambio:
            self.currentTextChanged.emit(self.currentText())

    def currentIndex(self): return self._idx

    def itemText(self, i): return self._items[i][0] if 0 <= i < len(self._items) else ""

    def itemData(self, i): return self._items[i][1] if 0 <= i < len(self._items) else None

    def findText(self, t):
        return next((i for i, (x, _) in enumerate(self._items) if x == t), -1)

    def findData(self, d):
        return next((i for i, (_, x) in enumerate(self._items) if x == d), -1)

    def setCurrentText(self, t):
        i = self.findText(t)
        if i >= 0:
            self.setCurrentIndex(i)

    def currentRow(self): return self._idx

    def setCurrentRow(self, i):
        self._idx = i
        self.currentRowChanged.emit(i)
        if self._items and 0 <= i < len(self._items):
            it = self._items[i][1]
            self.currentItemChanged.emit(it, None)

    def item(self, i, j=None):
        if j is not None:
            return self.__dict__.setdefault("_celdas", {}).get((i, j))
        return self._items[i][1] if i < len(self._items) else None

    def setItem(self, i, j, it):
        it._fila, it._col = i, j
        self.__dict__.setdefault("_celdas", {})[(i, j)] = it

    def rowCount(self): return self.__dict__.get("_filas", 0)

    def setColumnCount(self, n): pass

    def insertRow(self, n):
        celdas = self.__dict__.setdefault("_celdas", {})
        self.__dict__["_celdas"] = {((i + 1 if i >= n else i), j): v for (i, j), v in celdas.items()}
        self.__dict__["_filas"] = self.rowCount() + 1

    def removeRow(self, n):
        celdas = self.__dict__.setdefault("_celdas", {})
        self.__dict__["_celdas"] = {((i - 1 if i > n else i), j): v for (i, j), v in celdas.items() if i != n}
        self.__dict__["_filas"] = max(self.rowCount() - 1, 0)

    def setRowCount(self, n):
        self.__dict__["_filas"] = n
        self.__dict__["_celdas"] = {k: v for k, v in self.__dict__.get("_celdas", {}).items() if k[0] < n}

    def blockSignals(self, v): return False

    def exec(self): return self.__dict__.get("_resultado_exec", 1)

    def isVisible(self): return self._vis

    def setVisible(self, v): self._vis = v

    def width(self): return 800

    def height(self): return 600

    def property(self, k): return self._props.get(k)

    def setProperty(self, k, v): self._props[k] = v

    def checkState(self, *a): return self.__dict__.get("_cs", QtCore.Qt.CheckState.Checked)

    def setCheckState(self, *a): self.__dict__["_cs"] = a[-1]

    def row(self): return self.__dict__.get("_fila", 0)

    def column(self): return self.__dict__.get("_col", 0)

    def flags(self): return _Enum("flags")

    def data(self, *a):
        d = self.__dict__.get("_datos", {})
        return d.get(a[0] if a else None, d.get(None)) if a and a[0] in d else self.__dict__.get("_data")

    def setData(self, *a):
        self.__dict__.setdefault("_datos", {})[a[0] if len(a) > 1 else None] = a[-1]
        if len(a) < 2 or "+" not in str(getattr(a[0], "_n", "")):
            self.__dict__["_data"] = a[-1]

    def selectedIndexes(self): return []

    def done(self, r): pass

    def accept(self): self.__dict__["_aceptado"] = True

    def reject(self): pass

    def button(self, *a): return Widget()

    def screen(self):
        return None

    def menuBar(self):
        return self.__dict__.setdefault("_menubar", Widget())

    def statusBar(self):
        return self.__dict__.setdefault("_statusbar", Widget())

    def addMenu(self, *a): return Widget()

    def toggleViewAction(self): return Widget()


class QListWidgetItem(Widget):
    def __init__(self, texto=""):
        super().__init__(texto)


class QListWidget(Widget):
    def addItem(self, it, data=None):
        if isinstance(it, str):
            it = QListWidgetItem(it)
        self._items.append((it.text(), it))


class QTableWidgetItem(Widget):
    def __init__(self, texto=""):
        super().__init__(str(texto))


class QDialog(Widget):
    class DialogCode:
        Accepted = 1


class _ModuloQt(types.ModuleType):
    def __getattr__(self, k):
        if k.startswith("__"):
            raise AttributeError(k)
        if k in ("Qt",):
            return _Enum("Qt")
        return Widget


def _instalar_qt():
    global QtCore
    QtCore = _ModuloQt("PySide6.QtCore")
    QtCore.Qt = _Enum("Qt")
    QtCore.Signal = _Senal
    QtCore.QTimer = Widget
    QtCore.QPointF = lambda x=0, y=0: types.SimpleNamespace(x=lambda: x, y=lambda: y)
    QtCore.QRectF = Widget
    QtCore.QUrl = Widget
    w = _ModuloQt("PySide6.QtWidgets")
    for nombre in ("QDialog", "QListWidget", "QListWidgetItem", "QTableWidgetItem"):
        setattr(w, nombre, globals()[nombre])
    w.QMessageBox = Widget
    w.QMessageBox.StandardButton = _Enum("SB")
    w.QMessageBox.question = staticmethod(lambda *a, **k: _Enum("SB.Yes"))
    w.QMessageBox.information = staticmethod(lambda *a, **k: None)
    w.QMessageBox.warning = staticmethod(lambda *a, **k: (_ for _ in ()).throw(AssertionError(f"warning: {a[-1]}")))
    w.QFileDialog = Widget
    w.QInputDialog = Widget
    w.QInputDialog.getText = staticmethod(lambda *a, **k: ("Ing. Prueba CIP 0000", True))
    g = _ModuloQt("PySide6.QtGui")
    raiz = types.ModuleType("PySide6")
    raiz.QtCore, raiz.QtWidgets, raiz.QtGui = QtCore, w, g
    mm = _ModuloQt("PySide6.QtMultimedia")
    sys.modules.update({"PySide6": raiz, "PySide6.QtCore": QtCore, "PySide6.QtWidgets": w, "PySide6.QtGui": g,
                        "PySide6.QtMultimedia": mm})


# ======================================================================= pyvista falso (geometría real mínima)
class PolyData:
    def __init__(self, puntos=None, faces=None, lines=None):
        self.points = np.zeros((0, 3)) if puntos is None else np.asarray(puntos, float)
        self.faces = np.array([]) if faces is None else np.asarray(faces)
        self.lines = lines
        self.active_texture_coordinates = None
        self.cell_data = {}
        self._datos = {}

    @property
    def n_points(self): return len(self.points)

    @property
    def center(self): return self.points.mean(0) if len(self.points) else np.zeros(3)

    @property
    def bounds(self):
        p = self.points
        return (p[:, 0].min(), p[:, 0].max(), p[:, 1].min(), p[:, 1].max(), p[:, 2].min(), p[:, 2].max())

    def __setitem__(self, k, v): self._datos[k] = v

    def __getitem__(self, k): return self._datos[k]

    def triangulate(self): return self

    def subdivide(self, n): return self

    def extrude(self, v, capping=True):
        v = np.asarray(v, float)
        return PolyData(np.vstack([self.points, self.points + v]))

    def delaunay_3d(self): return self

    def delaunay_2d(self): return self

    def extract_surface(self): return self

    def extract_geometry(self): return self

    def compute_normals(self, **k): return self

    def outline(self): return self

    def merge(self, otros):
        otros = otros if isinstance(otros, list) else [otros]
        return PolyData(np.vstack([self.points] + [o.points for o in otros]))


def _caja(bounds=(-1, 1, -1, 1, -1, 1), **k):
    x0, x1, y0, y1, z0, z1 = bounds
    return PolyData(np.array([[x, y, z] for x in (x0, x1) for y in (y0, y1) for z in (z0, z1)], float))


def _cil(center=(0, 0, 0), direction=(0, 0, 1), radius=1.0, height=1.0, resolution=10, **k):
    c = np.asarray(center, float); d = np.asarray(direction, float); d = d / (np.linalg.norm(d) or 1)
    return PolyData(np.array([c - d * height / 2, c + d * height / 2, c + radius * np.cross(d, [0.3, 0.5, 0.8])]))


def _esfera(radius=1.0, center=(0, 0, 0), **k):
    c = np.asarray(center, float)
    return PolyData(np.array([c + [radius, 0, 0], c - [radius, 0, 0], c + [0, 0, radius]]))


def _disco(center=(0, 0, 0), inner=0, outer=1, normal=(0, 0, 1), c_res=10, **k):
    c = np.asarray(center, float)
    return PolyData(np.array([c, c + [outer, 0, 0], c + [0, 0, outer]]))


def _linea(a=(0, 0, 0), b=(1, 0, 0), **k):
    return PolyData(np.array([a, b], float))


class Actor:
    def __init__(self):
        self.user_matrix = np.eye(4)
        self.prop = types.SimpleNamespace(opacity=1.0, color=(1, 1, 1))
        self._vis = True

    def SetVisibility(self, v):
        # VTK real solo acepta bool/int de Python (no numpy.bool_): se verifica igual aquí
        assert type(v) in (bool, int), f"SetVisibility recibió {type(v).__name__}"
        self._vis = bool(v)

    def GetVisibility(self): return self._vis

    def GetAddressAsString(self, _t): return hex(id(self))


class Plotter:
    def __init__(self, *a, **k):
        self.actores = []
        self.interactor = Widget()
        self.iren = types.SimpleNamespace(interactor=types.SimpleNamespace(AddObserver=lambda *a: None))
        self.camera = types.SimpleNamespace(position=(0, -5, 1), focal_point=(0, 0, 1), up=(0, 0, 1))
        self.camera_position = [(0, -5, 1), (0, 0, 1), (0, 0, 1)]
        self.renderer = None
        self.scalar_bars = {}
        self.bounds = (0, 1, 0, 1, 0, 1)

    def add_mesh(self, malla, **k):
        assert malla is not None
        c = k.get("color")
        if isinstance(c, str) and c.startswith("#"):
            assert len(c) == 7, f"color no válido para PyVista: {c}"
        a = Actor()
        self.actores.append(a)
        return a

    def add_point_labels(self, *a, **k): return self.add_mesh(PolyData())

    def remove_actor(self, a, render=True):
        if a in self.actores:
            self.actores.remove(a)

    def __getattr__(self, k):
        if k.startswith("__"):
            raise AttributeError(k)
        return lambda *a, **kw: None


class Light:
    def __init__(self, *a, **k):
        self.intensity = k.get("intensity", 1.0)
        self.position = k.get("position", (0, 0, 0))
        self.focal_point = k.get("focal_point", (0, 0, 0))


class _ModuloPV(types.ModuleType):
    def __getattr__(self, k):
        if k.startswith("__"):
            raise AttributeError(k)
        return lambda *a, **kw: PolyData(np.zeros((3, 3)))


def _instalar_pyvista():
    pv = _ModuloPV("pyvista")
    pv.PolyData = PolyData
    pv.Box, pv.Cylinder, pv.Sphere, pv.Disc, pv.Line = _caja, _cil, _esfera, _disco, _linea
    pv.Texture = lambda img: ("textura", np.asarray(img).shape)
    pv.Light = Light
    pv.Plotter = Plotter
    pvqt = types.ModuleType("pyvistaqt")
    pvqt.QtInteractor = Plotter
    vtkm = types.ModuleType("vtkmodules")
    rc = types.ModuleType("vtkmodules.vtkRenderingCore")

    class Picker:
        def SetTolerance(self, t): pass

        def Pick(self, *a): return True

        def InitializePickList(self): pass

        def PickFromListOff(self): pass

        def PickFromListOn(self): pass

        def AddPickList(self, a): pass

        def GetActor(self): return Actor()

        def GetPickPosition(self): return (1.0, 2.0, 3.0)

    rc.vtkCellPicker = Picker
    sys.modules.update({"pyvista": pv, "pyvistaqt": pvqt, "vtkmodules": vtkm, "vtkmodules.vtkRenderingCore": rc})


def instalar():
    _instalar_qt()
    _instalar_pyvista()
