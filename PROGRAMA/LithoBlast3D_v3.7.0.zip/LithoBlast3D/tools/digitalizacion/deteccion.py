import cv2, numpy as np, sys, subprocess, re, os
def detect(path):
    img=cv2.imread(path); h,w=img.shape[:2]
    hsv=cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    col=((hsv[...,1]>90)&(hsv[...,2]>120)).astype(np.uint8)
    col=cv2.morphologyEx(col,cv2.MORPH_CLOSE,np.ones((7,7),np.uint8))
    n,lab,st,cen=cv2.connectedComponentsWithStats(col)
    holes=[]
    for i in range(1,n):
        x,y,bw,bh,a=st[i]
        if a<8: continue
        borde = x==0 or y==0 or x+bw>=w or y+bh>=h
        if not borde and abs(bw-bh)>0.45*max(bw,bh): continue
        if not borde and a<0.45*bw*bh: continue
        holes.append([cen[i][0],cen[i][1],(bw+bh)/4,'c',(x,y,bw,bh,borde)])
    rs=[h_[2] for h_ in holes if not h_[4][4]]
    r0=float(np.median(rs)) if rs else 12
    out=[]
    for cx,cy,r,t,(x,y,bw,bh,borde) in holes:
        if borde:
            if bw<r0*0.8 and bh<r0*0.8: continue
            cx = x+bw-r0 if x==0 else (x+r0 if x+bw>=w else cx)
            cy = y+bh-r0 if y==0 else (y+r0 if y+bh>=h else cy)
        out.append([cx,cy,r0,'c'])
    holes=out
    dark=(gray<170).astype(np.uint8)
    n2,lab2,st2,cen2=cv2.connectedComponentsWithStats(1-dark,connectivity=4)
    _,nd_lab,nd_st,_=cv2.connectedComponentsWithStats(dark,connectivity=8)
    for i in range(1,n2):
        x,y,bw,bh,a=st2[i]
        if x==0 or y==0 or x+bw>=w or y+bh>=h: continue
        req=np.sqrt(a/np.pi)
        if not(0.25*r0<=req<=1.2*r0): continue
        ring_lab=nd_lab[int(y+bh//2), max(0,x-2)] if x>=2 else 0
        if ring_lab and 0.7*r0<=req<0.85*r0:
            rx,ry,rw,rh,ra=nd_st[ring_lab]
            if abs(rw-rh)>0.26*max(rw,rh): continue
        if req<0.7*r0:
            # círculo pequeño: el anillo oscuro que lo rodea debe ser un círculo aislado
            ring_lab=nd_lab[int(y+bh//2), max(0,x-2)] if x>=2 else 0
            if ring_lab==0: continue
            rx,ry,rw,rh,ra=nd_st[ring_lab]
            if abs(rw-rh)>0.15*max(rw,rh) or rw>bw+8 or rw<bw+1: continue
            if not(rx<x and ry<y and rx+rw>x+bw and ry+rh>y+bh): continue
            if abs((rh-bh)-(rw-bw))>3: continue
        if abs(bw-bh)>0.25*max(bw,bh) or a<0.7*np.pi*(max(bw,bh)/2)**2: continue
        cx,cy=cen2[i]
        if any(np.hypot(cx-p,cy-q)<r0*1.5 for p,q,_,_ in holes): continue
        if hsv[int(cy),int(cx),1]>60: continue
        ang=np.linspace(0,2*np.pi,48,endpoint=False)
        out_=[gray[int(np.clip(cy+r0*1.8*np.sin(t),0,h-1)),int(np.clip(cx+r0*1.8*np.cos(t),0,w-1))] for t in ang]
        if np.mean(np.array(out_)<170)>0.3: continue
        holes.append([cx,cy,float(req),'w'])
    return img,holes,r0
if __name__=='__main__':
    img,holes,r0=detect(sys.argv[1])
    print(len(holes),r0, sum(1 for h in holes if h[3]=='w'))
    for x,y,r,t in holes: cv2.circle(img,(int(x),int(y)),int(r)+4,(255,0,255),2)
    cv2.imwrite(sys.argv[2],img)

def ocr(img,holes,r0):
    im=img.copy()
    for x,y,r,t in holes: cv2.circle(im,(int(x),int(y)),int(r0*1.25),(255,255,255),-1)
    g=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
    # quitar líneas del contorno (finas, largas): conservar texto
    g=np.where(g<200,0,255).astype(np.uint8)
    esc=max(1.0,26.0/(r0*1.9))  # normalizar altura de texto
    g2=cv2.resize(g,None,fx=esc*1.5,fy=esc*1.5,interpolation=cv2.INTER_CUBIC)
    cv2.imwrite('/tmp/_ocr.png',g2)
    tsv=subprocess.run(['tesseract','/tmp/_ocr.png','-','--psm','11','-c','tessedit_char_whitelist=0123456789,.','tsv'],capture_output=True,text=True).stdout
    words=[]
    for ln in tsv.splitlines()[1:]:
        c=ln.split('\t')
        if len(c)<12 or not c[11].strip(): continue
        x,y,ww,hh=[int(v)/(esc*1.5) for v in c[6:10]]
        words.append((x+ww/2,y+hh/2,ww,hh,c[11].strip(),float(c[10])))
    return words

def etiquetas(img,holes,r0):
    im=img.copy()
    for x,y,r,t in holes: cv2.circle(im,(int(x),int(y)),int(r0*1.6)+1,(255,255,255),-1)
    g=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
    d=(g<180).astype(np.uint8)
    n,lab,st,cen=cv2.connectedComponentsWithStats(d)
    txt=np.zeros_like(d)
    for i in range(1,n):
        x,y,bw,bh,a=st[i]
        if bw<4*r0 and bh<4*r0 and bh>0.4*r0: txt[lab==i]=1
        elif bw<4*r0 and bh<4*r0 and bh<=0.4*r0 and bw<=0.5*r0: txt[lab==i]=1  # comas/puntos
    k=cv2.getStructuringElement(cv2.MORPH_RECT,(int(r0*1.6),3))
    grp=cv2.dilate(txt,k)
    n2,lab2,st2,cen2=cv2.connectedComponentsWithStats(grp)
    blobs=[]
    for i in range(1,n2):
        x,y,bw,bh,a=st2[i]
        if bh<0.8*r0: continue
        blobs.append((x,y,bw,bh))
    # asignar cada bloque al taladro más cercano (por borde del rectángulo)
    res={}
    for (x,y,bw,bh) in blobs:
        best=None
        for j,(hx,hy,_,t) in enumerate(holes):
            if t=='w': continue
            dx=max(x-hx,0,hx-(x+bw)); dy=max(y-hy,0,hy-(y+bh))
            dd=np.hypot(dx,dy)
            if best is None or dd<best[0]: best=(dd,j)
        if best and best[0]<3.5*r0:
            res.setdefault(best[1],[]).append((x,y,bw,bh))
    out={}
    for j,bl in res.items():
        x0=min(b[0] for b in bl);y0=min(b[1] for b in bl);x1=max(b[0]+b[2] for b in bl);y1=max(b[1]+b[3] for b in bl)
        sub=g[max(0,y0-2):y1+3,max(0,x0-2):x1+3].copy()
        msk=cv2.dilate(txt,np.ones((3,3),np.uint8))[max(0,y0-2):y1+3,max(0,x0-2):x1+3]
        sub[msk==0]=255
        crop=sub
        crop=cv2.copyMakeBorder(crop,15,15,15,15,cv2.BORDER_CONSTANT,value=255)
        f=40.0/max(crop.shape[0]-30,1)
        crop=cv2.resize(crop,None,fx=f,fy=f,interpolation=cv2.INTER_CUBIC)
        cv2.imwrite('/tmp/_c%d.png'%os.getpid()+'',crop)
        ts=[]
        for psm in ('7','8'):
            ts.append(subprocess.run(['tesseract','/tmp/_c%d.png'%os.getpid()+'','-','--psm',psm,'-c','tessedit_char_whitelist=0123456789,.'],capture_output=True,text=True).stdout.strip())
        t='|'.join(ts)
        out[j]=(t,(x0,y0,x1,y1))
    return out
