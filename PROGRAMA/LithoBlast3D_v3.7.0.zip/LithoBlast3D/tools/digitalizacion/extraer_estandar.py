"""Extrae la biblioteca de mallas del estándar PDF (páginas 4-57).

Texto de tablas: pdfplumber (texto real del PDF).
Dibujo de malla: imagen incrustada -> digitalización (círculos de color,
rótulos "detonador,cartuchos" por OCR restringido por la tabla del plano).
"""
import sys, re, json, subprocess, itertools
import numpy as np, cv2, pdfplumber
from scipy.optimize import linear_sum_assignment
sys.path.insert(0, '/home/claude/trabajo/scripts')
from digit import detect, etiquetas

PDF = '/home/claude/trabajo/pdf/estandar.pdf'


def ocr_region(pg, bb, psm=6):
    pg.crop(bb).to_image(resolution=300).original.save('/tmp/_r%d.png' % __import__('os').getpid())
    return subprocess.run(['tesseract', '/tmp/_r%d.png' % __import__('os').getpid(), '-', '--psm', str(psm)],
                          capture_output=True, text=True).stdout


def num(s):
    s = s.replace(',', '')
    try:
        return float(s)
    except ValueError:
        return None


def tablas(pg):
    t = pg.extract_text()
    lines = t.splitlines()
    det = {}
    i = next((k for k, l in enumerate(lines) if l.startswith('N_Det_NE')), None)
    total_det = None
    for l in (lines[i + 1:] if i is not None else []):
        m = re.match(r'^(\d+)\s+(\d+)$', l.strip())
        if m:
            det[int(m.group(1))] = int(m.group(2)); continue
        m = re.match(r'^Total general\s+(\d+)', l)
        if m:
            total_det = int(m.group(1))
        break
    words = pg.extract_words()
    heads = [w for w in words if not w.get('upright', True) and w['x0'] > 400 and w['top'] < 330]
    cols = [(((w['x0'] + w['x1']) / 2), w['text'][::-1]) for w in heads]
    y_head = max(w['bottom'] for w in heads)
    mecha = next(w for w in words if w['text'].startswith('Mecha'))
    filas = []
    rows = {}
    for w in words:
        if w.get('upright', True) and w['x0'] > 400 and y_head < w['top'] < mecha['top'] - 2 and w['x0'] < max(c[0] for c in cols) + 20:
            rows.setdefault(round(w['top']), []).append(w)
    for top in sorted(rows):
        ws = sorted(rows[top], key=lambda w: w['x0'])
        x_corte = min(c[0] for c in cols) - 12
        nombre = ' '.join(w['text'] for w in ws if w['x1'] < x_corte)
        vals = {}
        for w in ws:
            if w['x1'] < x_corte: continue
            xc_ = (w['x0'] + w['x1']) / 2
            c = min(cols, key=lambda c: abs(c[0] - xc_))
            vals[c[1]] = num(w['text'])
        if nombre:
            filas.append({'nombre': nombre, 'valores': vals, 'top': top, 'x0': ws[0]['x0']})
    acc = {}
    j = next(k for k, l in enumerate(lines) if l.startswith('Mecha'))
    for l in lines[j:j + 4]:
        m = re.match(r'^(.*?)\s+([\d.]+)\s+[\d.]+$', l) or re.match(r'^(.*?)\s+([\d.]+)$', l)
        if m and not l.startswith('Sobrerotura'):
            acc[m.group(1).strip()] = num(m.group(2))
    par = {}
    pats = {
        'long_perforacion_pies': r'Longitud de perforación, pies\s+([\d.]+)',
        'long_efectiva_m': r'Longitud efectiva, m\s+([\d.]+)',
        'avance_m': r'Avance / disparo, m\s+([\d.]+)',
        'peso_especifico_t_m3': r'Peso especifico, TM/m3\s+([\d.]+)',
        'esponjamiento_pct': r'Esponjamiento, %\s+([\d.]+)',
        'sobrerotura_pct': r'Sobrerotura,%\s+([\d.]+)',
        'diam_max_fragmento_m': r'Diám. Máx. de fragmento, m\s+([\d.]+)',
        'perimetro_m': r'Perímetro, m\s+([\d.]+)',
        'area_m2': r'Area, m2\s+([\d.]+)\s+([\d.]+)',
        'volumen_m3': r'Volumen in situ, m3\s+([\d.]+)\s+([\d.]+)',
        'peso_t': r'Peso, TM\s+([\d.]+)\s+([\d.]+)',
        'volumen_esponjado_m3': r'Volumen esponjado, m3\s+([\d.]+)\s+([\d.]+)',
        'factor_potencia_kg_t': r'Factor de potencia, kg/TM\s+([\d.]+)',
        'factor_potencia_kg_m': r'Factor de potencia, kg/m\s+([\d.]+)',
        'costo_perf_vol_soles': r'Costo Perf\+ Vol, S/.\s+([\d.,]+)',
        'costo_soles_t': r'Costo, S/./TM\s+([\d.,]+)',
        'costo_soles_m': r'Costo, S/./m\s+([\d.,]+)',
    }
    for kk, p in pats.items():
        m = re.search(p, t)
        if m:
            v = [num(g) for g in m.groups()]
            par[kk] = v[0] if len(v) == 1 else {'sin_sobrerotura': v[0], 'con_sobrerotura': v[1]}
    return det, total_det, filas, acc, par


def colores_leyenda(pg, filas):
    """Color del cuadro a la izquierda de cada fila de explosivo."""
    words = pg.extract_words()
    img = pg.to_image(resolution=150).original.convert('RGB')
    f = 150 / 72
    res = {}
    for fi in filas:
        w = {'x0': fi['x0']}
        yc = (fi['top'] + 4) * f
        px = []
        for x in range(int((w['x0'] - 40) * f), int((w['x0'] - 3) * f)):
            for dy in (-2, 0, 2):
                c = img.getpixel((x, int(yc + dy)))
                mx, mn = max(c), min(c)
                if mx > 120 and (mx - mn) > 0.4 * mx:
                    px.append(c)
        if px:
            res[fi['nombre']] = tuple(int(v) for v in np.median(np.array(px), axis=0))
    return res


def lev(a, b):
    d = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        p, d[0] = d[0], i
        for j, cb in enumerate(b, 1):
            p, d[j] = d[j], min(d[j] + 1, d[j - 1] + 1, p + (ca != cb))
    return d[-1]


def leer_contorno(img, holes, r0):
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    d = ((g < 200) | (hsv[..., 1] > 90)).astype(np.uint8)
    n, lab, st, cen = cv2.connectedComponentsWithStats(d)
    m = np.zeros_like(d)
    for i in range(1, n):
        x, y, bw, bh, a = st[i]
        if bw > 6 * r0 or bh > 6 * r0:
            m[lab == i] = 1
    k = int(max(3, r0 * 3)) | 1
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    cs, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    c = max(cs, key=cv2.contourArea)
    relleno = np.zeros_like(m)
    cv2.drawContours(relleno, [c], -1, 1, -1)
    hh, ww = m.shape
    ys, xs = np.nonzero(relleno)
    x0, x1, y0 = xs.min(), xs.max(), ys.min()
    # piso: fila más baja con ancho relleno > 50 % (la cuneta es angosta)
    piso = None
    for y in range(hh - 1, int(hh * 0.5), -1):
        if relleno[y, x0:x1 + 1].sum() > 0.5 * (x1 - x0):
            piso = y; break
    c2 = cv2.approxPolyDP(c, 1.5, True)[:, 0, :]
    return x0, x1, y0, piso, c2


def procesar(pnum, pdf, indice):
    pg = pdf.pages[pnum - 1]
    det, total_det, filas, acc, par = tablas(pg)
    leyenda = colores_leyenda(pg, filas)
    titulo = ocr_region(pg, (395, 522, 790, 555))
    codigo = ocr_region(pg, (785, 545, 842, 595))
    img, holes, r0 = detect(f'/home/claude/trabajo/dib/p{pnum:02d}.png')
    # si hay más círculos blancos que alivios en la tabla, descartar los menos circulares/pequeños
    descartados = 0
    t_al = next((v.get('Perf') for f_ in filas if f_['nombre'].lower().startswith('sin') for v in [f_['valores']]), None)
    blancos = sorted([h for h in holes if h[3] == 'w'], key=lambda h: h[2])
    if t_al is not None and len(blancos) > t_al:
        for h in blancos[:len(blancos) - int(t_al)]:
            holes.remove(h); descartados += 1
    for h in holes:
        if h[3] == 'w': h[2] = r0
    lbl = etiquetas(img, holes, r0)
    x0, x1, y0, piso, cont = leer_contorno(img, holes, r0)
    info = indice[pnum]
    W, H = info['ancho'], info['alto']
    sx = W / (x1 - x0); sy = H / (piso - y0) if piso else sx
    xc = (x0 + x1) / 2

    # --- decodificación de rótulos con restricción de la tabla ---
    cargados = [j for j, h in enumerate(holes) if h[3] == 'c']
    electronico = not det
    if electronico:
        n_al = sum(1 for h in holes if h[3] == 'w')
        det = {k: 1 for k in range(n_al + 1, len(holes) + 1)}
        total_det = None
    slots = [d for d, n in sorted(det.items()) for _ in range(n)]
    # espejo de cada taladro (para apoyo de lectura)
    def espejo(j):
        x, y = holes[j][0], holes[j][1]
        best = min(cargados, key=lambda k: np.hypot(holes[k][0] - (2 * xc - x), holes[k][1] - y))
        dd = np.hypot(holes[best][0] - (2 * xc - x), holes[best][1] - y)
        return best if dd < 2 * r0 and best != j else None
    tres = any(k.lower().startswith('anfo') for fi in filas for k in fi['valores'])
    crudo = {j: [re.sub(r'[^0-9,.]', '', t) for t in lbl.get(j, ('', None))[0].split('|')] for j in cargados}
    anfo = {}

    def partir(t):
        if not tres:
            return t.replace('.', ''), None
        m = re.match(r'^(.*?),?(\d\.\d|0)$', t)
        if m:
            return m.group(1).replace('.', ''), m.group(2)
        return t.replace('.', ''), None
    lect = {}
    for j, ts in crudo.items():
        lect[j] = []
        for t in ts:
            a_, b_ = partir(t)
            lect[j].append(a_)
            if b_ is not None and j not in anfo:
                anfo[j] = float(b_)

    carts = sorted(set(range(1, 13)))

    def propio(j, L):
        return min(lev(s.replace(',', ''), L.replace(',', '')) + 0.2 * lev(s, L) for s in lect[j])

    def costo(j, d, c):
        L = f'{d},{c}'
        k = propio(j, L)
        e = espejo(j)
        if e is not None:
            k += 0.45 * propio(e, L)
        return k
    estado = 'ok'
    asign = {}
    if len(slots) == len(cargados) and slots:
        C = np.zeros((len(cargados), len(slots)))
        best_c = {}
        for a, j in enumerate(cargados):
            for b, d in enumerate(slots):
                cc = min(carts, key=lambda c: costo(j, d, c))
                C[a, b] = costo(j, d, cc); best_c[(j, d)] = cc
        ra, cb = linear_sum_assignment(C)
        for a, b in zip(ra, cb):
            j = cargados[a]; d = slots[b]
            asign[j] = (d, best_c[(j, d)], C[a, b])
    else:
        estado = f'cantidad distinta: {len(cargados)} detectados vs {len(slots)} en tabla'

    # colores -> explosivo: agrupar los tonos de los taladros (k-medias 1D) y emparejar
    # los grupos con la leyenda por orden de tono (rojo < naranja < amarillo < verde)
    def tono_bgr(b, g, r):
        return float(cv2.cvtColor(np.uint8([[[b, g, r]]]), cv2.COLOR_BGR2HSV)[0, 0, 0])
    ley = [(tono_bgr(B, G, R), nom) for nom, (R, G, B) in leyenda.items() if not nom.lower().startswith(('total', 'sin'))]
    ley.sort()
    tonos = {}
    for j in cargados:
        x, y = int(holes[j][0]), int(holes[j][1]); rr = int(r0)
        sub = img[max(0, y - rr):y + rr + 1, max(0, x - rr):x + rr + 1].reshape(-1, 3).astype(int)
        sat = sub[(sub.max(1) > 120) & ((sub.max(1) - sub.min(1)) > 0.4 * sub.max(1))]
        if len(sat):
            b_, g_, r_ = np.median(sat, axis=0)
            tonos[j] = tono_bgr(b_, g_, r_)
    mapa_exp = {}
    perf_por = {}
    for f_ in filas:
        for k_, x_ in f_['valores'].items():
            if k_.lower().startswith('perf'): perf_por[f_['nombre']] = int(x_)
    cuentas = [perf_por.get(nom) for _, nom in ley]
    if ley and tonos and None not in cuentas and sum(cuentas) == len(tonos):
        orden_h = sorted(tonos, key=lambda j: tonos[j])
        pos = 0; ok_gap = True
        for (t_, nom), n_ in zip(ley, cuentas):
            grupo = orden_h[pos:pos + n_]
            for j in grupo: mapa_exp[j] = nom
            if pos + n_ < len(orden_h) and n_ > 0:
                if tonos[orden_h[pos + n_]] - tonos[orden_h[pos + n_ - 1]] < 2: ok_gap = False
            pos += n_
        if not ok_gap: mapa_exp = {}
    if ley and tonos and not mapa_exp:
        vals = np.array(list(tonos.values()))
        centros = np.array([t for t, _ in ley], dtype=float)
        k = len(centros)
        # inicializar con cuantiles de los tonos observados para no depender del muestreo de leyenda
        for _ in range(50):
            asig = np.argmin(np.abs(vals[:, None] - centros[None, :]), axis=1)
            nuevos = np.array([vals[asig == i].mean() if np.any(asig == i) else centros[i] for i in range(k)])
            if np.allclose(nuevos, centros): break
            centros = nuevos
        # fusionar grupos casi iguales (menos colores en el dibujo que en la leyenda)
        orden = np.argsort(centros)
        for jj, t in tonos.items():
            i = int(np.argmin(np.abs(centros - t)))
            rango = int(np.where(orden == i)[0][0])
            mapa_exp[jj] = ley[rango][1]

    def explosivo_por_color(j):
        return mapa_exp.get(j)

    tal = []
    for j, (x, y, r, t) in enumerate(holes):
        e = {'_j': j, 'x': round((x - xc) * sx, 3), 'y': round((piso - y) * sy, 3) if piso else None,
             'px': [round(float(x), 1), round(float(y), 1)]}
        if t == 'w':
            e.update(tipo='alivio', detonador=None, cartuchos=0, explosivo=None, lectura='circulo blanco')
        else:
            d, c, k = asign.get(j, (None, None, 99))
            e.update(tipo='cargado', detonador=d, cartuchos=c, explosivo=explosivo_por_color(j),
                     anfo_kg=anfo.get(j),
                     ocr='|'.join(lect[j]))
            if d is None:
                e['lectura'] = 'sin asignar: revisar'
            else:
                dg = min(lev(s.replace(',', ''), f'{d}{c}') for s in lect[j])
                e['lectura'] = 'leído' if dg == 0 else ('leído (1 carácter corregido por tabla)' if dg == 1 else 'inferido por tabla y simetría: revisar')
        tal.append(e)

    # ajuste de cartuchos a la tabla de explosivos (mínimo cambio)
    def colv(v, pref):
        for k_, x in v.items():
            if k_.lower().startswith(pref): return x
        return None
    for fi in filas:
        n = fi['nombre']; objetivo = colv(fi['valores'], 'cart')
        idx = [i for i, e in enumerate(tal) if e['tipo'] == 'cargado' and e['explosivo'] == n and e['detonador'] is not None]
        if objetivo is None or not idx: continue
        if colv(fi['valores'], 'perf') is not None and int(colv(fi['valores'], 'perf')) != len(idx): continue
        objetivo = int(round(objetivo))
        if sum(tal[i]['cartuchos'] for i in idx) == objetivo: continue
        # DP: coste = lectura propia de cada opción
        hidx = [i for i in idx]
        opciones = []
        for i in hidx:
            d = tal[i]['detonador']; j = tal[i]['_j']
            ops = []
            for c in range(1, 13):
                k = propio(j, f'{d},{c}') + (0 if c == tal[i]['cartuchos'] else 0.01)
                ops.append((c, k))
            opciones.append(ops)
        INF = 1e9
        dp = {0: (0.0, [])}
        for ops in opciones:
            nd = {}
            for sm, (cst, el) in dp.items():
                for c, k in ops:
                    s2 = sm + c
                    if s2 > objetivo: continue
                    v = cst + k
                    if s2 not in nd or v < nd[s2][0]:
                        nd[s2] = (v, el + [c])
            dp = nd
        if objetivo in dp:
            for i, c in zip(hidx, dp[objetivo][1]):
                if c != tal[i]['cartuchos']:
                    tal[i]['cartuchos'] = c
                    tal[i]['lectura'] = 'cartuchos ajustados a la tabla de explosivos: revisar'
    # verificaciones contra tablas del propio plano
    ver = []
    def col(v, pref):
        for k_, x in v.items():
            if k_.lower().startswith(pref): return x
        return None
    nperf = next((col(fi['valores'], 'perf') for fi in filas if fi['nombre'].lower().startswith('total')), None)
    ver.append(('perforaciones totales', len(holes), nperf))
    if total_det is not None:
        ver.append(('taladros cargados (cuenta de detonadores)', len(cargados), total_det))
    for fi in filas:
        n = fi['nombre']; v = fi['valores']
        if n.lower().startswith('total'): continue
        if n.lower().startswith('sin'):
            ver.append(('sin explosivo (alivios)', sum(1 for h in holes if h[3] == 'w'), col(v, 'perf'))); continue
        mis = [e for e in tal if e['explosivo'] == n]
        if col(v, 'cart') is not None:
            ver.append((f'cartuchos {n}', sum(e['cartuchos'] or 0 for e in mis), col(v, 'cart')))
        ver.append((f'perforaciones {n}', len(mis), col(v, 'perf')))
        if tres and col(v, 'anfo') is not None:
            ver.append((f'ANFO kg {n} (informativo)', round(sum(e.get('anfo_kg') or 0 for e in mis), 2), col(v, 'anfo')))
    for e in tal: e.pop('_j', None)
    return {
        'pagina': pnum, 'titulo_ocr': ' '.join(titulo.split()), 'codigo_ocr': ' '.join(codigo.split()),
        **info, 'cuenta_detonadores': det, 'total_cargados': total_det,
        'explosivos_tabla': filas, 'accesorios': acc, 'parametros': par,
        'leyenda_colores': {k: list(v) for k, v in leyenda.items()},
        'escala': {'m_por_px_x': sx, 'm_por_px_y': sy, 'anisotropia_pct': round((sy / sx - 1) * 100, 1)},
        'contorno': [[round((float(px) - xc) * sx, 3), round((piso - float(py)) * sy, 3)] for px, py in cont],
        'taladros': tal, 'rotulo': ('n° de taladro (orden de salida), cartuchos' if electronico else 'n° de detonador (retardo), cartuchos') + (', ANFO kg' if tres else ''), 'iniciacion': 'electrónica' if electronico else 'no eléctrica', 'verificacion': [list(v) for v in ver], 'estado_asignacion': estado, 'circulos_blancos_descartados': descartados,
    }


def _uno(p):
    import io, contextlib
    indice = {int(k): v for k, v in json.load(open('/home/claude/trabajo/indice.json')).items()}
    pdf = pdfplumber.open(PDF)
    try:
        return procesar(p, pdf, indice)
    except Exception as ex:
        import traceback
        return {'pagina': p, 'error': traceback.format_exc()}


if __name__ == '__main__':
    import multiprocessing as mp
    indice = {int(k): v for k, v in json.load(open('/home/claude/trabajo/indice.json')).items()}
    pags = [int(a) for a in sys.argv[1:]] or sorted(indice)
    with mp.Pool(2) as pool:
        out = pool.map(_uno, pags)
    for r in out:
        if 'error' in r:
            print(r['pagina'], 'ERROR', r['error'][-300:]); continue
        ok = all(v[1] == v[2] for v in r['verificacion'] if 'informativo' not in v[0])
        nl = sum(1 for t in r['taladros'] if 'revisar' in t['lectura'])
        dif = [v for v in r['verificacion'] if v[1] != v[2] and 'informativo' not in v[0]]
        print(r['pagina'], r['seccion'], 'OK' if ok else 'DIF', dif, 'revisar:', nl, '/', len(r['taladros']), r['estado_asignacion'], r['escala']['anisotropia_pct'])
    json.dump([r for r in out if 'error' not in r], open('/home/claude/trabajo/biblioteca.json', 'w'), ensure_ascii=False, indent=1, default=float)
