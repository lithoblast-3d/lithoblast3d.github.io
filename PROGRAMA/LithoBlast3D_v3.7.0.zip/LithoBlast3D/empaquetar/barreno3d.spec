# -*- mode: python ; coding: utf-8 -*-
# Empaquetado de LithoBlast3D con PyInstaller (carpeta con LithoBlast3D.exe).
# Uso: empaquetar\crear_ejecutable.ps1   (o: python -m PyInstaller empaquetar\barreno3d.spec)
# Variable B3D_PUBLICA=1 -> edición pública (sin las mallas del estándar en app/datos).
import os
from pathlib import Path

from PyInstaller.utils.hooks import collect_all, collect_submodules

RAIZ = Path(SPECPATH).parent
PUBLICA = os.environ.get("B3D_PUBLICA", "0") == "1"

datas, binaries, ocultos = [], [], []
for paquete in ("pyvista", "pyvistaqt", "vtkmodules", "scooby"):
    d, b, h = collect_all(paquete)
    datas += d
    binaries += b
    ocultos += h
ocultos += collect_submodules("app")
ocultos += ["matplotlib.backends.backend_qtagg", "matplotlib.backends.backend_agg"]
# Datos del programa: fichas Emulnor, referencias de minas y la simulación 3D del ciclo (web3d) van siempre.
# La edición pública solo quita la biblioteca de mallas del estándar (biblioteca_estandar_6p.json y planos/).
DATOS = RAIZ / "app" / "datos"
for f in DATOS.iterdir():
    if PUBLICA and (f.name.startswith("biblioteca_estandar") or f.name == "planos"):
        continue
    datas += [(str(f), "app/datos/" + f.name if f.is_dir() else "app/datos")]
datas += [(str(RAIZ / "plantilla_pozos.csv"), ".")]

a = Analysis(
    [str(RAIZ / "ejecutar.py")],
    pathex=[str(RAIZ)],
    binaries=binaries,
    datas=datas,
    hiddenimports=ocultos,
    excludes=["tkinter", "PyQt5", "PyQt6", "PySide2", "IPython", "jupyter", "notebook", "pytest", "tests", "tools"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="LithoBlast3D",
    console=False,
    icon=str(RAIZ / "empaquetar" / "barreno3d.ico"),
)
coll = COLLECT(exe, a.binaries, a.datas, name="LithoBlast3D")
