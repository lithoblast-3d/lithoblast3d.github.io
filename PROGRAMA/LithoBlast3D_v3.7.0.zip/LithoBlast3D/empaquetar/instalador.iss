; Instalador de LithoBlast3D (Inno Setup 7, gratis: https://jrsoftware.org/isdl.php)
; Lo compila crear_ejecutable.ps1 -Instalador ; también: ISCC.exe /DVersion=3.1.0 instalador.iss
#ifndef Version
  #define Version "3.1.0"
#endif
#ifndef Edicion
  #define Edicion ""
#endif

[Setup]
AppId={{6C4B2E1A-3D7F-4B8E-9A51-B3D0B3D0B3D0}
AppName=LithoBlast3D
AppVersion={#Version}
AppVerName=LithoBlast3D {#Version}
DefaultDirName={autopf}\LithoBlast3D
DefaultGroupName=LithoBlast3D
DisableProgramGroupPage=yes
OutputDir=salida
OutputBaseFilename=LithoBlast3D-{#Version}{#Edicion}-instalador
SetupIconFile=barreno3d.ico
UninstallDisplayIcon={app}\LithoBlast3D.exe
Compression=lzma2/max
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
WizardStyle=modern

[Languages]
Name: "es"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "escritorio"; Description: "Crear un acceso directo en el escritorio"; Flags: unchecked

[Files]
Source: "dist\LithoBlast3D\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\LithoBlast3D"; Filename: "{app}\LithoBlast3D.exe"
Name: "{group}\Desinstalar LithoBlast3D"; Filename: "{uninstallexe}"
Name: "{autodesktop}\LithoBlast3D"; Filename: "{app}\LithoBlast3D.exe"; Tasks: escritorio

[Run]
Filename: "{app}\LithoBlast3D.exe"; Description: "Abrir LithoBlast3D"; Flags: nowait postinstall skipifsilent
