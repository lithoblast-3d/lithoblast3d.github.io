﻿<#
Crea LithoBlast3D.exe (carpeta lista para copiar), un .zip y, si tienes Inno Setup, un instalador.

Uso (PowerShell, en C:\Proyectos\barreno3d con (.venv) activo):
    .\empaquetar\crear_ejecutable.ps1 -Instalador     # programa completo + instalador (lo normal)
    .\empaquetar\crear_ejecutable.ps1                 # programa completo, solo .zip
    (opcional) -Publica : quita la biblioteca de mallas del estándar del paquete
Si PowerShell no deja ejecutar scripts:
    Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
#>
param([switch]$Publica, [switch]$Instalador, [switch]$SinPruebas)
$ErrorActionPreference = "Stop"
$raiz = Split-Path -Parent $PSScriptRoot
Set-Location $raiz

Write-Host "1/4 Instalando PyInstaller y dependencias..." -ForegroundColor Cyan
python -m pip install --upgrade "pyinstaller>=6.15" | Out-Null
python -m pip install -r requirements.txt | Out-Null

if (-not $SinPruebas) {
    Write-Host "2/4 Pruebas del motor de calculo..." -ForegroundColor Cyan
    python -m unittest discover -s tests
    if ($LASTEXITCODE -ne 0) { throw "Fallaron las pruebas: no se empaqueta." }
}

Write-Host "3/4 Empaquetando (tarda varios minutos)..." -ForegroundColor Cyan
$env:B3D_PUBLICA = $(if ($Publica) { "1" } else { "0" })
python -m PyInstaller --noconfirm --clean empaquetar\barreno3d.spec --distpath empaquetar\dist --workpath empaquetar\build
if ($LASTEXITCODE -ne 0) { throw "PyInstaller fallo." }

$version = (python -c "import app; print(app.VERSION)").Trim()
$edicion = $(if ($Publica) { "-sin-estandar" } else { "" })
New-Item -ItemType Directory -Force empaquetar\salida | Out-Null
$zip = "empaquetar\salida\LithoBlast3D-$version$edicion-windows.zip"
Write-Host "4/4 Comprimiendo $zip ..." -ForegroundColor Cyan
Compress-Archive -Path empaquetar\dist\LithoBlast3D -DestinationPath $zip -Force

if ($Instalador) {
    $iscc = @("$env:ProgramFiles\Inno Setup 7\ISCC.exe", "${env:ProgramFiles(x86)}\Inno Setup 7\ISCC.exe",
              "$env:LOCALAPPDATA\Programs\Inno Setup 7\ISCC.exe",
              "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
              "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $iscc) { $iscc = (Get-Command ISCC.exe -ErrorAction SilentlyContinue).Source }
    if ($iscc) {
        & $iscc "/DVersion=$version" "/DEdicion=$edicion" empaquetar\instalador.iss
    } else {
        Write-Warning "No se encontro Inno Setup (jrsoftware.org). Se creo solo el .zip."
    }
}
Write-Host ""
Write-Host "Listo. Prueba el programa: empaquetar\dist\LithoBlast3D\LithoBlast3D.exe" -ForegroundColor Green
Get-ChildItem empaquetar\salida | Format-Table Name, @{n="MB";e={[math]::Round($_.Length/1MB,1)}}
