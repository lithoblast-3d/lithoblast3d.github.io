@echo off
chcp 65001 >nul
title LithoBlast3D - Instalar
cd /d "%~dp0"
echo.
echo  === LithoBlast3D: instalando lo necesario (solo la primera vez) ===
echo.
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
%PY% --version >nul 2>nul
if errorlevel 1 (
  echo  No se encontro Python. Instalalo desde https://www.python.org/downloads/
  echo  y marca la casilla "Add Python to PATH". Luego vuelve a abrir este archivo.
  pause
  exit /b 1
)
if not exist .venv\Scripts\python.exe %PY% -m venv .venv
.venv\Scripts\python -m pip install --upgrade pip
.venv\Scripts\python -m pip install -r requirements.txt scipy ezdxf
if errorlevel 1 (
  echo.
  echo  Hubo un error al instalar. Revisa tu conexion a internet y vuelve a intentarlo.
  pause
  exit /b 1
)
echo.
echo  Listo. Ahora abre EJECUTAR.bat
pause
