"""El motor de la app móvil (web/app/nucleo.zip) debe funcionar SOLO con lo que lleva dentro."""

import json
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]

PRUEBA = r'''
import sys, json
sys.path.insert(0, CARPETA)
import movil
def ok(r):
    r = json.loads(r); assert r["ok"], r; return r["datos"]
inf = ok(movil.info())
ops = ok(movil.opciones(json.dumps({"ancho": 3.0, "alto": 3.2, "diametro": 38, "pies": 6,
                                    "explosivo": inf["explosivos"][2]})))
assert len(ops) == 8 and sum(1 for o in ops if o.get("taladros")) >= 6, [o["error"] for o in ops]
c = next(o["clave"] for o in ops if o.get("taladros"))
assert "AC1009" in ok(movil.dxf_frente(json.dumps({"clave": c})))["texto"]
ok(movil.danio(json.dumps({"clave": c, "ucs": 120, "t": 8})))
ok(movil.burden(json.dumps({"d": 102, "h": 10, "rho_e": 0.85, "rho_r": 2.7, "vod": 4000, "vc": 3500, "kb": 30,
                            "explosivo": "ANFO", "inclinacion": "Vertical", "c": 0.4})))
ok(movil.cimbra(json.dumps({"ancho": 4, "alto": 4, "perfil": "W6x20", "fy": 250, "esp": 1, "rmr": 45, "gamma": 27})))
ce = ok(movil.costos_ejemplo("{}"))
ok(movil.costos(json.dumps({**ce, "avance": 1.7, "volumen": 20, "toneladas": 54})))
mods = sorted(m for m in sys.modules if m.split(".")[0] in ("PySide6", "pyvista", "vtk", "matplotlib"))
assert not mods, mods
print("OK")
'''


class MotorMovil(unittest.TestCase):
    def test_nucleo_autonomo(self):
        sys.path.insert(0, str(RAIZ / "tools" / "web"))
        import construir_movil
        zipf = construir_movil.construir()
        carpeta = tempfile.mkdtemp()
        zipfile.ZipFile(zipf).extractall(carpeta)
        r = subprocess.run([sys.executable, "-I", "-c", f"CARPETA = {carpeta!r}\n" + PRUEBA],
                           capture_output=True, text=True, timeout=300, cwd=carpeta)
        self.assertIn("OK", r.stdout, r.stderr[-2000:])


if __name__ == "__main__":
    unittest.main()
