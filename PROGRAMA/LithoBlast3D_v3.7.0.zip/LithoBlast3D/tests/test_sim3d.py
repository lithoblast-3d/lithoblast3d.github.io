"""Pruebas del núcleo del simulador 3D (sin gráficos): ciclo, cinemática, fragmentos y física."""

import math
import unittest

import numpy as np

from app.sim3d import ciclo, fisica, fragmentos
from app.sim3d.cinematica import EspecEquipo, cabe_jumbo, planificar, pose_para
from app.sim3d.datos import FrenteSim, TaladroSim, casco_convexo, punto_en_poligono


def frente(ancho=3.0, alto=3.0):
    sec = [(-ancho / 2, 0), (ancho / 2, 0), (ancho / 2, alto * 0.75)] + \
        [(ancho / 2 * math.cos(a), alto * 0.75 + alto * 0.25 * math.sin(a)) for a in np.linspace(0.2, math.pi - 0.2, 8)] + \
        [(-ancho / 2, alto * 0.75)]
    tal = []
    k = 0
    for x in np.linspace(-ancho / 2 + 0.15, ancho / 2 - 0.15, 5):
        for z in np.linspace(0.15, alto * 0.8, 5):
            alivio = abs(x) < 0.2 and abs(z - alto * 0.4) < 0.4
            tal.append(TaladroSim(id=f"P{k}", x=float(x), z=float(z), direccion=np.array([0, 1.0, 0]),
                                  longitud=1.83, diametro_mm=38, alivio=alivio, funcion="Ayuda", retardo=k % 7,
                                  tiempo_ms=None, carga_kg=0 if alivio else 1.0, longitud_carga=1.2, taco=0.4,
                                  explosivo="E", cartuchos=0))
            k += 1
    return FrenteSim(nombre="t", seccion=sec, taladros=tal, avance=1.5, densidad_roca=2.7)


class TestCiclo(unittest.TestCase):
    def test_trece_etapas(self):
        self.assertEqual(len(ciclo.ETAPAS), 13)
        self.assertEqual(set(ciclo.TITULOS), set(ciclo.CLAVES))

    def test_cadena_y_fin(self):
        r = ciclo.Reloj()
        r.iniciar(0, cadena=True)
        total = sum(e.duracion for e in r.etapas)
        eventos = []
        for _ in range(int(total * 10) + 50):
            eventos += r.avanzar(0.1)
        self.assertTrue(r.terminado)
        self.assertEqual(r.indice, 12)
        self.assertEqual(sum(1 for e in eventos if e[0] == "inicio_etapa"), 12)

    def test_solo_una_etapa_pausa_lenta(self):
        r = ciclo.Reloj()
        r.iniciar(3, cadena=False)
        r.camara_lenta = True
        r.avanzar(4.0)
        self.assertAlmostEqual(r.t, 1.0)
        r.pausar(); r.avanzar(100)
        self.assertAlmostEqual(r.t, 1.0)
        r.continuar(); r.camara_lenta = False; r.set_velocidad(100)
        self.assertEqual(r.velocidad, ciclo.Reloj.VEL_MAX)
        r.avanzar(100)
        self.assertTrue(r.terminado and r.indice == 3)
        r.reiniciar()
        self.assertEqual((r.indice, r.t, r.en_marcha), (0, 0.0, False))


class TestCinematica(unittest.TestCase):
    def test_pose_alinea_viga_con_el_taladro(self):
        e = EspecEquipo()
        piv = np.array([0.0, -4.2, 1.2])
        collar = np.array([0.5, 0.0, 1.8]); d = np.array([0.05, 1.0, 0.0]); d /= np.linalg.norm(d)
        p = pose_para(e, piv, collar, d)
        u = (p.viga_fin - p.viga_inicio) / np.linalg.norm(p.viga_fin - p.viga_inicio)
        self.assertTrue(np.allclose(u, d))
        self.assertAlmostEqual(np.linalg.norm(p.viga_fin - p.viga_inicio), e.largo_viga)
        self.assertAlmostEqual(np.linalg.norm(collar - p.viga_fin), e.separacion_frente)
        self.assertAlmostEqual(np.linalg.norm(p.punta - p.pivote), p.largo_brazo)
        self.assertTrue(p.alcanzable)

    def test_fuera_de_alcance(self):
        e = EspecEquipo(brazo_max=2.0)
        p = pose_para(e, np.array([0.0, -4.2, 1.2]), np.array([0, 0, 1.5]), np.array([0, 1.0, 0]))
        self.assertFalse(p.alcanzable)
        self.assertIn("alcance", p.motivo)

    def test_seccion_angosta_usa_perforadora_manual(self):
        f = frente(1.2, 1.8)
        ok, motivo = cabe_jumbo(EspecEquipo(), f)
        self.assertFalse(ok)
        self.assertEqual(planificar(f).modo, "manual")

    def test_dos_brazos_y_todos_asignados(self):
        f = frente(3.0, 3.0)
        plan = planificar(f)
        self.assertEqual((plan.modo, plan.brazos), ("jumbo", 2))
        self.assertEqual(sorted(sum(plan.asignacion, [])), list(range(len(f.taladros))))
        # los alivios se perforan primero
        primeros = [plan.asignacion[b][0] for b in range(2) if plan.asignacion[b]]
        self.assertTrue(any(f.taladros[i].alivio for i in primeros))


class TestFragmentos(unittest.TestCase):
    def test_celdas_cubren_el_volumen(self):
        f = frente(2.5, 2.7)
        conv = casco_convexo(f.seccion)
        sec = np.array(fragmentos.simplificar_poligono(conv))
        area = 0.5 * abs(np.dot(sec[:, 0], np.roll(sec[:, 1], 1)) - np.dot(sec[:, 1], np.roll(sec[:, 0], 1)))
        frs = fragmentos.generar(conv, 1.5, np.array([[t.x, t.z] for t in f.taladros]), 60)
        try:
            import scipy  # noqa: F401
        except ImportError:
            self.skipTest("scipy no instalado: el volumen exacto de cada celda requiere scipy")
        self.assertAlmostEqual(sum(fr.volumen for fr in frs), area * 1.5, delta=area * 1.5 * 0.01)
        for fr in frs:
            self.assertTrue(np.all(fr.vertices[:, 1] >= -1e-6) and np.all(fr.vertices[:, 1] <= 1.5 + 1e-6))
            self.assertTrue(punto_en_poligono(fr.centro[0], fr.centro[2], conv))


class TestFisica(unittest.TestCase):
    def test_caen_y_reposan_sobre_el_piso(self):
        rng = np.random.default_rng(0)
        n = 40
        c = np.c_[rng.uniform(-1, 1, n), rng.uniform(0.2, 1.4, n), rng.uniform(0.3, 2.5, n)]
        m = fisica.MundoFisico(c, np.full(n, 0.15), np.full(n, 50.0), medio_ancho=1.25, alto=2.7, y_frente_final=1.5)
        v, w = fisica.velocidades_iniciales(c, np.array([0, 0.75, 1.2]), rng)
        m.liberar(range(n), v, w)
        for _ in range(600):
            m.paso(1 / 30)
        self.assertTrue(np.all(m.x[:, 2] >= 0.15 - 1e-6))
        self.assertTrue(np.all(np.abs(m.x[:, 0]) <= 1.25 - 0.15 + 1e-6))
        self.assertTrue(np.all(m.x[:, 1] <= 1.5 - 0.15 + 1e-6))
        self.assertLess(m.energia_cinetica(), 1.0)
        self.assertGreater(m.dormido.mean(), 0.8)
        # las matrices son rotaciones válidas
        T = m.matrices()
        R = T[:, :3, :3]
        self.assertTrue(np.allclose(np.einsum("nij,nkj->nik", R, R), np.eye(3), atol=1e-6))


if __name__ == "__main__":
    unittest.main()
