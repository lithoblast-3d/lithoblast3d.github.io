"""Pruebas de los cálculos de roca (valores resueltos a mano)."""

import math
import unittest

from app.calc import roca as r
from app.calc.carga import ErrorDeDatos


class PruebasRoca(unittest.TestCase):
    def test_clases(self):
        self.assertEqual(r.clase_rmr(85), ("I", "Muy buena"))
        self.assertEqual(r.clase_rmr(61), ("II", "Buena"))
        self.assertEqual(r.clase_rmr(50), ("III", "Regular"))
        self.assertEqual(r.clase_rmr(25), ("IV", "Mala"))
        self.assertEqual(r.clase_rmr(10), ("V", "Muy mala"))
        with self.assertRaises(ErrorDeDatos):
            r.clase_rmr(120)

    def test_ashby_y_c(self):
        # ρ = 2.6, GSI = 45, RQD = 60: tan(30°) = 0.57735 ; Jv = 55/3.3 = 16.667 ; ∛Jv = 2.5544
        # CE = 0.56·2.6·0.57735 / 2.5544 = 0.32910 kg/m³ ; c = 0.8784·0.32910 + 0.052 = 0.34108
        ce = r.consumo_especifico_ashby(2.6, 45, 60)
        self.assertAlmostEqual(ce, 0.32910, places=4)
        self.assertAlmostEqual(r.constante_roca(ce), 0.34108, places=4)

    def test_roca_mejor_mas_carga(self):
        mala = r.constante_roca(r.consumo_especifico_ashby(2.6, 20, 25))
        buena = r.constante_roca(r.consumo_especifico_ashby(2.6, 75, 90))
        self.assertLess(mala, buena)
        self.assertGreater(r.factor_burden_roca(mala), 1.0)   # roca mala: burden mayor
        self.assertLess(r.factor_burden_roca(buena), 1.0)     # roca buena: burden menor
        self.assertAlmostEqual(r.factor_burden_roca(0.4), 1.0)

    def test_exsa(self):
        # S = 9 m² dura: P = 12 m ; N = 12/0.5 + 2·9 = 42
        p, dt, n = r.taladros_exsa(9.0, "Dura")
        self.assertAlmostEqual(p, 12.0)
        self.assertEqual(n, 42)
        self.assertEqual(r.taladros_exsa(9.0, "Blanda")[2], math.ceil(12 / 0.7 + 9))


if __name__ == "__main__":
    unittest.main()
