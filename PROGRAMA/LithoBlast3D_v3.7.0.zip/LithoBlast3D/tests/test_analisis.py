"""Pruebas de los módulos de cálculo de la versión 3 (sin interfaz)."""

import math
import unittest

import numpy as np

from app.calc import burden_formulas as bf
from app.calc import cimbra as cb
from app.calc import costos as co
from app.calc import dinamica as dn
from app.calc import fragmentacion as fr
from app.calc import macizo as mz
from app.calc import zona_danio as zd


class Fragmentacion(unittest.TestCase):
    def test_x50_kuznetsov_a_mano(self):
        # x50 [cm] = A·K^-0.8·Q^(1/6)·(115/RWS)^(19/20)
        a, k, q, rws = 7.0, 0.6, 100.0, 100.0
        esperado = a * k ** -0.8 * q ** (1 / 6) * (115 / rws) ** (19 / 20) * 10  # mm
        self.assertAlmostEqual(fr.x50_kuznetsov(a, k, q, rws), esperado, places=6)

    def test_curvas_pasan_por_x50(self):
        r = fr.kuz_ram(fr.EntradaKuzRam())
        self.assertAlmostEqual(float(fr.pasante_rosin([r.x50_mm], r.x50_mm, r.n)[0]), 0.5, places=6)
        self.assertAlmostEqual(float(fr.pasante_swebrec([r.x50_mm], r.x50_mm, r.xmax_mm, r.b)[0]), 0.5, places=6)
        self.assertAlmostEqual(fr.tamano_swebrec(0.8, r.x50_mm, r.xmax_mm, r.b), r.x80_sw_mm, places=6)

    def test_mas_carga_mas_fino(self):
        e = fr.EntradaKuzRam()
        x1 = fr.kuz_ram(e).x50_mm
        e.factor_carga *= 1.5
        self.assertLess(fr.kuz_ram(e).x50_mm, x1)

    def test_ajuste_recupera_parametros(self):
        x = fr.tamices_log(5, 900, 14)
        p = fr.pasante_swebrec(x, 120.0, 1000.0, 2.2) * 100
        x50, xmax, b, r2 = fr.ajustar_swebrec(x, p)
        self.assertGreater(r2, 0.999)
        self.assertAlmostEqual(x50, 120.0, delta=3)
        x50r, n, r2r = fr.ajustar_rosin(x, fr.pasante_rosin(x, 80.0, 1.3) * 100)
        self.assertAlmostEqual(x50r, 80.0, places=3)
        self.assertAlmostEqual(n, 1.3, places=4)

    def test_factor_roca(self):
        r = fr.factor_roca("Masiva", "> tamaño de malla", "Rumbo perpendicular al frente", 2.7, 100, 50)
        self.assertGreater(r["A"], 0)


class ZonaDanio(unittest.TestCase):
    def test_presion_y_radio(self):
        pb = zd.presion_taladro_mpa(1.0, 4000)  # ρVOD²/8
        self.assertAlmostEqual(pb, 1000 * 4000 ** 2 / 8 / 1e6)
        desacoplado = zd.presion_taladro_mpa(1.0, 4000, 32, 38)
        self.assertAlmostEqual(desacoplado, pb * (32 / 38) ** 2.6)
        r = zd.radio_critico(0.02, 2000, 20)
        self.assertAlmostEqual(r, 0.02 * math.sqrt(100))

    def test_cobertura(self):
        t = [zd.TaladroPresion(0, 0, 0.02, 2000)]
        xs = ys = np.linspace(-1, 1, 101)
        cob = zd.cobertura(t, np.ones((101, 101), bool), xs, ys, 20)
        area_teo = math.pi * 0.2 ** 2 / 4.0
        self.assertAlmostEqual(cob, area_teo, delta=0.01)


class Dinamica(unittest.TestCase):
    def test_respuesta_estatica(self):
        # carga constante: desplazamiento estático u = −ag/ω², pico ≈ 2× con ξ = 0
        T = 0.5
        ag = np.full(4000, 1.0)
        r = dn.newmark_sdof(ag, 0.001, T, 0.0)
        w = 2 * math.pi / T
        self.assertAlmostEqual(np.max(np.abs(r.u)), 2 / w ** 2, delta=0.02 / w ** 2)

    def test_espectro_resonancia(self):
        dt, f = 0.002, 4.0
        t = np.arange(0, 6, dt)
        ag = np.sin(2 * math.pi * f * t)
        T, sd, sv, sa = dn.espectro(ag, dt, np.geomspace(0.05, 2, 60), 0.05)
        self.assertAlmostEqual(T[int(np.argmax(sa))], 1 / f, delta=0.03)

    def test_leer_csv(self):
        dt, a = dn.leer_registro_csv("t;a\n0;0\n0.01;0.1\n0.02;-0.1\n0.03;0\n")
        self.assertAlmostEqual(dt, 0.01)
        self.assertAlmostEqual(a[1], 0.1 * dn.G)


class Cimbra(unittest.TestCase):
    def test_equilibrio_vertical(self):
        e = cb.EntradaCimbra()
        r = cb.analizar(e)
        self.assertAlmostEqual(r.reacciones[:, 1].sum(), r.q * e.ancho, delta=1e-6 * r.q * e.ancho)
        self.assertAlmostEqual(r.hp, (100 - e.rmr) / 100 * e.ancho)
        self.assertGreater(r.n_max, 0)

    def test_perfil_mayor_menos_utilizacion(self):
        u = [cb.analizar(cb.EntradaCimbra(perfil=p)).utilizacion for p in ("W4x13", "W8x31")]
        self.assertGreater(u[0], u[1])


class Costos(unittest.TestCase):
    def test_costo_horario(self):
        e = co.Equipo("X", 100000, valor_residual_pct=20, neumaticos=0, vida_util_h=10000, anios=5, horas_anio=2000,
                      interes_pct=10, seguro_pct=2, factor_reparacion=0.8)
        c = e.costo_horario()
        self.assertAlmostEqual(c["Amortización"], 8.0)
        self.assertAlmostEqual(c["Interés y seguros"], 100000 * 6 / 10 * 0.12 / 2000)
        self.assertAlmostEqual(c["Reparaciones"], 8.0)

    def test_resumen(self):
        tareas, cat = co.ejemplo(30, 40, 70)
        r = co.resumen(tareas, cat, 2.0, 20.0, 54.0)
        self.assertAlmostEqual(r["por_m"], r["total"] / 2.0)
        self.assertAlmostEqual(sum(c["Total"] for _, c in r["filas"]), r["total"])


class Macizo(unittest.TestCase):
    def test_rmr_y_q(self):
        r = mz.rmr89(100, 75, 0.4, list(mz.CONDICION_JUNTAS)[1], "Completamente seco")
        self.assertEqual(r["RMR89"], 7 + 17 + 10 + 25 + 15)
        q = mz.q_barton(80, 9, 1.5, 2, 1, 1)
        self.assertAlmostEqual(q, 80 / 9 * 1.5 / 2)
        self.assertAlmostEqual(mz.q_desde_rmr(mz.rmr_desde_q(q)), q)

    def test_hoek_brown_intacta(self):
        hb = mz.hoek_brown(100, 15, 0)
        self.assertAlmostEqual(hb["mb"], 15)
        self.assertAlmostEqual(hb["s"], 1)
        self.assertAlmostEqual(hb["a"], 0.5, places=2)

    def test_soporte(self):
        self.assertAlmostEqual(mz.carga_unal(50, 4), 2.0)
        self.assertAlmostEqual(mz.longitud_perno(4, 1.6), 2 + 0.15 * 4 / 1.6)


class Burden(unittest.TestCase):
    def test_comparar(self):
        filas = bf.comparar(102, 10, 0.85, 2.7, 4000, 3500, 30, 6.9)
        self.assertEqual(len(filas), 9)  # + Pearse y Langefors
        for nombre, b, _ in filas:
            self.assertTrue(1.5 < b < 6.0, (nombre, b))
        self.assertAlmostEqual(bf.ash(102, 30), 30 * 102 / 25.4 / 12 * 0.3048)


class OpcionesMalla(unittest.TestCase):
    def test_siete_opciones(self):
        from app.biblioteca import estandar as est
        from app.biblioteca import opciones as opc
        from app.core.ejemplos import explosivos_referenciales
        exp = explosivos_referenciales()[2]
        d = opc.DatosFrente(ancho=3.5, alto=3.5, flecha=1.2, forma="Baúl (arco)", roca="Regular", rmr=None,
                            gsi=None, rqd=None, densidad_roca=2.7, diametro_mm=38, diametro_alivio_mm=64,
                            n_alivios=1, longitud=6 * est.PIE, explosivo=exp, explosivo_contorno=None,
                            largo_cartucho_m=0.2032, angulo_v=65, cuneta=True, cuneta_lado="izquierda",
                            cuneta_ancho=0.35, cuneta_profundidad=0.3)
        ops = opc.generar_opciones(d, est.cargar_biblioteca())
        self.assertEqual(len(ops), 8)  # 7 tipos de arranque + referencia Volcan
        for o in ops:
            if o.plano is None:
                continue
            r = o.resumen()
            self.assertGreater(r["cargados"], 10, o.nombre)
            self.assertGreater(r["kg"], 0, o.nombre)
            self.assertGreaterEqual(r["alivios"], 0)


if __name__ == "__main__":
    unittest.main()
