"""Pruebas de importación DXF y topografía (TIN, cota, perfil, pendientes)."""

import math
import tempfile
import unittest
from pathlib import Path

import numpy as np

from app.cad import dxf, topografia as topo

DXF_EJEMPLO = """0
SECTION
2
HEADER
9
$ACADVER
1
AC1015
9
$INSUNITS
70
4
0
ENDSEC
0
SECTION
2
TABLES
0
TABLE
2
LAYER
0
LAYER
2
CURVAS
62
3
0
ENDTAB
0
ENDSEC
0
SECTION
2
BLOCKS
0
BLOCK
2
MARCA
10
0
20
0
30
0
0
LINE
8
0
10
0
20
0
30
0
11
1000
21
0
31
0
0
ENDBLK
0
ENDSEC
0
SECTION
2
ENTITIES
0
LWPOLYLINE
8
CURVAS
38
2500
70
1
10
0
20
0
10
10000
20
0
10
10000
20
10000
0
LINE
8
EJES
10
0
20
0
30
0
11
5000
21
5000
31
1000
0
LWPOLYLINE
8
ARCOS
70
0
10
0
20
0
42
1
10
2000
20
0
0
3DFACE
8
TERRENO
10
0
20
0
30
0
11
1000
21
0
31
0
12
1000
22
1000
32
500
13
1000
23
1000
33
500
0
INSERT
8
SIMBOLOS
2
MARCA
10
5000
20
5000
30
0
41
2
50
90
0
HATCH
8
X
0
TEXT
8
COTAS
10
100
20
200
30
2510
1
2510
0
ENDSEC
0
EOF
"""


class TestDXF(unittest.TestCase):
    def setUp(self):
        self.d = dxf.leer_dxf_texto(DXF_EJEMPLO, "prueba.dxf")

    def test_encabezado_y_unidades(self):
        self.assertEqual(self.d.version, "AC1015")
        self.assertEqual(self.d.insunits, 4)
        self.assertEqual(self.d.unidad, ("Milímetros", 0.001))

    def test_capas_y_entidades(self):
        capas = self.d.capas()
        self.assertEqual(set(capas), {"CURVAS", "EJES", "ARCOS", "TERRENO", "SIMBOLOS", "COTAS"})
        self.assertEqual(self.d.ignoradas.get("HATCH"), 1)
        self.assertEqual(self.d.color_hex("CURVAS"), "#00ff00")

    def test_elevacion_de_lwpolyline(self):
        curva = next(e for e in self.d.entidades if e.capa == "CURVAS")
        self.assertTrue(curva.cerrada)
        self.assertTrue(all(p[2] == 2500 for p in curva.puntos))

    def test_bulge_semicirculo(self):
        arco = next(e for e in self.d.entidades if e.capa == "ARCOS")
        ys = [p[1] for p in arco.puntos]
        # bulge = 1 → semicírculo de radio 1000; antihorario de (0,0) a (2000,0) pasa por y = -1000
        self.assertAlmostEqual(min(ys), -1000, delta=15)
        for x, y, _ in arco.puntos:
            self.assertAlmostEqual(math.hypot(x - 1000, y), 1000, delta=1e-6)

    def test_insert_con_escala_y_rotacion(self):
        lin = next(e for e in self.d.entidades if e.capa == "SIMBOLOS")
        (x0, y0, _), (x1, y1, _) = lin.puntos
        self.assertAlmostEqual(x0, 5000); self.assertAlmostEqual(y0, 5000)
        self.assertAlmostEqual(x1, 5000, delta=1e-6); self.assertAlmostEqual(y1, 7000, delta=1e-6)

    def test_escalar_a_metros(self):
        self.d.escalar(0.001)
        ext = self.d.extension()
        self.assertAlmostEqual(ext[1], 10.0)
        self.assertAlmostEqual(ext[5], 2.51)

    def test_ida_y_vuelta_con_escritor(self):
        with tempfile.TemporaryDirectory() as dd:
            ruta = Path(dd) / "a.dxf"
            dxf.escribir_dxf(ruta, [("PERFIL", [(1, 2, 3), (4, 5, 6), (7, 8, 9.5)])])
            d = dxf.leer_dxf(ruta)
        self.assertEqual(len(d.entidades), 1)
        self.assertEqual(d.entidades[0].puntos[-1], (7.0, 8.0, 9.5))

    def test_texto_no_dxf(self):
        with self.assertRaises(dxf.ErrorDXF):
            dxf.leer_dxf_texto("hola\nmundo\n")


class TestTopografia(unittest.TestCase):
    def plano_inclinado(self):
        xs, ys = np.meshgrid(np.arange(0, 51, 5.0), np.arange(0, 31, 5.0))
        z = 100 + 0.2 * xs  # pendiente 20 % en X
        return np.c_[xs.ravel(), ys.ravel(), z.ravel()]

    def test_tin_cota_y_pendiente(self):
        t = topo.crear_tin(self.plano_inclinado())
        self.assertAlmostEqual(t.cota(12.5, 7.0), 102.5, places=6)
        self.assertIsNone(t.cota(-5, 0))
        self.assertTrue(np.allclose(t.pendientes(), math.degrees(math.atan(0.2))))
        self.assertAlmostEqual(t.area_planta(), 50 * 30)

    def test_perfil(self):
        t = topo.crear_tin(self.plano_inclinado())
        pf = topo.perfil(t, [(0, 15), (50, 15)], paso=1.0)
        r = pf.resumen()
        self.assertAlmostEqual(r["longitud"], 50)
        self.assertAlmostEqual(r["desnivel"], 10, places=6)
        self.assertAlmostEqual(r["pend_max_pct"], 20, places=6)

    def test_lado_maximo_descarta_triangulos_largos(self):
        p = self.plano_inclinado()
        p = np.vstack([p, [[500, 500, 100]]])
        t1 = topo.crear_tin(p)
        t2 = topo.crear_tin(p, lado_max=10)
        self.assertLess(t2.n_triangulos, t1.n_triangulos)

    def test_clasificacion_pendientes(self):
        c = topo.clasificar_pendientes(np.array([5, 30, 70.0]), 15, 45)
        self.assertEqual(list(c), [0, 1, 2])

    def test_medir(self):
        m = topo.medir((0, 0, 0), (3, 4, 12))
        self.assertAlmostEqual(m["distancia_3d"], 13)
        self.assertAlmostEqual(m["horizontal"], 5)
        self.assertAlmostEqual(m["azimut"], math.degrees(math.atan2(3, 4)))

    def test_errores(self):
        with self.assertRaises(topo.ErrorTopografia):
            topo.crear_tin([(0, 0, 0), (1, 1, 1)])
        with self.assertRaises(topo.ErrorTopografia):
            topo.crear_tin([(0, 0, 0), (1, 0, 1), (2, 0, 2), (3, 0, 0)])


if __name__ == "__main__":
    unittest.main()
