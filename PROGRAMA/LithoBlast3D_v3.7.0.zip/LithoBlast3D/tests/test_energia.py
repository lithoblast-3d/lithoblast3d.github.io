"""Pruebas del mapa de vibración (Holmberg–Persson). Ejecutar: python -m unittest discover -s tests -v"""

import unittest

import numpy as np

from app.calc.energia import ColumnaCarga, ppv_holmberg_persson, zonas


class PruebasEnergia(unittest.TestCase):
    def test_un_elemento_a_mano(self):
        # Columna de 1 m con 4 elementos: q = 10 kg/m. Punto a 5 m del centro, lateral.
        # Comparamos con la suma calculada a mano elemento por elemento.
        col = ColumnaCarga(inicio=(0, 0, 0.5), fin=(0, 0, -0.5), carga_lineal=10.0, radio=0.05)
        ppv = ppv_holmberg_persson(np.array([[5.0, 0, 0]]), [col], elementos_por_metro=4)[0]
        zs = [0.375, 0.125, -0.125, -0.375]
        suma = sum(10.0 * 0.25 / (np.hypot(5.0, z) ** (1.5 / 0.7)) for z in zs)
        self.assertAlmostEqual(ppv, 700 * suma**0.7, places=6)

    def test_disminuye_con_la_distancia(self):
        col = ColumnaCarga((0, 0, 0), (0, 0, -10), 17.1, 0.08)
        v = ppv_holmberg_persson(np.array([[1, 0, -5], [3, 0, -5], [10, 0, -5]]), [col])
        self.assertTrue(v[0] > v[1] > v[2] > 0)

    def test_suma_mayor_o_igual_que_maximo(self):
        cols = [ColumnaCarga((0, 0, 0), (0, 0, -10), 17.1, 0.08),
                ColumnaCarga((3, 0, 0), (3, 0, -10), 17.1, 0.08)]
        p = np.array([[1.5, 0, -5]])
        self.assertGreaterEqual(ppv_holmberg_persson(p, cols, modo="suma")[0],
                                ppv_holmberg_persson(p, cols, modo="maximo")[0])

    def test_zonas_bauer_calder(self):
        self.assertEqual(list(zonas(np.array([100, 300, 1000, 3000]))), [0, 1, 2, 3])

    def test_constantes_invalidas(self):
        with self.assertRaises(ValueError):
            ppv_holmberg_persson(np.zeros((1, 3)), [], k=0)


if __name__ == "__main__":
    unittest.main()
