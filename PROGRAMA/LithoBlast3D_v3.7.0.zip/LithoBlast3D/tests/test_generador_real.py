"""Pruebas de la malla automática a partir de las mallas reales del estándar."""

import math
import tempfile
import unittest
from pathlib import Path

import numpy as np

from app.biblioteca import estandar as est
from app.biblioteca import generador as gen

SIN_USUARIO = Path(tempfile.gettempdir()) / "no_existe_b3d.json"


class TestGeneradorReal(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.planos = est.cargar_biblioteca(ruta_usuario=SIN_USUARIO)

    def test_catalogo_de_arranques_del_pdf(self):
        cat = gen.catalogo_arranques(self.planos)
        self.assertEqual(set(cat), {"cruz5", "triangulo3", "rectangulo6"})
        self.assertEqual(cat["triangulo3"].rocas, ["Mala"])
        self.assertEqual(sorted(cat["rectangulo6"].paginas), [30, 32, 33])
        self.assertAlmostEqual(cat["cruz5"].sep_alivios, 0.125, delta=0.02)
        self.assertEqual(sum(len(t.paginas) for t in cat.values()), 54)

    def test_roca_desde_rmr(self):
        self.assertEqual(gen.roca_desde_rmr(70), "Buena")
        self.assertEqual(gen.roca_desde_rmr(50), "Regular")
        self.assertEqual(gen.roca_desde_rmr(30), "Mala")

    def test_misma_seccion_reproduce_el_plano(self):
        """Con la sección exacta de un plano, la malla generada se parece a la del plano."""
        r = gen.generar(gen.EntradaMallaReal(2.5, 2.5, "Buena", variante="Exa", cuneta=True), self.planos)
        self.assertEqual(r.plantilla.pagina, 13)
        self.assertEqual(len(r.plano.alivios()), 5)
        self.assertLessEqual(abs(len(r.plano.taladros) - len(r.plantilla.taladros)), 3)
        kg_t = next(f["valores"]["Expl_Kg"] for f in r.plantilla.explosivos_tabla if f["nombre"].startswith("Total"))
        kg_n = next(f["valores"]["Expl_Kg"] for f in r.plano.explosivos_tabla if f["nombre"].startswith("Total"))
        self.assertLess(abs(kg_n / kg_t - 1), 0.1)

    def test_arranque_copiado_con_medidas_reales(self):
        r = gen.generar(gen.EntradaMallaReal(3.3, 3.2, "Regular"), self.planos)
        al_t = np.array([[t.x, t.y] for t in r.plantilla.alivios()])
        al_n = np.array([[t.x, t.y] for t in r.plano.alivios()])
        rel_t = np.sort(np.linalg.norm(al_t - al_t.mean(0), axis=1))
        rel_n = np.sort(np.linalg.norm(al_n - al_n.mean(0), axis=1))
        self.assertTrue(np.allclose(rel_t, rel_n, atol=1e-3), "el arranque no se escala")

    def test_roca_mala_usa_triangulo(self):
        r = gen.generar(gen.EntradaMallaReal(2.4, 2.6, "Mala"), self.planos)
        self.assertEqual(r.arranque, "triangulo3")
        self.assertEqual(len(r.plano.alivios()), 3)

    def test_cuneta_a_la_derecha(self):
        r = gen.generar(gen.EntradaMallaReal(2.8, 3.0, "Regular", cuneta=True, cuneta_lado="derecha",
                                             cuneta_ancho=0.4, cuneta_profundidad=0.3), self.planos)
        cont = np.array(r.plano.contorno)
        self.assertAlmostEqual(cont[:, 1].min(), -0.3)
        bajo = cont[cont[:, 1] < -0.01]
        self.assertTrue(np.all(bajo[:, 0] > 1.4 - 0.4 - 1e-6))
        cun = [t for t in r.plano.taladros if t.y < -0.05]
        self.assertEqual(len(cun), 1)
        self.assertGreater(cun[0].x, 1.0)

    def test_sin_cuneta(self):
        r = gen.generar(gen.EntradaMallaReal(2.8, 3.0, "Regular", cuneta=False), self.planos)
        self.assertGreaterEqual(min(v[1] for v in r.plano.contorno), -1e-9)
        self.assertFalse([t for t in r.plano.taladros if t.y < -0.05])

    def test_seccion_grande_conserva_espaciamiento_y_cobertura(self):
        r = gen.generar(gen.EntradaMallaReal(4.5, 4.2, "Buena", cuneta=False), self.planos)
        filas = {f.concepto: f for f in r.informe}
        cob = filas["Cobertura (distancia máx. a un taladro cargado)"]
        self.assertLessEqual(float(cob.generado.split()[0]), float(cob.plantilla.split()[0]) * 1.1)
        self.assertGreater(len(r.plano.taladros), len(r.plantilla.taladros))
        # todos los taladros dentro de la sección
        poli = gen.recortar_sobre_piso(r.plano.contorno)
        def dist_borde(x, y):
            best = 9.0
            for (x1, y1), (x2, y2) in zip(poli, poli[1:] + poli[:1]):
                dx, dy = x2 - x1, y2 - y1
                L2 = dx * dx + dy * dy or 1e-12
                u = max(0.0, min(1.0, ((x - x1) * dx + (y - y1) * dy) / L2))
                best = min(best, math.hypot(x - x1 - u * dx, y - y1 - u * dy))
            return best
        for t in r.plano.taladros:
            self.assertTrue(gen._dentro(poli, t.x, t.y) or dist_borde(t.x, t.y) < 0.03, (t.x, t.y))

    def test_tablas_consistentes(self):
        r = gen.generar(gen.EntradaMallaReal(2.6, 2.8, "Regular", cuneta=True), self.planos)
        filas = est.verificar(r.plano)
        self.assertFalse([f for f in filas if f.coincide is False and not f.informativo])

    def test_conversion_al_proyecto(self):
        r = gen.generar(gen.EntradaMallaReal(2.6, 2.8, "Buena"), self.planos)
        ids = {n: n for n in r.plano.kg_por_cartucho()}
        pozos, _ = est.plano_a_pozos(r.plano, set(), 38, 38, 0, 0, 0, 0, ids, longitud_m=1.83)
        total = next(f["valores"]["Expl_Kg"] for f in r.plano.explosivos_tabla if f["nombre"].startswith("Total"))
        self.assertAlmostEqual(sum(p.kg_documento or 0 for p in pozos), total, delta=0.1)
        self.assertTrue(all("adaptada" in p.origen for p in pozos))


if __name__ == "__main__":
    unittest.main()
