"""Pruebas de la biblioteca de mallas del estándar (datos digitalizados y verificación)."""

import math
import tempfile
import unittest
from pathlib import Path

from app.biblioteca import estandar as est

SIN_USUARIO = Path(tempfile.gettempdir()) / "no_existe_b3d.json"


class TestBiblioteca(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.planos = est.cargar_biblioteca(ruta_usuario=SIN_USUARIO)

    def test_54_planos_y_6_secciones(self):
        self.assertEqual(len(self.planos), 54)
        self.assertEqual({p.seccion for p in self.planos}, set(est.SECCIONES))
        self.assertEqual(len(est.filtrar(self.planos, "2.50 x 2.50")), 12)
        self.assertEqual(len(est.filtrar(self.planos, "3.50 x 3.50")), 3)

    def test_todos_marcados_como_referencia_documental(self):
        for p in self.planos:
            self.assertEqual(p.estado, est.ESTADO_DOC)

    def test_plano_pagina_4_coincide_con_sus_tablas(self):
        p = next(x for x in self.planos if x.pagina == 4)
        self.assertEqual(len(p.taladros), 30)
        self.assertEqual(len(p.alivios()), 5)
        self.assertEqual(p.cuenta_detonadores, {1: 2, 8: 2, 16: 2, 40: 2, 56: 4, 72: 1, 92: 2, 120: 4, 140: 3,
                                                180: 1, 220: 2})
        ok, dif, rev = est.resumen_verificacion(p)
        self.assertEqual(dif, 0)
        self.assertEqual(rev, 0)
        self.assertEqual(p.parametros["perimetro_m"], 5.47)
        self.assertAlmostEqual(p.longitud_perforacion(), 6 * 0.3048)

    def test_verificacion_global(self):
        """53 de 54 planos coinciden con sus tablas; la pág. 55 tiene una diferencia propia del documento
        (el dibujo muestra 29 taladros naranjas y 27 amarillos; la tabla dice 27 y 28)."""
        con_dif = [p.pagina for p in self.planos if est.resumen_verificacion(p)[1] > 0]
        self.assertEqual(con_dif, [55])

    def test_escala_conserva_la_seccion(self):
        for p in self.planos:
            xs = [v[0] for v in p.contorno]
            ys = [v[1] for v in p.contorno]
            self.assertAlmostEqual(max(xs) - min(xs), p.ancho, delta=0.02, msg=p.pagina)
            self.assertAlmostEqual(max(ys), p.alto, delta=0.03, msg=p.pagina)

    def test_area_digitalizada_cercana_a_la_tabla(self):
        for p in self.planos:
            area = p.parametros["area_m2"]["sin_sobrerotura"]
            self.assertLess(abs(p.area_contorno() - area) / area, 0.08, p.pagina)

    def test_edicion_se_detecta_y_se_guarda_aparte(self):
        p = est.copia(next(x for x in self.planos if x.pagina == 13))
        p.cargados()[0].cartuchos += 3
        self.assertGreater(est.resumen_verificacion(p)[1], 0)
        with tempfile.TemporaryDirectory() as d:
            ru = Path(d) / "u.json"
            est.guardar_edicion(p, ru)
            otra = est.cargar_biblioteca(ruta_usuario=ru)
            self.assertTrue(next(x for x in otra if x.pagina == 13).editado)
            est.descartar_edicion(13, ru)
            self.assertFalse(next(x for x in est.cargar_biblioteca(ruta_usuario=ru) if x.pagina == 13).editado)

    def test_kg_por_cartucho_y_densidad_derivada(self):
        p = next(x for x in self.planos if x.pagina == 4)
        kgc = p.kg_por_cartucho()
        self.assertAlmostEqual(kgc['Emulnor 3000,1"x8"'], 12.2 / 111)
        ex = {e["nombre"]: e for e in est.explosivos_del_plano(p)}
        e = ex['Emulnor 3000,1"x8"']
        vol = math.pi / 4 * 0.0254 ** 2 * 8 * 0.0254
        self.assertAlmostEqual(e["densidad_gcc"], round(12.2 / 111 / vol / 1000, 3))

    def test_conversion_al_proyecto_reproduce_la_carga_del_plano(self):
        p = next(x for x in self.planos if x.pagina == 4)
        ids = {n: f"E{i}" for i, n in enumerate(p.kg_por_cartucho())}
        pozos, cont = est.plano_a_pozos(p, set(), 38, 64, 100, 200, 3000, 90, ids)
        self.assertEqual(len(pozos), 30)
        total = sum(q.kg_documento or 0 for q in pozos)
        self.assertAlmostEqual(total, 19.6, delta=0.05)
        # azimut 90° (Este): el frente queda en el plano Y–Z, avance hacia +X
        self.assertTrue(all(abs(q.x - 100) < 1e-9 for q in pozos))
        self.assertTrue(all(q.origen for q in pozos))
        fun = [q.funcion for q in pozos]
        self.assertEqual(fun.count("Alivio"), 5)


if __name__ == "__main__":
    unittest.main()
