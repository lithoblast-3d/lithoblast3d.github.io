"""Pruebas del diseño automático (valores resueltos a mano)."""

import math
import unittest

from app.calc import diseno_automatico as da
from app.calc.carga import ErrorDeDatos


class PruebasHolmberg(unittest.TestCase):
    def test_avance(self):
        # Dos alivios de 102 mm: φ2 = 0.102·√2 = 0.14425 m
        # L = 0.15 + 34.1·0.14425 − 39.4·0.14425² = 0.15 + 4.9189 − 0.8198 = 4.249 m
        phi2 = da.diametro_equivalente(0.102, 2)
        self.assertAlmostEqual(phi2, 0.14425, places=4)
        self.assertAlmostEqual(da.avance_maximo(phi2), 4.249, places=2)

    def test_primer_cuadro(self):
        # φ2 = 0.102 → B1 = 0.153 ; F = 0.01·3.5 + 0.02 = 0.055 ; A1 = √2·0.098 = 0.1386
        b1 = da.burden_primer_cuadro(0.102)
        f = da.error_perforacion(3.5, 0.01, 0.02)
        self.assertAlmostEqual(b1, 0.153)
        self.assertAlmostEqual(f, 0.055)
        self.assertAlmostEqual(da.abertura_primer_cuadro(b1, f), math.sqrt(2) * 0.098, places=6)

    def test_burden_cuadro(self):
        # A = 0.2 m, q = 1.27 kg/m, PRP = 1, d = 0.045 m, c = 0.4
        # B = 0.088·√(0.254 / 0.018) = 0.088·3.7565 = 0.3306 m
        self.assertAlmostEqual(da.burden_cuadro(0.2, 1.27, 1.0, 0.045, 0.4), 0.3306, places=3)

    def test_burden_holmberg_converge(self):
        b = da.burden_holmberg(1.27, 1.0, 1.45, 1.0, 0.4)
        # Debe cumplir la ecuación con el c̄ correspondiente a su propio B
        esperado = 0.9 * math.sqrt(1.27 / (da.c_barra(0.4, b) * 1.45))
        self.assertAlmostEqual(b, esperado, places=5)
        self.assertLess(b, 1.4)

    def test_contorno(self):
        s, b = da.contorno_recorte(0.045)
        self.assertAlmostEqual(s, 0.675)
        self.assertAlmostEqual(b, 0.84375)

    def test_error_si_desviacion_excesiva(self):
        with self.assertRaises(ErrorDeDatos):
            da.abertura_primer_cuadro(0.1, 0.2)


class PruebasKonya(unittest.TestCase):
    def test_burden_ejemplo_publicado(self):
        # De = 152.4 mm, SGe = 1.5, SGr = 2.5 → 0.012·(1.2 + 1.5)·152.4 = 4.938 m
        self.assertAlmostEqual(da.burden_konya(152.4, 1.5, 2.5), 4.938, places=3)

    def test_espaciamiento(self):
        self.assertAlmostEqual(da.espaciamiento_konya(10, 4, True), (10 + 28) / 8)
        self.assertAlmostEqual(da.espaciamiento_konya(20, 4, True), 5.6)
        self.assertAlmostEqual(da.espaciamiento_konya(10, 4, False), (10 + 8) / 3)
        self.assertAlmostEqual(da.espaciamiento_konya(20, 4, False), 8.0)

    def test_taco_y_sobreperforacion(self):
        self.assertAlmostEqual(da.taco_konya(4.0), 2.8)
        self.assertAlmostEqual(da.sobreperforacion_konya(4.0), 1.2)


class PruebasArticuloYilmaz2023(unittest.TestCase):
    """Números publicados en Yilmaz (2023), Sci. Rep. 13:2449."""

    def test_ec3_burden_practico(self):
        # Ec. 10: 1.7·0.076 − (0.02·2.85 + 0.02) = 0.05 m ; Ec. 11: 0.12 m (D0 = 115 mm)
        self.assertAlmostEqual(da.burden_primer_cuadro_practico(0.076, 2.85, 0.02, 0.02), 0.0522, places=3)
        self.assertAlmostEqual(da.burden_primer_cuadro_practico(0.115, 2.85, 0.02, 0.02), 0.1185, places=3)

    def test_ec8_y_ec7(self):
        # Ec. 12: qd = 7.854e-4·38²·1.5·0.8 = 1.36 kg/m ; Ec. 13: B = 30·1.36/38 = 1.07 m
        qb = da.carga_fondo(38, 1.5, 0.8)
        self.assertAlmostEqual(qb, 1.36, places=2)
        self.assertAlmostEqual(da.burden_frente(qb, 38), 1.07, places=2)

    def test_tabla4_desde_tabla2(self):
        b = da.burden_frente(da.carga_fondo(38, 1.5, 0.8), 38)  # 1.074 sin redondear
        self.assertAlmostEqual(da.TABLA_2["Ayuda (hacia arriba y horizontal)"][1] * b, 1.18, places=2)
        self.assertAlmostEqual(da.TABLA_2["Ayuda (hacia abajo)"][1] * b, 1.29, places=2)
        self.assertAlmostEqual(da.TABLA_2["Corona"][0] * b, 0.97, places=2)

    def test_ec4_burden_ajustado_por_carga(self):
        # El artículo obtiene burdens prácticos de 0.113 m (D0 76 mm) y 0.182 m (115 mm)
        # para dinamita gelatina (q = 1.20 kg/m, RWS = 1.20), dh = 38 mm, F = 0.077 m.
        # Con c = 0.45 (roca de la mina) la inversa de la Ec. 4 da valores muy próximos.
        f = 0.02 * 2.85 + 0.02
        b76 = da.burden_para_carga(1.20, 0.038, 0.076, 0.45, 1.20) - f
        b115 = da.burden_para_carga(1.20, 0.038, 0.115, 0.45, 1.20) - f
        self.assertAlmostEqual(b76, 0.113, delta=0.01)
        self.assertAlmostEqual(b115, 0.182, delta=0.015)

    def test_ec5_ec6(self):
        c = da.cuadros_arranque(0.113, 3)
        self.assertAlmostEqual(c[0][1], 0.160, places=3)  # Fig. 9: W1 = 160 mm
        self.assertAlmostEqual(c[1][0], 0.7 * 0.160, places=3)
        self.assertAlmostEqual(c[2][1], 0.462, places=3)  # Fig. 9: 462 mm

    def test_alivio_necesario(self):
        for h in (1.5, 2.85, 3.37, 4.0):
            self.assertAlmostEqual(da.perforacion_maxima(da.alivio_necesario(h)), h, places=6)

    def test_realce(self):
        self.assertAlmostEqual(da.realce_maximo(2.85), 0.1855)  # "about 19 cm"


if __name__ == "__main__":
    unittest.main()


class PruebasModelosBanco(unittest.TestCase):
    def test_ash(self):
        # Kb = 30, D = 4" → B = 30·4/12 = 10 pies = 3.048 m
        self.assertAlmostEqual(da.burden_ash(30, 101.6), 3.048, places=3)
        self.assertEqual(da.KB_ASH[da.clase_explosivo_ash(0.85)]["Dura"], 20)
        self.assertEqual(da.KB_ASH[da.clase_explosivo_ash(1.10)]["Media"], 30)

    def test_ash_modificado_ejemplo(self):
        # Ejemplo publicado: roca 73 lb/pie³ vs. referencia 160 lb/pie³, explosivo igual al de
        # referencia → Kb1 = 30·(160/73)^(1/3) ≈ 38.9 ; B = Kb1·4/12 ≈ 12.96 pies ≈ 3.95 m
        kb1 = da.kb_ash_corregido(30, 160, 73, 1.3, 1.3, 3657, 3657)
        self.assertAlmostEqual(kb1, 38.97, places=1)
        self.assertAlmostEqual(da.burden_ash(kb1, 101.6), 3.96, places=2)

    def test_pearse(self):
        # RQD 80 %, JSF 0.9 → ERQD 72 → K = 1.96 − 0.27·ln 72 = 0.8053
        k = da.factor_volabilidad_pearse(80, 0.9)
        self.assertAlmostEqual(k, 0.8053, places=4)
        # D = 6" (152.4 mm), P2/Std = 4000/10 → B = 0.8053·6/12·20 = 8.053 pies = 2.455 m
        self.assertAlmostEqual(da.burden_pearse(k, 152.4, 4000, 10), 2.4545, places=3)

    def test_presion_detonacion(self):
        # ANFO 0.8 g/cm³, 4000 m/s → 800·16e6/4 = 3200 MPa
        self.assertAlmostEqual(da.presion_detonacion_mpa(0.8, 4000), 3200.0)

    def test_langefors(self):
        b = da.burden_langefors(165, 0.8, 1.0, 0.4, 1.0, 1.25)
        # Debe cumplir la ecuación con su propio c̄ (≥ 1.4 m → c̄ = 0.45)
        self.assertAlmostEqual(b, 165 / 33 * math.sqrt(0.8 / (0.45 * 1.25)), places=6)
        self.assertAlmostEqual(da.burden_practico_langefors(b, 0.05, 0.03, 11), b - 0.05 - 0.33)
