"""Revisión de las mallas de cada opción: chimenea sin arrastres, corte en V solo donde es práctico,
referencia Volcan solo para secciones parecidas, carga escalonada en el corte de Ash y orden de salida."""

import unittest

from app.biblioteca import opciones as opc
from app.core.ejemplos import explosivos_referenciales

ORDEN = {"Arranque": 0, "Ayuda": 1, "Hastial": 2, "Contorno": 2, "Corona": 3, "Arrastre": 4}


def ops(**k):
    d = opc.DatosFrente(explosivo=explosivos_referenciales()[2], **k)
    return {o.clave: o for o in opc.generar_opciones(d, [])}


class MallasCorrectas(unittest.TestCase):
    def test_chimenea_sin_arrastres(self):
        for o in ops(ancho=1.5, alto=1.5, labor="chimenea").values():
            if o.plano is None:
                continue
            f = {t.funcion for t in o.plano.taladros}
            self.assertFalse(f & {"Arrastre", "Corona", "Hastial"}, (o.clave, f))
            per = [t for t in o.plano.taladros if t.funcion == "Contorno"]
            self.assertTrue(per)
            self.assertEqual(len({t.detonador for t in per}), 1)       # salen juntos, al final
            ult = max(t.detonador for t in o.plano.taladros if t.tipo == "cargado")
            self.assertEqual(per[0].detonador, ult)

    def test_chimenea_rectangular_sin_arco(self):
        """Aunque el formulario diga «Baúl (arco)», la chimenea se dibuja rectangular (techo en planta)."""
        for a, h in ((1.5, 1.5), (2.4, 1.5)):
            for o in ops(ancho=a, alto=h, labor="chimenea", forma="Baúl (arco)", flecha=0.8).values():
                if o.plano is None:
                    continue
                xs = sorted({round(p[0], 3) for p in o.plano.contorno})
                ys = sorted({round(p[1], 3) for p in o.plano.contorno})
                self.assertEqual(len(o.plano.contorno), 4, o.clave)
                self.assertEqual((xs, ys), ([-a / 2, a / 2], [0.0, h]), o.clave)

    def test_corte_v_solo_si_es_practico(self):
        self.assertTrue(ops(ancho=1.5, alto=1.5)["v"].error)
        self.assertFalse(ops(ancho=4.5, alto=4.0)["v"].error)

    def test_volcan_solo_secciones_parecidas(self):
        self.assertTrue(ops(ancho=3.0, alto=3.0)["ref_volcan"].error)
        self.assertFalse(ops(ancho=4.0, alto=4.0)["ref_volcan"].error)

    def test_orden_de_salida_por_funcion(self):
        for k, o in ops(ancho=3.5, alto=3.5).items():
            if o.plano is None or o.error or k == "ref_volcan":   # Volcan: datos reales de la mina, tal cual
                continue
            prom = {}
            for t in o.plano.taladros:
                if t.tipo == "cargado" and t.funcion in ORDEN:
                    prom.setdefault(t.funcion, []).append(t.detonador or 0)
            m = {f: sum(v) / len(v) for f, v in prom.items()}
            for f1 in m:
                for f2 in m:
                    if ORDEN[f1] < ORDEN[f2]:
                        self.assertLessEqual(m[f1], m[f2] + 1e-9, (k, f1, f2))

    def test_ash_carga_escalonada(self):
        o = ops(ancho=3.0, alto=3.0)["ash"]
        cuad = {}
        for t in o.plano.taladros:
            if t.lectura.startswith("cuadrante"):
                cuad.setdefault(int(t.lectura.split()[1]), t.cartuchos)
        self.assertLess(cuad[1], cuad[max(cuad)])

    def test_factor_de_carga_razonable(self):
        for (a, h) in ((3.0, 3.0), (4.5, 4.0)):
            for k, o in ops(ancho=a, alto=h).items():
                if o.plano is None or o.error:
                    continue
                fc = o.resumen().get("factor_carga") or 0
                self.assertTrue(1.0 < fc < 4.5, (a, h, k, fc))


if __name__ == "__main__":
    unittest.main()
