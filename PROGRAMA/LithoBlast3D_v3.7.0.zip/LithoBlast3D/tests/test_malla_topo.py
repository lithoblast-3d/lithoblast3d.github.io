"""Malla sobre topografía y exportación DXF."""

import math
import tempfile
import unittest
from pathlib import Path

import numpy as np

from app.cad import dxf, exportar as ex, malla_topografica as mt, topografia as topo
from app.core.ejemplos import crear_proyecto_vacio, explosivos_referenciales
from app.core.modelo import DisenoVoladura, Perforacion


def banco():
    """Plataforma a 3500 (y < 50) con cara de 15 m hacia el Norte."""
    pts = []
    for x in np.linspace(0, 100, 26):
        for y in np.linspace(0, 100, 41):
            z = 3500 if y < 50 else (3500 - 15 * (y - 50) / 5 if y < 55 else 3485)
            pts.append((x, y, z))
    return topo.crear_tin(np.array(pts))


class MallaTopo(unittest.TestCase):
    def setUp(self):
        self.tin = banco()
        self.pol = mt.rectangulo(50, 35, 40, 20, 90)

    def test_detecta_cara(self):
        az = mt.azimut_pendiente(self.tin, self.pol)
        self.assertIsNotNone(az)
        self.assertLess(min(az, 360 - az), 10)

    def test_malla(self):
        e = mt.EntradaMallaTopo(poligono=self.pol, burden=4, espaciamiento=5, azimut_salida=0, margen=1,
                                cota_piso=3485, sobreperforacion=1.2, taco=3, diametro_mm=165,
                                densidad_explosivo=0.85)
        r = mt.generar(e, self.tin)
        self.assertEqual(r.filas, 5)  # 20 m − 2 m de margen → filas cada 4 m
        for t in r.taladros:
            self.assertAlmostEqual(t.z, 3500, places=3)
            self.assertAlmostEqual(t.longitud, 16.2, places=2)
            q = math.pi / 4 * 0.165 ** 2 * 850
            self.assertAlmostEqual(t.carga_kg, q * (16.2 - 3), delta=0.02)
        primera = [t for t in r.taladros if t.fila == 1]
        self.assertTrue(all(abs(t.y - 44) < 1e-6 for t in primera), "1.ª fila a «margen» de la cara")
        self.assertTrue(all(t.retardo >= 1 for t in r.taladros))
        # tresbolillo: la fila 2 desplazada S/2 respecto de la 1
        x1 = sorted(t.x for t in primera)
        x2 = sorted(t.x for t in r.taladros if t.fila == 2)
        self.assertAlmostEqual(abs(x2[0] - x1[0]) % 5, 2.5, places=6)
        self.assertAlmostEqual(r.volumen_m3, len(r.taladros) * 4 * 5 * 15)

    def test_inclinado_y_altura_constante(self):
        e = mt.EntradaMallaTopo(poligono=self.pol, modo_piso=mt.MODOS_PISO[1], altura_banco=10,
                                sobreperforacion=1, inclinacion=75, azimut_salida=0)
        r = mt.generar(e, self.tin)
        self.assertAlmostEqual(r.taladros[0].longitud, 11 / math.sin(math.radians(75)), places=2)

    def test_fuera_del_tin(self):
        e = mt.EntradaMallaTopo(poligono=mt.rectangulo(100, 35, 40, 20, 90), cota_piso=3485)
        r = mt.generar(e, self.tin)
        self.assertTrue(r.avisos)


class AreaSobreTerreno(unittest.TestCase):
    def test_borde_apoyado_en_la_superficie(self):
        """El área no debe flotar: cada vértice del borde tiene la cota del terreno."""
        x = np.linspace(0, 60, 31)
        pts = [(a, b, 4200 + 0.2 * a + 0.1 * b) for a in x for b in x]  # terreno inclinado
        tin = topo.crear_tin(np.array(pts))
        borde = mt.poligono_sobre_terreno(tin, mt.rectangulo(30, 30, 30, 20, 90), 1.0)
        self.assertGreater(len(borde), 90)
        for bx, by, bz in borde:
            self.assertAlmostEqual(bz, 4200 + 0.2 * bx + 0.1 * by, places=4)
        g = mt.rejilla_terreno(tin, 10, 50, 10, 50, 9)
        self.assertEqual(len(g["z"]), 81)
        self.assertAlmostEqual(g["z"][0], 4200 + 0.2 * 10 + 0.1 * 10, places=2)


class ExportarDXF(unittest.TestCase):
    def test_ida_y_vuelta(self):
        pr = crear_proyecto_vacio("Exp", DisenoVoladura())
        pr.explosivos = explosivos_referenciales()
        pr.agregar_objeto(Perforacion(id="P-01", nombre="P-01", capa_id="perforaciones", x=10, y=20, z=3500,
                                      longitud=12, explosivo_id="EXP-01", taco=3, retardo=4))
        pr.agregar_objeto(Perforacion(id="P-02", nombre="P-02", capa_id="perforaciones", x=14, y=20, z=3500,
                                      longitud=12, inclinacion=70, azimut=0, explosivo_id=None))
        ruta = Path(tempfile.mkdtemp()) / "m.dxf"
        ex.exportar(pr, ruta)
        dib = dxf.leer_dxf(ruta)
        capas = {e.capa for e in dib.entidades}
        for c in ("COLLARES", "ALIVIOS", "TALADROS", "CARGA", "TXT_ID", "TXT_RETARDO", "LEYENDA"):
            self.assertIn(c, capas)
        textos = {e.texto for e in dib.entidades if e.tipo == "texto"}
        self.assertIn("P-01", textos)
        self.assertIn("4", textos)
        carga = [e for e in dib.entidades if e.capa == "CARGA"][0]
        self.assertAlmostEqual(carga.puntos[0][2], 3497.0, places=3)  # empieza bajo el taco
        self.assertAlmostEqual(carga.puntos[-1][2], 3488.0, places=3)
        texto = ruta.read_text(encoding="cp1252")
        self.assertIn("AC1009", texto)
        self.assertTrue(texto.rstrip().endswith("EOF"))


if __name__ == "__main__":
    unittest.main()
