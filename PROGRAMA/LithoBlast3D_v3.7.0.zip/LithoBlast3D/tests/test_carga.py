"""
Pruebas del motor de cálculo con ejemplos resueltos a mano.

Ejecutar (terminal PowerShell, con (.venv) activo, en C:\\Proyectos\\barreno3d):
    python -m unittest discover -s tests -v
"""

import math
import unittest

from app.calc import carga as c


class PruebasCarga(unittest.TestCase):
    def test_carga_lineal_granel(self):
        # Pozo 165 mm con explosivo de 0.80 g/cm³:
        # área = π/4 · 0.165² = 0.0213825 m² ; × 800 kg/m³ = 17.106 kg/m
        self.assertAlmostEqual(c.carga_lineal(165, 0.80), 17.106, places=3)

    def test_carga_lineal_formula_practica(self):
        # Comprobación con la forma práctica 0.000785 · ρ · d²
        d, rho = 32, 1.13
        self.assertAlmostEqual(c.carga_lineal(d, rho), 0.000785398 * rho * d**2, places=5)

    def test_longitud_de_carga(self):
        self.assertEqual(c.longitud_de_carga(11.0, 3.5), 7.5)
        self.assertEqual(c.longitud_de_carga(2.0, 3.0), 0.0)

    def test_factor_de_carga_tajo(self):
        # q = 17.1060 kg/m, Lc = 11 − 3.5 = 7.5 m → Q = 128.295 kg
        # V = 3.0 × 3.5 × 10 = 105 m³ → FC = 128.295 / 105 = 1.2219 kg/m³
        # T = 105 × 2.6 = 273 t → FP = 128.295 / 273 = 0.4699 kg/t
        q = c.carga_lineal(165, 0.80)
        q_pozo = c.carga_por_pozo(q, c.longitud_de_carga(11.0, 3.5))
        v = c.volumen_tajo(3.0, 3.5, 10.0)
        t = c.tonelaje(v, 2.6)
        self.assertAlmostEqual(q_pozo, 128.295, places=2)
        self.assertAlmostEqual(v, 105.0)
        self.assertAlmostEqual(c.factor_de_carga(q_pozo, v), 1.2219, places=4)
        self.assertAlmostEqual(c.factor_de_potencia(q_pozo, t), 0.4699, places=4)

    def test_subterraneo(self):
        # Sección 4 × 4 = 16 m², avance 3.2 m → 51.2 m³ ; con 120 kg → 2.34 kg/m³
        v = c.volumen_subterraneo(16.0, 3.2)
        self.assertAlmostEqual(v, 51.2)
        self.assertAlmostEqual(c.factor_de_carga(120.0, v), 2.34375)

    def test_datos_invalidos(self):
        with self.assertRaises(c.ErrorDeDatos):
            c.carga_lineal(0, 0.8)
        with self.assertRaises(c.ErrorDeDatos):
            c.volumen_tajo(3.0, -1, 10)
        with self.assertRaises(c.ErrorDeDatos):
            c.longitud_de_carga(10, -1)

    def test_area_circular(self):
        self.assertAlmostEqual(c.carga_lineal(1000, 1.0), math.pi / 4 * 1000, places=6)


if __name__ == "__main__":
    unittest.main()
