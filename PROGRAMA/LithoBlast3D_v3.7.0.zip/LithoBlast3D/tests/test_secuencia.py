"""Pruebas de la secuencia de salida y de la simulación."""

import unittest

from app.core.documento import Documento
from app.core.ejemplos import crear_ejemplo_tajo, crear_proyecto_vacio, explosivos_referenciales
from app.core.malla_auto import EntradaFrente, disenar_frente, frente_a_pozos
from app.core.modelo import Contorno, DisenoVoladura
from app.core.secuencia import preparar_simulacion, secuencia_banco, secuencia_frente

ORDEN = ["Arranque", "Ayuda", "Hastial", "Corona", "Arrastre"]


def _frente(ancho=3.0, alto=3.0):
    p = crear_proyecto_vacio("F", DisenoVoladura(escenario="subterraneo"))
    p.explosivos = explosivos_referenciales()
    e = EntradaFrente(ancho=ancho, alto=alto, flecha=0.6, forma="Esquinas redondeadas",
                      longitud=3.0, diametro_mm=45, diametro_alivio_mm=102)
    r = disenar_frente(e, p.explosivos[2])
    pozos, verts = frente_a_pozos(r, e, [], 0, 0, 0, 0, "EXP-03", "EXP-03")
    doc = Documento(p)
    doc.aplicar_lote([Contorno(id="S", nombre="s", capa_id="contornos", vertices=verts), *pozos])
    return p, doc


class PruebasSecuenciaFrente(unittest.TestCase):
    def test_orden_por_funcion(self):
        p, doc = _frente()
        doc.asignar_secuencia(secuencia_frente(p, 100))
        rango = {}
        for q in p.perforaciones():
            if q.funcion in ORDEN:
                lo, hi = rango.get(q.funcion, (99, 0))
                rango[q.funcion] = (min(lo, q.retardo), max(hi, q.retardo))
        for antes, despues in zip(ORDEN, ORDEN[1:]):
            self.assertLess(rango[antes][1], rango[despues][0], f"{antes} debe salir antes que {despues}")

    def test_alivio_sin_tiempo_y_tiempos(self):
        p, doc = _frente()
        doc.asignar_secuencia(secuencia_frente(p, 100))
        for q in p.perforaciones():
            if q.funcion == "Alivio":
                self.assertIsNone(q.tiempo_ms)
            else:
                self.assertAlmostEqual(q.tiempo_ms, q.retardo * 100)

    def test_primer_cuadro_uno_por_retardo(self):
        p, doc = _frente()
        doc.asignar_secuencia(secuencia_frente(p, 100))
        numeros = sorted(q.retardo for q in p.perforaciones() if q.retardo in (1, 2, 3, 4))
        self.assertEqual(numeros, [1, 2, 3, 4])

    def test_todos_con_abertura_y_deshacer(self):
        p, doc = _frente(4.5, 4.5)
        doc.asignar_secuencia(secuencia_frente(p, 100))
        sim = preparar_simulacion(p)
        self.assertFalse(any(q.sin_cara_libre for q in sim.pozos))
        self.assertEqual(sim.sin_tiempo, 0)
        doc.deshacer()
        self.assertTrue(all(q.tiempo_ms is None for q in p.perforaciones()))

    def test_estado_en_el_tiempo(self):
        p, doc = _frente()
        doc.asignar_secuencia(secuencia_frente(p, 100))
        sim = preparar_simulacion(p)
        antes = [e for _p, e in sim.estado(-1) if e != "alivio"]
        despues = [e for _p, e in sim.estado(sim.duracion + 1000) if e != "alivio"]
        self.assertTrue(all(e == "pendiente" for e in antes))
        self.assertTrue(all(e == "detonado" for e in despues))
        kg = sum(q.carga_kg for q in sim.pozos)
        self.assertAlmostEqual(sum(r[3] for r in sim.retardos), kg, places=6)


class PruebasSecuenciaBanco(unittest.TestCase):
    def test_filas_y_tiempos(self):
        t = crear_ejemplo_tajo()
        sec = secuencia_banco(t, 25, 50)
        # 3 filas × 6 taladros: la primera fila sale en 0, 25, …, 125 ms
        primera = sorted(v[1] for v in sec.values() if v[1] is not None)[:6]
        self.assertEqual(primera[0], 0)
        tiempos = sorted({v[1] for v in sec.values()})
        self.assertEqual(max(tiempos), 2 * 50 + 5 * 25)

    def test_en_v_mas_corto(self):
        t = crear_ejemplo_tajo()
        linea = max(v[1] for v in secuencia_banco(t, 25, 50).values())
        en_v = max(v[1] for v in secuencia_banco(t, 25, 50, en_v=True).values())
        self.assertLess(en_v, linea)


if __name__ == "__main__":
    unittest.main()
