# Publicar LithoBlast3D en internet (gratis, con GitHub)

Resultado: una página como `https://TU-USUARIO.github.io/barreno3d` con el botón
«Descargar», que siempre baja la última versión del instalador.
En GitHub subes SOLO la página (carpeta `web`) y el instalador. El código fuente
queda en tu PC.

## A. Crear el instalador (en tu PC)
1. Instala Inno Setup 7 (gratis): https://jrsoftware.org/isdl.php
2. En VS Code, terminal PowerShell, con `(.venv)` activo:
       cd C:\Proyectos\barreno3d
       .\empaquetar\crear_ejecutable.ps1 -Instalador
   (si dice que los scripts están deshabilitados, ejecuta una vez:
    `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`)
3. Tarda varios minutos. Al final tendrás en `empaquetar\salida\`:
   - `LithoBlast3D-VERSIÓN-instalador.exe`  ← el que se publica
   - `LithoBlast3D-VERSIÓN-windows.zip`     (versión portátil, sin instalar)
4. Pruébalo antes de publicar: `empaquetar\dist\LithoBlast3D\LithoBlast3D.exe`.
   Si algo falla, el detalle queda en `C:\Users\TU-USUARIO\.barreno3d\registro.txt`.

## B. Crear el repositorio y la página
1. Crea una cuenta en https://github.com (gratis).
2. Botón **New** (nuevo repositorio) → nombre `barreno3d` → **Public** → Create.
3. En el repositorio: **Add file → Upload files** y arrastra el CONTENIDO de la carpeta `web`
   (`index.html` y la carpeta `img`). **Commit changes**.
4. **Settings → Pages** → Source: *Deploy from a branch* → Branch: `main`, carpeta `/ (root)` → Save.
   En 1–2 minutos la página está en `https://TU-USUARIO.github.io/barreno3d`.
5. Edita `index.html` en GitHub (ícono del lápiz) y cambia la línea
       const REPO = "TU-USUARIO/barreno3d";
   por tu usuario real. Commit.

## C. Publicar el instalador (cada versión nueva)
1. En el repositorio: **Releases → Create a new release**.
2. **Choose a tag** → escribe `v3.6.1` (la versión que dice el título del programa) → *Create new tag*.
3. Título: `LithoBlast3D 3.6.1`. En la descripción pon las novedades.
4. Arrastra `LithoBlast3D-VERSIÓN-instalador.exe` (y si quieres el .zip) a la zona de archivos.
5. **Publish release**.
El botón de la página detecta solo la última versión: para actualizar, solo crea otro release.

## Notas
- Windows SmartScreen avisará «Windows protegió su PC» porque el instalador no tiene firma
  comercial (cuesta un certificado de firma de código). Los usuarios pulsan
  «Más información → Ejecutar de todas formas». Con descargas, el aviso disminuye.
- El instalador incluye el programa completo, igual al que usas, con la biblioteca de mallas
  del estándar. Esas mallas vienen del documento de una empresa: si no tienes permiso para
  difundirlas, crea el instalador con `-Publica` (todo igual, sin la biblioteca del estándar).
- Las capturas de `web/img` son gráficos del programa; puedes cambiarlas por capturas de
  pantalla tuyas (Win + Shift + S) con el mismo nombre.
- Dominio propio (opcional): compras `barreno3d.com` y en Settings → Pages → Custom domain lo indicas.

## Actualizar una versión que ya está publicada
- Desde la versión 3.6.2 `index.html` detecta solo tu usuario y repositorio a partir de la dirección
  (usuario.github.io/repositorio): puedes subirlo sin editar la línea `const REPO`.

## D. Versión para celular (Android / iPhone)
La carpeta `web\app` es la app móvil. Se publica junto con la página:
1. En GitHub, en tu repositorio: **Add file → Upload files**.
2. Arrastra la carpeta **app** completa (la que está dentro de `C:\Proyectos\barreno3d\web\`).
3. **Commit changes**. En 1–2 minutos queda en `https://TU-USUARIO.github.io/barreno3d/app/`.
4. Sube también el `index.html` nuevo de `web\` (tiene el botón «Usar en el celular»).

En el teléfono: abre la dirección → pestaña **Más → Instalar app**
(Android: menú ⋮ de Chrome → Instalar aplicación · iPhone: Safari → Compartir → Agregar a pantalla de inicio).
La primera vez descarga el motor de cálculo (unos 15–25 MB); luego funciona sin internet.

Si cambias el cálculo del programa, vuelve a generar el motor de la app:
    python tools/web/construir_movil.py
y sube de nuevo `web\app\nucleo.zip`.
