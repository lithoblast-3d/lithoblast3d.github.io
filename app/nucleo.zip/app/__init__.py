"""LithoBlast3D: software de escritorio para geometría minera 2D/3D."""

NOMBRE_APP = "LithoBlast3D"
VERSION = "3.7.0"
