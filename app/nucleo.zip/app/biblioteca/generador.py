"""
Malla automática a partir de las MALLAS REALES del estándar (no de fórmulas).

Datos de entrada: ancho y alto de la sección, tipo de roca (o RMR), diámetros de
perforación y de alivio, longitud de perforación, tipo de arranque y cuneta.

Procedimiento (todo trazable a un plano del estándar):
1. Plantilla: el plano del estándar con la MISMA calidad de roca y la sección más parecida.
2. Arranque: se copia TAL CUAL (medidas reales en metros, sin escalar) del plano plantilla,
   o del tipo de arranque elegido (catálogo medido en los 54 planos). Su altura sobre el
   piso se escala con el alto de la sección.
3. Perímetro (hastiales y corona) y arrastres: se redistribuyen sobre el contorno nuevo con
   el MISMO espaciamiento (m) que tiene el plano plantilla.
4. Ayudas: se trasladan proporcionalmente entre el arranque y el perímetro (anillos), y
   luego se completan o se depuran para conservar la misma cobertura (distancia máxima de
   cualquier punto del frente a un taladro cargado) que tiene la plantilla.
5. Cada taladro hereda N.º de retardo, cartuchos y explosivo de su taladro de origen en la
   plantilla; la carga = cartuchos × kg/cartucho (+ ANFO) de la tabla del plano.
6. Cuneta opcional (lado, ancho, profundidad) con su taladro, como en los planos.

Resultado: «Adaptado del estándar (no validado)». Es un punto de partida trazable, NO un
diseño probado en tu mina: ajústalo con los resultados de campo. Las comprobaciones teóricas (Holmberg) se
muestran como referencia.
"""

from __future__ import annotations

import copy
import math
from dataclasses import dataclass, field

import numpy as np

from app.biblioteca import estandar as est

ROCA_POR_RMR = [(61, "Buena"), (41, "Regular"), (0, "Mala")]  # títulos de los planos: 61-80, 41-60, 21-40


def roca_desde_rmr(rmr: float) -> str:
    for lim, nombre in ROCA_POR_RMR:
        if rmr >= lim:
            return nombre
    return "Mala"


# =========================================================================== geometría
def _area(poli) -> float:
    p = np.asarray(poli, float)
    return 0.5 * abs(np.dot(p[:, 0], np.roll(p[:, 1], 1)) - np.dot(p[:, 1], np.roll(p[:, 0], 1)))


def _orientar_antihorario(poli):
    p = [tuple(v) for v in poli]
    s = sum(x1 * y2 - x2 * y1 for (x1, y1), (x2, y2) in zip(p, p[1:] + p[:1]))
    return p if s > 0 else p[::-1]


def recortar_sobre_piso(poli, y0: float = 0.0):
    """Sutherland–Hodgman con el semiplano y ≥ y0 (quita la cuneta del contorno)."""
    salida = []
    p = list(poli)
    for i in range(len(p)):
        a, b = p[i - 1], p[i]
        da, db = a[1] - y0, b[1] - y0
        if db >= 0:
            if da < 0:
                t = da / (da - db)
                salida.append((a[0] + t * (b[0] - a[0]), y0))
            salida.append(tuple(b))
        elif da >= 0:
            t = da / (da - db)
            salida.append((a[0] + t * (b[0] - a[0]), y0))
    # quitar duplicados consecutivos
    limpio = []
    for q in salida:
        if not limpio or math.dist(q, limpio[-1]) > 1e-6:
            limpio.append(q)
    return _orientar_antihorario(limpio)


def contorno_limpio(poli, ancho: float, n: int = 81):
    """Contorno sin el «ruido» de la digitalización: hastiales verticales y techo como envolvente
    superior suavizada y simétrica de la sección del plano (misma forma, sin bultos)."""
    p = list(poli)
    xs = np.linspace(-ancho / 2, ancho / 2, n)
    xs[0] += 1e-4; xs[-1] -= 1e-4
    ys = []
    for x in xs:
        cortes = []
        for i in range(len(p)):
            (x1, y1), (x2, y2) = p[i - 1], p[i]
            if (x1 - x) * (x2 - x) <= 0 and x1 != x2:
                cortes.append(y1 + (x - x1) * (y2 - y1) / (x2 - x1))
        ys.append(max(cortes) if cortes else 0.0)
    y = np.array(ys)
    # mediana móvil (quita bultos de los círculos de los taladros) + media móvil + simetría
    k = 3
    med = np.array([np.median(y[max(0, i - k):i + k + 1]) for i in range(n)])
    suave = np.array([med[max(0, i - 2):i + 3].mean() for i in range(n)])
    suave = (suave + suave[::-1]) / 2
    suave[0] = suave[-1] = (suave[0] + suave[1]) / 2 if n > 2 else suave[0]
    xs[0], xs[-1] = -ancho / 2, ancho / 2
    from app.sim3d.datos import casco_convexo  # casco convexo: techo sin entrantes
    pts = [(-ancho / 2, 0.0), (ancho / 2, 0.0)] + [(float(x), float(v)) for x, v in zip(xs, suave)]
    return _orientar_antihorario(casco_convexo(pts))


def camino_perimetral(poli, ancho: float):
    """Polilínea del hastial izquierdo → corona → hastial derecho (sin el piso).
    Devuelve (puntos, longitudes acumuladas)."""
    p = _orientar_antihorario(poli)
    n = len(p)
    i_der = min(range(n), key=lambda k: math.dist(p[k], (ancho / 2, 0.0)))
    i_izq = min(range(n), key=lambda k: math.dist(p[k], (-ancho / 2, 0.0)))
    # en sentido antihorario: esquina derecha → sube → corona → baja → esquina izquierda
    pts = []
    k = i_der
    while True:
        pts.append(p[k])
        if k == i_izq:
            break
        k = (k + 1) % n
    pts = pts[::-1]  # izquierda → derecha
    acum = [0.0]
    for a, b in zip(pts, pts[1:]):
        acum.append(acum[-1] + math.dist(a, b))
    return pts, acum


def punto_en_camino(pts, acum, s):
    s = min(max(s, 0.0), acum[-1])
    for i in range(len(acum) - 1):
        if acum[i] <= s <= acum[i + 1]:
            L = acum[i + 1] - acum[i] or 1.0
            t = (s - acum[i]) / L
            return (pts[i][0] + t * (pts[i + 1][0] - pts[i][0]), pts[i][1] + t * (pts[i + 1][1] - pts[i][1]))
    return pts[-1]


def proyectar_en_camino(pts, acum, q):
    best = (1e9, 0.0)
    for i in range(len(pts) - 1):
        a, b = np.array(pts[i]), np.array(pts[i + 1])
        d = b - a
        L2 = float(d @ d) or 1e-12
        t = max(0.0, min(1.0, float((np.array(q) - a) @ d) / L2))
        dist = float(np.linalg.norm(a + t * d - np.array(q)))
        if dist < best[0]:
            best = (dist, acum[i] + t * math.sqrt(L2))
    return best[1]


def distancia_rayo(poli, c, ang) -> float:
    """Distancia desde c hasta el contorno en la dirección «ang»."""
    d = np.array([math.cos(ang), math.sin(ang)])
    c = np.asarray(c, float)
    mejor = 1e9
    p = list(poli)
    for i in range(len(p)):
        a, b = np.array(p[i - 1], float), np.array(p[i], float)
        e = b - a
        M = np.array([[d[0], -e[0]], [d[1], -e[1]]])
        det = np.linalg.det(M)
        if abs(det) < 1e-12:
            continue
        t, u = np.linalg.solve(M, a - c)
        if t > 1e-9 and -1e-9 <= u <= 1 + 1e-9:
            mejor = min(mejor, t)
    return mejor


def _dentro(poli, x, y) -> bool:
    dentro = False
    p = list(poli)
    for i in range(len(p)):
        (x1, y1), (x2, y2) = p[i - 1], p[i]
        if (y1 > y) != (y2 > y) and x < x1 + (y - y1) * (x2 - x1) / (y2 - y1):
            dentro = not dentro
    return dentro


def cobertura(poli, puntos, paso=0.06):
    """(distancia máxima de un punto del frente al taladro cargado más cercano, punto)."""
    p = np.asarray(poli, float)
    xs = np.arange(p[:, 0].min() + paso / 2, p[:, 0].max(), paso)
    ys = np.arange(p[:, 1].min() + paso / 2, p[:, 1].max(), paso)
    g = np.array([(x, y) for x in xs for y in ys if _dentro(poli, x, y)])
    if not len(g) or not len(puntos):
        return 0.0, None
    q = np.asarray(puntos, float)
    d = np.min(np.linalg.norm(g[:, None, :] - q[None, :, :], axis=2), axis=1)
    k = int(np.argmax(d))
    return float(d[k]), tuple(g[k])


# =========================================================================== catálogo de arranques
@dataclass
class TipoArranque:
    clave: str
    nombre: str
    descripcion: str
    paginas: list[int] = field(default_factory=list)
    rocas: list[str] = field(default_factory=list)
    sep_alivios: float = 0.0  # m, del alivio central a los periféricos (mediana)
    burden1: float = 0.0  # m, del centro del arranque al primer taladro cargado (mediana)
    n_alivios: int = 0
    n_cargados: int = 0  # taladros cargados del arranque


def _firma_arranque(p: est.PlanoRef) -> str:
    n = len(p.alivios())
    return {5: "cruz5", 3: "triangulo3", 6: "rectangulo6"}.get(n, f"alivios{n}")


NOMBRES_ARRANQUE = {
    "cruz5": ("Cruz de 5 alivios",
              "Un alivio central y cuatro a su alrededor (en cruz); 4 taladros cargados a 45° forman el "
              "primer cuadro y otros 4 el segundo."),
    "triangulo3": ("Triángulo de 3 alivios",
                   "Tres alivios en triángulo; 3 taladros cargados enfrentados a cada lado, luego el 2.º cuadro."),
    "rectangulo6": ("Rectángulo de 6 alivios",
                    "Seis alivios en 2 filas × 3 columnas; taladros cargados entre ellos (planos con ANFO)."),
}


def catalogo_arranques(planos: list[est.PlanoRef]) -> dict[str, TipoArranque]:
    grupos: dict[str, list[est.PlanoRef]] = {}
    for p in planos:
        grupos.setdefault(_firma_arranque(p), []).append(p)
    res = {}
    for clave, ps in grupos.items():
        seps, b1, ncar = [], [], []
        for p in ps:
            al = np.array([[t.x, t.y] for t in p.alivios()])
            c = al.mean(0)
            d = np.linalg.norm(al - c, axis=1)
            seps.append(float(np.median(d[d > 0.03])) if np.any(d > 0.03) else 0.0)
            dist = sorted(math.hypot(t.x - c[0], t.y - c[1]) for t in p.cargados())
            b1.append(dist[0] if dist else 0.0)
            ncar.append(sum(1 for f in est.clasificar(p) if f == "Arranque"))
        nombre, desc = NOMBRES_ARRANQUE.get(clave, (clave, ""))
        res[clave] = TipoArranque(clave, nombre, desc, [p.pagina for p in ps], sorted({p.roca for p in ps}),
                                  round(float(np.median(seps)), 3), round(float(np.median(b1)), 3),
                                  len(ps[0].alivios()), int(np.median(ncar)))
    return res


# =========================================================================== entrada / salida
@dataclass
class EntradaMallaReal:
    ancho: float
    alto: float
    roca: str = "Regular"  # Buena / Regular / Mala
    diametro_mm: float = 38.0
    diametro_alivio_mm: float = 38.0
    longitud_pies: float = 6.0
    arranque: str = "auto"  # "auto" o clave del catálogo
    variante: str = "auto"  # texto de la variante del plano (Exa, Fan, Emul.Fan…) o "auto"
    cuneta: bool = False
    cuneta_lado: str = "izquierda"
    cuneta_ancho: float = 0.35
    cuneta_profundidad: float = 0.30


@dataclass
class FilaInforme:
    concepto: str
    plantilla: str
    generado: str
    nota: str = ""
    aviso: bool = False


@dataclass
class ResultadoMallaReal:
    plano: est.PlanoRef
    plantilla: est.PlanoRef
    arranque: str
    informe: list[FilaInforme]
    avisos: list[str]


def elegir_plantilla(planos, e: EntradaMallaReal) -> est.PlanoRef:
    cand = [p for p in planos if p.roca == e.roca] or list(planos)
    if e.variante != "auto":
        con_var = [p for p in cand if p.variante == e.variante]
        cand = con_var or cand
    # preferir iniciación no eléctrica (la numeración de retardos se puede heredar)
    def costo(p):
        return (abs(math.log(p.ancho / e.ancho)) + abs(math.log(p.alto / e.alto)),
                p.iniciacion == "electrónica", est.resumen_verificacion(p)[1] > 0, p.pagina)
    return min(cand, key=costo)


def variantes_disponibles(planos, roca: str) -> list[str]:
    return sorted({p.variante for p in planos if p.roca == roca})


# =========================================================================== generador
def generar(e: EntradaMallaReal, planos: list[est.PlanoRef] | None = None) -> ResultadoMallaReal:
    planos = planos or est.cargar_biblioteca()
    if e.ancho <= 0.8 or e.alto <= 1.2:
        raise ValueError("La sección es demasiado pequeña (mínimo 0.8 m de ancho y 1.2 m de alto).")
    tpl = elegir_plantilla(planos, e)
    avisos: list[str] = []
    funciones = est.clasificar(tpl)
    poli_t = contorno_limpio(recortar_sobre_piso(tpl.contorno), tpl.ancho)
    sx, sy = e.ancho / tpl.ancho, e.alto / tpl.alto
    poli_n = _orientar_antihorario([(x * sx, y * sy) for x, y in poli_t])

    tal_t = list(zip(tpl.taladros, funciones))
    al_t = [t for t, f in tal_t if f == "Alivio"]
    c_t = np.array([np.mean([t.x for t in al_t]), np.mean([t.y for t in al_t])]) if al_t \
        else np.array([0.0, tpl.alto * 0.4])
    c_n = np.array([0.0, c_t[1] * sy])

    # ---------------------------------------------------- arranque (medidas reales, sin escalar)
    origen_arranque = tpl
    clave_arr = _firma_arranque(tpl)
    if e.arranque not in ("auto", clave_arr):
        otros = [p for p in planos if _firma_arranque(p) == e.arranque]
        if not otros:
            raise ValueError(f"No hay planos con el arranque «{e.arranque}».")
        otros.sort(key=lambda p: (p.roca != e.roca, abs(p.ancho - e.ancho) + abs(p.alto - e.alto), p.pagina))
        origen_arranque = otros[0]
        clave_arr = e.arranque
        if origen_arranque.roca != e.roca:
            avisos.append(f"El arranque elegido se tomó de un plano de roca {origen_arranque.roca} "
                          f"(pág. {origen_arranque.pagina}); el estándar no lo usa en roca {e.roca}.")
    f_arr = est.clasificar(origen_arranque)
    al_o = [t for t in origen_arranque.alivios()]
    c_o = np.array([np.mean([t.x for t in al_o]), np.mean([t.y for t in al_o])])
    nuevos: list[est.TaladroRef] = []

    def copia_de(t: est.TaladroRef, x, y, lectura):
        n = copy.copy(t)
        n.x, n.y = round(float(x), 3), round(float(y), 3)
        n.px = []
        n.ocr = ""
        n.lectura = lectura
        return n

    for t, f in zip(origen_arranque.taladros, f_arr):
        if f in ("Alivio", "Arranque"):
            nuevos.append(copia_de(t, c_n[0] + t.x - c_o[0], c_n[1] + t.y - c_o[1],
                                   f"arranque copiado del plano pág. {origen_arranque.pagina}"))
    if origen_arranque is not tpl:
        # el arranque viene de otro plano: sus retardos y explosivos se adaptan a la plantilla
        dets_t = sorted(t.detonador for t, f in tal_t if f == "Arranque" and t.detonador is not None) or [1]
        exp_t = [t.explosivo for t, f in tal_t if f == "Arranque" and t.explosivo]
        exp_t = max(set(exp_t), key=exp_t.count) if exp_t else None
        kg_t = tpl.kg_por_cartucho()
        carg = sorted([t for t in nuevos if t.tipo == "cargado"], key=lambda t: (t.detonador or 0))
        for k, t in enumerate(carg):
            t.detonador = dets_t[min(k * len(dets_t) // max(len(carg), 1), len(dets_t) - 1)]
            if t.explosivo not in kg_t and exp_t:
                t.explosivo = exp_t
            if t.anfo_kg and not any("anfo" in c.lower() for f in tpl.explosivos_tabla for c in f["valores"]):
                t.anfo_kg = 0.0
    radio_arr = max(math.hypot(t.x - c_n[0], t.y - c_n[1]) for t in nuevos)

    # ---------------------------------------------------- perímetro (hastiales + corona)
    pts_t, ac_t = camino_perimetral(poli_t, tpl.ancho)
    pts_n, ac_n = camino_perimetral(poli_n, e.ancho)
    per_t = [(t, proyectar_en_camino(pts_t, ac_t, (t.x, t.y))) for t, f in tal_t if f in ("Contorno", "Corona")]
    per_t.sort(key=lambda a: a[1])
    esp_per = ac_t[-1] / (len(per_t) + 1) if per_t else 0.6
    n_per = max(1, round(ac_n[-1] / esp_per) - 1)
    for k in range(1, n_per + 1):
        s = ac_n[-1] * k / (n_per + 1)
        x, y = punto_en_camino(pts_n, ac_n, s)
        frac = s / ac_n[-1]
        if not per_t:
            continue
        fuente = min(per_t, key=lambda a: abs(a[1] / ac_t[-1] - frac))[0]
        if fuente.revisar:  # lectura dudosa: usar el taladro simétrico del plano si está bien leído
            espejo = min(per_t, key=lambda a: abs(a[1] / ac_t[-1] - (1 - frac)))[0]
            if not espejo.revisar:
                fuente = espejo
        nuevos.append(copia_de(fuente, x, y, f"perímetro: espaciamiento {esp_per:.2f} m del plano pág. {tpl.pagina}"))

    # ---------------------------------------------------- arrastres
    arr_t = sorted([t for t, f in tal_t if f == "Arrastre" and t.y > -0.05], key=lambda t: t.x)
    if len(arr_t) >= 2:
        esp_arr = (arr_t[-1].x - arr_t[0].x) / (len(arr_t) - 1)
        margen = (tpl.ancho / 2 - arr_t[-1].x + arr_t[0].x + tpl.ancho / 2) / 2
        x0, x1 = -e.ancho / 2 + margen, e.ancho / 2 - margen
        n_arr = max(2, round((x1 - x0) / esp_arr) + 1)
        for k in range(n_arr):
            x = x0 + (x1 - x0) * k / (n_arr - 1)
            frac = k / (n_arr - 1)
            fuente = min(arr_t, key=lambda t: abs((t.x - arr_t[0].x) / ((arr_t[-1].x - arr_t[0].x) or 1) - frac))
            nuevos.append(copia_de(fuente, x, fuente.y, f"arrastre: espaciamiento {esp_arr:.2f} m del plano"))
    else:
        esp_arr = 0.6

    # ---------------------------------------------------- ayudas (anillos entre arranque y perímetro)
    radio_arr_t = max(math.hypot(t.x - c_t[0], t.y - c_t[1]) for t, f in tal_t if f in ("Alivio", "Arranque"))
    ayudas_t = [t for t, f in tal_t if f == "Ayuda"]
    for t in ayudas_t:
        v = np.array([t.x, t.y]) - c_t
        r = float(np.linalg.norm(v))
        ang = math.atan2(v[1], v[0])
        R_t = distancia_rayo(poli_t, c_t, ang)
        R_n = distancia_rayo(poli_n, c_n, ang)
        rel = (r - radio_arr_t) / max(R_t - radio_arr_t, 1e-6)
        r_n = radio_arr + rel * max(R_n - radio_arr, 0.0)
        x, y = c_n + r_n * np.array([math.cos(ang), math.sin(ang)])
        if _dentro(poli_n, x, y):
            nuevos.append(copia_de(t, x, y, "ayuda trasladada proporcionalmente del plano"))

    # ---------------------------------------------------- depurar ayudas demasiado juntas
    def nn_ayudas(lista):
        q = np.array([[t.x, t.y] for t in lista])
        if len(q) < 2:
            return 0.5
        d = np.linalg.norm(q[:, None] - q[None], axis=2) + np.eye(len(q)) * 9
        return float(np.median(d.min(1)))
    esp_ayuda = nn_ayudas([t for t, f in tal_t if f in ("Ayuda", "Arranque", "Contorno", "Corona", "Arrastre")])
    minimo = 0.55 * esp_ayuda
    finales: list[est.TaladroRef] = []
    for t in nuevos:
        if "ayuda" in t.lectura:
            if any(math.hypot(t.x - o.x, t.y - o.y) < minimo for o in finales if o.tipo == "cargado"):
                continue
        finales.append(t)
    nuevos = finales

    # ---------------------------------------------------- completar cobertura como la plantilla
    cob_t, _ = cobertura(poli_t, [(t.x, t.y) for t in tpl.cargados()])
    agregados = 0
    for _ in range(40):
        cob_n, punto = cobertura(poli_n, [(t.x, t.y) for t in nuevos if t.tipo == "cargado"])
        if punto is None or cob_n <= cob_t * 1.05:
            break
        cand = [t for t in nuevos if t.tipo == "cargado" and "ayuda" in t.lectura] or \
            [t for t in nuevos if t.tipo == "cargado" and "arranque" not in t.lectura]
        fuente = min(cand, key=lambda t: math.hypot(t.x - punto[0], t.y - punto[1]))
        nuevos.append(copia_de(fuente, punto[0], punto[1], "ayuda agregada para conservar la cobertura del plano"))
        agregados += 1
    cob_n, _ = cobertura(poli_n, [(t.x, t.y) for t in nuevos if t.tipo == "cargado"])

    # ---------------------------------------------------- cuneta
    contorno_n = list(poli_n)
    if e.cuneta:
        lado = -1 if e.cuneta_lado.startswith("izq") else 1
        a, h = max(0.15, e.cuneta_ancho), max(0.1, e.cuneta_profundidad)
        borde = lado * e.ancho / 2
        interior = borde - lado * a
        contorno_n = _contorno_con_cuneta(poli_n, e.ancho, lado, a, h)
        fuente_c = [t for t, f in tal_t if t.y < -0.05]
        if not fuente_c:
            fuente_c = [min(arr_t, key=lambda t: abs(t.x - borde))] if arr_t else []
        n_c = 1 if a < 0.6 else 2
        for k in range(n_c):
            x = interior + (borde - interior) * (k + 1) / (n_c + 1)
            if fuente_c:
                nuevos.append(copia_de(fuente_c[0], x, -h / 2, f"cuneta (taladro como en el plano pág. {tpl.pagina})"))

    # ---------------------------------------------------- numeración para iniciación electrónica
    if tpl.iniciacion == "electrónica":
        orden = sorted(nuevos, key=lambda t: (t.tipo != "alivio", t.detonador or 0,
                                              math.atan2(t.y - c_n[1], t.x - c_n[0])))
        for k, t in enumerate(orden, 1):
            t.detonador = k
        avisos.append("Iniciación electrónica: se renumeró el orden de salida 1…N siguiendo el orden de la plantilla.")

    plano = _armar_plano(tpl, e, nuevos, contorno_n)
    informe = _informe(tpl, plano, e, esp_per, esp_arr, cob_t, cob_n, agregados, clave_arr, origen_arranque, avisos)
    return ResultadoMallaReal(plano=plano, plantilla=tpl, arranque=clave_arr, informe=informe, avisos=avisos)


def _contorno_con_cuneta(poli, ancho, lado, a, h):
    """Agrega el rebaje de la cuneta en el piso (esquina izquierda o derecha)."""
    borde = lado * ancho / 2
    interior = borde - lado * a
    p = _orientar_antihorario(poli)
    # insertar la cuneta en el tramo del piso (y ≈ 0)
    for i in range(len(p)):
        a1, b1 = p[i], p[(i + 1) % len(p)]
        if abs(a1[1]) < 1e-6 and abs(b1[1]) < 1e-6 and min(a1[0], b1[0]) <= min(borde, interior) + 1e-6 \
                and max(a1[0], b1[0]) >= max(borde, interior) - 1e-6:
            # antihorario: el piso va de izquierda a derecha
            if lado < 0:
                nuevos = [(borde, 0.0), (borde, -h), (interior, -h), (interior, 0.0)]
            else:
                nuevos = [(interior, 0.0), (interior, -h), (borde, -h), (borde, 0.0)]
            res = p[:i + 1] + [q for q in nuevos if math.dist(q, a1) > 1e-6 and math.dist(q, b1) > 1e-6] + p[i + 1:]
            return res
    return p


def _armar_plano(tpl: est.PlanoRef, e: EntradaMallaReal, taladros, contorno) -> est.PlanoRef:
    kgc = tpl.kg_por_cartucho()
    filas = []
    for f in tpl.explosivos_tabla:
        nom = f["nombre"]
        if nom.lower().startswith("total"):
            continue
        if nom.lower().startswith("sin"):
            filas.append({"nombre": nom, "valores": {"Perf": float(sum(1 for t in taladros if t.tipo == "alivio"))}})
            continue
        mis = [t for t in taladros if t.tipo == "cargado" and t.explosivo == nom]
        cart = sum(t.cartuchos for t in mis)
        anfo = sum(t.anfo_kg or 0 for t in mis)
        v = {"Cart": float(cart), "Perf": float(len(mis)), "Expl_Kg": round(cart * kgc.get(nom, 0) + anfo, 2)}
        if anfo:
            v["Anfo,Kg"] = round(anfo, 2)
        filas.append({"nombre": nom, "valores": v})
    tot = {"Cart": float(sum(f["valores"].get("Cart", 0) for f in filas)), "Perf": float(len(taladros)),
           "Expl_Kg": round(sum(f["valores"].get("Expl_Kg", 0) for f in filas), 2)}
    filas.append({"nombre": "Total general", "valores": tot})
    cuenta = {}
    for t in taladros:
        if t.tipo == "cargado" and t.detonador is not None:
            cuenta[int(t.detonador)] = cuenta.get(int(t.detonador), 0) + 1
    par = dict(tpl.parametros)
    par["long_perforacion_pies"] = e.longitud_pies
    area = _area(recortar_sobre_piso(contorno))
    par["area_m2"] = {"sin_sobrerotura": round(area, 2), "con_sobrerotura": round(area * 1.1, 2)}
    par.pop("perimetro_m", None)
    par.pop("factor_potencia_kg_t", None); par.pop("factor_potencia_kg_m", None)
    for k in [k for k in par if k.startswith("costo") or k in ("volumen_m3", "peso_t", "volumen_esponjado_m3")]:
        par.pop(k)
    nombre_sec = f"{e.ancho:.2f} x {e.alto:.2f}"
    return est.PlanoRef(
        pagina=0, seccion=nombre_sec, ancho=e.ancho, alto=e.alto, variante=tpl.variante, roca=e.roca,
        rotulo=tpl.rotulo, iniciacion=tpl.iniciacion, cuenta_detonadores=cuenta, total_cargados=sum(cuenta.values()),
        explosivos_tabla=filas, accesorios={}, parametros=par, contorno=[tuple(map(float, v)) for v in contorno],
        taladros=taladros, estado="Adaptado del estándar (no validado)",
        titulo=f"Malla para {nombre_sec} m · roca {e.roca} (adaptada de la pág. {tpl.pagina})",
        plantilla=tpl.pagina)


def _informe(tpl, pl, e, esp_per, esp_arr, cob_t, cob_n, agregados, clave_arr, origen_arr, avisos):
    fs = []
    fs.append(FilaInforme("Plano de referencia", f"pág. {tpl.pagina}: {tpl.seccion} m, roca {tpl.roca}, {tpl.variante}",
                          f"{e.ancho:.2f} × {e.alto:.2f} m, roca {e.roca}",
                          f"escala {e.ancho / tpl.ancho:.2f} × {e.alto / tpl.alto:.2f}"))
    tipo = NOMBRES_ARRANQUE.get(clave_arr, (clave_arr,))[0]
    fs.append(FilaInforme("Arranque", f"pág. {origen_arr.pagina}", tipo, "medidas reales copiadas sin escalar"))
    fs.append(FilaInforme("Taladros totales", str(len(tpl.taladros)), str(len(pl.taladros))))
    fs.append(FilaInforme("Taladros cargados", str(len(tpl.cargados())), str(len(pl.cargados()))))
    fs.append(FilaInforme("Alivios", str(len(tpl.alivios())), str(len(pl.alivios()))))
    fs.append(FilaInforme("Espaciamiento en el perímetro", f"{esp_per:.2f} m", f"{esp_per:.2f} m", "se conserva"))
    fs.append(FilaInforme("Espaciamiento de arrastres", f"{esp_arr:.2f} m", f"{esp_arr:.2f} m", "se conserva"))
    fs.append(FilaInforme("Cobertura (distancia máx. a un taladro cargado)", f"{cob_t:.2f} m", f"{cob_n:.2f} m",
                          f"{agregados} ayudas agregadas" if agregados else "", cob_n > cob_t * 1.1))
    area_t = (tpl.parametros.get("area_m2") or {}).get("sin_sobrerotura") or tpl.area_contorno()
    area_n = pl.parametros["area_m2"]["sin_sobrerotura"]
    kg_t = next((f["valores"].get("Expl_Kg") for f in tpl.explosivos_tabla if f["nombre"].startswith("Total")), None)
    kg_n = next(f["valores"]["Expl_Kg"] for f in pl.explosivos_tabla if f["nombre"].startswith("Total"))
    fs.append(FilaInforme("Área de la sección", f"{area_t:.2f} m²", f"{area_n:.2f} m²"))
    if kg_t:
        q_t, q_n = kg_t / area_t, kg_n / area_n
        fs.append(FilaInforme("Explosivo total", f"{kg_t:.1f} kg", f"{kg_n:.1f} kg"))
        fs.append(FilaInforme("Explosivo por m² de frente", f"{q_t:.2f} kg/m²", f"{q_n:.2f} kg/m²",
                              "debe parecerse al plano", abs(q_n / q_t - 1) > 0.2))
    # comprobación teórica del arranque (referencia)
    al = pl.alivios()
    if al:
        c = np.array([np.mean([t.x for t in al]), np.mean([t.y for t in al])])
        b1 = min(math.hypot(t.x - c[0], t.y - c[1]) for t in pl.cargados())
        d0 = e.diametro_alivio_mm / 1000 * math.sqrt(len(al))
        fs.append(FilaInforme("Burden del 1.er cuadro (centro de los alivios → 1.er cargado)", "medida del plano",
                              f"{b1:.3f} m",
                              f"referencia teórica (no exigida por el estándar): 1.7·D0 = {1.7 * d0:.3f} m con "
                              f"D0 = Ø alivio·√n = {d0 * 1000:.0f} mm", b1 > 1.7 * d0))
        if b1 > 1.7 * d0:
            avisos.append(f"El estándar no indica el Ø de los alivios. Con {e.diametro_alivio_mm:.0f} mm la regla teórica "
                          f"1.7·D0 da {1.7 * d0:.2f} m y el arranque del estándar usa {b1:.2f} m: confirma el Ø real "
                          "de alivios (o rimado) con que se usa esta malla.")
    if e.diametro_mm < 32:
        avisos.append("Diámetro de perforación menor de 32 mm: los cartuchos de 1\" del estándar no entran con holgura.")
    if e.diametro_mm > 51:
        avisos.append("Diámetro mayor de 51 mm: el estándar es para perforación de 6 pies con cartuchos de 1\"; "
                      "con barrenos más grandes el burden puede ser mayor. Compara con la malla teórica.")
    if abs(e.longitud_pies - 6.0) > 0.3:
        avisos.append(f"Las mallas del estándar son para 6 pies; pediste {e.longitud_pies:g} pies. "
                      "Cargas y avance deben recalcularse.")
    if not (0.6 <= e.ancho / tpl.ancho <= 1.6 and 0.6 <= e.alto / tpl.alto <= 1.6):
        avisos.append("La sección está lejos de las del estándar: revisa con cuidado la malla generada.")
    return fs
