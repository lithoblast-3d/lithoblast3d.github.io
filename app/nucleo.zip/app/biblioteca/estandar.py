"""
Biblioteca de mallas de referencia documental.

Fuente: Estándar MIN-SOS-ESO-001 v02 "Voladura en labores de avance de 6 pies"
(Cía. Minera Poderosa), planos de las páginas 4 a 57.

Cómo se obtuvieron los datos (ver tools/digitalizar_estandar.py):
- Tablas del plano (cuenta de detonadores, explosivos, accesorios, parámetros):
  texto real del PDF, extraído sin interpretación.
- Dibujo de la malla: en el PDF es una IMAGEN (no vectores). Se digitalizó:
  cada taladro = círculo de color (cargado) o blanco (alivio); su rótulo
  "detonador,cartuchos" se leyó por OCR y se ajustó con las tablas del mismo
  plano (cantidad por detonador, cartuchos y perforaciones por explosivo).
  Escala: ancho y alto nominales de la sección (título del plano).
- Cada taladro lleva el estado de lectura: "leído", "leído (1 carácter corregido
  por tabla)" o "...: revisar". Los que dicen "revisar" deben compararse con
  la imagen original (se muestra de fondo en el editor).

ESTADO: REFERENCIA DOCUMENTAL. No es un diseño validado para condiciones
reales hasta que lo verifiques en tu mina.
"""

from __future__ import annotations

import copy
import json
import math
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path

CARPETA_DATOS = Path(__file__).resolve().parent.parent / "datos"
ARCHIVO_BIBLIOTECA = CARPETA_DATOS / "biblioteca_estandar_6p.json"
CARPETA_PLANOS = CARPETA_DATOS / "planos"


def hay_estandar() -> bool:
    """False en la edición pública (se distribuye sin las mallas del estándar)."""
    return ARCHIVO_BIBLIOTECA.exists()
ARCHIVO_USUARIO = Path.home() / ".barreno3d" / "biblioteca_usuario.json"

DOCUMENTO = "MIN-SOS-ESO-001 v02 · Voladura en labores de avance de 6 pies"
PIE = 0.3048  # m
SECCIONES = ["1.20 x 1.80", "2.50 x 2.50", "2.50 x 2.70", "2.70 x 2.70", "3.00 x 3.00", "3.50 x 3.50"]
ROCAS = ["Buena", "Regular", "Mala"]
ESTADO_DOC = "Del estándar (digitalizado)"
ESTADO_VALIDADO = "Verificado"


@dataclass
class TaladroRef:
    x: float  # m, horizontal desde el eje de la labor
    y: float  # m, vertical desde el piso
    tipo: str  # "cargado" o "alivio"
    detonador: int | None = None  # n.º de retardo (o n.º de orden en iniciación electrónica)
    cartuchos: int = 0
    explosivo: str | None = None
    anfo_kg: float | None = None
    lectura: str = ""
    px: list = field(default_factory=list)  # posición en la imagen del plano (píxeles)
    ocr: str = ""
    kg: float | None = None  # carga calculada (mallas teóricas); None = cartuchos × kg/cartucho
    azimut_rel: float = 0.0  # ° respecto al eje de avance (taladros inclinados del corte en V)
    longitud: float | None = None  # m (None = longitud de perforación de la malla)
    funcion: str = ""  # función asignada por el diseño (si se conoce)

    @property
    def revisar(self) -> bool:
        return "revisar" in self.lectura


@dataclass
class PlanoRef:
    pagina: int
    seccion: str
    ancho: float
    alto: float
    variante: str
    roca: str
    titulo_ocr: str = ""
    codigo_ocr: str = ""
    rotulo: str = ""
    iniciacion: str = ""
    cuenta_detonadores: dict = field(default_factory=dict)
    total_cargados: int | None = None
    explosivos_tabla: list = field(default_factory=list)
    accesorios: dict = field(default_factory=dict)
    parametros: dict = field(default_factory=dict)
    escala: dict = field(default_factory=dict)
    contorno: list = field(default_factory=list)
    taladros: list[TaladroRef] = field(default_factory=list)
    estado: str = ESTADO_DOC
    validado_por: str = ""
    editado: bool = False
    notas: str = ""
    titulo: str = ""  # nombre propio (mallas generadas a partir del estándar)
    plantilla: int | None = None  # página del plano usado como base (mallas generadas)

    # ------------------------------------------------------------ descripción
    @property
    def nombre(self) -> str:
        if self.titulo:
            return self.titulo
        return f"Sección {self.seccion} · {self.variante} · Roca {self.roca} (pág. {self.pagina})"

    @property
    def codigo(self) -> str:
        if self.plantilla is not None:
            return f"Adaptado de la pág. {self.plantilla}"
        m = re.search(r"(\d{2})\s*$", self.codigo_ocr or "")
        return f"MIN-VOL-ESO-001-{m.group(1)}" if m else f"pág. {self.pagina}"

    @property
    def rmr(self) -> str:
        m = re.search(r"RMR[:\s]*([\d]+\s*-\s*[\d]+|<\s*\d+)", self.titulo_ocr or "")
        return m.group(1).replace(" ", "") if m else "—"

    @property
    def imagen(self) -> Path:
        return CARPETA_PLANOS / f"p{self.pagina:02d}.png"

    def cargados(self) -> list[TaladroRef]:
        return [t for t in self.taladros if t.tipo == "cargado"]

    def alivios(self) -> list[TaladroRef]:
        return [t for t in self.taladros if t.tipo == "alivio"]

    def longitud_perforacion(self) -> float:
        pies = self.parametros.get("long_perforacion_pies") or 6.0
        return pies * PIE

    def kg_por_cartucho(self) -> dict[str, float]:
        """kg por cartucho = (Expl_Kg − ANFO kg) / Cart, de la tabla del plano.
        (En los planos con ANFO, Expl_Kg incluye el ANFO de la columna «Anfo,Kg».)"""
        res = {}
        for fila in self.explosivos_tabla:
            v = fila.get("valores", {})
            cart = _col(v, "cart")
            kg = _col(v, "expl")
            anfo = _col(v, "anfo") or 0.0
            if cart and kg and not fila["nombre"].lower().startswith(("total", "sin")):
                res[fila["nombre"]] = (kg - anfo) / cart
        return res

    def area_contorno(self) -> float:
        if len(self.contorno) < 3:
            return 0.0
        a = 0.0
        for (x1, y1), (x2, y2) in zip(self.contorno, self.contorno[1:] + self.contorno[:1]):
            a += x1 * y2 - x2 * y1
        return abs(a) / 2


def _col(valores: dict, prefijo: str):
    for k, v in valores.items():
        if k.lower().startswith(prefijo):
            return v
    return None


# ================================================================= verificación
@dataclass
class FilaVerificacion:
    concepto: str
    digitalizado: float | int | None
    documento: float | int | None
    informativo: bool = False

    @property
    def coincide(self) -> bool | None:
        if self.digitalizado is None or self.documento is None:
            return None
        return abs(float(self.digitalizado) - float(self.documento)) < 1e-6 or (
            self.informativo and abs(float(self.digitalizado) - float(self.documento))
            <= 0.05 * abs(float(self.documento)))


def verificar(p: PlanoRef) -> list[FilaVerificacion]:
    """Compara la malla digitalizada (o editada) con las tablas del mismo plano."""
    filas: list[FilaVerificacion] = []
    total = next((f for f in p.explosivos_tabla if f["nombre"].lower().startswith("total")), None)
    filas.append(FilaVerificacion("Perforaciones totales", len(p.taladros),
                                  _col(total["valores"], "perf") if total else None))
    if p.cuenta_detonadores:
        filas.append(FilaVerificacion("Taladros cargados (cuenta de detonadores)", len(p.cargados()),
                                      p.total_cargados))
        for det, n in sorted(p.cuenta_detonadores.items(), key=lambda kv: int(kv[0])):
            filas.append(FilaVerificacion(f"  Detonador N.º {det}",
                                          sum(1 for t in p.cargados() if t.detonador == int(det)), n))
    for f in p.explosivos_tabla:
        nom = f["nombre"]; v = f["valores"]
        if nom.lower().startswith("total"):
            continue
        if nom.lower().startswith("sin"):
            filas.append(FilaVerificacion("Sin explosivo (alivios)", len(p.alivios()), _col(v, "perf")))
            continue
        mis = [t for t in p.cargados() if t.explosivo == nom]
        if _col(v, "cart") is not None:
            filas.append(FilaVerificacion(f"Cartuchos {nom}", sum(t.cartuchos for t in mis), _col(v, "cart")))
        filas.append(FilaVerificacion(f"Perforaciones {nom}", len(mis), _col(v, "perf")))
        if _col(v, "anfo") is not None:
            filas.append(FilaVerificacion(f"ANFO kg {nom} (rótulos, informativo)",
                                          round(sum(t.anfo_kg or 0 for t in mis), 2), _col(v, "anfo"), True))
    area = p.parametros.get("area_m2")
    if isinstance(area, dict) and p.contorno:
        filas.append(FilaVerificacion("Área del contorno digitalizado, m² (informativo; incluye cuneta)",
                                      round(p.area_contorno(), 2), area.get("sin_sobrerotura"), True))
    return filas


def resumen_verificacion(p: PlanoRef) -> tuple[int, int, int]:
    """(coinciden, difieren, taladros por revisar)."""
    fs = [f for f in verificar(p) if not f.informativo and f.coincide is not None]
    ok = sum(1 for f in fs if f.coincide)
    return ok, len(fs) - ok, sum(1 for t in p.taladros if t.revisar)


# ================================================================= carga / guardado
def _plano_desde_dict(d: dict) -> PlanoRef:
    d = dict(d)
    tal = [TaladroRef(**{k: v for k, v in t.items() if k in TaladroRef.__dataclass_fields__})
           for t in d.pop("taladros", [])]
    campos = PlanoRef.__dataclass_fields__
    p = PlanoRef(**{k: v for k, v in d.items() if k in campos}, taladros=tal)
    p.cuenta_detonadores = {int(k): int(v) for k, v in p.cuenta_detonadores.items()}
    return p


def plano_a_dict(p: PlanoRef) -> dict:
    return asdict(p)


def cargar_biblioteca(ruta: Path | None = None, ruta_usuario: Path | None = None) -> list[PlanoRef]:
    """Planos del estándar; si el usuario editó o validó alguno, se usa su versión."""
    ruta = ruta or ARCHIVO_BIBLIOTECA
    if not Path(ruta).exists():
        return []
    datos = json.loads(Path(ruta).read_text(encoding="utf-8"))
    planos = {d["pagina"]: _plano_desde_dict(d) for d in datos}
    ru = ruta_usuario or ARCHIVO_USUARIO
    if Path(ru).exists():
        try:
            for d in json.loads(Path(ru).read_text(encoding="utf-8")):
                planos[d["pagina"]] = _plano_desde_dict(d)
        except (ValueError, KeyError):
            pass
    return [planos[k] for k in sorted(planos)]


def original(pagina: int, ruta: Path | None = None) -> PlanoRef:
    datos = json.loads(Path(ruta or ARCHIVO_BIBLIOTECA).read_text(encoding="utf-8"))
    return _plano_desde_dict(next(d for d in datos if d["pagina"] == pagina))


def guardar_edicion(p: PlanoRef, ruta_usuario: Path | None = None) -> Path:
    ru = Path(ruta_usuario or ARCHIVO_USUARIO)
    ru.parent.mkdir(parents=True, exist_ok=True)
    lista = []
    if ru.exists():
        try:
            lista = [d for d in json.loads(ru.read_text(encoding="utf-8")) if d["pagina"] != p.pagina]
        except ValueError:
            lista = []
    p.editado = True
    lista.append(plano_a_dict(p))
    ru.write_text(json.dumps(lista, ensure_ascii=False, indent=1), encoding="utf-8")
    return ru


def descartar_edicion(pagina: int, ruta_usuario: Path | None = None) -> None:
    ru = Path(ruta_usuario or ARCHIVO_USUARIO)
    if ru.exists():
        lista = [d for d in json.loads(ru.read_text(encoding="utf-8")) if d["pagina"] != pagina]
        ru.write_text(json.dumps(lista, ensure_ascii=False, indent=1), encoding="utf-8")


def filtrar(planos: list[PlanoRef], seccion: str | None = None, roca: str | None = None,
            texto: str = "") -> list[PlanoRef]:
    r = planos
    if seccion:
        r = [p for p in r if p.seccion == seccion]
    if roca:
        r = [p for p in r if p.roca == roca]
    if texto:
        t = texto.lower()
        r = [p for p in r if t in p.nombre.lower() or t in p.variante.lower()]
    return r


# ================================================================= clasificación geométrica
def _dist_poligono(x: float, y: float, poli: list) -> float:
    best = 1e9
    for (x1, y1), (x2, y2) in zip(poli, poli[1:] + poli[:1]):
        dx, dy = x2 - x1, y2 - y1
        L2 = dx * dx + dy * dy
        t = 0.0 if L2 == 0 else max(0.0, min(1.0, ((x - x1) * dx + (y - y1) * dy) / L2))
        best = min(best, math.hypot(x - (x1 + t * dx), y - (y1 + t * dy)))
    return best


def clasificar(p: PlanoRef) -> list[str]:
    """Función de cada taladro deducida de su POSICIÓN (no viene escrita en el plano).

    Alivio = círculo blanco. Arranque = cargados a menos de 2.2 veces la distancia
    del taladro cargado más cercano al centro de los alivios. Arrastre / Contorno / Corona = sobre el contorno
    (a menos de 0.12 m), según la altura. Ayuda = el resto. Es una ayuda visual: verificar.
    """
    al = p.alivios()
    if al:
        cx = sum(t.x for t in al) / len(al); cy = sum(t.y for t in al) / len(al)
        r_al = max(math.hypot(t.x - cx, t.y - cy) for t in al)
    else:
        cx, cy, r_al = 0.0, p.alto / 2, 0.0
    dists = [math.hypot(t.x - cx, t.y - cy) for t in p.cargados()]
    r_arr = 2.2 * min(dists) if dists else 0.0
    hastial = p.alto * 0.62
    res = []
    for t in p.taladros:
        if t.tipo == "alivio":
            res.append("Alivio"); continue
        d_borde = _dist_poligono(t.x, t.y, p.contorno) if p.contorno else 1.0
        if d_borde < 0.12 or t.y < 0.05:
            if t.y < 0.15:
                res.append("Arrastre")
            elif t.y > hastial:
                res.append("Corona")
            else:
                res.append("Contorno")
        elif math.hypot(t.x - cx, t.y - cy) <= r_arr:
            res.append("Arranque")
        else:
            res.append("Ayuda")
    return res


# ================================================================= conversión al proyecto
def explosivos_del_plano(p: PlanoRef) -> list[dict]:
    """Explosivos de la tabla del plano con su densidad DERIVADA:
    kg/cartucho (tabla) ÷ volumen nominal del cartucho (medida del nombre, p. ej. 1"x8").
    Se marcan como referenciales: reemplazar con la ficha técnica del fabricante."""
    res = []
    for nombre, kgc in p.kg_por_cartucho().items():
        m = re.search(r'(\d+(?:\.\d+)?)\s*"\s*[xX]\s*(\d+(?:\.\d+)?)\s*"', nombre)
        d_mm = float(m.group(1).replace(",", ".")) * 25.4 if m else 0.0
        l_m = float(m.group(2).replace(",", ".")) * 0.0254 if m else 0.0
        dens = kgc / (math.pi / 4 * (d_mm / 1000) ** 2 * l_m) / 1000 if d_mm and l_m else None
        res.append({"nombre": nombre, "kg_cartucho": kgc, "diametro_mm": d_mm,
                    "densidad_gcc": round(dens, 3) if dens else None})
    return res


def plano_a_pozos(p: PlanoRef, ids_existentes, diametro_mm: float, diametro_alivio_mm: float,
                  x0: float, y0: float, z0: float, azimut: float, explosivo_ids: dict[str, str],
                  longitud_m: float | None = None, labor: str = "frente"):
    """Convierte el plano en perforaciones del proyecto (frente en el plano vertical).

    labor = "chimenea": el plano se coloca en el TECHO (plano horizontal a la cota z0) y los taladros se
    perforan hacia arriba (inclinación −90°); «y» del plano va en la dirección del azimut.

    El diámetro de perforación NO figura en el estándar: lo ingresa el usuario.
    La carga de cada taladro = cartuchos del rótulo × kg/cartucho de la tabla del plano.
    """
    from app.core.generador import _generador_ids
    from app.core.modelo import Perforacion

    nuevo_id = _generador_ids(ids_existentes)
    a = math.radians(azimut)
    kgc = p.kg_por_cartucho()
    funciones = clasificar(p)
    L = longitud_m or p.longitud_perforacion()
    origen = (f"{p.codigo} (malla adaptada del estándar)" if p.plantilla is not None
              else f"{p.codigo} · pág. {p.pagina} (digitalizado)")

    vertical = labor == "chimenea"

    def mundo(s, h):
        if vertical:
            return (round(x0 + s * math.cos(a) + h * math.sin(a), 3), round(y0 - s * math.sin(a) + h * math.cos(a), 3),
                    round(z0, 3))
        return (round(x0 + s * math.cos(a), 3), round(y0 - s * math.sin(a), 3), round(z0 + h, 3))

    pozos = []
    for t, fun in zip(p.taladros, funciones):
        fun = t.funcion or fun
        x, y, z = mundo(t.x, t.y)
        ident = nuevo_id()
        cargado = t.tipo == "cargado"
        kg = None
        if cargado and t.kg is not None:
            kg = round(t.kg, 3)
        elif cargado and t.explosivo in kgc:
            # cartuchos × kg/cartucho (tabla) + ANFO del rótulo (si el plano lo indica)
            kg = round(t.cartuchos * kgc[t.explosivo] + (t.anfo_kg or 0.0), 3)
        pozos.append(Perforacion(
            id=ident, nombre=ident, capa_id="perforaciones", x=x, y=y, z=z,
            azimut=(azimut + t.azimut_rel) % 360, inclinacion=-90.0 if vertical else 0.0,
            longitud=round(t.longitud or L, 3),
            diametro_mm=diametro_mm if cargado else diametro_alivio_mm,
            explosivo_id=explosivo_ids.get(t.explosivo) if cargado else None,
            funcion=fun, retardo=int(t.detonador or 0), cartuchos=int(t.cartuchos or 0),
            kg_documento=kg if cargado else None, origen=origen,
        ))
    contorno = [mundo(s, h) for s, h in p.contorno]
    return pozos, contorno


def copia(p: PlanoRef) -> PlanoRef:
    return copy.deepcopy(p)
