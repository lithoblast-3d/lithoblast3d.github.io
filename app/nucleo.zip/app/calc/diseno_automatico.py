"""
Diseño automático de mallas de perforación (versión 1) — PENDIENTE DE VALIDAR.

FICHA TÉCNICA
=============
Requisito
    A partir de pocos datos (sección o área, diámetros, explosivo, roca) calcular
    burden, espaciamiento, taco y número de pozos de cada zona.

Fuentes
    Subterráneo — método de Holmberg:
      Holmberg, R. (1982). "Charge calculations for tunneling". En: Underground
      Mining Methods Handbook, SME. Presentado en: López Jimeno, C. et al.,
      "Manual de Perforación y Voladura de Rocas", IGME (capítulo de túneles).
    Tajo abierto — método de Konya:
      Konya, C. J. & Walter, E. J. (1990). "Surface Blast Design". Prentice Hall;
      y "Rock Blasting and Overbreak Control", FHWA-HI-92-001.

Estado de verificación
    - Verificado contra fuentes consultadas: avance L = 0.15 + 34.1·φ2 − 39.4·φ2²,
      φ2 = φ·√N, avance real ≈ 0.95·L; burden de Konya (comprobado con el ejemplo
      De = 152.4 mm, SGe = 1.5, SGr = 2.5 → B = 4.94 m).
    - Resto de expresiones: tomadas de la presentación estándar del método
      (López Jimeno) SIN haber podido cotejar el texto original en esta versión.
      Revísalas contra tu copia del manual antes de usar la
      malla en campo. Las constantes están en el formulario y se pueden cambiar.

Unidades
    Diámetros de entrada en mm; dentro de las fórmulas de Holmberg en metros.
    Longitudes en m, carga lineal q en kg/m, densidades en g/cm³ (explosivo)
    y t/m³ (roca). PRP = potencia relativa en peso respecto al ANFO (ANFO = 1).

Fórmulas (subterráneo, Holmberg)
    Avance máximo               L  = 0.15 + 34.1·φ2 − 39.4·φ2²       (φ2 en m)
    Alivio equivalente          φ2 = φ_alivio · √N_alivios
    Error de perforación        F  = α·H + e'     (α m/m, e' m)
    Arranque, 1.er cuadro       B1 = 1.5·φ2 ;  abertura A1 = √2·(B1 − F)
    Cuadros siguientes          B  = 0.088·√(A·q·PRP / (d·c)) ,  Bp = B − F ≤ 2·A
                                abertura nueva = √2·(Bp + A/2)
                                se agregan cuadros mientras la abertura < √H
    Arrastres, ayudas           B  = 0.9·√(q·PRP / (c̄·f·S/B))
                                c̄ = c + 0.05 (B ≥ 1.4 m) ;  c̄ = c + 0.07/B (B < 1.4 m)
                                arrastre: f = 1.45, S/B = 1
                                ayudas:   f = 1.45, S/B = 1.25
                                Bp = B − H·sen(γ) − F  (γ: ángulo de realce/contorno)
    Contorno (recorte)          S  = K·d (K ≈ 15–16) ;  B = S / 0.8
    Taco                        arranque 10·d ; arrastre 0.2·B ; ayudas y contorno 0.5·B

Fórmulas (tajo abierto, Konya)
    Burden                      B = 0.012·(2·ρe/ρr + 1.5)·De         (De en mm, B en m)
    Taco                        T = 0.7·B
    Sobreperforación            J = 0.3·B
    Espaciamiento (retardos)    H/B < 4: S = (H + 7B)/8 ;  H/B ≥ 4: S = 1.4·B
    Espaciamiento (instantáneo) H/B < 4: S = (H + 2B)/3 ;  H/B ≥ 4: S = 2·B

Supuestos y límites
    - Roca homogénea; c (constante de roca, ≈ 0.4) no reemplaza ensayos.
    - No considera agua, estructuras, secuencia de salida ni fragmentación.
    - El resultado es un diseño PRELIMINAR que se ajusta en campo.

Validación
    tests/test_diseno_automatico.py (valores calculados a mano).
"""

import math

from app.calc.carga import ErrorDeDatos

C_ROCA = 0.4  # constante de roca usada por Holmberg (≈ kg/m³ de explosivo de referencia)
F_ARRASTRE, SB_ARRASTRE = 1.45, 1.0
F_AYUDA, SB_AYUDA = 1.45, 1.25
K_CONTORNO = 15.0
RELACION_SB_CONTORNO = 0.8


def _pos(nombre: str, valor: float) -> None:
    if valor is None or valor <= 0:
        raise ErrorDeDatos(f"{nombre} debe ser mayor que cero")


# =================================================================== Holmberg
def diametro_equivalente(diametro_alivio_m: float, n_alivios: int) -> float:
    _pos("El diámetro de alivio", diametro_alivio_m)
    if n_alivios < 1:
        raise ErrorDeDatos("Se necesita al menos un taladro de alivio")
    return diametro_alivio_m * math.sqrt(n_alivios)


def avance_maximo(phi2_m: float) -> float:
    """Profundidad máxima de perforación que permite el alivio (m)."""
    return 0.15 + 34.1 * phi2_m - 39.4 * phi2_m**2


def error_perforacion(longitud_m: float, alfa: float, emboquille_m: float) -> float:
    return alfa * longitud_m + emboquille_m


def burden_primer_cuadro(phi2_m: float) -> float:
    return 1.5 * phi2_m


def abertura_primer_cuadro(b1: float, f: float) -> float:
    if b1 - f <= 0:
        raise ErrorDeDatos("El error de perforación es mayor que el burden del arranque: "
                           "aumenta el alivio o reduce la desviación")
    return math.sqrt(2) * (b1 - f)


def burden_cuadro(abertura: float, q: float, prp: float, d_m: float, c: float = C_ROCA) -> float:
    for nombre, v in (("La abertura", abertura), ("La carga lineal", q), ("La PRP", prp),
                      ("El diámetro", d_m), ("La constante de roca", c)):
        _pos(nombre, v)
    return 0.088 * math.sqrt(abertura * q * prp / (d_m * c))


def c_barra(c: float, burden: float) -> float:
    return c + 0.05 if burden >= 1.4 else c + 0.07 / burden


def burden_holmberg(q: float, prp: float, f: float, sb: float, c: float = C_ROCA) -> float:
    """B = 0.9·√(q·PRP/(c̄·f·S/B)); c̄ depende de B, por eso se itera."""
    _pos("La carga lineal", q)
    _pos("La PRP", prp)
    b = 1.0
    for _ in range(50):
        nuevo = 0.9 * math.sqrt(q * prp / (c_barra(c, b) * f * sb))
        if abs(nuevo - b) < 1e-6:
            break
        b = nuevo
    return b


def contorno_recorte(d_m: float, k: float = K_CONTORNO) -> tuple[float, float]:
    """(espaciamiento, burden) para voladura de recorte."""
    _pos("El diámetro", d_m)
    s = k * d_m
    return s, s / RELACION_SB_CONTORNO


# =================================================================== Konya
def burden_konya(diametro_mm: float, densidad_explosivo: float, densidad_roca: float) -> float:
    _pos("El diámetro", diametro_mm)
    _pos("La densidad del explosivo", densidad_explosivo)
    _pos("La densidad de la roca", densidad_roca)
    return 0.012 * (2 * densidad_explosivo / densidad_roca + 1.5) * diametro_mm


def espaciamiento_konya(altura_banco: float, burden: float, con_retardos: bool = True) -> float:
    _pos("La altura de banco", altura_banco)
    rigidez = altura_banco / burden
    if con_retardos:
        return (altura_banco + 7 * burden) / 8 if rigidez < 4 else 1.4 * burden
    return (altura_banco + 2 * burden) / 3 if rigidez < 4 else 2 * burden


def taco_konya(burden: float) -> float:
    return 0.7 * burden


def sobreperforacion_konya(burden: float) -> float:
    return 0.3 * burden


# =================================================================== Arranque paralelo
# Fuente principal (verificada contra el texto del artículo):
#   Yilmaz, O. (2023). "Drilling and blasting designs for parallel hole cut and V-cut
#   method in excavation of underground coal mine galleries". Scientific Reports 13:2449.
#   https://doi.org/10.1038/s41598-023-29803-6
#   (recoge Holmberg 1982, Olofsson 1988, Persson et al. 2001, Langefors y Kihlström 1963)
#
#   Ec. 1   I  = 0.95·H                                   avance
#   Ec. 2   H  = 0.15 + 34.1·D0 − 39.4·D0²  (0.05 ≤ D0 ≤ 0.25 m)
#   Ec. 3   B1 = 1.7·D0 − (α·H + β)                       burden práctico, 1.er cuadro
#   Ec. 4   q  = 55·dh·(B/D0)^1.5·(B − D0/2)·(c/0.4)·(1/RWS)   carga lineal necesaria
#   Ec. 5   W1 = B1·√2
#   Ec. 6   Bn = 0.7·W(n−1) ;  Wn = 1.7·W(n−1)
#   Ec. 7   B  = 30·qb / dh            (dh en mm)          burden del resto del frente
#   Ec. 8   qb = (π·dh²/4)·ρe·AWS     (dh en mm → kg/m con factor 1e-3)
#   Tabla 2 geometría y carga por zona; retacado del arranque = 10·dh;
#   look-out (realce) ≤ 0.10 m + 0.03 m por metro de perforación.

D0_MIN, D0_MAX = 0.05, 0.25  # m, rango de validez de la Ec. 2

# Tabla 2: zona → (factor de burden, factor de espaciamiento, altura de carga de fondo
#                  como fracción de H, carga de columna / qb, retacado / B)
TABLA_2 = {
    "Ayuda (hacia arriba y horizontal)": (1.0, 1.1, 1 / 3, 0.5, 0.5),
    "Ayuda (hacia abajo)": (1.0, 1.2, 1 / 3, 0.5, 0.5),
    "Corona": (0.9, 1.1, 1 / 6, 0.3, 0.5),
    "Hastial": (0.9, 1.1, 1 / 6, 0.4, 0.5),
    "Arrastre": (1.0, 1.1, 1 / 3, 1.0, 0.2),
}


def perforacion_maxima(d0_m: float) -> float:
    """Ec. 2: profundidad de perforación que permite el alivio D0."""
    return 0.15 + 34.1 * d0_m - 39.4 * d0_m**2


def alivio_necesario(longitud: float) -> float:
    """Inversa de la Ec. 2: diámetro de alivio (m) que permite perforar 'longitud' m."""
    disc = 34.1**2 - 4 * 39.4 * (longitud - 0.15)
    if disc < 0:
        raise ErrorDeDatos("Ninguna perforación de alivio permite esa longitud según la Ec. 2")
    return (34.1 - math.sqrt(disc)) / (2 * 39.4)


def burden_primer_cuadro_practico(d0_m: float, longitud: float, alfa: float, beta: float) -> float:
    """Ec. 3."""
    return 1.7 * d0_m - (alfa * longitud + beta)


def carga_necesaria_arranque(dh_m: float, burden: float, d0_m: float, c: float, rws: float) -> float:
    """Ec. 4: carga lineal (kg/m) que necesita un taladro del arranque."""
    _pos("La RWS", rws)
    if burden <= d0_m / 2:
        return 0.0
    return 55 * dh_m * (burden / d0_m) ** 1.5 * (burden - d0_m / 2) * (c / 0.4) / rws


def burden_para_carga(q_disponible: float, dh_m: float, d0_m: float, c: float, rws: float) -> float:
    """Inversa de la Ec. 4: burden (centro a centro) con el que la carga disponible es justo
    la necesaria. El artículo la usa cuando el explosivo da más carga que la requerida."""
    bajo, alto = d0_m / 2, 10 * d0_m
    for _ in range(80):
        medio = (bajo + alto) / 2
        if carga_necesaria_arranque(dh_m, medio, d0_m, c, rws) < q_disponible:
            bajo = medio
        else:
            alto = medio
    return (bajo + alto) / 2


def cuadros_arranque(b1: float, n: int) -> list[tuple[float, float]]:
    """Ec. 5 y 6: [(burden, ancho W)] de los n cuadros."""
    cuadros = [(b1, b1 * math.sqrt(2))]
    for _ in range(n - 1):
        w_previo = cuadros[-1][1]
        cuadros.append((0.7 * w_previo, 1.7 * w_previo))
    return cuadros


def carga_fondo(dh_mm: float, densidad: float, aws: float) -> float:
    """Ec. 8: concentración de carga de fondo qb (kg/m)."""
    _pos("El diámetro", dh_mm)
    _pos("La densidad", densidad)
    _pos("La AWS", aws)
    return math.pi * dh_mm**2 / 4 * densidad * aws / 1000


def burden_frente(qb: float, dh_mm: float) -> float:
    """Ec. 7: burden del resto del frente (m)."""
    _pos("El diámetro", dh_mm)
    return 30 * qb / dh_mm


def realce_maximo(longitud: float) -> float:
    """Look-out recomendado: 0.10 m + 0.03 m/m."""
    return 0.10 + 0.03 * longitud


# =================================================================== Banco: modelos de burden
# Fuente: presentación "Diseño de disparos primarios para minería superficial",
# MSc. Eduardo Noriega (UPN), semana 11 de Perforación y Voladura; referencias: IGME (1987),
# EXSA (2000), Langefors y Kihlström. Correcciones aplicadas tras contrastar con otras fuentes:
#   - Ash modificado: Kb1 es adimensional (la diapositiva repite por error el factor d/12).
#   - Langefors: c̄ = c + 0.05 para 1.4 ≤ B ≤ 15 m (la diapositiva muestra 0.7).
PIE = 0.3048  # m
PULGADA = 25.4  # mm
PSI = 6894.757  # Pa

# Tabla I (Ash): Kb por tipo de explosivo (fila) y de roca (columna)
KB_ASH = {
    "baja": {"Blanda": 30, "Media": 25, "Dura": 20},   # 0.8–0.9 g/cm³, baja potencia
    "media": {"Blanda": 35, "Media": 30, "Dura": 25},  # 1.0–1.2 g/cm³, potencia media
    "alta": {"Blanda": 40, "Media": 35, "Dura": 30},   # 1.3–1.4 g/cm³, alta potencia
}
# Tabla II (Pearse): JSF según la calidad de la roca
JSF_PEARSE = {"Competente": 1.0, "Media": 0.9, "Suave": 0.8, "Muy suave": 0.7}
# Factor de fijación f (Langefors) según la inclinación del taladro
F_FIJACION = {"Vertical": 1.0, "Inclinado 3:1": 0.90, "Inclinado 2:1": 0.85}


def clase_explosivo_ash(densidad: float) -> str:
    """Fila de la Tabla I según la densidad del explosivo (límites a mitad de los rangos)."""
    if densidad < 0.95:
        return "baja"
    if densidad < 1.25:
        return "media"
    return "alta"


def burden_ash(kb: float, diametro_mm: float) -> float:
    """Ash: B = Kb·D/12 (B en pies, D en pulgadas). Devuelve metros."""
    _pos("Kb", kb)
    _pos("El diámetro", diametro_mm)
    return kb * (diametro_mm / PULGADA) / 12 * PIE


def kb_ash_corregido(kb_estandar: float, densidad_roca_ref: float, densidad_roca: float,
                     densidad_exp_ref: float, densidad_exp: float,
                     vod_ref: float, vod: float) -> float:
    """Ash modificado: Kb1 = Kb·(dr1/dr2)^(1/3)·(SG2·V2² / (SG1·V1²))^(1/3)."""
    for nombre, v in (("La densidad de roca", densidad_roca), ("La densidad del explosivo", densidad_exp),
                      ("La VOD", vod)):
        _pos(nombre, v)
    return (kb_estandar * (densidad_roca_ref / densidad_roca) ** (1 / 3)
            * (densidad_exp * vod**2 / (densidad_exp_ref * vod_ref**2)) ** (1 / 3))


def factor_volabilidad_pearse(rqd: float, jsf: float) -> float:
    """K = 1.96 − 0.27·ln(ERQD), ERQD = RQD·JSF (en %)."""
    erqd = rqd * jsf
    _pos("El ERQD (RQD × JSF)", erqd)
    return 1.96 - 0.27 * math.log(erqd)


def presion_detonacion_mpa(densidad_gcc: float, vod_ms: float) -> float:
    """Estimación habitual PD ≈ ρ·VOD²/4 (MPa), con ρ en kg/m³ y VOD en m/s."""
    return densidad_gcc * 1000 * vod_ms**2 / 4 / 1e6


def burden_pearse(k: float, diametro_mm: float, pd_mpa: float, std_mpa: float) -> float:
    """Pearse: B = K·D/12·√(P2/Std) (B en pies, D en pulgadas, P2 y Std en psi). Devuelve m."""
    _pos("K", k)
    _pos("La presión de detonación", pd_mpa)
    _pos("La resistencia a la tracción dinámica", std_mpa)
    return k * (diametro_mm / PULGADA) / 12 * math.sqrt(pd_mpa / std_mpa) * PIE  # psi/psi = MPa/MPa


def c_langefors(c: float, burden: float) -> float:
    return c + 0.05 if burden >= 1.4 else c + 0.07 / burden


def burden_langefors(diametro_mm: float, densidad: float, prp: float, c: float, f: float,
                     s_b: float) -> float:
    """Bmax = (D/33)·√(ρe·PRP / (c̄·f·S/B)); c̄ depende de Bmax, por eso se itera."""
    for nombre, v in (("El diámetro", diametro_mm), ("La densidad", densidad), ("La PRP", prp),
                      ("f", f), ("S/B", s_b)):
        _pos(nombre, v)
    b = 1.0
    for _ in range(60):
        nuevo = diametro_mm / 33 * math.sqrt(densidad * prp / (c_langefors(c, b) * f * s_b))
        if abs(nuevo - b) < 1e-7:
            break
        b = nuevo
    return b


def burden_practico_langefors(bmax: float, emboquille: float, desviacion: float, longitud: float) -> float:
    """B = Bmax − e' − db·H."""
    return bmax - emboquille - desviacion * longitud
