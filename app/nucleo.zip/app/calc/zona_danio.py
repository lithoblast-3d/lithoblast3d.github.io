"""
Esfuerzos alrededor de los taladros y radios de daño (enfoque de cilindro de pared gruesa,
Lamé / Kirsch para presión interna):

    σ(r) = p0 · (a / r)²        a = radio del taladro, p0 = presión en la pared del taladro

Radios característicos (σ = resistencia):
    r_triturado = a · √(p0 / σc,d)       σc,d = resistencia dinámica a compresión
    r_fisurado  = a · √(p0 / σt,d)       σt,d = resistencia dinámica a tracción

Presión del taladro (aproximación habitual en voladura):
    PD  = ρe · VOD² / 4          (presión de detonación, Pa con ρe en kg/m³ y VOD en m/s)
    Pb  = PD / 2                 (presión de explosión, carga acoplada)
    Pb,ef = Pb · (dc/dh)^2.6     (carga desacoplada: cartucho de diámetro dc en taladro dh;
                                   exponente usual 2.4–2.6)

Es un modelo cuasi-estático y elástico: sirve para comparar mallas y ver la cobertura
del frente, no reemplaza mediciones de daño.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


def presion_taladro_mpa(densidad_gcc: float, vod_ms: float, d_carga_mm: float | None = None,
                        d_taladro_mm: float | None = None, exponente: float = 2.6) -> float:
    pd = densidad_gcc * 1000.0 * vod_ms ** 2 / 4.0 / 1e6
    pb = pd / 2.0
    if d_carga_mm and d_taladro_mm and d_carga_mm < d_taladro_mm:
        pb *= (d_carga_mm / d_taladro_mm) ** exponente
    return pb


def radio_critico(a_m: float, p0_mpa: float, resistencia_mpa: float) -> float:
    if resistencia_mpa <= 0:
        raise ValueError("La resistencia debe ser mayor que cero")
    return a_m * math.sqrt(max(p0_mpa, 0.0) / resistencia_mpa)


@dataclass
class TaladroPresion:
    x: float
    y: float
    radio_m: float
    p0_mpa: float


def mapa_esfuerzos(taladros: list[TaladroPresion], xs, ys, modo: str = "max"):
    """Esfuerzo radial σ [MPa] en una rejilla. modo "max" (envolvente) o "suma" (superposición)."""
    X, Y = np.meshgrid(np.asarray(xs, float), np.asarray(ys, float))
    S = np.zeros_like(X)
    for t in taladros:
        r = np.hypot(X - t.x, Y - t.y)
        r = np.maximum(r, t.radio_m * 1.01)
        s = t.p0_mpa * (t.radio_m / r) ** 2
        S = np.maximum(S, s) if modo == "max" else S + s
    return X, Y, S


def cobertura(taladros: list[TaladroPresion], dentro, xs, ys, umbral_mpa: float, modo: str = "max") -> float:
    """Fracción del área del frente con σ ≥ umbral (0–1). «dentro»: máscara booleana de la sección."""
    _, _, S = mapa_esfuerzos(taladros, xs, ys, modo)
    m = np.asarray(dentro, bool)
    if not m.any():
        return 0.0
    return float(np.mean(S[m] >= umbral_mpa))
