"""
Calidad del macizo rocoso → parámetros de diseño de la voladura (versión 1).

FICHA TÉCNICA
=============
Clasificación
    RMR (Bieniawski, 1989): I 81–100 muy buena · II 61–80 buena · III 41–60 regular ·
    IV 21–40 mala · V ≤ 20 muy mala.
    GSI ≈ RMR89 − 5 (Hoek, Kaiser y Bawden, 1995; válido para RMR89 > 23).
    Jv (juntas por m³) = (115 − RQD) / 3.3  (relación de Palmström, RQD = 115 − 3.3·Jv).

Consumo específico y constante de roca
    Ashby (1977), con φ + i ≈ (GSI + 15)/2 como se usa en el diseño de túneles:
        CE = 0.56·ρr·tan((GSI + 15)/2) / ∛Jv                    [kg/m³]
    Constante de roca sueca a partir del consumo específico (BISTUA, 2021, Ec. 13):
        c = 0.8784·CE + 0.052                                   [kg/m³]

Efecto en la malla
    - Arranque: c entra directamente en la Ec. 4 (carga necesaria / burden del arranque).
    - Resto del frente: el burden de Olofsson (B = 30·qb/dh) corresponde a una roca de
      referencia con c = 0.4. Se corrige con la dependencia de Langefors, B ∝ 1/√c̄:
          B_roca = B · √(0.45 / c̄) ,  c̄ = c + 0.05
      (corrección propia de este programa a partir de esa dependencia; PENDIENTE DE VALIDAR).

Comparación (no se usa para colocar taladros)
    EXSA, Manual Práctico de Voladura: N° taladros = P/dt + k·S, P = 4·√S
        dura: dt = 0.5 m, k = 2.0 · semidura: 0.6 m, 1.5 · blanda: 0.7 m, 1.0

Límites
    Correlaciones empíricas; calibra con disparos reales de tu mina.
"""

import math

from app.calc.carga import ErrorDeDatos

CLASES_RMR = [  # (mínimo, clase, descripción)
    (81, "I", "Muy buena"),
    (61, "II", "Buena"),
    (41, "III", "Regular"),
    (21, "IV", "Mala"),
    (0, "V", "Muy mala"),
]
# Dureza EXSA asumida por clase RMR (supuesto de este programa; se puede cambiar en la ventana)
DUREZA_POR_CLASE = {"I": "Dura", "II": "Dura", "III": "Semidura", "IV": "Blanda", "V": "Blanda"}
TABLA_EXSA = {"Dura": (0.5, 2.0), "Semidura": (0.6, 1.5), "Blanda": (0.7, 1.0)}  # dt (m), k
C_REFERENCIA = 0.4


def clase_rmr(rmr: float) -> tuple[str, str]:
    if not 0 <= rmr <= 100:
        raise ErrorDeDatos("El RMR debe estar entre 0 y 100")
    for minimo, clase, descripcion in CLASES_RMR:
        if rmr >= minimo:
            return clase, descripcion
    return "V", "Muy mala"


def gsi_desde_rmr(rmr: float) -> float:
    return max(rmr - 5, 0.0)


def juntas_por_m3(rqd: float) -> float:
    if not 0 <= rqd <= 100:
        raise ErrorDeDatos("El RQD debe estar entre 0 y 100 %")
    return (115 - rqd) / 3.3


def consumo_especifico_ashby(densidad_roca: float, gsi: float, rqd: float) -> float:
    if densidad_roca <= 0:
        raise ErrorDeDatos("La densidad de la roca debe ser mayor que cero")
    if not 0 <= gsi <= 100:
        raise ErrorDeDatos("El GSI debe estar entre 0 y 100")
    return 0.56 * densidad_roca * math.tan(math.radians((gsi + 15) / 2)) / juntas_por_m3(rqd) ** (1 / 3)


def constante_roca(consumo_especifico: float) -> float:
    return 0.8784 * consumo_especifico + 0.052


def factor_burden_roca(c: float) -> float:
    """Corrección del burden de Olofsson por la roca: √(0.45 / c̄)."""
    if c <= 0:
        raise ErrorDeDatos("La constante de roca debe ser mayor que cero")
    return math.sqrt((C_REFERENCIA + 0.05) / (c + 0.05))


def taladros_exsa(area_m2: float, dureza: str) -> tuple[float, float, int]:
    """(perímetro P, dt, N° de taladros) según EXSA."""
    dt, k = TABLA_EXSA[dureza]
    perimetro = 4 * math.sqrt(area_m2)
    return perimetro, dt, math.ceil(perimetro / dt + k * area_m2)
