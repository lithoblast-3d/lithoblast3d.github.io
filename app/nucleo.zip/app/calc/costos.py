"""
Costos del ciclo de minado (perforación, voladura, ventilación, desatado, limpieza,
carguío y transporte, sostenimiento).

Costo horario de un equipo (método de costos de propiedad + operación):
  Amortización          A  = (pa − vr − vn) / vu            [$/h]
  Inversión media       Im = pa · (n + 1) / (2n)
  Interés y seguros     Is = Im · (i + s) / ha               [$/h]
  Reparaciones          Rp = Frep · (pa − vn) / vu            [$/h]   (Frep ≈ 0.7–1.1)
  Neumáticos/recambio   Nm = vn / vn_vida                    [$/h]
  Energía o combustible E  = consumo/h · precio
  pa precio de adquisición, vr valor residual, vn valor de neumáticos/recambios, vu vida útil [h],
  n años de amortización, ha horas trabajadas por año, i interés anual, s seguros anual.

Costo de una tarea = Σ personal (n · salario/h · horas) + Σ equipos (costo horario · horas)
                     + materiales.
Los valores por defecto son EJEMPLOS editables (cada mina tiene sus precios).
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Equipo:
    nombre: str
    precio: float  # pa
    valor_residual_pct: float = 20.0
    neumaticos: float = 0.0  # vn
    vida_neumaticos_h: float = 2000.0
    vida_util_h: float = 10000.0
    anios: float = 5.0
    horas_anio: float = 2000.0
    interes_pct: float = 10.0
    seguro_pct: float = 2.0
    factor_reparacion: float = 0.8
    consumo_h: float = 0.0  # gal/h o kWh/h
    precio_energia: float = 0.0  # $/gal o $/kWh

    def costo_horario(self) -> dict:
        vr = self.precio * self.valor_residual_pct / 100
        a = (self.precio - vr - self.neumaticos) / self.vida_util_h
        im = self.precio * (self.anios + 1) / (2 * self.anios)
        isg = im * (self.interes_pct + self.seguro_pct) / 100 / self.horas_anio
        rp = self.factor_reparacion * (self.precio - self.neumaticos) / self.vida_util_h
        nm = self.neumaticos / self.vida_neumaticos_h if self.vida_neumaticos_h else 0.0
        en = self.consumo_h * self.precio_energia
        d = {"Amortización": a, "Interés y seguros": isg, "Reparaciones": rp, "Neumáticos/recambios": nm,
             "Energía/combustible": en}
        d["Total"] = sum(d.values())
        return d


@dataclass
class Tarea:
    nombre: str
    horas: float = 1.0
    trabajadores: int = 1
    salario_h: float = 5.0
    equipos: list[tuple[str, float]] = field(default_factory=list)  # (nombre del equipo, horas)
    materiales: list[tuple[str, float, float]] = field(default_factory=list)  # (nombre, cantidad, precio unitario)

    def costo(self, catalogo: dict[str, Equipo]) -> dict:
        personal = self.trabajadores * self.salario_h * self.horas
        eq = sum(catalogo[n].costo_horario()["Total"] * h for n, h in self.equipos if n in catalogo)
        mat = sum(c * p for _, c, p in self.materiales)
        return {"Personal": personal, "Equipos": eq, "Materiales": mat, "Total": personal + eq + mat}


def resumen(tareas: list[Tarea], catalogo: dict[str, Equipo], avance_m: float, volumen_m3: float,
            toneladas: float) -> dict:
    filas = []
    total = 0.0
    for t in tareas:
        c = t.costo(catalogo)
        filas.append((t.nombre, c))
        total += c["Total"]
    return {
        "filas": filas, "total": total,
        "por_m": total / avance_m if avance_m > 0 else None,
        "por_m3": total / volumen_m3 if volumen_m3 > 0 else None,
        "por_t": total / toneladas if toneladas > 0 else None,
    }


def ejemplo(kg_explosivo: float = 30.0, n_detonadores: int = 40, metros_perforados: float = 70.0) -> tuple[list, dict]:
    """Datos de EJEMPLO (editables) para empezar; usa las cantidades del proyecto si se pasan."""
    catalogo = {
        "Perforadora neumática": Equipo("Perforadora neumática", 6500, neumaticos=0, vida_util_h=4000, anios=3,
                                        horas_anio=1500),
        "Compresora diésel": Equipo("Compresora diésel", 45000, neumaticos=1200, vida_neumaticos_h=3000,
                                    vida_util_h=15000, anios=6, consumo_h=3.0, precio_energia=4.5),
        "Ventilador": Equipo("Ventilador", 8000, vida_util_h=20000, anios=8, consumo_h=15.0, precio_energia=0.12),
        "Scoop (LHD)": Equipo("Scoop (LHD)", 380000, neumaticos=24000, vida_neumaticos_h=2500, vida_util_h=20000,
                              anios=7, consumo_h=4.0, precio_energia=4.5),
        "Lanzadora de concreto": Equipo("Lanzadora de concreto", 120000, vida_util_h=15000, anios=6),
    }
    tareas = [
        Tarea("Perforación", horas=3.0, trabajadores=2, salario_h=6.0,
              equipos=[("Perforadora neumática", 3.0), ("Compresora diésel", 3.0)],
              materiales=[("Barra y broca (desgaste por metro)", metros_perforados, 0.9)]),
        Tarea("Voladura", horas=1.5, trabajadores=2, salario_h=6.0,
              materiales=[("Explosivo (kg)", kg_explosivo, 4.0), ("Detonadores", n_detonadores, 2.8),
                          ("Cordón / mecha (m)", 10, 0.6)]),
        Tarea("Ventilación", horas=1.0, trabajadores=0, equipos=[("Ventilador", 1.0)]),
        Tarea("Desatado", horas=0.5, trabajadores=2, salario_h=6.0),
        Tarea("Limpieza y carguío", horas=2.0, trabajadores=1, salario_h=7.0, equipos=[("Scoop (LHD)", 2.0)]),
        Tarea("Sostenimiento", horas=1.5, trabajadores=2, salario_h=6.0, equipos=[("Lanzadora de concreto", 1.0)],
              materiales=[("Pernos", 6, 18.0), ("Concreto lanzado (m³)", 0.8, 160.0)]),
    ]
    return tareas, catalogo
