"""
Cimbra (arco de acero) de sostenimiento: análisis por el método de rigidez (pórtico plano).

Geometría: dos patas rectas (hastiales) de altura hw y un arco circular de radio R = ancho/2
(o bóveda rebajada con flecha f). El arco se divide en elementos rectos; cada elemento es
una viga-columna de 3 g.d.l. por nudo (u, w, θ) con rigidez axial EA/L y de flexión EI/L³.
Apoyos en el piso: empotrados o articulados.

Carga de roca sobre la cimbra (presión vertical uniforme, en proyección horizontal):
    hp = (100 − RMR) / 100 · B         (Unal 1983)   B = ancho de la excavación
    q  = γ · hp · s                    s = espaciamiento entre cimbras  [kN/m]
Carga lateral opcional: qh = K · q sobre los hastiales.

Verificación: σ = N/A + |M|/W ≤ fy  (tensiones normales, sin pandeo ni efecto del bloqueo).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

# Perfiles W (AISC). A [cm²], Ix [cm⁴], Sx [cm³], peso [kg/m]
PERFILES = {
    "W4x13": (24.7, 470.0, 89.5, 19.3),
    "W5x16": (30.2, 886.0, 140.0, 23.8),
    "W6x15": (28.6, 1210.0, 157.0, 22.5),
    "W6x20": (37.9, 1720.0, 220.0, 29.8),
    "W6x25": (47.4, 2210.0, 275.0, 37.1),
    "W8x31": (58.9, 4580.0, 451.0, 46.1),
}


@dataclass
class EntradaCimbra:
    ancho: float = 4.0  # m
    alto: float = 4.0  # m (piso a clave)
    perfil: str = "W6x20"
    e_gpa: float = 200.0
    fy_mpa: float = 250.0  # A36
    espaciamiento: float = 1.0  # m entre cimbras
    rmr: float = 45.0
    peso_unitario: float = 27.0  # kN/m³
    k_lateral: float = 0.0  # qh/q
    apoyos: str = "empotrados"  # o "articulados"
    n_arco: int = 16
    n_pata: int = 4
    carga_manual: float | None = None  # kN/m (si se indica reemplaza a Unal)


@dataclass
class ResultadoCimbra:
    nudos: np.ndarray
    elementos: list[tuple[int, int]]
    desplazamientos: np.ndarray  # (n, 3)
    fuerzas: list[np.ndarray]  # por elemento: [N1, V1, M1, N2, V2, M2] (locales)
    hp: float
    q: float
    n_max: float  # kN (compresión positiva)
    m_max: float  # kN·m
    sigma_max: float  # MPa
    utilizacion: float
    reacciones: np.ndarray


def geometria(e: EntradaCimbra):
    R = e.ancho / 2
    hw = e.alto - R
    if hw < 0:
        raise ValueError("El alto debe ser al menos la mitad del ancho (arco semicircular)")
    nudos = []
    for k in range(e.n_pata + 1):
        nudos.append((-R, hw * k / e.n_pata))
    for k in range(1, e.n_arco):
        a = math.pi - math.pi * k / e.n_arco
        nudos.append((R * math.cos(a), hw + R * math.sin(a)))
    for k in range(e.n_pata, -1, -1):
        nudos.append((R, hw * k / e.n_pata))
    nudos = np.array(nudos)
    elementos = [(i, i + 1) for i in range(len(nudos) - 1)]
    return nudos, elementos


def analizar(e: EntradaCimbra) -> ResultadoCimbra:
    A_cm2, I_cm4, S_cm3, _ = PERFILES[e.perfil]
    E = e.e_gpa * 1e6  # kN/m²
    A = A_cm2 * 1e-4; I = I_cm4 * 1e-8; W = S_cm3 * 1e-6
    nudos, elementos = geometria(e)
    n = len(nudos)
    K = np.zeros((3 * n, 3 * n)); F = np.zeros(3 * n)
    hp = (100 - e.rmr) / 100 * e.ancho
    q = e.carga_manual if e.carga_manual is not None else e.peso_unitario * hp * e.espaciamiento
    qh = e.k_lateral * q
    datos = []
    for (i, j) in elementos:
        (x1, y1), (x2, y2) = nudos[i], nudos[j]
        L = math.hypot(x2 - x1, y2 - y1)
        c, s = (x2 - x1) / L, (y2 - y1) / L
        kl = np.array([
            [E * A / L, 0, 0, -E * A / L, 0, 0],
            [0, 12 * E * I / L ** 3, 6 * E * I / L ** 2, 0, -12 * E * I / L ** 3, 6 * E * I / L ** 2],
            [0, 6 * E * I / L ** 2, 4 * E * I / L, 0, -6 * E * I / L ** 2, 2 * E * I / L],
            [-E * A / L, 0, 0, E * A / L, 0, 0],
            [0, -12 * E * I / L ** 3, -6 * E * I / L ** 2, 0, 12 * E * I / L ** 3, -6 * E * I / L ** 2],
            [0, 6 * E * I / L ** 2, 2 * E * I / L, 0, -6 * E * I / L ** 2, 4 * E * I / L]])
        T = np.zeros((6, 6))
        T[:3, :3] = T[3:, 3:] = [[c, s, 0], [-s, c, 0], [0, 0, 1]]
        kg = T.T @ kl @ T
        idx = [3 * i, 3 * i + 1, 3 * i + 2, 3 * j, 3 * j + 1, 3 * j + 2]
        K[np.ix_(idx, idx)] += kg
        # carga vertical por proyección horizontal (solo arco) y lateral por proyección vertical (patas y arco)
        dx, dy = abs(x2 - x1), abs(y2 - y1)
        fv = -q * dx if max(y1, y2) > nudos[e.n_pata][1] + 1e-9 else 0.0
        lado = -1 if (x1 + x2) / 2 < 0 else 1
        fh = -lado * qh * dy  # empuja hacia el interior
        # fuerzas nodales equivalentes (reparto simple + momentos de empotramiento perfecto)
        fe_global = np.array([fh / 2, fv / 2, 0, fh / 2, fv / 2, 0])
        F[idx] += fe_global
        datos.append((idx, kl, T, fe_global))
    apoyos = [0, n - 1]
    fijos = []
    for a in apoyos:
        fijos += [3 * a, 3 * a + 1] + ([3 * a + 2] if e.apoyos == "empotrados" else [])
    libres = [k for k in range(3 * n) if k not in fijos]
    d = np.zeros(3 * n)
    d[libres] = np.linalg.solve(K[np.ix_(libres, libres)], F[libres])
    reacciones = K @ d - F
    fuerzas = []
    for idx, kl, T, fe in datos:
        f_local = kl @ (T @ d[idx]) - T @ fe
        fuerzas.append(f_local)
    n_max = max(max(f[0], -f[3]) for f in fuerzas)  # compresión positiva
    m_max = max(max(abs(f[2]), abs(f[5])) for f in fuerzas)
    sig = max(max(abs(f[0]) / A + abs(f[2]) / W, abs(f[3]) / A + abs(f[5]) / W) for f in fuerzas) / 1000.0
    return ResultadoCimbra(nudos=nudos, elementos=elementos, desplazamientos=d.reshape(-1, 3), fuerzas=fuerzas,
                           hp=hp, q=q, n_max=n_max, m_max=m_max, sigma_max=sig, utilizacion=sig / e.fy_mpa,
                           reacciones=reacciones.reshape(-1, 3)[apoyos])
