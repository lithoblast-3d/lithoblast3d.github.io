"""
Respuesta de un sistema de un grado de libertad (estructura, talud, sostenimiento…) ante un
registro de aceleración (sismo o vibración de voladura).

Método de Newmark-β (Newmark 1959; Chopra, «Dynamics of Structures», cap. 5):
  γ = 1/2, β = 1/4 → aceleración promedio (incondicionalmente estable).
  m·ü + c·u̇ + k·u = −m·üg(t),  ω = 2π/T,  c = 2ξmω, k = mω²  (m = 1).
Espectro de respuesta: Sd = máx|u|, Sv = ω·Sd, Sa = ω²·Sd (pseudo-espectros).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

G = 9.81


@dataclass
class Respuesta:
    t: np.ndarray
    u: np.ndarray  # m
    v: np.ndarray  # m/s
    a_abs: np.ndarray  # m/s² (aceleración absoluta = ü + üg)


def newmark_sdof(ag_ms2, dt: float, periodo: float, xi: float, gamma: float = 0.5, beta: float = 0.25) -> Respuesta:
    ag = np.asarray(ag_ms2, float)
    if periodo <= 0 or dt <= 0:
        raise ValueError("El periodo y el paso de tiempo deben ser mayores que cero")
    w = 2 * math.pi / periodo
    m, k, c = 1.0, w * w, 2 * xi * w
    n = len(ag)
    u = np.zeros(n); v = np.zeros(n); a = np.zeros(n)
    a[0] = (-m * ag[0] - c * v[0] - k * u[0]) / m
    a1 = m / (beta * dt * dt) + gamma * c / (beta * dt)
    a2 = m / (beta * dt) + (gamma / beta - 1) * c
    a3 = (1 / (2 * beta) - 1) * m + dt * (gamma / (2 * beta) - 1) * c
    k_ = k + a1
    for i in range(n - 1):
        p = -m * ag[i + 1] + a1 * u[i] + a2 * v[i] + a3 * a[i]
        u[i + 1] = p / k_
        v[i + 1] = (gamma / (beta * dt)) * (u[i + 1] - u[i]) + (1 - gamma / beta) * v[i] \
            + dt * (1 - gamma / (2 * beta)) * a[i]
        a[i + 1] = (u[i + 1] - u[i]) / (beta * dt * dt) - v[i] / (beta * dt) - (1 / (2 * beta) - 1) * a[i]
    return Respuesta(t=np.arange(n) * dt, u=u, v=v, a_abs=a + ag)


def espectro(ag_ms2, dt: float, periodos, xi: float):
    """(T, Sd [m], Sv [m/s], Sa [m/s²])."""
    T = np.asarray(periodos, float)
    sd = np.array([np.max(np.abs(newmark_sdof(ag_ms2, dt, p, xi).u)) for p in T])
    w = 2 * np.pi / T
    return T, sd, w * sd, w * w * sd


def registro_sintetico(duracion: float = 1.0, dt: float = 0.001, frecuencia: float = 30.0, ppv_mm_s: float = 20.0,
                       n_retardos: int = 8, intervalo_ms: float = 25.0, semilla: int = 3):
    """Registro de EJEMPLO de vibración de voladura: suma de pulsos amortiguados (uno por retardo)
    con frecuencia dominante dada, escalado a la PPV pedida. Devuelve (t, aceleración m/s², velocidad mm/s)."""
    rng = np.random.default_rng(semilla)
    t = np.arange(0, duracion, dt)
    vel = np.zeros_like(t)
    for k in range(n_retardos):
        t0 = 0.02 + k * intervalo_ms / 1000
        f = frecuencia * rng.uniform(0.8, 1.25)
        amort = rng.uniform(25, 45)
        tau = np.clip(t - t0, 0, None)
        vel += np.where(t >= t0, rng.uniform(0.6, 1.0) * np.exp(-amort * tau) * np.sin(2 * np.pi * f * tau), 0.0)
    vel *= ppv_mm_s / (np.max(np.abs(vel)) or 1)
    acel = np.gradient(vel / 1000.0, dt)
    return t, acel, vel


def leer_registro_csv(texto: str):
    """Columnas: tiempo [s] y aceleración [g] (separador , ; o tabulación). Devuelve (dt, aceleración m/s²)."""
    t, a = [], []
    for linea in texto.splitlines():
        partes = [p for p in linea.replace(";", " ").replace(",", " ").replace("\t", " ").split() if p]
        if len(partes) < 2:
            continue
        try:
            t.append(float(partes[0])); a.append(float(partes[1]))
        except ValueError:
            continue
    if len(t) < 3:
        raise ValueError("El archivo debe tener al menos 3 filas con tiempo (s) y aceleración (g)")
    dt = float(np.median(np.diff(t)))
    return dt, np.array(a) * G
