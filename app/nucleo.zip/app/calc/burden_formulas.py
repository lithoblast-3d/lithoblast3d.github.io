"""
Comparador de fórmulas empíricas de burden para bancos (recopilación de López Jimeno et al.,
«Manual de perforación y voladura de rocas»). Unidades de cada autor convertidas a metros.

- Andersen (1952):     B[ft] = K·√(D[in]·L[ft]),  K ≈ 1
- Ash (1963):          B[ft] = Kb·D[in]/12,  Kb según roca y explosivo (20–40)
- Konya (1972):        B[ft] = 3.15·De[in]·(ρe/ρr)^(1/3)
- Konya (1983):        B[ft] = (2·ρe/ρr + 1.5)·De[in]
- López Jimeno (1980): B[m] = 0.76·D[in]·F,  F = fr·fe
                       fr = (2.7·3500/(ρr·VC))^0.33,  fe = (ρe·VD²/(1.3·3660²))^0.33
                       (válida para D entre 165 y 250 mm)
- Rustan (1990):       B[m] = 18.1·D[m]^0.689   (cielo abierto, D 89–311 mm)
                       B[m] = 11.8·D[m]^0.630   (subterráneo, D 48–100 mm)
- Olofsson (1990):     Bmax[m] = K·√(q)·R1·R2,  K: dinamitas 1.47, emulsiones 1.45, ANFO 1.36;
                       q [kg/m] carga lineal de fondo; R1 por inclinación, R2 por constante de roca c.
- Pearse (1955):       B[m] = K·10⁻³·D[mm]·√(PD/RT),  K 0.7–1.0; PD = ρe·VD²/4 presión de detonación,
                       RT resistencia a la tracción de la roca (mismas unidades)
- Langefors (1968):    Bmax[m] = (D[mm]/33)·√(ρe·PRP / (c̄·f·E/B)),  c̄ = c + 0.05, f = 1 vertical
                       (0.9 a 3:1, 0.85 a 2:1), E/B = 1.25
Los valores son puntos de partida para comparar; el burden final se ajusta con pruebas.
"""

from __future__ import annotations

import math

FT = 0.3048
IN = 0.0254

R1_OLOFSSON = {"Vertical": 0.95, "10:1": 0.96, "5:1": 0.98, "3:1": 1.00, "2:1": 1.03, "1:1": 1.10}
R2_OLOFSSON = {0.3: 1.15, 0.4: 1.00, 0.5: 0.90}
K_OLOFSSON = {"Dinamita / gelatina": 1.47, "Emulsión": 1.45, "ANFO": 1.36}


def andersen(d_mm: float, l_m: float, k: float = 1.0) -> float:
    return k * math.sqrt(d_mm / 25.4 * l_m / FT) * FT


def ash(d_mm: float, kb: float = 30.0) -> float:
    return kb * d_mm / 25.4 / 12 * FT


def konya_1972(de_mm: float, rho_e: float, rho_r: float) -> float:
    return 3.15 * de_mm / 25.4 * (rho_e / rho_r) ** (1 / 3) * FT


def konya_1983(de_mm: float, rho_e: float, rho_r: float) -> float:
    return (2 * rho_e / rho_r + 1.5) * de_mm / 25.4 * FT


def lopez_jimeno(d_mm: float, rho_r: float, vc_ms: float, rho_e: float, vd_ms: float) -> float:
    fr = (2.7 * 3500 / (rho_r * vc_ms)) ** 0.33
    fe = (rho_e * vd_ms ** 2 / (1.3 * 3660 ** 2)) ** 0.33
    return 0.76 * d_mm / 25.4 * fr * fe


def rustan(d_mm: float, subterraneo: bool = False) -> float:
    d = d_mm / 1000
    return 11.8 * d ** 0.630 if subterraneo else 18.1 * d ** 0.689


def olofsson(q_kg_m: float, explosivo: str, inclinacion: str, c: float) -> float:
    c_ref = min(R2_OLOFSSON, key=lambda k: abs(k - c))
    return K_OLOFSSON[explosivo] * math.sqrt(q_kg_m) * R1_OLOFSSON[inclinacion] * R2_OLOFSSON[c_ref]


F_LANGEFORS = {"Vertical": 1.0, "10:1": 0.98, "5:1": 0.95, "3:1": 0.9, "2:1": 0.85, "1:1": 0.75}


def pearse(d_mm: float, rho_e: float, vd_ms: float, rt_mpa: float, k: float = 0.85) -> float:
    pd_mpa = rho_e * 1000 * vd_ms ** 2 / 4 / 1e6
    return k * 1e-3 * d_mm * math.sqrt(pd_mpa / rt_mpa)


def langefors(d_mm: float, rho_e: float, prp: float, c: float, inclinacion: str = "Vertical",
              e_sobre_b: float = 1.25) -> float:
    return d_mm / 33 * math.sqrt(rho_e * prp / ((c + 0.05) * F_LANGEFORS.get(inclinacion, 1.0) * e_sobre_b))


def comparar(d_mm: float, altura_m: float, rho_e: float, rho_r: float, vd_ms: float, vc_ms: float,
             kb_ash: float, q_kg_m: float, explosivo: str = "ANFO", inclinacion: str = "Vertical",
             c: float = 0.4, rt_mpa: float = 10.0, prp: float = 1.0) -> list[tuple[str, float, str]]:
    long_barreno = altura_m * 1.1
    filas = [
        ("Andersen (1952)", andersen(d_mm, long_barreno), "B = √(D·L) [ft, in]"),
        ("Ash (1963)", ash(d_mm, kb_ash), f"B = Kb·D/12, Kb = {kb_ash:g}"),
        ("Konya (1972)", konya_1972(d_mm, rho_e, rho_r), "B = 3.15·De·(ρe/ρr)^⅓"),
        ("Konya (1983)", konya_1983(d_mm, rho_e, rho_r), "B = (2ρe/ρr + 1.5)·De"),
        ("López Jimeno (1980)", lopez_jimeno(d_mm, rho_r, vc_ms, rho_e, vd_ms), "B = 0.76·D·fr·fe"),
        ("Rustan (1990)", rustan(d_mm), "B = 18.1·D^0.689"),
        ("Olofsson (1990)", olofsson(q_kg_m, explosivo, inclinacion, c), "Bmax = K·√q·R1·R2"),
        ("Pearse (1955)", pearse(d_mm, rho_e, vd_ms, rt_mpa), f"B = K·D·√(PD/RT), K 0.85, RT {rt_mpa:g} MPa"),
        ("Langefors (1968)", langefors(d_mm, rho_e, prp, c, inclinacion), "Bmax = (D/33)·√(ρe·PRP/(c̄·f·E/B))"),
    ]
    return filas
