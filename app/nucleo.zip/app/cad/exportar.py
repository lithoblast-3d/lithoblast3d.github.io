"""
Exportación de la malla a DXF (R12, se abre en cualquier AutoCAD/Civil 3D/BricsCAD/QGIS) y a DWG
(convirtiendo ese DXF con ODA File Converter, ver app/cad/dwg.py).

Capas:
  COLLARES        círculo en el collar (símbolo) + punto 3D
  ALIVIOS         taladros sin carga
  TALADROS        eje 3D del taladro (collar → fondo)
  CARGA           tramo cargado (taco → fondo)
  PIE             punto en el fondo
  TXT_ID, TXT_RETARDO, TXT_COTA, TXT_LONGITUD  textos
  SECCION_AREA    contornos / área de voladura
  LEYENDA         resumen
  <capa original> polilíneas de la topografía importada (opcional)
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from app.core.modelo import Contorno, PolilineaCAD, Proyecto

# (nombre, color ACI)
CAPAS = [("COLLARES", 4), ("ALIVIOS", 8), ("TALADROS", 5), ("CARGA", 1), ("PIE", 6), ("TXT_ID", 7),
         ("TXT_RETARDO", 2), ("TXT_COTA", 3), ("TXT_LONGITUD", 30), ("SECCION_AREA", 140), ("LEYENDA", 7)]

VISTAS = ["Coordenadas reales 3D (planta)", "Vista del frente 2D (plano de la malla)"]


@dataclass
class OpcionesExportar:
    vista: str = VISTAS[0]
    radio_simbolo: float = 0.0  # m; 0 = automático (escala con la malla)
    altura_texto: float = 0.0  # m; 0 = automático
    textos_id: bool = True
    textos_retardo: bool = True
    textos_cota: bool = True
    textos_longitud: bool = False
    contornos: bool = True
    topografia: bool = True
    leyenda: bool = True


class _Dxf:
    def __init__(self):
        self.l: list[str] = []
        self.capas_extra: dict[str, int] = {}
        self.min = np.array([np.inf] * 3)
        self.max = np.array([-np.inf] * 3)

    def _ext(self, *pts):
        for p in pts:
            p = np.asarray(p, float)
            self.min = np.minimum(self.min, p)
            self.max = np.maximum(self.max, p)

    def g(self, *pares):
        for c, v in pares:
            self.l += [str(c), v if isinstance(v, str) else f"{v:.4f}" if isinstance(v, float) else str(v)]

    def punto(self, capa, p):
        self._ext(p)
        self.g((0, "POINT"), (8, capa), (10, float(p[0])), (20, float(p[1])), (30, float(p[2])))

    def linea(self, capa, a, b):
        self._ext(a, b)
        self.g((0, "LINE"), (8, capa), (10, float(a[0])), (20, float(a[1])), (30, float(a[2])),
               (11, float(b[0])), (21, float(b[1])), (31, float(b[2])))

    def circulo(self, capa, c, r):
        self._ext((c[0] - r, c[1] - r, c[2]), (c[0] + r, c[1] + r, c[2]))
        self.g((0, "CIRCLE"), (8, capa), (10, float(c[0])), (20, float(c[1])), (30, float(c[2])), (40, float(r)))

    def polilinea(self, capa, pts, cerrada=False):
        if len(pts) < 2:
            return
        self._ext(*pts)
        self.g((0, "POLYLINE"), (8, capa), (66, 1), (70, 8 | (1 if cerrada else 0)), (10, 0.0), (20, 0.0), (30, 0.0))
        for p in pts:
            self.g((0, "VERTEX"), (8, capa), (10, float(p[0])), (20, float(p[1])), (30, float(p[2])), (70, 32))
        self.g((0, "SEQEND"), (8, capa))

    def texto(self, capa, p, h, s, desp=(0.0, 0.0)):
        x, y = p[0] + desp[0], p[1] + desp[1]
        self._ext((x, y, p[2]))
        self.g((0, "TEXT"), (8, capa), (10, float(x)), (20, float(y)), (30, float(p[2])), (40, float(h)), (1, str(s)))

    def texto_capa(self, nombre: str) -> str:
        limpio = "".join(ch if ch.isalnum() or ch in "-_$" else "_" for ch in nombre)[:31] or "CAPA"
        self.capas_extra.setdefault(limpio, 8)
        return limpio

    def documento(self) -> str:
        mn = np.where(np.isfinite(self.min), self.min, 0)
        mx = np.where(np.isfinite(self.max), self.max, 1)
        cab = ["0", "SECTION", "2", "HEADER",
               "9", "$ACADVER", "1", "AC1009",
               "9", "$DWGCODEPAGE", "3", "ANSI_1252",
               "9", "$EXTMIN", "10", f"{mn[0]:.4f}", "20", f"{mn[1]:.4f}", "30", f"{mn[2]:.4f}",
               "9", "$EXTMAX", "10", f"{mx[0]:.4f}", "20", f"{mx[1]:.4f}", "30", f"{mx[2]:.4f}",
               "0", "ENDSEC",
               "0", "SECTION", "2", "TABLES",
               "0", "TABLE", "2", "LTYPE", "70", "1",
               "0", "LTYPE", "2", "CONTINUOUS", "70", "0", "3", "Solid line", "72", "65", "73", "0", "40", "0.0",
               "0", "ENDTAB"]
        capas = CAPAS + list(self.capas_extra.items())
        cab += ["0", "TABLE", "2", "LAYER", "70", str(len(capas) + 1),
                "0", "LAYER", "2", "0", "70", "0", "62", "7", "6", "CONTINUOUS"]
        for nombre, color in capas:
            cab += ["0", "LAYER", "2", nombre, "70", "0", "62", str(color), "6", "CONTINUOUS"]
        cab += ["0", "ENDTAB", "0", "ENDSEC", "0", "SECTION", "2", "ENTITIES"]
        return "\n".join(cab + self.l + ["0", "ENDSEC", "0", "EOF"]) + "\n"


def _base_frente(pozos):
    """Ejes del plano del frente: horizontal (u) y cota; origen en el centro de los collares."""
    xy = np.array([[p.x, p.y] for p in pozos])
    centro = xy.mean(axis=0)
    _, s, vt = np.linalg.svd(xy - centro)
    eje = vt[0] if len(s) and s[0] > 1e-6 else np.array([1.0, 0.0])
    if eje[0] < 0:
        eje = -eje
    z0 = min(p.z for p in pozos)
    return lambda x, y, z: (float(np.dot([x - centro[0], y - centro[1]], eje)), float(z - z0), 0.0)


def dxf_de_proyecto(proyecto: Proyecto, op: OpcionesExportar | None = None) -> str:
    op = op or OpcionesExportar()
    pozos = proyecto.perforaciones()
    d = _Dxf()
    frente = op.vista == VISTAS[1]
    if frente and not pozos:
        raise ValueError("No hay taladros para la vista del frente")
    transf = _base_frente(pozos) if frente else (lambda x, y, z: (x, y, z))

    # escala de símbolos y textos según la separación típica
    if len(pozos) > 1:
        P = np.array([[p.x, p.y, p.z] for p in pozos])
        dmin = [np.partition(np.linalg.norm(P - q, axis=1), 1)[1] for q in P[: min(len(P), 300)]]
        sep = float(np.median(dmin)) or 1.0
    else:
        sep = 1.0
    r_sim = op.radio_simbolo or max(sep * 0.12, 0.02)
    h_txt = op.altura_texto or max(sep * 0.16, 0.03)

    for p in pozos:
        c = transf(*p.collar())
        f = transf(*p.fondo())
        cargado = p.explosivo_id is not None and proyecto.explosivo(p.explosivo_id) is not None
        capa = "COLLARES" if cargado else "ALIVIOS"
        if frente:
            r = (p.diametro_mm / 2000) if not cargado and p.diametro_mm > 60 else r_sim
            d.circulo(capa, c, r)
            if cargado:
                d.circulo(capa, c, max(r_sim * 0.25, p.diametro_mm / 2000))
        else:
            if p.inclinacion >= 80:
                d.circulo(capa, c, r_sim)
            else:  # círculo en el plano perpendicular al eje (polilínea 3D)
                ax = np.array(p.direccion())
                a = np.cross(ax, [0, 0, 1.0])
                a = a / (np.linalg.norm(a) or 1)
                b = np.cross(ax, a)
                pts = [tuple(np.array(c) + r_sim * (math.cos(t) * a + math.sin(t) * b))
                       for t in np.linspace(0, 2 * math.pi, 25)]
                d.polilinea(capa, pts)
            d.punto(capa, c)
            d.linea("TALADROS", c, f)
            if cargado and p.longitud > p.taco:
                k = p.taco / p.longitud if p.longitud else 0
                ini = tuple(np.array(c) + k * (np.array(f) - np.array(c)))
                d.linea("CARGA", ini, f)
            d.punto("PIE", f)
        dx = r_sim * 1.2
        if op.textos_id:
            d.texto("TXT_ID", c, h_txt, p.nombre or p.id, (dx, dx * 0.2))
        if op.textos_retardo and p.retardo:
            d.texto("TXT_RETARDO", c, h_txt, str(p.retardo), (dx, -h_txt - dx * 0.2))
        if op.textos_cota and not frente:
            d.texto("TXT_COTA", c, h_txt * 0.7, f"{p.z:.2f}", (-2.0 * h_txt, -dx - 2.3 * h_txt))
        if op.textos_longitud:
            d.texto("TXT_LONGITUD", c, h_txt * 0.8, f"L={p.longitud:.2f}", (dx, -2.3 * h_txt - dx * 0.2))

    if op.contornos:
        for o in proyecto.objetos.values():
            if isinstance(o, Contorno) and len(o.vertices) >= 3:
                d.polilinea("SECCION_AREA", [transf(*v) for v in o.vertices], cerrada=True)
    if op.topografia and not frente:
        for o in proyecto.objetos.values():
            if isinstance(o, PolilineaCAD) and len(o.vertices) >= 2:
                d.polilinea(d.texto_capa(o.capa_cad or "TOPOGRAFIA"), o.vertices, o.cerrada)
    if op.leyenda and pozos:
        from app.core.resultados import resumen_voladura
        r = resumen_voladura(proyecto)
        x0 = float(d.min[0]) if np.isfinite(d.min[0]) else 0.0
        y0 = float(d.min[1]) if np.isfinite(d.min[1]) else 0.0
        z0 = float(d.min[2]) if np.isfinite(d.min[2]) and not frente else 0.0
        lineas = [f"LITHOBLAST3D - {proyecto.nombre}",
                  f"Taladros: {r.pozos_total}  (cargados {r.pozos_cargados})",
                  f"Explosivo total: {r.carga_total:.1f} kg   Perforacion: {r.metros_perforados:.1f} m"]
        if r.factor_carga:
            lineas.append(f"Factor de carga: {r.factor_carga:.3f} kg/m3")
        dz = proyecto.diseno
        lineas.append(f"Burden {dz.burden:.2f} m x Espaciamiento {dz.espaciamiento:.2f} m")
        for i, t in enumerate(lineas):
            d.texto("LEYENDA", (x0, y0 - (3 + 1.6 * i) * h_txt * 1.5, z0), h_txt * 1.5, t)
    return d.documento()


def exportar_dxf(proyecto: Proyecto, ruta: str | Path, op: OpcionesExportar | None = None) -> Path:
    ruta = Path(ruta)
    ruta.write_text(dxf_de_proyecto(proyecto, op), encoding="cp1252", errors="replace")
    return ruta


def exportar(proyecto: Proyecto, ruta: str | Path, op: OpcionesExportar | None = None,
             version_dwg: str = "ACAD2013") -> Path:
    """Guarda en DXF o DWG según la extensión de «ruta»."""
    ruta = Path(ruta)
    if ruta.suffix.lower() == ".dwg":
        import tempfile
        from app.cad.dwg import convertir_dxf_a_dwg
        tmp = Path(tempfile.mkdtemp(prefix="b3d_exp_")) / (ruta.stem + ".dxf")
        exportar_dxf(proyecto, tmp, op)
        return convertir_dxf_a_dwg(tmp, ruta, version=version_dwg)
    if ruta.suffix.lower() != ".dxf":
        ruta = ruta.with_suffix(".dxf")
    return exportar_dxf(proyecto, ruta, op)
