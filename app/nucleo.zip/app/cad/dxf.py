"""
Lectura de archivos DXF (AutoCAD Drawing Exchange Format) sin dependencias.

Soporta DXF ASCII (R12 a 2018): LINE, LWPOLYLINE (con elevación y bulges),
POLYLINE 2D/3D, malla policara (polyface), 3DFACE, POINT, TEXT/MTEXT (como puntos
con texto, útil para cotas), CIRCLE, ARC, SPLINE (puntos de ajuste o de control:
aproximación) e INSERT (bloques, con escala, rotación y anidamiento).
Si el paquete «ezdxf» está instalado se usa para leer DXF BINARIOS.

Unidades: variable $INSUNITS del encabezado; si no existe (0 = sin unidades),
el usuario elige la unidad al importar. Todo se convierte a metros.

Limitaciones (documentadas también en el LÉEME):
- Entidades no listadas (HATCH, DIMENSION, REGION, sólidos ACIS, etc.) se ignoran
  y se informan en el resumen.
- Vector de extrusión (OCS): solo se corrige el caso (0,0,-1) (espejo en X).
- SPLINE: se dibuja por sus puntos (no se evalúa la NURBS exacta).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path

UNIDADES_INSUNITS = {
    0: ("Sin unidades", None), 1: ("Pulgadas", 0.0254), 2: ("Pies", 0.3048), 3: ("Millas", 1609.344),
    4: ("Milímetros", 0.001), 5: ("Centímetros", 0.01), 6: ("Metros", 1.0), 7: ("Kilómetros", 1000.0),
    10: ("Yardas", 0.9144), 14: ("Decímetros", 0.1),
}

# Colores ACI básicos (1-9); el resto se aproxima con gris
ACI = {1: "#ff0000", 2: "#ffff00", 3: "#00ff00", 4: "#00ffff", 5: "#0000ff", 6: "#ff00ff",
       7: "#ffffff", 8: "#808080", 9: "#c0c0c0"}


class ErrorDXF(Exception):
    pass


@dataclass
class EntidadCAD:
    tipo: str  # "polilinea", "punto", "triangulos", "texto"
    capa: str
    puntos: list[tuple[float, float, float]] = field(default_factory=list)
    cerrada: bool = False
    triangulos: list[tuple[int, int, int]] = field(default_factory=list)
    texto: str = ""
    origen: str = ""  # entidad DXF de origen
    color: int = 256  # 256 = por capa


@dataclass
class DibujoCAD:
    ruta: str
    version: str = ""
    insunits: int = 0
    entidades: list[EntidadCAD] = field(default_factory=list)
    colores_capa: dict[str, int] = field(default_factory=dict)
    ignoradas: dict[str, int] = field(default_factory=dict)
    avisos: list[str] = field(default_factory=list)

    @property
    def unidad(self) -> tuple[str, float | None]:
        return UNIDADES_INSUNITS.get(self.insunits, (f"Código {self.insunits}", None))

    def capas(self) -> dict[str, dict[str, int]]:
        res: dict[str, dict[str, int]] = {}
        for e in self.entidades:
            d = res.setdefault(e.capa, {})
            d[e.tipo] = d.get(e.tipo, 0) + 1
        return dict(sorted(res.items()))

    def extension(self):
        xs = [p[0] for e in self.entidades for p in e.puntos]
        ys = [p[1] for e in self.entidades for p in e.puntos]
        zs = [p[2] for e in self.entidades for p in e.puntos]
        if not xs:
            return None
        return (min(xs), max(xs), min(ys), max(ys), min(zs), max(zs))

    def escalar(self, factor: float) -> None:
        if factor == 1.0:
            return
        for e in self.entidades:
            e.puntos = [(x * factor, y * factor, z * factor) for x, y, z in e.puntos]

    def color_hex(self, capa: str) -> str:
        c = abs(self.colores_capa.get(capa, 7))
        return ACI.get(c, "#9aa3ad")


# ======================================================================= lector
def _pares(texto: str):
    lineas = texto.splitlines()
    n = len(lineas) - len(lineas) % 2
    for i in range(0, n, 2):
        try:
            codigo = int(lineas[i].strip())
        except ValueError as error:
            raise ErrorDXF(f"Línea {i + 1}: se esperaba un código de grupo numérico") from error
        yield codigo, lineas[i + 1].strip()


def _f(v, defecto=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return defecto


def _arco_bulge(p1, p2, bulge, z, segs_por_rad=8):
    """Puntos intermedios de un tramo con bulge (tan(θ/4)) de LWPOLYLINE."""
    (x1, y1), (x2, y2) = p1, p2
    th = 4 * math.atan(bulge)
    c = math.hypot(x2 - x1, y2 - y1)
    if c == 0 or abs(th) < 1e-9:
        return []
    r = c / (2 * math.sin(abs(th) / 2))
    mx, my = (x1 + x2) / 2, (y1 + y2) / 2
    h = math.sqrt(max(r * r - (c / 2) ** 2, 0))
    ux, uy = (x2 - x1) / c, (y2 - y1) / c
    s = 1 if (th > 0) == (abs(th) < math.pi) else -1
    cx, cy = mx - s * uy * h, my + s * ux * h
    a1 = math.atan2(y1 - cy, x1 - cx)
    n = max(2, int(abs(th) * segs_por_rad))
    return [(cx + r * math.cos(a1 + th * k / n), cy + r * math.sin(a1 + th * k / n), z) for k in range(1, n)]


def _circulo(cx, cy, z, r, a0=0.0, a1=360.0, n=48):
    if a1 <= a0:
        a1 += 360.0
    m = max(4, int(n * (a1 - a0) / 360))
    return [(cx + r * math.cos(math.radians(a0 + (a1 - a0) * k / m)),
             cy + r * math.sin(math.radians(a0 + (a1 - a0) * k / m)), z) for k in range(m + 1)]


class _Lector:
    def __init__(self, pares):
        self.p = list(pares)
        self.i = 0

    def fin(self):
        return self.i >= len(self.p)

    def ver(self):
        return self.p[self.i]

    def tomar(self):
        par = self.p[self.i]
        self.i += 1
        return par

    def entidad(self):
        """Lee una entidad completa: (tipo, [(codigo, valor), ...])."""
        c, tipo = self.tomar()
        datos = []
        while not self.fin() and self.ver()[0] != 0:
            datos.append(self.tomar())
        return tipo, datos


def _valores(datos, codigo):
    return [v for c, v in datos if c == codigo]


def _uno(datos, codigo, defecto=None):
    for c, v in datos:
        if c == codigo:
            return v
    return defecto


def leer_dxf(ruta: str | Path) -> DibujoCAD:
    ruta = Path(ruta)
    crudo = ruta.read_bytes()
    if crudo.startswith(b"AutoCAD Binary DXF"):
        return _leer_con_ezdxf(ruta, "El archivo es DXF binario")
    texto = None
    for cod in ("utf-8", "cp1252", "latin-1"):
        try:
            texto = crudo.decode(cod)
            break
        except UnicodeDecodeError:
            continue
    return leer_dxf_texto(texto, str(ruta))


def _leer_con_ezdxf(ruta: Path, motivo: str) -> DibujoCAD:
    try:
        import ezdxf  # noqa: F401
    except ImportError as error:
        raise ErrorDXF(f"{motivo}. Para leerlo instala ezdxf:  pip install ezdxf  "
                       "(o guárdalo como DXF ASCII desde tu programa CAD).") from error
    import io
    import ezdxf
    doc = ezdxf.readfile(str(ruta))
    flujo = io.StringIO()
    doc.write(flujo, fmt="asc")
    return leer_dxf_texto(flujo.getvalue(), str(ruta))


def leer_dxf_texto(texto: str, ruta: str = "") -> DibujoCAD:
    dib = DibujoCAD(ruta=ruta)
    lec = _Lector(_pares(texto))
    bloques: dict[str, list] = {}
    entidades_raiz: list = []
    while not lec.fin():
        c, v = lec.tomar()
        if c == 0 and v == "SECTION":
            _, nombre = lec.tomar()
            if nombre == "HEADER":
                _leer_header(lec, dib)
            elif nombre == "TABLES":
                _leer_tablas(lec, dib)
            elif nombre == "BLOCKS":
                bloques = _leer_bloques(lec)
            elif nombre == "ENTITIES":
                entidades_raiz = _leer_entidades(lec, "ENDSEC")
            else:
                while not lec.fin() and lec.ver() != (0, "ENDSEC"):
                    lec.tomar()
        elif c == 0 and v == "EOF":
            break
    for tipo, datos, hijos in entidades_raiz:
        _convertir(dib, tipo, datos, hijos, bloques, _identidad(), "0", 0)
    if not dib.entidades:
        dib.avisos.append("No se encontraron entidades geométricas compatibles.")
    return dib


def _leer_header(lec, dib):
    var = None
    while not lec.fin():
        c, v = lec.tomar()
        if c == 0 and v == "ENDSEC":
            return
        if c == 9:
            var = v
        elif var == "$INSUNITS" and c == 70:
            dib.insunits = int(_f(v))
        elif var == "$ACADVER" and c == 1:
            dib.version = v


def _leer_tablas(lec, dib):
    tabla = None
    while not lec.fin():
        c, v = lec.tomar()
        if c == 0 and v == "ENDSEC":
            return
        if c == 0 and v == "TABLE":
            tabla = lec.tomar()[1] if lec.ver()[0] == 2 else None
        elif c == 0 and v == "LAYER" and tabla == "LAYER":
            datos = []
            while not lec.fin() and lec.ver()[0] != 0:
                datos.append(lec.tomar())
            nombre = _uno(datos, 2)
            if nombre is not None:
                dib.colores_capa[nombre] = int(_f(_uno(datos, 62, 7)))


def _leer_entidades(lec, fin_marca):
    """Lista de (tipo, datos, hijos) hasta ENDSEC/ENDBLK; agrupa VERTEX en su POLYLINE."""
    res = []
    while not lec.fin():
        c, v = lec.ver()
        if c == 0 and v in (fin_marca, "ENDSEC", "ENDBLK"):
            lec.tomar()
            if v == "ENDBLK":
                while not lec.fin() and lec.ver()[0] != 0:
                    lec.tomar()
            return res
        if c != 0:
            lec.tomar()
            continue
        tipo, datos = lec.entidad()
        hijos = []
        if tipo == "POLYLINE" or (tipo == "INSERT" and _uno(datos, 66) == "1"):
            while not lec.fin():
                t2, d2 = lec.entidad()
                if t2 == "SEQEND":
                    break
                hijos.append((t2, d2))
        res.append((tipo, datos, hijos))
    return res


def _leer_bloques(lec):
    bloques = {}
    while not lec.fin():
        c, v = lec.ver()
        if c == 0 and v == "ENDSEC":
            lec.tomar()
            return bloques
        if c == 0 and v == "BLOCK":
            _, datos = lec.entidad()
            nombre = _uno(datos, 2, "")
            base = (_f(_uno(datos, 10)), _f(_uno(datos, 20)), _f(_uno(datos, 30)))
            ents = _leer_entidades(lec, "ENDBLK")
            bloques[nombre] = (base, ents)
        else:
            lec.tomar()
    return bloques


# ------------------------------------------------------------------- transformaciones
def _identidad():
    return [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0]]


def _mult(a, b):
    # a, b: matrices 3x4 afines
    r = []
    for i in range(3):
        fila = []
        for j in range(4):
            s = sum(a[i][k] * b[k][j] for k in range(3))
            if j == 3:
                s += a[i][3]
            fila.append(s)
        r.append(fila)
    return r


def _aplicar(m, p):
    x, y, z = p
    return (m[0][0] * x + m[0][1] * y + m[0][2] * z + m[0][3],
            m[1][0] * x + m[1][1] * y + m[1][2] * z + m[1][3],
            m[2][0] * x + m[2][1] * y + m[2][2] * z + m[2][3])


def _convertir(dib, tipo, datos, hijos, bloques, m, capa_padre, nivel):
    capa = _uno(datos, 8, capa_padre)
    if capa == "0" and capa_padre != "0":
        capa = capa_padre
    color = int(_f(_uno(datos, 62, 256)))
    ocs_espejo = _f(_uno(datos, 230, 1.0)) < 0

    def P(x, y, z):
        if ocs_espejo:
            x = -x
        return _aplicar(m, (x, y, z))

    def agregar(**kw):
        dib.entidades.append(EntidadCAD(capa=capa, origen=tipo, color=color, **kw))

    if tipo == "LINE":
        agregar(tipo="polilinea", puntos=[P(_f(_uno(datos, 10)), _f(_uno(datos, 20)), _f(_uno(datos, 30))),
                                          P(_f(_uno(datos, 11)), _f(_uno(datos, 21)), _f(_uno(datos, 31)))])
    elif tipo == "LWPOLYLINE":
        z = _f(_uno(datos, 38))
        cerrada = int(_f(_uno(datos, 70, 0))) & 1 == 1
        vert, bulges = [], []
        x = None
        for c, v in datos:
            if c == 10:
                x = _f(v)
            elif c == 20 and x is not None:
                vert.append((x, _f(v)))
                bulges.append(0.0)
                x = None
            elif c == 42 and bulges:
                bulges[-1] = _f(v)
        pts = []
        n = len(vert)
        for k in range(n):
            pts.append((vert[k][0], vert[k][1], z))
            if bulges[k] and (k < n - 1 or cerrada):
                pts.extend(_arco_bulge(vert[k], vert[(k + 1) % n], bulges[k], z))
        if pts:
            agregar(tipo="polilinea", puntos=[P(*q) for q in pts], cerrada=cerrada)
    elif tipo == "POLYLINE":
        flags = int(_f(_uno(datos, 70, 0)))
        elev = _f(_uno(datos, 30))
        if flags & 64:  # malla policara
            vs, caras = [], []
            for t2, d2 in hijos:
                if t2 != "VERTEX":
                    continue
                vf = int(_f(_uno(d2, 70, 0)))
                if vf & 128 and not vf & 64:
                    idx = [abs(int(_f(_uno(d2, c, 0)))) for c in (71, 72, 73, 74)]
                    idx = [i - 1 for i in idx if i > 0]
                    if len(idx) >= 3:
                        caras.append((idx[0], idx[1], idx[2]))
                    if len(idx) == 4:
                        caras.append((idx[0], idx[2], idx[3]))
                else:
                    vs.append(P(_f(_uno(d2, 10)), _f(_uno(d2, 20)), _f(_uno(d2, 30))))
            caras = [c for c in caras if max(c) < len(vs)]
            if vs and caras:
                agregar(tipo="triangulos", puntos=vs, triangulos=caras)
        elif flags & 16:
            dib.avisos.append("Malla poligonal M×N (POLYLINE 16) importada como puntos.")
            pts = [P(_f(_uno(d2, 10)), _f(_uno(d2, 20)), _f(_uno(d2, 30))) for t2, d2 in hijos if t2 == "VERTEX"]
            if pts:
                agregar(tipo="punto", puntos=pts)
        else:
            es3d = bool(flags & 8)
            pts = []
            for t2, d2 in hijos:
                if t2 == "VERTEX":
                    z = _f(_uno(d2, 30)) if es3d else elev
                    pts.append(P(_f(_uno(d2, 10)), _f(_uno(d2, 20)), z))
            if pts:
                agregar(tipo="polilinea", puntos=pts, cerrada=bool(flags & 1))
    elif tipo == "3DFACE":
        q = [P(_f(_uno(datos, 10 + k)), _f(_uno(datos, 20 + k)), _f(_uno(datos, 30 + k))) for k in range(4)]
        tris = [(0, 1, 2)] if q[3] == q[2] else [(0, 1, 2), (0, 2, 3)]
        agregar(tipo="triangulos", puntos=q, triangulos=tris)
    elif tipo == "POINT":
        agregar(tipo="punto", puntos=[P(_f(_uno(datos, 10)), _f(_uno(datos, 20)), _f(_uno(datos, 30)))])
    elif tipo in ("TEXT", "MTEXT"):
        txt = "".join(_valores(datos, 3)) + (_uno(datos, 1, "") or "")
        agregar(tipo="texto", puntos=[P(_f(_uno(datos, 10)), _f(_uno(datos, 20)), _f(_uno(datos, 30)))],
                texto=txt)
    elif tipo in ("CIRCLE", "ARC"):
        cx, cy, z, r = _f(_uno(datos, 10)), _f(_uno(datos, 20)), _f(_uno(datos, 30)), _f(_uno(datos, 40))
        if tipo == "CIRCLE":
            pts = _circulo(cx, cy, z, r)
        else:
            pts = _circulo(cx, cy, z, r, _f(_uno(datos, 50)), _f(_uno(datos, 51)))
        agregar(tipo="polilinea", puntos=[P(*q) for q in pts], cerrada=tipo == "CIRCLE")
    elif tipo == "SPLINE":
        fit = list(zip(map(_f, _valores(datos, 11)), map(_f, _valores(datos, 21)), map(_f, _valores(datos, 31))))
        ctrl = list(zip(map(_f, _valores(datos, 10)), map(_f, _valores(datos, 20)), map(_f, _valores(datos, 30))))
        pts = fit or ctrl
        if pts:
            agregar(tipo="polilinea", puntos=[P(*q) for q in pts])
            dib.ignoradas["SPLINE (aproximada por sus puntos)"] = dib.ignoradas.get(
                "SPLINE (aproximada por sus puntos)", 0) + 1
    elif tipo == "INSERT":
        nombre = _uno(datos, 2, "")
        if nombre not in bloques or nivel > 8:
            dib.ignoradas[f"INSERT {nombre}"] = dib.ignoradas.get(f"INSERT {nombre}", 0) + 1
            return
        base, ents = bloques[nombre]
        ix, iy, iz = _f(_uno(datos, 10)), _f(_uno(datos, 20)), _f(_uno(datos, 30))
        sx, sy, sz = _f(_uno(datos, 41, 1), 1), _f(_uno(datos, 42, 1), 1), _f(_uno(datos, 43, 1), 1)
        rot = math.radians(_f(_uno(datos, 50, 0)))
        c, s = math.cos(rot), math.sin(rot)
        t = [[c * sx, -s * sy, 0, ix], [s * sx, c * sy, 0, iy], [0, 0, sz, iz]]
        t = _mult(t, [[1, 0, 0, -base[0]], [0, 1, 0, -base[1]], [0, 0, 1, -base[2]]])
        m2 = _mult(m, t)
        for tipo2, datos2, hijos2 in ents:
            _convertir(dib, tipo2, datos2, hijos2, bloques, m2, capa, nivel + 1)
    elif tipo in ("VIEWPORT", "SEQEND", "ATTRIB", "ATTDEF"):
        return
    else:
        dib.ignoradas[tipo] = dib.ignoradas.get(tipo, 0) + 1


# ======================================================================= escritura mínima (pruebas / exportar)
def escribir_dxf(ruta: str | Path, polilineas: list[tuple[str, list[tuple[float, float, float]]]],
                 insunits: int = 6) -> None:
    """Escribe un DXF R12 sencillo con POLYLINE 3D por capa (sirve para exportar perfiles o contornos)."""
    l = ["0", "SECTION", "2", "HEADER", "9", "$ACADVER", "1", "AC1009", "9", "$INSUNITS", "70", str(insunits),
         "0", "ENDSEC", "0", "SECTION", "2", "ENTITIES"]
    for capa, pts in polilineas:
        l += ["0", "POLYLINE", "8", capa, "66", "1", "70", "8", "10", "0", "20", "0", "30", "0"]
        for x, y, z in pts:
            l += ["0", "VERTEX", "8", capa, "10", f"{x:.4f}", "20", f"{y:.4f}", "30", f"{z:.4f}", "70", "32"]
        l += ["0", "SEQEND", "8", capa]
    l += ["0", "ENDSEC", "0", "EOF"]
    Path(ruta).write_text("\n".join(l) + "\n", encoding="utf-8")
