"""
Generador geométrico de mallas de perforación.

Solo coloca pozos según los parámetros que define el usuario (burden,
espaciamiento, distancias del arranque, etc.). NO decide qué valores son
adecuados: eso lo decides tú según la mina.
"""

import math
from collections.abc import Iterable
from dataclasses import dataclass, field

from app.core.modelo import Contorno, Perforacion


# =============================================================== tajo abierto
@dataclass
class ParamMallaTajo:
    x0: float = 0.0  # m, primer pozo (fila 1, pozo 1)
    y0: float = 0.0  # m
    z0: float = 0.0  # m, cota del collar
    filas: int = 3
    pozos_por_fila: int = 6
    burden: float = 3.0  # m, distancia entre filas
    espaciamiento: float = 3.5  # m, distancia entre pozos de una fila
    tresbolillo: bool = True  # filas pares desplazadas medio espaciamiento
    azimut_filas: float = 90.0  # °, dirección en que corre cada fila (90 = hacia el Este)
    inclinacion: float = 90.0  # °, 90 = vertical
    azimut_pozo: float = 0.0  # ° (solo importa si el pozo es inclinado)
    longitud: float = 10.0  # m
    diametro_mm: float = 165.0
    explosivo_id: str | None = None
    taco: float = 0.0  # m
    funcion: str = "Producción"


def posiciones_tajo(p: ParamMallaTajo) -> list[tuple[float, float, int]]:
    """Posiciones (x, y, fila) de la malla. Las filas avanzan 90° a la izquierda
    de la dirección de las filas (con azimut 90°, las filas avanzan hacia el Norte)."""
    az = math.radians(p.azimut_filas)
    ux, uy = math.sin(az), math.cos(az)  # a lo largo de la fila
    vx, vy = -uy, ux  # avance entre filas
    puntos = []
    for f in range(p.filas):
        desfase = p.espaciamiento / 2 if (p.tresbolillo and f % 2 == 1) else 0.0
        for k in range(p.pozos_por_fila):
            s = desfase + k * p.espaciamiento
            b = f * p.burden
            puntos.append((p.x0 + s * ux + b * vx, p.y0 + s * uy + b * vy, f + 1))
    return puntos


def generar_malla_tajo(p: ParamMallaTajo, ids: Iterable[str]) -> list[Perforacion]:
    nuevo_id = _generador_ids(ids)
    pozos = []
    for x, y, _fila in posiciones_tajo(p):
        ident = nuevo_id()
        pozos.append(Perforacion(
            id=ident, nombre=ident, capa_id="perforaciones",
            x=round(x, 3), y=round(y, 3), z=p.z0,
            azimut=p.azimut_pozo, inclinacion=p.inclinacion, longitud=p.longitud,
            diametro_mm=p.diametro_mm, explosivo_id=p.explosivo_id, taco=p.taco, funcion=p.funcion,
        ))
    return pozos


# =============================================================== subterráneo
@dataclass
class ParamFrente:
    # Ubicación
    x0: float = 0.0  # m, centro del piso de la sección en el frente
    y0: float = 0.0  # m
    z0: float = 0.0  # m, cota del piso
    azimut_avance: float = 0.0  # °, dirección de avance de la labor (0 = Norte)
    # Sección tipo baúl
    ancho: float = 4.0  # m
    altura_hastial: float = 3.0  # m, altura de las paredes rectas
    flecha: float = 1.0  # m, altura del arco sobre los hastiales
    # Arranque
    altura_arranque: float = 1.5  # m, altura del centro del arranque sobre el piso
    n_alivios: int = 1
    separacion_alivios: float = 0.16  # m, entre centros
    diametro_alivio_mm: float = 102.0
    distancias_arranque: list[float] = field(default_factory=lambda: [0.25, 0.55, 0.95])
    # Ayudas y contorno
    separacion_ayudas: float = 1.1  # m, entre ayudas del anillo
    retiro_ayudas: float = 0.8  # m, distancia del anillo de ayudas al contorno
    separacion_contorno: float = 0.75  # m, entre pozos de contorno, corona y arrastre
    retiro_contorno: float = 0.12  # m, distancia del collar al contorno teórico
    # Pozos
    longitud: float = 3.5  # m
    diametro_mm: float = 45.0
    explosivo_id: str | None = None
    taco: float = 0.5  # m (arranque y ayudas)
    taco_contorno: float = 0.8  # m (contorno y corona)
    taco_arrastre: float = 0.4  # m


def seccion_baul(ancho: float, altura_hastial: float, flecha: float, n_arco: int = 16):
    """Contorno (s, h) de la sección: s horizontal (0 = eje), h altura sobre el piso."""
    semi = ancho / 2
    if flecha <= 0:
        return [(-semi, 0.0), (semi, 0.0), (semi, altura_hastial), (-semi, altura_hastial)]
    radio = (semi**2 + flecha**2) / (2 * flecha)
    hc = altura_hastial + flecha - radio
    ang0 = math.atan2(altura_hastial - hc, semi)
    puntos = [(-semi, 0.0), (semi, 0.0)]
    for k in range(n_arco + 1):
        a = ang0 + (math.pi - 2 * ang0) * k / n_arco
        puntos.append((radio * math.cos(a), hc + radio * math.sin(a)))
    return puntos


def puntos_en_contorno(contorno, separacion: float, retiro: float):
    """Reparte puntos uniformes sobre un contorno cerrado (s, h), desplazados
    hacia el centro de la sección la distancia 'retiro'."""
    cs = sum(s for s, _ in contorno) / len(contorno)
    ch = sum(h for _, h in contorno) / len(contorno)
    n = len(contorno)
    tramos = [(contorno[k], contorno[(k + 1) % n]) for k in range(n)]
    largos = [math.dist(a, b) for a, b in tramos]
    total = sum(largos)
    cantidad = max(3, round(total / separacion))
    puntos = []
    for i in range(cantidad):
        objetivo = total * i / cantidad
        acumulado = 0.0
        for (a, b), largo in zip(tramos, largos):
            if acumulado + largo >= objetivo and largo > 0:
                t = (objetivo - acumulado) / largo
                s, h = a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t
                d = math.hypot(cs - s, ch - h) or 1.0
                puntos.append((s + (cs - s) / d * retiro, h + (ch - h) / d * retiro))
                break
            acumulado += largo
    return puntos


def posiciones_frente(p: ParamFrente) -> list[tuple[float, float, str, bool]]:
    """Posiciones (s, h, función, es_alivio) en la cara del frente."""
    seccion = seccion_baul(p.ancho, p.altura_hastial, p.flecha)
    hc = p.altura_arranque
    pozos: list[tuple[float, float, str, bool]] = []
    # Alivios: uno al centro; varios, agrupados en polígono regular (no en fila horizontal)
    if p.n_alivios == 1:
        pozos.append((0.0, hc, "Alivio", True))
    elif p.n_alivios > 1:
        radio = p.separacion_alivios / (2 * math.sin(math.pi / p.n_alivios))
        for k in range(p.n_alivios):
            a = math.radians(90 + 360 * k / p.n_alivios)
            pozos.append((radio * math.cos(a), hc + radio * math.sin(a), "Alivio", True))
    for n, r in enumerate(sorted(p.distancias_arranque)):
        giro = math.radians(45 if n % 2 else 0)
        funcion = "Arranque" if n == 0 else "Ayuda"
        for k in range(4):
            a = giro + math.radians(90 * k)
            pozos.append((r * math.cos(a), hc + r * math.sin(a), funcion, False))
    radio_arranque = max(p.distancias_arranque, default=0.0)
    for s, h in puntos_en_contorno(seccion, p.separacion_ayudas, p.retiro_ayudas):
        if math.hypot(s, h - hc) > radio_arranque + p.separacion_ayudas / 2:
            pozos.append((s, h, "Ayuda", False))
    for s, h in puntos_en_contorno(seccion, p.separacion_contorno, p.retiro_contorno):
        if h < p.retiro_contorno + 0.2:
            funcion = "Arrastre"
        elif h > p.altura_hastial:
            funcion = "Corona"
        else:
            funcion = "Contorno"
        pozos.append((s, h, funcion, False))
    return pozos


def _a_mundo(p: ParamFrente, s: float, h: float) -> tuple[float, float, float]:
    """Convierte (s, h) de la cara del frente a coordenadas X, Y, Z."""
    a = math.radians(p.azimut_avance)
    # 's' crece hacia la derecha mirando en la dirección de avance
    return (p.x0 + s * math.cos(a), p.y0 - s * math.sin(a), p.z0 + h)


def generar_frente(p: ParamFrente, ids: Iterable[str], id_contorno: str) -> tuple[list[Perforacion], Contorno]:
    nuevo_id = _generador_ids(ids)
    pozos = []
    for s, h, funcion, alivio in posiciones_frente(p):
        x, y, z = _a_mundo(p, s, h)
        taco = {"Contorno": p.taco_contorno, "Corona": p.taco_contorno,
                "Arrastre": p.taco_arrastre}.get(funcion, p.taco)
        ident = nuevo_id()
        pozos.append(Perforacion(
            id=ident, nombre=ident, capa_id="perforaciones",
            x=round(x, 3), y=round(y, 3), z=round(z, 3),
            azimut=p.azimut_avance, inclinacion=0.0, longitud=p.longitud,
            diametro_mm=p.diametro_alivio_mm if alivio else p.diametro_mm,
            explosivo_id=None if alivio else p.explosivo_id,
            taco=0.0 if alivio else min(taco, p.longitud), funcion=funcion,
        ))
    contorno = Contorno(
        id=id_contorno, nombre=f"Sección {id_contorno}", capa_id="contornos",
        vertices=[_a_mundo(p, s, h) for s, h in seccion_baul(p.ancho, p.altura_hastial, p.flecha)],
    )
    return pozos, contorno


# =============================================================== utilidades
def _generador_ids(existentes: Iterable[str], prefijo: str = "P-"):
    usados = set(existentes)
    contador = [0]

    def siguiente() -> str:
        while True:
            contador[0] += 1
            ident = f"{prefijo}{contador[0]:02d}"
            if ident not in usados:
                usados.add(ident)
                return ident

    return siguiente


def nuevo_id_contorno(existentes: Iterable[str], prefijo: str = "SEC-") -> str:
    return _generador_ids(existentes, prefijo)()
