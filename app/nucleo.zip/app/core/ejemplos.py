"""
Proyectos nuevos y escenas de EJEMPLO.

Los valores de los ejemplos (cotas, mallas, explosivos, cargas) son
inventados para mostrar el programa. NO son un diseño ni una recomendación.
Los proyectos vacíos no contienen ningún dato inventado.
"""

import math

from app.core.generador import ParamFrente, generar_frente
from app.core.modelo import (
    ESCENARIO_SUBTERRANEO,
    ESCENARIO_TAJO,
    TIPO_ENCARTUCHADO,
    TIPO_GRANEL,
    Banco,
    Contorno,
    DisenoVoladura,
    Explosivo,
    Perforacion,
    Proyecto,
    Superficie,
)


def crear_proyecto_vacio(nombre: str, diseno: DisenoVoladura) -> Proyecto:
    proyecto = Proyecto(nombre=nombre, diseno=diseno)
    proyecto.asegurar_capas_base()
    return proyecto


def explosivos_referenciales() -> list[Explosivo]:
    """Valores genéricos de referencia: reemplazar con la ficha técnica del fabricante."""
    return [
        Explosivo(id="EXP-01", nombre="ANFO (genérico)", tipo=TIPO_GRANEL,
                  densidad_gcc=0.80, vod_ms=3500, referencial=True),
        Explosivo(id="EXP-02", nombre="Emulsión a granel (genérica)", tipo=TIPO_GRANEL,
                  densidad_gcc=1.15, vod_ms=5000, referencial=True),
        Explosivo(id="EXP-03", nombre="Emulsión encartuchada 1¼\" (genérica)",
                  tipo=TIPO_ENCARTUCHADO, densidad_gcc=1.13, diametro_cartucho_mm=32,
                  vod_ms=4500, referencial=True),
    ]


# --------------------------------------------------------------- tajo abierto
def crear_ejemplo_tajo() -> Proyecto:
    cota_piso, h, angulo = 3820.0, 10.0, 75.0
    retiro = h / math.tan(math.radians(angulo))

    p = Proyecto(
        nombre="Ejemplo: tajo abierto",
        escenario_demo=True,
        explosivos=explosivos_referenciales(),
        diseno=DisenoVoladura(escenario=ESCENARIO_TAJO, densidad_roca=2.6,
                              burden=3.0, espaciamiento=3.5, altura_banco=h),
    )
    p.asegurar_capas_base()

    def cota(y: float) -> float:
        if y <= 0:
            return cota_piso
        if y < retiro:
            return cota_piso + h * y / retiro
        if y <= 30:
            return cota_piso + h
        if y < 30 + retiro:
            return cota_piso + h + h * (y - 30) / retiro
        return cota_piso + 2 * h

    x0, y0, paso_x, paso_y, nx, ny = -20.0, -20.0, 1.0, 0.5, 101, 141
    p.agregar_objeto(Superficie(
        id="SUP-01", nombre="Superficie del tajo", capa_id="topografia", es_demo=True,
        x0=x0, y0=y0, paso_x=paso_x, paso_y=paso_y, nx=nx, ny=ny,
        cotas=[cota(y0 + j * paso_y) for j in range(ny) for _ in range(nx)],
    ))
    for n, y_pie, c_pie in ((1, 0.0, cota_piso), (2, 30.0, cota_piso + h)):
        p.agregar_objeto(Banco(
            id=f"BAN-{n:02d}", nombre=f"Banco {c_pie:.0f}–{c_pie + h:.0f}", capa_id="bancos",
            es_demo=True, x_inicio=-20.0, x_fin=80.0, y_pie=y_pie,
            cota_pie=c_pie, cota_cresta=c_pie + h, angulo_cara=angulo,
        ))

    cota_banco = cota_piso + h
    pozos = []
    for fila in range(3):
        y = retiro + 3.0 * (fila + 1)
        desfase = 1.75 if fila % 2 else 0.0
        for col in range(6):
            pozos.append(Perforacion(
                id=f"P-{len(pozos) + 1:02d}", nombre=f"P-{len(pozos) + 1:02d}",
                capa_id="perforaciones", es_demo=True,
                x=round(12.0 + desfase + col * 3.5, 2), y=round(y, 2), z=cota_banco,
                azimut=0.0, inclinacion=90.0, longitud=11.0, diametro_mm=165.0,
                explosivo_id="EXP-01" if fila > 0 else "EXP-02",
                taco=3.5, funcion="Producción",
            ))
    xs, ys = [q.x for q in pozos], [q.y for q in pozos]
    zc = cota_banco
    p.agregar_objeto(Contorno(
        id="FV-01", nombre="Polígono de voladura FV-01", capa_id="contornos", es_demo=True,
        vertices=[(min(xs) - 2, min(ys) - 2, zc), (max(xs) + 2, min(ys) - 2, zc),
                  (max(xs) + 2, max(ys) + 2, zc), (min(xs) - 2, max(ys) + 2, zc)],
    ))
    for pozo in pozos:
        p.agregar_objeto(pozo)
    return p


# --------------------------------------------------------------- subterráneo
def crear_ejemplo_subterraneo() -> Proyecto:
    p = Proyecto(
        nombre="Ejemplo: frente subterráneo",
        escenario_demo=True,
        explosivos=explosivos_referenciales(),
        diseno=DisenoVoladura(escenario=ESCENARIO_SUBTERRANEO, densidad_roca=2.7, avance=3.2),
    )
    p.asegurar_capas_base()
    parametros = ParamFrente(explosivo_id="EXP-03")  # valores de ejemplo del generador
    pozos, contorno = generar_frente(parametros, [], "SEC-01")
    contorno.nombre = "Sección del frente F-01"
    contorno.es_demo = True
    p.diseno.area_seccion = round(contorno.area(), 2)
    p.agregar_objeto(contorno)
    for pozo in pozos:
        pozo.es_demo = True
        p.agregar_objeto(pozo)
    return p
