"""
Puente entre la app móvil (JavaScript) y el motor de cálculo de LithoBlast3D (el mismo de escritorio).
Corre dentro del navegador con Pyodide. Todas las funciones reciben y devuelven texto JSON.
"""

from __future__ import annotations

import json
import math
import traceback

import numpy as np

from app import VERSION
from app.biblioteca import estandar as est
from app.biblioteca import opciones as opc
from app.biblioteca import productos as prod
from app.biblioteca import referencias as ref
from app.biblioteca.generador import roca_desde_rmr
from app.cad import exportar as ex
from app.cad import malla_topografica as mt
from app.calc import burden_formulas as bf
from app.calc import cimbra as cb
from app.calc import costos as co
from app.calc import dinamica as dn
from app.calc import fragmentacion as fr
from app.calc import macizo as mz
from app.calc import zona_danio as zd
from app.calc import accesorios as acc
from app.core import equipos as eqp
from app.core.ejemplos import crear_proyecto_vacio, explosivos_referenciales
from app.core.generador import _generador_ids, nuevo_id_contorno
from app.core.malla_auto import FORMAS_SECCION
from app.core.modelo import (
    ESCENARIO_SUBTERRANEO,
    ESCENARIO_TAJO,
    TIPO_ENCARTUCHADO,
    TIPO_GRANEL,
    Contorno,
    DisenoVoladura,
    Explosivo,
    Perforacion,
    PolilineaCAD,
)
from app.core.resultados import carga_de_pozo

_ESTADO = {"planos": None, "opciones": {}, "dxf": None, "tin": None, "topo": None}


def _r(x, n=4):
    if x is None:
        return None
    if isinstance(x, (np.floating, float)):
        return None if not math.isfinite(float(x)) else round(float(x), n)
    if isinstance(x, (np.integer,)):
        return int(x)
    return x


def _lista(a, n=4, paso=1):
    return [_r(float(v), n) for v in np.asarray(a, float)[::paso]]


def _json(f):
    """Envuelve: entrada JSON → resultado {"ok": ..., "datos" | "error"} en JSON."""
    def envoltura(texto="{}"):
        try:
            datos = json.loads(texto) if texto else {}
            return json.dumps({"ok": True, "datos": f(datos)}, ensure_ascii=False)
        except (ValueError, KeyError, ZeroDivisionError, OverflowError, IndexError) as e:
            return json.dumps({"ok": False, "error": str(e) or e.__class__.__name__}, ensure_ascii=False)
        except Exception as e:  # noqa: BLE001
            return json.dumps({"ok": False, "error": f"{e.__class__.__name__}: {e}",
                               "detalle": traceback.format_exc()[-1500:]}, ensure_ascii=False)
    envoltura.__name__ = f.__name__
    return envoltura


def _planos():
    if _ESTADO["planos"] is None:
        _ESTADO["planos"] = est.cargar_biblioteca()
    return _ESTADO["planos"]


_CATALOGO_EXP: list[Explosivo] = []


def _catalogo_exp() -> list[Explosivo]:
    if not _CATALOGO_EXP:
        _CATALOGO_EXP.extend(prod.catalogo_explosivos())
    return _CATALOGO_EXP


def _explosivo(d: dict | None, defecto: int = 2) -> Explosivo:
    refs = explosivos_referenciales()
    if not d:
        return refs[defecto]
    if d.get("id") and not d.get("personalizado"):
        e = next((x for x in refs + _catalogo_exp() if x.id == d["id"]), None)
        if e:
            return e
    return Explosivo(id=d.get("id") or "EXP-U", nombre=d.get("nombre") or "Explosivo",
                     tipo=TIPO_ENCARTUCHADO if d.get("tipo") == "encartuchado" else TIPO_GRANEL,
                     densidad_gcc=float(d.get("densidad", 1.0)), diametro_cartucho_mm=float(d.get("diametro_cartucho", 0)),
                     prp=float(d.get("prp", 1.0)), vod_ms=float(d.get("vod", 0)), referencial=False)


def _exp_dict(e: Explosivo) -> dict:
    return {"id": e.id, "nombre": e.nombre, "tipo": "encartuchado" if e.tipo == TIPO_ENCARTUCHADO else "granel",
            "densidad": e.densidad_gcc, "diametro_cartucho": e.diametro_cartucho_mm, "prp": e.prp, "vod": e.vod_ms,
            "kg_cartucho": e.kg_cartucho, "fuente": e.fuente}


def _equipo_dict(e) -> dict:
    from dataclasses import asdict
    d = asdict(e)
    d["descripcion"] = e.descripcion_corta()
    d["seccion_minima"] = list(e.seccion_minima())
    return d


def _scoop_dict(x) -> dict:
    from dataclasses import asdict
    d = asdict(x)
    d["seccion_minima"] = list(x.seccion_minima())
    return d


def _seleccion_dict(sel) -> dict | None:
    if sel is None:
        return None
    return {"equipo": _equipo_dict(sel.equipo), "motivo": sel.motivo, "avisos": list(sel.avisos),
            "evaluados": [{"clave": e.clave, "nombre": e.nombre, "ok": ok, "motivo": m} for e, ok, m in sel.evaluados]}


# ====================================================================== información
@_json
def info(_):
    return {"version": VERSION, "rocas": est.ROCAS, "formas": FORMAS_SECCION,
            "explosivos": [_exp_dict(e) for e in explosivos_referenciales()],
            "explosivos_ficha": [_exp_dict(e) for e in _catalogo_exp()],
            "labores": eqp.LABORES, "tipos_equipo": eqp.TIPOS, "sistemas": acc.SISTEMAS,
            "equipos": [_equipo_dict(e) for e in eqp.catalogo()],
            "scoops": [_scoop_dict(x) for x in eqp.CATALOGO_SCOOP],
            "emulnor": {"fuente": prod.datos()["fuente"], "productos": prod.productos(),
                        "presentaciones": prod.datos()["presentaciones"], "accesorios": prod.ACCESORIOS},
            "estandar": est.hay_estandar(), "pie": est.PIE,
            "frag": {"rmd": list(fr.RMD), "jps": list(fr.JPS), "jpa": list(fr.JPA)},
            "macizo": {"condicion": list(mz.CONDICION_JUNTAS), "agua": list(mz.AGUA),
                       "orientacion": list(mz.ORIENTACION_TUNEL), "esr": list(mz.ESR)},
            "burden": {"explosivo": list(bf.K_OLOFSSON), "inclinacion": list(bf.R1_OLOFSSON)},
            "perfiles": list(cb.PERFILES),
            "topo": {"patrones": mt.PATRONES, "secuencias": mt.SECUENCIAS, "pisos": mt.MODOS_PISO}}


# ====================================================================== malla del frente
def _datos_frente(d: dict) -> opc.DatosFrente:
    rmr = d.get("rmr")
    roca = d.get("roca", "Regular")
    if rmr is not None:
        roca = roca_desde_rmr(float(rmr))
    return opc.DatosFrente(
        ancho=float(d["ancho"]), alto=float(d["alto"]), flecha=float(d.get("flecha", min(d["ancho"], d["alto"]) / 3)),
        forma=d.get("forma", FORMAS_SECCION[0]), roca=roca, rmr=None if rmr is None else float(rmr), gsi=None,
        rqd=None if d.get("rqd") is None else float(d["rqd"]), densidad_roca=float(d.get("densidad_roca", 2.7)),
        diametro_mm=float(d.get("diametro", 38)), diametro_alivio_mm=float(d.get("diametro_alivio", 64)),
        n_alivios=int(d.get("n_alivios", 1)), longitud=float(d.get("pies", 6)) * est.PIE,
        explosivo=_explosivo(d.get("explosivo")),
        explosivo_contorno=_explosivo(d["explosivo_contorno"]) if d.get("explosivo_contorno") else None,
        largo_cartucho_m=float(d.get("largo_cartucho_pulg", 8)) * 0.0254, angulo_v=float(d.get("angulo_v", 65)),
        cuneta=bool(d.get("cuneta", True)), cuneta_lado=d.get("cuneta_lado", "izquierda"),
        cuneta_ancho=float(d.get("cuneta_ancho", 0.35)), cuneta_profundidad=float(d.get("cuneta_prof", 0.3)),
        labor=d.get("labor", "frente"), burden_tajeo=float(d.get("burden_tajeo", 0.40)),
        espaciamiento_tajeo=float(d.get("espaciamiento_tajeo", 0.30)), equipo=d.get("equipo") or None)


def _proyecto_frente(op: opc.OpcionMalla, d: dict):
    """Proyecto con la malla colocada en el frente (x horizontal, z vertical, avance hacia +y)."""
    pl = op.plano
    pr = crear_proyecto_vacio("Malla", DisenoVoladura(escenario=ESCENARIO_SUBTERRANEO))
    pr.explosivos = []
    ids = {}
    conocidos = {e.nombre: e for e in _catalogo_exp() + explosivos_referenciales()}
    for e in (_explosivo(d.get("explosivo")), _explosivo(d["explosivo_contorno"]) if d.get("explosivo_contorno") else None):
        if e is not None:
            conocidos[e.nombre] = e
    for e in est.explosivos_del_plano(pl):
        n = len(pr.explosivos) + 1
        if e["nombre"] in conocidos:
            x = Explosivo(**{**conocidos[e["nombre"]].__dict__, "id": f"EXP-{n:02d}"})
            pr.explosivos.append(x)
            ids[e["nombre"]] = x.id
            continue
        x = Explosivo(id=f"EXP-{n:02d}", nombre=e["nombre"], tipo=TIPO_ENCARTUCHADO, densidad_gcc=e["densidad_gcc"] or 1.0,
                      diametro_cartucho_mm=round(e["diametro_mm"], 1), referencial=True)
        pr.explosivos.append(x)
        ids[e["nombre"]] = x.id
    for e in (_explosivo(d.get("explosivo")), _explosivo(d["explosivo_contorno"]) if d.get("explosivo_contorno") else None):
        if e is not None and e.nombre not in ids:
            e = Explosivo(**{**e.__dict__, "id": f"EXP-{len(pr.explosivos) + 1:02d}"})
            pr.explosivos.append(e)
            ids[e.nombre] = e.id
    L = float(d.get("pies", 6)) * est.PIE
    pozos, vertices = est.plano_a_pozos(pl, set(), float(d.get("diametro", 38)), float(d.get("diametro_alivio", 64)),
                                        0.0, 0.0, 0.0, 0.0, ids, L, labor=op.labor)
    pr.agregar_objeto(Contorno(id="SEC-01", nombre="Sección", capa_id="contornos", vertices=vertices))
    for p in pozos:
        pr.agregar_objeto(p)
    pr.diseno.area_seccion = op.resumen().get("area") or 0.0
    pr.diseno.avance = op.avance or 0.95 * L
    pr.nombre = op.nombre
    return pr, pozos


@_json
def opciones(d):
    datos = _datos_frente(d)
    ops = opc.generar_opciones(datos, _planos())
    _ESTADO["opciones"] = {o.clave: (o, d) for o in ops}
    if datos.labor == "chimenea":
        scoop_sel, scoop_motivo = None, "En la chimenea el material cae por gravedad y se limpia desde el nivel inferior."
    else:
        sco, scoop_motivo = eqp.seleccionar_scoop(datos.ancho, datos.alto)
        scoop_sel = _scoop_dict(sco) if sco else None
    salida = []
    for o in ops:
        item = {"clave": o.clave, "nombre": o.nombre, "familia": o.familia, "descripcion": o.descripcion,
                "error": o.error, "avisos": list(o.avisos), "avance": _r(o.avance, 2), "labor": o.labor,
                "equipo": _seleccion_dict(o.equipo), "comparacion": list(o.comparacion),
                "scoop": scoop_sel, "scoop_motivo": scoop_motivo, "sistema": d.get("sistema", "carmex")}
        if o.plano is not None and not o.error:
            item["accesorios"] = [{"item": a.item, "cantidad": _r(a.cantidad, 2), "unidad": a.unidad, "nota": a.nota}
                                  for a in o.accesorios(d.get("sistema", "carmex"))]
            pr, pozos = _proyecto_frente(o, d)
            res = o.resumen()
            item["resumen"] = {k: _r(v, 3) for k, v in res.items()}
            item["contorno"] = [[_r(x, 3), _r(y, 3)] for x, y in o.plano.contorno]
            item["taladros"] = []
            for t, p in zip(o.plano.taladros, pozos):
                c = carga_de_pozo(pr, p)
                item["taladros"].append({
                    "x": _r(t.x, 3), "y": _r(t.y, 3), "tipo": t.tipo, "retardo": t.detonador or 0,
                    "cartuchos": t.cartuchos, "kg": _r(c.carga, 3) if c.cargado else 0.0,
                    "explosivo": c.explosivo_nombre if c.cargado else "", "funcion": p.funcion,
                    "azimut_rel": _r(t.azimut_rel, 2), "longitud": _r(p.longitud, 3),
                    "diametro": _r(p.diametro_mm, 1), "inclinacion": _r(p.inclinacion, 1)})
        salida.append(item)
    return salida


@_json
def dxf_frente(d):
    o, datos = _ESTADO["opciones"][d["clave"]]
    pr, _ = _proyecto_frente(o, datos)
    vista = ex.VISTAS[1] if d.get("vista", "frente") == "frente" else ex.VISTAS[0]
    return {"nombre": f"malla_{o.clave}.dxf", "texto": ex.dxf_de_proyecto(pr, ex.OpcionesExportar(vista=vista))}


# ====================================================================== equipos y referencias
@_json
def equipos(d):
    """Catálogo de equipos. d.cambios: cambios guardados en el teléfono (se aplican antes);
    d.lista: catálogo editado a guardar; d.probar: {ancho, alto, labor} → equipo recomendado."""
    if "cambios" in d:
        eqp.ARCHIVO_USUARIO.parent.mkdir(parents=True, exist_ok=True)
        eqp.ARCHIVO_USUARIO.write_text(json.dumps(d["cambios"] or {}, ensure_ascii=False), encoding="utf-8")
    if d.get("restaurar"):
        eqp.ARCHIVO_USUARIO.unlink(missing_ok=True)
    if d.get("lista") is not None:
        from dataclasses import fields
        nombres = {f.name for f in fields(eqp.Equipo)}
        lista = []
        for x in d["lista"]:
            v = {k: x[k] for k in x if k in nombres}
            for k in ("labores", "resistencia_mpa"):
                if isinstance(v.get(k), list):
                    v[k] = tuple(v[k])
            lista.append(eqp.Equipo(**v))
        eqp.guardar_cambios(lista)
    cambios = json.loads(eqp.ARCHIVO_USUARIO.read_text(encoding="utf-8")) if eqp.ARCHIVO_USUARIO.exists() else {}
    res = {"catalogo": [_equipo_dict(e) for e in eqp.catalogo()], "cambios": cambios}
    if d.get("probar"):
        p = d["probar"]
        res["seleccion"] = _seleccion_dict(eqp.seleccionar(float(p["ancho"]), float(p["alto"]), p.get("labor", "frente")))
    return res


@_json
def referencias(d):
    """Referencias de minas: lista de mallas Volcan (y el dibujo de una), chimeneas y tajeos de Retamas."""
    v = ref.volcan()
    res = {"aviso": v["aviso"], "fuente": v["fuente"],
           "volcan": [{"i": i, "codigo": x["codigo"], "ancho": x["ancho"], "alto": x["alto"], "clase": x["clase"],
                       "rmr": x["rmr"], "tabla": x["tabla"], "pagina": x["pagina"]} for i, x in enumerate(v["disenos"])],
           "chimeneas": [{"seccion": c.seccion, "rmr": list(c.rmr), "longitud": c.longitud, "cargados": c.cargados,
                          "rimados": c.rimados, "alivios": c.alivios, "kg": c.kg, "fc": c.factor_carga}
                         for c in ref.CHIMENEAS], "fuente_chimeneas": ref.FUENTE_CHIMENEAS,
           "tajeos": [{"rmr": list(t.rmr), "ancho": t.ancho, "alto": t.alto, "pies": t.pies, "long_corte": t.long_corte,
                       "filas": {k: list(n) for k, n in t.filas.items()}, "kg": t.kg, "fc": t.factor_carga,
                       "mecha_rapida_m": t.mecha_rapida_m, "carmex": t.carmex} for t in ref.TAJEOS],
           "fuente_tajeos": ref.FUENTE_TAJEOS}
    if d.get("i") is not None:
        x = v["disenos"][int(d["i"])]
        res["diseno"] = {"contorno": [[_r(a, 3), _r(b, 3)] for a, b in x["contorno"]],
                         "taladros": [{"x": _r(t["x"], 3), "y": _r(t["y"], 3), "tipo": t["tipo"],
                                       "explosivo": t.get("explosivo") or "", "retardo": t.get("retardo")}
                                      for t in x["taladros"]]}
    return res


# ====================================================================== topografía (DXF)
@_json
def cargar_dxf(d):
    from app.cad.dxf import leer_dxf_texto
    dib = leer_dxf_texto(d["texto"], d.get("nombre", ""))
    _ESTADO["dxf"] = dib
    capas = {}
    for e in dib.entidades:
        c = capas.setdefault(e.capa, {"capa": e.capa, "polilineas": 0, "puntos": 0, "caras": 0, "con_cota": False})
        if e.tipo == "polilinea":
            c["polilineas"] += 1
        elif e.tipo == "punto":
            c["puntos"] += 1
        elif e.tipo == "triangulos":
            c["caras"] += 1
        if any(abs(p[2]) > 1e-6 for p in e.puntos[:3]):
            c["con_cota"] = True
    return {"capas": sorted(capas.values(), key=lambda c: -c["polilineas"] - c["puntos"]),
            "avisos": list(dib.avisos)}


@_json
def crear_tin(d):
    from app.cad import topografia as topo
    dib = _ESTADO["dxf"]
    if dib is None:
        raise ValueError("Primero abre un archivo DXF")
    capas = set(d["capas"])
    pts, lineas = [], []
    for e in dib.entidades:
        if e.capa not in capas:
            continue
        if e.tipo in ("polilinea", "punto"):
            pts += e.puntos
        elif e.tipo == "triangulos":
            pts += e.puntos
        if e.tipo == "polilinea" and len(e.puntos) > 1:
            lineas.append(e.puntos)
    if len(pts) < 3:
        raise ValueError("Las capas elegidas no tienen puntos suficientes")
    P = np.unique(np.round(np.asarray(pts, float), 3), axis=0)
    paso = max(1, len(P) // 60000)
    tin = topo.crear_tin(P[::paso])
    _ESTADO["tin"] = tin
    curvas = []
    for l in lineas[:3000]:
        a = np.asarray(l, float)
        s = max(1, len(a) // 80)
        a = a[::s] if len(a) > 2 else a
        curvas.append([[_r(x, 2), _r(y, 2), _r(z, 2)] for x, y, z in a])
    cerr = [e for e in dib.entidades if e.tipo == "polilinea" and e.cerrada and len(e.puntos) >= 3]
    areas = [{"indice": i, "capa": e.capa, "area": _r(mt.area_poligono([p[:2] for p in e.puntos]), 1),
              "vertices": [[_r(p[0], 3), _r(p[1], 3)] for p in e.puntos]} for i, e in enumerate(cerr[:200])]
    v = tin.puntos
    return {"triangulos": int(tin.n_triangulos), "puntos": int(len(v)),
            "x": [_r(v[:, 0].min(), 2), _r(v[:, 0].max(), 2)], "y": [_r(v[:, 1].min(), 2), _r(v[:, 1].max(), 2)],
            "z": [_r(v[:, 2].min(), 2), _r(v[:, 2].max(), 2)], "curvas": curvas, "areas": areas}


def _entrada_topo(d) -> mt.EntradaMallaTopo:
    if d.get("poligono"):
        pol = [tuple(p) for p in d["poligono"]]
    else:
        pol = mt.rectangulo(float(d["cx"]), float(d["cy"]), float(d["largo"]), float(d["ancho"]),
                            float(d.get("az_largo", 90)))
    e = _explosivo(d.get("explosivo"), 0)
    dia = float(d.get("diametro", 165))
    return mt.EntradaMallaTopo(
        poligono=pol, burden=float(d["burden"]), espaciamiento=float(d["espaciamiento"]),
        patron=d.get("patron", mt.PATRONES[0]), azimut_salida=float(d.get("azimut", 0)),
        margen=float(d.get("margen", 1)), modo_piso=d.get("modo_piso", mt.MODOS_PISO[0]),
        cota_piso=float(d.get("cota_piso", 0)), altura_banco=float(d.get("altura", 10)),
        sobreperforacion=float(d.get("sobreperforacion", 1)), taco=float(d.get("taco", 3)),
        inclinacion=float(d.get("inclinacion", 90)), diametro_mm=dia, densidad_explosivo=e.densidad_gcc,
        diametro_carga_mm=e.diametro_de_carga(dia), explosivo_id=e.id, secuencia=d.get("secuencia", mt.SECUENCIAS[0]),
        ms_taladros=float(d.get("ms_taladros", 25)), ms_filas=float(d.get("ms_filas", 67)))


@_json
def azimut_salida(d):
    if _ESTADO["tin"] is None:
        raise ValueError("Primero crea la superficie")
    az = mt.azimut_pendiente(_ESTADO["tin"], _entrada_topo({**d, "burden": 1, "espaciamiento": 1}).poligono)
    return {"azimut": None if az is None else round(float(az), 1) % 360}


@_json
def malla_topo(d):
    tin = _ESTADO["tin"]
    if tin is None:
        raise ValueError("Primero abre el DXF y crea la superficie")
    e = _entrada_topo(d)
    r = mt.generar(e, tin)
    _ESTADO["topo"] = (e, r, d)
    return {"taladros": [{"x": t.x, "y": t.y, "z": t.z, "longitud": t.longitud, "fila": t.fila, "orden": t.orden,
                          "kg": t.carga_kg, "altura": t.altura, "retardo": t.retardo, "ms": t.tiempo_ms}
                         for t in r.taladros],
            "poligono": [[_r(x, 3), _r(y, 3)] for x, y in e.poligono], "avisos": r.avisos,
            "kg": _r(r.kg, 1), "metros": _r(r.metros, 1), "volumen": _r(r.volumen_m3, 1), "area": _r(r.area_m2, 1),
            "filas": r.filas, "factor_carga": _r(r.kg / r.volumen_m3 if r.volumen_m3 else 0, 3),
            "borde3d": [[_r(x, 3), _r(y, 3), _r(z, 3)] for x, y, z in mt.poligono_sobre_terreno(tin, e.poligono, max(e.espaciamiento / 4, 0.5))],
            "terreno": _rejilla_area(tin, e.poligono)}


def _rejilla_area(tin, pol):
    p = np.asarray(pol, float)
    c = p.mean(axis=0)
    R = float(np.max(np.hypot(p[:, 0] - c[0], p[:, 1] - c[1]))) * 1.8
    return mt.rejilla_terreno(tin, c[0] - R, c[0] + R, c[1] - R, c[1] + R, 64)


@_json
def dxf_topo(d):
    if _ESTADO["topo"] is None:
        raise ValueError("Primero calcula la malla")
    e, r, datos = _ESTADO["topo"]
    exp = _explosivo(datos.get("explosivo"), 0)
    pr = crear_proyecto_vacio("Malla sobre topografía", DisenoVoladura(escenario=ESCENARIO_TAJO, burden=e.burden,
                                                                    espaciamiento=e.espaciamiento))
    pr.explosivos = [exp]
    nuevo = _generador_ids([])
    for t in r.taladros:
        i = nuevo()
        pr.agregar_objeto(Perforacion(id=i, nombre=i, capa_id="perforaciones", x=t.x, y=t.y, z=t.z,
                                      azimut=e.azimut_salida, inclinacion=e.inclinacion, longitud=t.longitud,
                                      diametro_mm=e.diametro_mm, explosivo_id=exp.id, taco=e.taco, retardo=t.retardo,
                                      tiempo_ms=t.tiempo_ms))
    pr.agregar_objeto(Contorno(id=nuevo_id_contorno([], "AREA-"), nombre="Área", capa_id="contornos",
                               vertices=mt.poligono_sobre_terreno(_ESTADO["tin"], e.poligono, max(e.espaciamiento / 4, 0.5))))
    dib = _ESTADO["dxf"]
    if d.get("topografia", True) and dib is not None:
        k = 0
        for ent in dib.entidades:
            if ent.tipo == "polilinea" and len(ent.puntos) > 1:
                k += 1
                pr.agregar_objeto(PolilineaCAD(id=f"CAD-{k}", nombre=f"CAD-{k}", capa_id="topografia",
                                               vertices=[tuple(map(float, p)) for p in ent.puntos],
                                               cerrada=ent.cerrada, capa_cad=ent.capa))
    return {"nombre": "malla_banco.dxf", "texto": ex.dxf_de_proyecto(pr)}


# ====================================================================== análisis
@_json
def fragmentacion(d):
    if d.get("a_manual"):
        a = float(d["a"])
        comp = None
    else:
        comp = fr.factor_roca(d["rmd"], d["jps"], d["jpa"], float(d["densidad"]), float(d["ucs"]), float(d["e"]))
        a = comp["A"]
    lc = float(d["long_carga"])
    bcl = min(float(d.get("bcl", 0)), lc)
    e = fr.EntradaKuzRam(a_roca=a, factor_carga=float(d["k"]), carga_taladro=float(d["q"]), rws=float(d["rws"]),
                         burden=float(d["b"]), espaciamiento=float(d["s"]), diametro_mm=float(d["d"]),
                         desviacion=float(d["w"]), long_carga=lc, carga_fondo=bcl, carga_columna=lc - bcl,
                         altura=float(d["h"]), xmax_mm=float(d["xmax"]) or None)
    r = fr.kuz_ram(e)
    x = fr.tamices_log(1, max(r.xmax_mm * 1.05, 50), 120)
    par = float(d.get("parrilla", 300))
    salida = {"a": _r(a, 3), "x50": _r(r.x50_mm, 1), "n": _r(r.n, 3), "b": _r(r.b, 3), "xmax": _r(r.xmax_mm, 0),
              "x80_sw": _r(r.x80_sw_mm, 1), "x80_rr": _r(r.x80_rr_mm, 1), "pasos": r.pasos,
              "bajo_parrilla": _r(float(fr.pasante_swebrec([par], r.x50_mm, r.xmax_mm, r.b)[0]) * 100, 1),
              "x": _lista(x, 2), "swebrec": _lista(fr.pasante_swebrec(x, r.x50_mm, r.xmax_mm, r.b) * 100, 2),
              "rosin": _lista(fr.pasante_rosin(x, r.x50_mm, r.n) * 100, 2)}
    med = [(float(a_), float(b_)) for a_, b_ in d.get("medidos", []) if a_ not in ("", None) and b_ not in ("", None)]
    if len(med) >= 3:
        xs, ps = zip(*sorted(med))
        x50s, xm, bb, r2s = fr.ajustar_swebrec(xs, ps)
        x50r, nn, r2r = fr.ajustar_rosin(xs, ps)
        xx = fr.tamices_log(max(min(xs) / 3, 0.1), xm * 1.05, 120)
        salida["ajuste"] = {"x50": _r(x50s, 1), "xmax": _r(xm, 0), "b": _r(bb, 3), "r2": _r(r2s, 4),
                            "x50_rr": _r(x50r, 1), "n_rr": _r(nn, 3), "r2_rr": _r(r2r, 4),
                            "a_calibrado": _r(a * x50s / r.x50_mm, 2), "x": _lista(xx, 2),
                            "swebrec": _lista(fr.pasante_swebrec(xx, x50s, xm, bb) * 100, 2),
                            "rosin": _lista(fr.pasante_rosin(xx, x50r, nn) * 100, 2), "medidos": [list(m) for m in med]}
    return salida


@_json
def burden(d):
    dm = float(d["d"])
    q = math.pi / 4 * (dm / 1000) ** 2 * float(d["rho_e"]) * 1000
    filas = bf.comparar(dm, float(d["h"]), float(d["rho_e"]), float(d["rho_r"]), float(d["vod"]), float(d["vc"]),
                        float(d["kb"]), q, d["explosivo"], d["inclinacion"], float(d["c"]))
    bs = [b for _, b, _ in filas]
    return {"filas": [[n, _r(b, 3), f] for n, b, f in filas], "mediana": _r(float(np.median(bs)), 3), "q": _r(q, 3)}


@_json
def macizo(d):
    r = mz.rmr89(float(d["ucs"]), float(d["rqd"]), float(d["esp"]), d["condicion"], d["agua"], d["orientacion"])
    rmr = r["RMR89"]
    q = mz.q_barton(float(d["rqd"]), float(d["jn"]), float(d["jr"]), float(d["ja"]), float(d["jw"]), float(d["srf"]))
    gsi = mz.gsi_desde_rmr(r["RMR básico"])
    D = float(d["D"])
    hb = mz.hoek_brown(gsi, float(d["mi"]), D)
    esr = mz.ESR[d["esr"]]
    B = float(d["ancho"])
    sci = float(d["ucs"])
    em_b = mz.em_bieniawski(rmr)
    s3 = np.linspace(-sci * hb["s"] / hb["mb"] * 0.999, 0.25 * sci, 80)
    s1 = s3 + sci * np.clip(hb["mb"] * s3 / sci + hb["s"], 0, None) ** hb["a"]
    R = np.linspace(5, 100, 60)
    return {
        "puntajes": [[k, v] for k, v in r.items()], "rmr": rmr, "clase": mz.clase(rmr), "q": _r(q, 4),
        "rmr_desde_q": _r(mz.rmr_desde_q(q), 1), "q_desde_rmr": _r(mz.q_desde_rmr(rmr), 4), "gsi": gsi,
        "em": {"Bieniawski": _r(em_b, 2), "Serafim-Pereira": _r(mz.em_serafim(rmr), 2),
               "Nicholson-Bieniawski": _r(mz.em_nicholson(rmr, float(d["ei"])), 2),
               "Hoek-Diederichs": _r(mz.em_hoek_diederichs(gsi, D), 2)},
        "hb": {k: _r(v, 5) for k, v in hb.items()}, "scm": _r(sci * hb["s"] ** hb["a"], 3),
        "hp": _r(mz.carga_unal(rmr, B), 3), "presion": _r(mz.carga_unal(rmr, B) * float(d["gamma"]), 1),
        "perno": _r(mz.longitud_perno(B, esr), 2), "luz": _r(2 * esr * q ** 0.4, 2), "esr": esr,
        "curva_hb": {"s3": _lista(s3, 3), "s1": _lista(s1, 3)},
        "curva_em": {"rmr": _lista(R, 1), "serafim": _lista([mz.em_serafim(x) for x in R], 3),
                     "hoek": _lista([mz.em_hoek_diederichs(x - 5, D) for x in R], 3),
                     "nicholson": _lista([mz.em_nicholson(x, float(d["ei"])) for x in R], 3)}}


@_json
def cimbra(d):
    e = cb.EntradaCimbra(ancho=float(d["ancho"]), alto=float(d["alto"]), perfil=d["perfil"], e_gpa=float(d.get("e", 200)),
                         fy_mpa=float(d["fy"]), espaciamiento=float(d["esp"]), rmr=float(d["rmr"]),
                         peso_unitario=float(d["gamma"]), k_lateral=float(d.get("k", 0)),
                         apoyos=d.get("apoyos", "empotrados"),
                         carga_manual=float(d["q_manual"]) if d.get("q_manual") not in (None, "", 0) else None)
    r = cb.analizar(e)
    nud = r.nudos
    s_acum, n_l, m_l = [0.0], [], []
    for (i, j), f in zip(r.elementos, r.fuerzas):
        L = float(np.hypot(*(nud[j] - nud[i])))
        s0 = s_acum[-1]
        s_acum.append(s0 + L)
        n_l += [[_r(s0, 3), _r(f[0], 2)], [_r(s0 + L, 3), _r(-f[3], 2)]]
        m_l += [[_r(s0, 3), _r(-f[2], 3)], [_r(s0 + L, 3), _r(f[5], 3)]]
    perfiles = []
    for nombre in cb.PERFILES:
        rr = cb.analizar(cb.EntradaCimbra(**{**e.__dict__, "perfil": nombre}))
        perfiles.append([nombre, cb.PERFILES[nombre][3], _r(rr.sigma_max, 1), _r(rr.utilizacion * 100, 1)])
    return {"hp": _r(r.hp, 3), "q": _r(r.q, 2), "n_max": _r(r.n_max, 2), "m_max": _r(r.m_max, 3),
            "sigma": _r(r.sigma_max, 1), "util": _r(r.utilizacion * 100, 1),
            "nudos": [[_r(x, 4), _r(y, 4)] for x, y in nud],
            "desp": [[_r(u, 7), _r(v, 7)] for u, v in r.desplazamientos[:, :2]],
            "N": n_l, "M": m_l, "perfiles": perfiles}


@_json
def dinamica(d):
    xi = float(d["xi"]) / 100
    if d.get("registro"):
        dt, ag = dn.leer_registro_csv(d["registro"])
        nombre = d.get("nombre_registro", "Registro")
    else:
        dt = 0.0005
        _, ag, _ = dn.registro_sintetico(float(d["dur"]), dt, float(d["frec"]), float(d["ppv"]), int(d["nret"]),
                                         float(d["interv"]))
        nombre = "Ejemplo sintético"
    r = dn.newmark_sdof(ag, dt, float(d["T"]), xi)
    T = np.geomspace(float(d["tmin"]), float(d["tmax"]), int(d.get("npt", 60)))
    T, sd, sv, sa = dn.espectro(ag, dt, T, xi)
    paso = max(1, len(ag) // 1500)
    g = dn.G
    return {"nombre": nombre, "pga": _r(np.max(np.abs(ag)) / g, 4), "umax": _r(np.max(np.abs(r.u)) * 1000, 4),
            "amax": _r(np.max(np.abs(r.a_abs)) / g, 4), "t": _lista(r.t, 4, paso), "ag": _lista(ag / g, 5, paso),
            "u": _lista(r.u * 1000, 5, paso), "a": _lista(r.a_abs / g, 5, paso), "T": _lista(T, 4),
            "sd": _lista(sd * 1000, 4), "sv": _lista(sv * 1000, 3), "sa": _lista(sa / g, 4)}


@_json
def costos(d):
    cat = {e["nombre"]: co.Equipo(**e) for e in d["equipos"]}
    tareas = []
    for t in d["tareas"]:
        faltan = [n for n, _ in t.get("equipos", []) if n not in cat]
        if faltan:
            raise ValueError(f"Tarea «{t['nombre']}»: el equipo «{faltan[0]}» no existe")
        tareas.append(co.Tarea(t["nombre"], float(t["horas"]), int(t["trabajadores"]), float(t["salario_h"]),
                               [(n, float(h)) for n, h in t.get("equipos", [])],
                               [(n, float(c), float(p)) for n, c, p in t.get("materiales", [])]))
    r = co.resumen(tareas, cat, float(d["avance"]), float(d["volumen"]), float(d["toneladas"]))
    return {"filas": [[n, {k: _r(v, 2) for k, v in c.items()}] for n, c in r["filas"]], "total": _r(r["total"], 2),
            "por_m": _r(r["por_m"], 2), "por_m3": _r(r["por_m3"], 3), "por_t": _r(r["por_t"], 3),
            "horario": {n: {k: _r(v, 3) for k, v in e.costo_horario().items()} for n, e in cat.items()}}


@_json
def costos_ejemplo(d):
    tareas, cat = co.ejemplo(float(d.get("kg", 30)), int(d.get("detonadores", 40)), float(d.get("metros", 70)))
    return {"equipos": [e.__dict__ for e in cat.values()],
            "tareas": [{"nombre": t.nombre, "horas": t.horas, "trabajadores": t.trabajadores, "salario_h": t.salario_h,
                        "equipos": [list(x) for x in t.equipos], "materiales": [list(x) for x in t.materiales]}
                       for t in tareas]}


@_json
def danio(d):
    """Mapa de esfuerzos (Kirsch) de la malla elegida del frente."""
    o, datos = _ESTADO["opciones"][d["clave"]]
    pr, pozos = _proyecto_frente(o, datos)
    sc = float(d["ucs"]) * float(d.get("fd", 1))
    st = float(d["t"])
    tal, grupos = [], {}
    for t, p in zip(o.plano.taladros, pozos):
        e = pr.explosivo(p.explosivo_id)
        if e is None:
            continue
        vod = e.vod_ms or float(d.get("vod", 4500))
        dc = e.diametro_de_carga(p.diametro_mm)
        pb = zd.presion_taladro_mpa(e.densidad_gcc, vod, dc, p.diametro_mm)
        tal.append(zd.TaladroPresion(t.x, t.y, p.diametro_mm / 2000, pb))
        grupos.setdefault((e.nombre, p.diametro_mm), pb)
    if not tal:
        raise ValueError("La malla no tiene taladros cargados")
    cont = np.asarray(o.plano.contorno, float)
    x0, x1 = cont[:, 0].min() - 0.3, cont[:, 0].max() + 0.3
    y0, y1 = cont[:, 1].min() - 0.3, cont[:, 1].max() + 0.3
    n = int(d.get("res", 110))
    paso = max(x1 - x0, y1 - y0) / n
    xs = np.arange(x0, x1 + paso, paso)
    ys = np.arange(y0, y1 + paso, paso)
    X, Y, S = zd.mapa_esfuerzos(tal, xs, ys, "max" if d.get("modo", "max") == "max" else "suma")
    dentro = mt._dentro(cont, X, Y)
    cob = float(np.mean(S[dentro] >= st)) * 100 if dentro.any() else 0
    radios = [[nm, _r(dh, 1), _r(pb, 0), _r(zd.radio_critico(dh / 2000, pb, sc) * 100, 2),
               _r(zd.radio_critico(dh / 2000, pb, st), 3)] for (nm, dh), pb in grupos.items()]
    L = np.log10(np.clip(S, 1e-3, None))
    return {"x0": _r(x0, 3), "y0": _r(y0, 3), "paso": _r(paso, 5), "nx": len(xs), "ny": len(ys),
            "log_s": [_r(v, 3) for v in L.ravel()], "dentro": [int(v) for v in dentro.ravel()],
            "cobertura": _r(cob, 1), "radios": radios, "sc": sc, "st": st,
            "taladros": [[_r(t.x, 3), _r(t.y, 3)] for t in tal]}
